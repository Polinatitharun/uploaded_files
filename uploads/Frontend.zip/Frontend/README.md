# Project Title

IDP-Interated Learning Platform




## Project Description
Provides a platform where users can learn about programming concepts from the root level.
Focuses on building strong foundation on java and python at the same time.
All the content used in the application is AI generated and reviewed by a SME and then pubised for the users 


### Prerequisites

Before you begin, ensure you have the following installed on your machine:
[Python](https://www.python.org/)(Python 3.10.10)
[Node.js](https://nodejs.org/) (version 14 or higher)
[npm](https://www.npmjs.com/) (comes with Node.js)
[MongoDB](https://www.mongodb.com/) (local installation or use a cloud service)

## Installation and Running the Project
Pre requisites :- must have Python,Node Installed and a Chrome Browser .
Frontend--  cmd->npm install (to install required dependencies)
            cmd-> npm run dev (to run the React application)
Backend--   cmd->npm install (to install required dependencies)
            cmd->npm start (to run the API uses nodemon)
LLM--       cmd->pip install requirements.txt
            cmd->python -m run fastapi olstructered.py



## Tech Stack

**Client:** React.js
**Server:** Node.js, Express.js,FastAPI
**Database:** MongoDB


### Clone the Project

To get started, clone the repository to your local machine:
```bash
git clone <repository-link>
```
### Navigate to the Project Directory

Change into the project directory:

#### Install Frontend Dependencies

Navigate to the frontend directory and install the necessary dependencies:
```bash
cd frontend
npm install
```
#### Install Backend Dependencies

Navigate to the backend directory and install the necessary dependencies:
```bash
cd ../backend
npm install
```
#### Install LLM Dependencies

Navigate to the backend directory and install the necessary dependencies:
```bash
cd ../llmapi
pip install requirements.txt
```
#### Run Frontend Backend and LLM Separately

To start the application, you will need to run the frontend and backend servers in separate terminal windows.

#### Start the Frontend

In one terminal window, navigate to the frontend directory and run:
```bash
cd frontend
npm run dev
```
#### Start the Backend

In another terminal window, navigate to the backend directory and run:
```bash
cd backend
npm start 
```
#### Start the LLM

In another terminal window, navigate to the backend directory and run:
```bash
cd llmapi
Python -m run fastapi olstructered.py

```


#### Access the Application

Once all servers are running, you can access the application by navigating to [http://localhost:5012](http://10.59.52.98:5000) (http://localhost:8000) in your web browser (or the port specified in your frontend configuration).

#### Additional Notes

Ensure that your MongoDB server is running before starting the backend.

For production deployment, consider using environment variables to manage sensitive information and configurations.

Refer to the documentation for each technology used in the stack for more detailed setup and configuration options.