set http_proxy=http://proxy.tcs.com:8080
set https_proxy=http://proxy.tcs.com:8080
npm i
PAUSE