import ParticleBackground from "./ParticleBackground";
import About from "./About";
import Feature from "./Feature";
import Hello from "../assets/Hello.gif";
import "../Styles/Home.css";
import AOS from "aos";
// import "animate.css/animate.compat.css"
import "aos/dist/aos.css";
import { useEffect } from "react";
import Aos from "aos";
import { Link } from 'react-router-dom';
import Navbar from './common/NavBar/Navbar';

//  const Home = () => {
function Home({userId,username,onLogout}) {
  useEffect(() => {
    Aos.init({ duration: 2 });
  }, []);
  return (
    <>
    <ParticleBackground />
    {/* <Navbar onLogout={onLogout} /> */}
      <div className="homepage">
        <div className="subhome">
          

          <div className="animated">
            <p className="heading1 fadeinup" data-aos="fade-up">
              Hello <img src={Hello} alt="Hello" width="25px" /> Welcome to
            </p>
            <h1 className="home_heading" data-aos="fade-up">
            Integrated Learning Platform
            </h1>
            <h3 className="home_subheading" data-aos="fade-up">
              Navigate Your Tech Journey: Learn, Test, and Thrive!
            </h3>
            <Link to="/learning">
            <button
              className="home-button"
              data-aos="fade-up"

            >
              Go to Learning path
            </button></Link>
            <Link to="/questions/all">
            <button
              className="home-button"
              data-aos="fade-up"
            >
             Take Coding Challenge
            </button></Link>
            {/* <Link to="/mcq">
            <button
              className="home-button"
              data-aos="fade-up"

            >
              Practice MCQ's
            </button></Link> */}
            {/* <Link to="http://172.20.201.133:3999/">
            <button
              className="home-button"
              data-aos="fade-up"

            >
              LearnX
            </button></Link> */}
          </div>
        </div>
      </div>
        <About />
        <Feature />
      
    </>
  );
}

export default Home;
