import React, { useRef, useState } from "react";
import MarkdownViewer from "./MarkdownViewer";
import "./styles.css";
import {
  FaBold,
  FaItalic,
  FaLink,
  IoListOutline,
  MdFormatListNumbered,
  RiListCheck3,
  MdFormatQuote,
  IoMdCode,
  AiOutlineClear,
} from "./utils";

export default function MarkdownEditor({ value, onChange, initialValue = "" }) {
  const isControlled = typeof value === "string";

  const [internalMd, setInternalMd] = useState(
    isControlled ? value ?? "" : initialValue ?? ""
  );

  const md = isControlled ? value ?? "" : internalMd;

  const [previewOn, setPreviewOn] = useState(true);
  const taRef = useRef(null);

  const updateMarkdown = (next) => {
    if (isControlled) {
      onChange?.(next);
    } else {
      setInternalMd(next);
      onChange?.(next);
    }
  };

  function commit(next) {
    updateMarkdown(next);
  }

  const wrapSelection = (before, after = before, placeholder = "text") => {
    const ta = taRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const selected = md.slice(start, end) || placeholder;

    const next = md.slice(0, start) + before + selected + after + md.slice(end);
    commit(next);

    // restore selection
    const cursorStart = start + before.length;
    const cursorEnd = cursorStart + selected.length;
    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(cursorStart, cursorEnd);
    });
  };

  const prefixLines = (prefix) => {
    const ta = taRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;

    const lineStart = md.lastIndexOf("\n", start - 1) + 1;
    const lineEndIdx = md.indexOf("\n", end);
    const lineEnd = lineEndIdx === -1 ? md.length : lineEndIdx;

    const block = md.slice(lineStart, lineEnd);
    const lines = block.split("\n");
    const updated = lines
      .map((l) => (l.startsWith(prefix) ? l : prefix + l))
      .join("\n");

    const next = md.slice(0, lineStart) + updated + md.slice(lineEnd);
    commit(next);

    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(lineStart, lineStart + updated.length);
    });
  };

  const applyOrderedList = () => {
    const ta = taRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;

    const lineStart = md.lastIndexOf("\n", start - 1) + 1;
    const lineEndIdx = md.indexOf("\n", end);
    const lineEnd = lineEndIdx === -1 ? md.length : lineEndIdx;

    const block = md.slice(lineStart, lineEnd);
    const lines = block.split("\n").filter((l) => l.length > 0);
    const updated = lines
      .map((l, i) => (/^\s*\d+\.\s+/.test(l) ? l : `${i + 1}. ${l}`))
      .join("\n");

    const next = md.slice(0, lineStart) + updated + md.slice(lineEnd);
    commit(next);

    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(lineStart, lineStart + updated.length);
    });
  };

  const insertHr = () => {
    const ta = taRef.current;
    if (!ta) return;
    const pos = ta.selectionStart;
    const insert = (md.endsWith("\n") ? "" : "\n") + "\n---\n\n";
    const next = md.slice(0, pos) + insert + md.slice(pos);
    commit(next);
    requestAnimationFrame(() => {
      ta.focus();
      const nextPos = pos + insert.length;
      ta.setSelectionRange(nextPos, nextPos);
    });
  };

  const insertLink = () => {
    const url = window.prompt("Enter URL", "https://");
    if (!url) return;
    wrapSelection("[", `](${url})`, "link text");
  };

  const onKeyDown = (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "b") {
      e.preventDefault();
      wrapSelection("**", "**", "bold");
    }
    if (mod && e.key.toLowerCase() === "i") {
      e.preventDefault();
      wrapSelection("_", "_", "italic");
    }
    if (mod && e.key.toLowerCase() === "k") {
      e.preventDefault();
      insertLink();
    }
    if (mod && e.key.toLowerCase() === "p") {
      e.preventDefault();
      setPreviewOn((v) => !v);
    }
  };

  return (
    <div className="container editor">
      {/* Toolbar */}
      <div className="toolbar" role="toolbar" aria-label="Markdown toolbar">
        <button  className="btn" onClick={() => wrapSelection("**", "**", "bold")} title="Bold">
          <FaBold />
        </button>
        <button className="btn" onClick={() => wrapSelection("_", "_", "italic")} title="Italic">
          <FaItalic />
        </button>
        {/* <button  className="btn" onClick={() => wrapSelection("`", "`", "code")} title="Inline code">
          `code`
        </button> */}
        <button
        className="btn"
          onClick={() => wrapSelection("\n```lang\n", "\n```\n", "code here")}
          title="Code block"
        >
          <IoMdCode />
        </button>

        <button className="btn" onClick={() => prefixLines("- ")} title="Unordered list">
          <IoListOutline />
        </button>
        <button className="btn" onClick={applyOrderedList} title="Ordered list">
          <MdFormatListNumbered />
        </button>
        <button className="btn" onClick={() => prefixLines(" [ ] ")} title="Task list">
          <RiListCheck3 />
        </button>
        <button className="btn" onClick={() => prefixLines("> ")} title="Quote">
          <MdFormatQuote />
        </button>
        <button className="btn hr" onClick={insertHr} title="Horizontal rule">
          HR
        </button>

        <button className="btn" onClick={insertLink} title="Link (Ctrl/Cmd+K)">
          <FaLink />
        </button>

        <button
          className="btn"
          onClick={() => {
            if (window.confirm("Clear editor content?")) commit("");
          }}
          title="Clear"
        >
          <AiOutlineClear />
        </button>
      </div>

      {/* Editor + Preview */}
      <div className="container main">
        <section className="editorPane">
          <div className="paneHeader">Editor</div>
          <textarea
            ref={taRef}
            value={md}
            onChange={(e) => updateMarkdown(e.target.value)}
            onKeyDown={onKeyDown}
            spellCheck={false}
            className="container "
            placeholder="Write Markdown here…"
          />
        </section>

        <section className={`previewPane ${previewOn ? "" : "hide"}`}>
          <div className="paneHeader">Preview</div>
          <div className="preview prose">
            <MarkdownViewer content={md} />
          </div>
        </section>
      </div>
    </div>
  );
}