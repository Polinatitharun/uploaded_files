import { FaBold } from "react-icons/fa";
import { FaItalic } from "react-icons/fa";
import { FaStrikethrough } from "react-icons/fa";
import { IoListOutline } from "react-icons/io5";
import { MdFormatListNumbered } from "react-icons/md";
import { RiListCheck3 } from "react-icons/ri";
import { MdFormatQuote } from "react-icons/md";
import { IoMdCode } from "react-icons/io";
import { FaLink } from "react-icons/fa6";
import { AiOutlineClear } from "react-icons/ai";
import { FaHeading } from "react-icons/fa";
import { VscPreview } from "react-icons/vsc";

export{
    FaBold,
    FaItalic,
    FaStrikethrough,
    FaLink,
    IoListOutline,
    MdFormatListNumbered,
    RiListCheck3,
    MdFormatQuote,
    IoMdCode,
    AiOutlineClear,
    FaHeading,
    VscPreview,
}