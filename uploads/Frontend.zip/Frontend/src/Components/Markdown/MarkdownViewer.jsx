import { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import rehypeHighlight from 'rehype-highlight';

import './styles.css';

const MarkdownViewer = ({
  src,
  content,
  className,
  allowHtml = false, 
}) => {
  const [md, setMd] = useState(content ?? '');
  const [error, setError] = useState('');

  useEffect(() => {
    if (typeof content === 'string') {
      setMd(content);
      setError('');
    }
  }, [content]);

  useEffect(() => {
    if (content || !src) return;

    const ac = new AbortController();
    (async () => {
      try {
        setError('');
        const r = await fetch(src, { signal: ac.signal });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const text = await r.text();
        setMd(text);
      } catch (e) {
        if (e.name === 'AbortError') return;
        setError(`Could not load: ${src} (${e.message})`);
      }
    })();

    return () => ac.abort();
  }, [src, content]);

  if (error) {
    return (
      <div className={className} style={{ color: 'crimson' }}>
        {error}
      </div>
    );
  }

  const hasSomething = typeof md === 'string' && md.length > 0;
  if (!hasSomething && !src) {
    return <div className={className} />;
  }

  return (
    <div className='container viewer'>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[
          rehypeHighlight,
          ...(allowHtml ? [rehypeRaw] : []),
        ]}
        components={{
          a: ({ node, ...props }) => (
            <a target="_blank" rel="noopener noreferrer" {...props} />
          ),
          code({ inline, className, children, ...props }) {
            return (
              <code
                className={className}
                style={{
                  background: inline ? '#f6f8fa' : undefined,
                  padding: inline ? '0.15rem 0.35rem' : undefined,
                  borderRadius: inline ? 4 : undefined,
                }}
                {...props}
              >
                {children}
              </code>
            );
          },
        }}
      >
        {md}
      </ReactMarkdown>
    </div>
  );
};

export default MarkdownViewer;