import React from 'react';

const TerminalCard = ({ language, command }) => {
  return (
    <div className="wrap">
      <div className="terminal">
        <hgroup className="head">
          <p className="title">
            <svg width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M7 15L10 12L7 9M13 15H17" />
            </svg>
            Let's Learn
          </p>
        </hgroup>
        
        <div className="body">
          <pre className="pre">
            <code>- </code>
            <code>{language}: </code>
            <code className="cmd">{command}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};

export default TerminalCard;
