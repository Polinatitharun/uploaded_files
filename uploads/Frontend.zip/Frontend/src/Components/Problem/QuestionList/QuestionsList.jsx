import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./QuestionList.css";
import { TiArrowBack } from "react-icons/ti";
import { getQuestionsWithStatusActive } from "../Service/service";
import {
  getSolvedLanguages,
  LanguageIcon,
  languageLabel,
} from "./LanguageIcon";
import { FaJava } from "react-icons/fa";
import { RiJavascriptFill } from "react-icons/ri";
import { BiLogoTypescript } from "react-icons/bi";
import { FaPython } from "react-icons/fa";
import Navbar from "../../common/NavBar/Navbar";

const QuestionsList = ({ onLogout }) => {
  const location = useLocation();
  const didAutoSwitchRef = useRef(false);

  const [questions, setQuestions] = useState([]);
  const [selectedType, setSelectedType] = useState(
    location.state?.mainTopic || ""
  );

  const [selectedSubTopic, setSelectedSubTopic] = useState("");
  const [completionStatus, setCompletionStatus] = useState({});
  const [statusFilter, setStatusFilter] = useState("unsolved");
  const [difficultyFilter, setDifficultyFilter] = useState("all");
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState(false);
  const [error, setError] = useState("");
  const ITEMS_PER_PAGE = 5;
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedType, selectedSubTopic, statusFilter, difficultyFilter, searchTerm]);

  const normalizeDifficulty = (value) => {
    if (!value) return "unknown";
    const v = String(value).trim().toLowerCase();
    if (["easy", "medium", "hard"].includes(v)) return v;
    return v || "unknown";
  };

  const labelizeDifficulty = (value) => {
    const v = normalizeDifficulty(value);
    if (v === "unknown") return "Unknown";
    return v.charAt(0).toUpperCase() + v.slice(1);
  };

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedType, selectedSubTopic, statusFilter, difficultyFilter]);

  useEffect(() => {
    let isActive = true;
    const ac = new AbortController();

    (async () => {
      try {
        setLoadingQuestions(true);
        setError("");

        const payload = await getQuestionsWithStatusActive({ signal: ac.signal });

        if (!isActive) return;

        const rawQuestions = Array.isArray(payload?.questions)
          ? payload.questions
          : [];

        setQuestions(rawQuestions);

        const statusMap = {};
        for (const q of rawQuestions) {
          if (!q || !q.id) continue;
          statusMap[q.id] = !!q?.status?.isSolved;
        }

        setLoadingStatus(true);
        setCompletionStatus(statusMap);
      } catch (err) {
        if (!isActive) return;

        if (err?.name === "CanceledError" || err?.code === "ERR_CANCELED") {
          return;
        }

        console.log("Error occurred in fetching questions payload.", err);
        setError(
          err?.response?.data?.message ||
          "Failed to load questions. Please try again."
        );
      } finally {
        if (isActive) {
          setLoadingQuestions(false);
          setTimeout(() => {
            if (isActive) setLoadingStatus(false);
          }, 0);
        }
      }
    })();

    return () => {
      isActive = false;
      ac.abort();
    };
  }, []);

  useEffect(() => {
    if (didAutoSwitchRef.current) return;
    if (!questions.length) return;

    const unsolvedCount = questions.reduce((acc, q) => {
      return acc + (completionStatus[q.id] ? 0 : 1);
    }, 0);
    const solvedCount = questions.length - unsolvedCount;

    if (
      questions.length > 0 &&
      unsolvedCount === 0 &&
      solvedCount > 0 &&
      statusFilter === "unsolved"
    ) {
      setStatusFilter("solved");
      didAutoSwitchRef.current = true;
    }
  }, [questions, completionStatus, statusFilter]);

  useEffect(() => {
    if (!questions.length) return;
    const lState = location.state;
    if (!lState?.selectedTopic) return;
    setSelectedType(lState.selectedTopic);
    setSelectedSubTopic(lState?.selectedSubTopic || "");
  }, [location.state, questions]);

  const questionTypes = useMemo(() => {
    if (!questions?.length) return [];
    return Array.from(new Set(questions.map((p) => p.mainTopicName)));
  }, [questions]);

  const subTopics = useMemo(() => {
    if (!selectedType) return [];
    const subs = questions
      .filter((q) => q.mainTopicName === selectedType)
      .map((q) => q.subTopicTitle);
    return Array.from(new Set(subs));
  }, [questions, selectedType]);

  const difficulties = useMemo(() => {
    if (!questions?.length) return [];
    const set = new Set(
      questions.map((q) => normalizeDifficulty(q.difficulty || "unknown"))
    );
    const order = ["easy", "medium", "hard", "unknown"];
    return order.filter((d) => set.has(d));
  }, [questions]);

  const filteredByTopic = useMemo(() => {
    if (!questions.length) return [];
    if (!selectedType) return questions;
    return questions.filter((q) => {
      const matchMain = q.mainTopicName === selectedType;
      const matchSub = selectedSubTopic
        ? q.subTopicTitle === selectedSubTopic
        : true;
      return matchMain && matchSub;
    });
  }, [questions, selectedType, selectedSubTopic]);

  const filteredByTopicAndDifficulty = useMemo(() => {
    if (difficultyFilter === "all") return filteredByTopic;
    return filteredByTopic.filter(
      (q) => normalizeDifficulty(q.difficulty) === difficultyFilter
    );
  }, [filteredByTopic, difficultyFilter]);

  const filteredBySearch = useMemo(() => {
    if (!searchTerm.trim()) return filteredByTopicAndDifficulty;

    const term = searchTerm.toLowerCase();

    return filteredByTopicAndDifficulty.filter((q) =>
      `${q.title}`
        .toLowerCase()
        .includes(term)
    );
  }, [filteredByTopicAndDifficulty, searchTerm]);

  const filteredQuestions = useMemo(() => {
    if (!filteredBySearch.length) return [];
    if (statusFilter === "all") return filteredByTopicAndDifficulty.sort((a, b) => a.id - b.id);
    if (statusFilter === "solved") {
      return filteredByTopicAndDifficulty.filter(
        (q) => !!completionStatus[q.id]
      ).sort((a, b) => a.id - b.id);
    }
    return filteredBySearch.filter((q) => !completionStatus[q.id]).sort((a, b) => a.id - b.id);
  }, [filteredBySearch, completionStatus, statusFilter]);

  const counts = useMemo(() => {
    const inScope = filteredBySearch;
    const solved = inScope.filter((q) => !!completionStatus[q.id]).length;
    const unsolved = inScope.length - solved;
    return { total: inScope.length, solved, unsolved };
  }, [filteredBySearch, completionStatus]);

  const handleTopicChange = (e) => {
    const selected = e.target.value;
    setSelectedType(selected);
    setSelectedSubTopic("");
  };

  const handleSubTopicChange = (e) => {
    setSelectedSubTopic(e.target.value);
  };

  const handleStatusFilterChange = (e) => {
    setStatusFilter(e.target.value);
  };

  const handleDifficultyFilterChange = (e) => {
    setDifficultyFilter(e.target.value);
  };

  const totalPages = Math.ceil(filteredQuestions.length / ITEMS_PER_PAGE);

  const paginatedQuestions = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredQuestions.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredQuestions, currentPage]);

  const isLoading = loadingQuestions || loadingStatus;

  return (
    <div>
      <Navbar onLogout={onLogout} />

      <div className="list-top">
        <Link to="/">
          <button className="back-button">
            <TiArrowBack size={24} />
            <span>Back</span>
          </button>
        </Link>
        <h2 className="list-header">Scenario Based Questions</h2>
      </div>



      <div className="questions-container">
        <div className="question-header sticky-header">
          {/* Filters */}
          <div className="filter-controls">
            {/* Topic Filter */}
            <select
              className="dropdown-btn"
              value={selectedType}
              onChange={handleTopicChange}
              disabled={loadingQuestions}
              aria-label="Filter by topic"
              title="Filter by topic"
            >
              <option value="">Select Topic</option>
              {questionTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>

            {/* Subtopic Filter */}
            {subTopics.length > 0 && (
              <select
                className="dropdown-btn"
                value={selectedSubTopic}
                onChange={handleSubTopicChange}
                disabled={loadingQuestions}
                aria-label="Filter by subtopic"
                title="Filter by subtopic"
              >
                <option value="">Select Subtopic</option>
                {subTopics.map((sub) => (
                  <option key={sub} value={sub}>
                    {sub}
                  </option>
                ))}
              </select>
            )}

            {/* Difficulty Filter */}
            <select
              className="dropdown-btn"
              value={difficultyFilter}
              onChange={handleDifficultyFilterChange}
              disabled={loadingQuestions}
              aria-label="Filter by difficulty"
              title="Filter by difficulty"
            >
              <option value="all">All Difficulty</option>
              {difficulties.map((diff) => (
                <option key={diff} value={diff}>
                  {labelizeDifficulty(diff)}
                </option>
              ))}
            </select>

            {/* Status Filter */}
            <select
              className="dropdown-btn"
              value={statusFilter}
              onChange={handleStatusFilterChange}
              disabled={loadingQuestions}
              aria-label="Filter by status"
              title="Filter by status"
            >
              <option value="unsolved">Not Solved</option>
              <option value="solved">Solved</option>
              <option value="all">All</option>
            </select>

            <input
              type="text"
              className="search-input"
              placeholder="Search questions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search questions"
            />
          </div>

          <div className="counts-row">
            Total: {counts.total} | Unsolved: {counts.unsolved} | Solved:{" "}
            {counts.solved}
          </div>
        </div>

        {error && <p className="error-text">{error}</p>}
        {isLoading && <p className="loading-text">Loading...</p>}

        <div className="question-list">
          {!isLoading &&
            paginatedQuestions?.map((question) => {
              const isDone = !!completionStatus[question?.id];
              const diffKey = normalizeDifficulty(question?.difficulty);
              return (
                <div key={question.id} className="question-row">
                  <div className="question-info">
                    <small className="question-subinfo">
                      <small className="question-subinfo">
                        <span className="problem-id">#{question?.id}</span>
                        <span className="question-title">
                          {question?.title}
                        </span>

                        {/* Difficulty */}
                        <span
                          className={`difficulty-badge difficulty--${diffKey}`}
                          title={`Difficulty: ${labelizeDifficulty(diffKey)}`}
                        >
                          {labelizeDifficulty(diffKey)}
                        </span>

                        {/* Language Icons Tag */}
                        {(() => {
                          const langKeys = getSolvedLanguages(
                            question?.solvedLanguageList
                          );
                          if (!langKeys.length) return null;
                          return (
                            <span
                              className="lang-icons lang-icons--md" /* or --sm / --lg */
                            >
                              {/* Optional label: <span className="lang-icons__label">Solved in</span> */}
                              {langKeys.map((key) => (
                                <span
                                  key={key}
                                  className="lang-icon-wrapper"
                                  data-tooltip={languageLabel(
                                    key
                                  )} /* tooltip text */
                                  role="img"
                                  aria-label={languageLabel(
                                    key
                                  )} /* screen readers */
                                  tabIndex={0} /* focusable for tooltip */
                                >
                                  <LanguageIcon langKey={key} size={16} />
                                </span>
                              ))}
                            </span>
                          );
                        })()}
                      </small>
                    </small>
                    <small className="question-subinfo">
                      <span>
                        {question?.mainTopicName} → {question?.subTopicTitle}
                      </span>
                    </small>
                  </div>
                  <div className="button-progress-wrapper">
                    <Link
                      to={`/questions/${question.id}/solve`}
                      state={{
                        selectedTopic: selectedType,
                        selectedSubTopic: selectedSubTopic,
                      }}
                    >
                      <button
                        className={`solve-now ${isDone ? "solve-now--solved" : "solve-now--unsolved"
                          }`}
                        aria-label={
                          isDone ? "Solved - Solve Again" : "Solve Now"
                        }
                        title={isDone ? "Solved - Solve Again" : "Solve Now"}
                      >
                        {isDone ? "Solve Now" : "Solve Now"}
                      </button>
                    </Link>
                  </div>
                </div>
              );
            })}

          {!isLoading && filteredQuestions.length === 0 && (
            <p className="no-questions">No questions available.</p>
          )}
        </div>
        {!isLoading && totalPages > 0 && (
          <div className="pagination">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
            >
              Prev
            </button>

            <span className="page-info">
              Page {currentPage} of {totalPages}
            </span>

            <button
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage((p) => p + 1)}
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuestionsList;
