// Icon imports
import { FaJava } from "react-icons/fa";
import { RiJavascriptFill } from "react-icons/ri";
import { BiLogoTypescript } from "react-icons/bi";
import { FaPython } from "react-icons/fa";
import './QuestionList.css'

import { MdCode } from "react-icons/md"; // fallback

export const LANGUAGE_ICON_MAP = {
  java: { Icon: FaJava, label: "Java" },
  javascript: { Icon: RiJavascriptFill, label: "JavaScript" },
  typescript: { Icon: BiLogoTypescript, label: "TypeScript" },
  python: { Icon: FaPython, label: "Python" },
};

// Normalize language key labels (fallback)
export const languageLabel = (key) => {
  const known = LANGUAGE_ICON_MAP[key]?.label;
  if (known) return known;
  // Fallback: Title Case
  return key ? key.charAt(0).toUpperCase() + key.slice(1) : "Unknown";
};

// Extract ordered list of solved languages
export const getSolvedLanguages = (solvedLanguageList = {}) => {
  const preferredOrder = ["java", "javascript", "typescript", "python"];
  const entries = Object.entries(solvedLanguageList || {}).filter(
    ([, solved]) => !!solved
  );

  entries.sort((a, b) => {
    const ia = preferredOrder.indexOf(a[0]);
    const ib = preferredOrder.indexOf(b[0]);
    if (ia !== -1 && ib !== -1) return ia - ib;
    if (ia !== -1) return -1;
    if (ib !== -1) return 1;
    return a[0].localeCompare(b[0]);
  });

  return entries.map(([k]) => k);
};

// A tiny presentational component for a single language icon
export const LanguageIcon = ({ langKey }) => {
  const mapping = LANGUAGE_ICON_MAP[langKey];
  const Label = languageLabel(langKey);
  const IconComp = mapping?.Icon || MdCode; // fallback icon
  const className = `lang-icon lang-${(mapping?.label || langKey || "unknown")
    .toLowerCase()
    .replace(/\s+/g, "-")}`;

  return (
    <span className="lang-icon-wrapper" title={Label} aria-label={Label}>
      <IconComp className={className}  />
    </span>
  );
};