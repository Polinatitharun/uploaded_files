import axios from "axios";
import { backend_service_url } from "../../../[constants]/urls";

export const fetchAllQuestionsStatus = async (questionList) => {
  const statusMap = {};
  for (const question of questionList) {
    try {
      const response = await axios.get(
        `${backend_service_url}/problems/all/with-status`
      );
      const isCompleted =
        response.data.length > 0 &&
        response.data.every((sub) => sub.isCorrect === true);
      statusMap[question.id] = isCompleted;
    } catch (err) {
      console.error(
        `Error checking completion for question ${question.id}`,
        err
      );
      statusMap[question.id] = false;
    }
  }
  return statusMap;
};

export const fetchAllQuestions = async () => {
  try {
    const response = await axios.get(
      `${backend_service_url}/user/problem-submissions/all`
    );

    const data = response.data;
    const allProblems = [];

    data.forEach((mainTopic) => {
      mainTopic.subTopics?.forEach((subTopic) => {
        subTopic.content?.problems?.forEach((problem) => {
          allProblems.push({
            id: problem.id,
            title: problem.title,
            mainTopicName: mainTopic.mainTopicName,
            subTopicTitle: subTopic.title,
          });
        });
      });
    });
    return allProblems;
  } catch (error) {
    return "Error fetching questions:", error;
  }
};

export async function getQuestionsWithStatusActive(options = {}) {
  const { signal } = options;

  const res = await axios.get(
    `${backend_service_url}/api/v1/problems/active`,
    { signal ,withCredentials:true}
  );

  return res.data;
}
