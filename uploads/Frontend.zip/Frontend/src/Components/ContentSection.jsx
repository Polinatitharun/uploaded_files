import React, { useEffect, useState } from 'react';
import '../Styles/ContentSection.css';
import { Link } from 'react-router-dom';
import { useTopic } from '../context/topicContext';
import { TbBulb } from "react-icons/tb";
import { FaCode } from "react-icons/fa6";

const ContentSection = () => {
    const [activeTab, setActiveTab] = useState("java");
    const { topics, topic, subtopic, setActiveShow, activeshow } = useTopic();
    const [currentTopic, setCurrentTopic] = useState({});
    const [subTopic, setSubTopic] = useState(subtopic);

    const currentTopics = topics.filter((t) => t.topic === topic.topic);

    const updateTopic = (sub) => {
        setSubTopic(sub);
        setActiveShow(true);
    };

    const codingQuestions = [
        {
            id: 200,
            topic: "Strings",
            title: "The Spy Cipher",
            text: "During an international mission, Agent Zaina intercepts a coded message from an enemy base. The message is a long string of characters. According to intel, the message is valid if:\n1. All words are palindromes (case-insensitive).\n2. No digits are allowed.\n3. The message contains at least 3 words.\nHelp Zaina validate the message by writing a program that checks all three conditions.",
            input_desc: "A single line containing the intercepted message.",
            output_desc: "Print 'Message Secure' if all conditions are met, otherwise 'Compromised'.",
            sample_input: "Radar level Civic",
            sample_output: "Message Secure",
            progress: 0,
            testcases: [
                { input: "Kayak noon racecar", expected_output: "Message Secure" },
                { input: "Madam123 noon civic", expected_output: "Compromised" }
            ]
        },
        {
            id: 201,
            topic: "Loops",
            title: "Drone Delivery Log",
            text: "A delivery company tracks drone deliveries over 30 days. Each drone logs the number of packages delivered per day. The company wants to:\n1. Calculate total deliveries.\n2. Identify the day with the highest delivery.\n3. Find average delivery per day (rounded to 2 decimal places).\nWrite a program to help them analyze the data.",
            input_desc: "30 space-separated integers representing daily deliveries.",
            output_desc: "Three lines: total deliveries, day of max delivery (1-based), average deliveries.",
            sample_input: "5 6 7 4 3 9 10 2 5 6 7 8 9 10 6 7 4 3 6 5 9 10 8 6 7 5 6 4 3 2",
            sample_output: "186\n7\n6.20",
            progress: 0,
            testcases: [
                { input: "1 2 3 4 5 6 7 8 9 10 10 10 10 10 10 9 8 7 6 5 4 3 2 1 1 2 3 4 5 6", expected_output: "180\n11\n6.00" }
            ]
        },
        {
            id: 202,
            topic: "Arrays",
            title: "Inventory Stock Balancer",
            text: "A warehouse receives daily shipments of various item quantities over N days. Some days might have zero stock. Write a program to:\n1. Display the maximum stock received.\n2. Display the total stock.\n3. Display the number of days with zero stock.\n4. Print the average daily stock.",
            input_desc: "First line: integer N. Next line: N space-separated integers (stock values).",
            output_desc: "Four lines: max stock, total stock, zero-stock days, average stock (rounded to 2 decimals).",
            sample_input: "5\n0 10 0 20 30",
            sample_output: "30\n60\n2\n12.00",
            progress: 0,
            testcases: [
                { input: "6\n5 0 5 0 5 0", expected_output: "5\n15\n3\n2.50" }
            ]
        },
        {
            id: 203,
            topic: "Data Types",
            title: "Sensor Calibration System",
            text: "A smart city monitors traffic, pollution, and temperature using sensors. Each sensor sends values like: 30 (int), 24.6 (float), or 'OFFLINE' (string). You must build a system that reads a value and detects its data type. Note: Integers have no decimal, floats have a decimal, and any non-number input is considered a string.",
            input_desc: "A single line of input representing a sensor value.",
            output_desc: "Print 'Integer', 'Float', or 'String'.",
            sample_input: "45.6",
            sample_output: "Float",
            progress: 0,
            testcases: [
                { input: "OFFLINE", expected_output: "String" },
                { input: "100", expected_output: "Integer" }
            ]
        },
        {
            id: 204,
            topic: "Functions",
            title: "Smart Toll Booth",
            text: "At an automated toll booth, charges are calculated based on vehicle type and number of axles:\n- Car: ₹100\n- Truck: ₹150 per axle\n- Bus: ₹120 flat + ₹30 per axle\nWrite a function `calculateToll(type, axles)` that returns the toll. Then, process N vehicles and print tolls for each.",
            input_desc: "First line: integer N. Next N lines: vehicle type and axles (separated by space).",
            output_desc: "N lines: toll for each vehicle.",
            sample_input: "3\nCar 4\nTruck 6\nBus 2",
            sample_output: "100\n900\n180",
            progress: 0,
            testcases: [
                { input: "2\nTruck 4\nBus 3", expected_output: "600\n210" }
            ]
        },
        {
            id: 205,
            topic: "OOP",
            title: "Library Management System",
            text: "A library manages books with title, author, and copies. Implement a `Book` class with:\n- Constructor to set values\n- Method `isAvailable()` returns true if copies > 0\n- Method `borrow()` decreases copies by 1 if available\n- Method `display()` shows: 'Title: [title], Author: [author], Copies Left: [copies]'\nInitialize 2 books and simulate borrowing them. Show the final details.",
            input_desc: "Each book has 3 lines: title, author, number of copies (int).",
            output_desc: "Details of both books after borrow operations.",
            sample_input: "Inferno\nDan Brown\n2\n1984\nGeorge Orwell\n1",
            sample_output: "Title: Inferno, Author: Dan Brown, Copies Left: 1\nTitle: 1984, Author: George Orwell, Copies Left: 0",
            progress: 0,
            testcases: [
                {
                    input: "Harry Potter\nJ.K. Rowling\n3\nThe Alchemist\nPaulo Coelho\n2",
                    expected_output: "Title: Harry Potter, Author: J.K. Rowling, Copies Left: 2\nTitle: The Alchemist, Author: Paulo Coelho, Copies Left: 1"
                }
            ]
        },
        {
            id: 206,
            topic: "Type Casting",
            title: "Smart Agriculture System",
            text: "A smart agriculture system collects sensor data (temperature, humidity, pH) in string format from multiple fields. The data may contain corrupt or non-numeric readings due to faulty sensors. You are tasked to:\n1. Convert valid readings to float.\n2. Ignore any corrupt data (e.g., 'N/A', '--').\n3. Compute average temperature and humidity (rounded to 2 decimals).\n4. Print number of valid pH readings.\nThis helps farmers make real-time decisions on irrigation and fertilization.",
            input_desc: "Three space-separated lines for temperature, humidity, and pH readings (string values).",
            output_desc: "Print average temperature, average humidity, and count of valid pH readings.",
            sample_input: "22.5 24.1 N/A 20.0\n55.3 50.1 -- 48.0\n6.5 7.0 error 6.8",
            sample_output: "22.20\n51.13\n3",
            progress: 0,
            testcases: [
                {
                    input: "23.0 N/A 25.5\n60.0 55.5 50.0\n6.2 7.3 invalid",
                    expected_output: "24.25\n55.17\n2"
                }
            ]
        },
        {
            id: 207,
            topic: "Operators",
            title: "Energy Efficiency Analyzer",
            text: "A city plans to reduce energy consumption by analyzing appliance usage. For each appliance, the daily usage in hours and power consumption in watts is recorded. Your task is to:\n1. Calculate daily energy consumed (kWh = hours × watts / 1000).\n2. Apply a bonus if energy < 1.0 kWh (reduce by 10%).\n3. Print total cost assuming ₹5 per kWh (rounded to 2 decimals).\nThis data helps incentivize low-energy appliances.",
            input_desc: "First line: integer N (number of appliances)\nNext N lines: hours and watts (space-separated)",
            output_desc: "Print total energy consumed and total cost.",
            sample_input: "2\n2 100\n4 150",
            sample_output: "0.80\n4.00",
            progress: 0,
            testcases: [
                {
                    input: "3\n1 90\n2 300\n0.5 500",
                    expected_output: "1.60\n8.00"
                }
            ]
        },

        {
            id: 208,
            topic: "Conditional Statements",
            title: "Health Risk Predictor",
            text: "A hospital is creating a simple triage system based on patient vitals. Each patient has:\n- Heart rate\n- Body temperature\n- Oxygen saturation\nBased on these, classify patients:\n- 'Critical' if HR > 120 or Temp > 102 or SpO2 < 90\n- 'Observation' if HR between 100-120 or Temp between 99-102\n- 'Stable' otherwise\nYou must write a program to categorize the patient based on the input values.",
            input_desc: "Three integers: heart rate, temperature (in F), and SpO2.",
            output_desc: "Print one of: 'Critical', 'Observation', or 'Stable'.",
            sample_input: "130 101 91",
            sample_output: "Critical",
            progress: 0,
            testcases: [
                {
                    "input": "110 100 95",
                    "expected_output": "Observation"
                },
                {
                    "input": "85 98 96",
                    "expected_output": "Stable"
                }
            ]
        },
        {
            id: 209,
            topic: "Control Statements",
            title: "Warehouse Robot Navigation",
            text: "In a smart warehouse, robots follow commands (FORWARD, BACKWARD, STOP, SKIP). The robot should:\n1. Move in a loop and execute each command.\n2. Skip movement on SKIP command.\n3. Terminate immediately if STOP is encountered.\nPrint final position of robot (starting at 0, forward = +1, backward = -1).\nUse appropriate control statements.",
            input_desc: "A single line with space-separated commands.",
            output_desc: "Print final position as integer.",
            sample_input: "FORWARD FORWARD SKIP BACKWARD STOP FORWARD",
            sample_output: "1",
            progress: 0,
            testcases: [
                {
                    input: "FORWARD BACKWARD FORWARD SKIP FORWARD",
                    expected_output: "2"
                }
            ]
        },
        {
            id: 210,
            topic: "Data Structures",
            titl: "Online Shopping Tracker",
            text: "An online shopping site records customer purchases. Each entry logs customer name and item. Use a dictionary where:\n- Key = customer name\n- Value = list of items\nYou must:\n1. Add entries for N purchases.\n2. On query, print item list of given customer.\n3. If customer not found, print 'No purchases found'.",
            input_desc: "First line: integer N\nNext N lines: name and item\nLast line: query name",
            output_desc: "Print items purchased by the queried name (comma-separated) or a message.",
            sample_inpu: "4\nAlice Book\nBob Pen\nAlice Bag\nCara Phone\nAlice",
            sample_output: "Book, Bag",
            progress: 0,
            testcases: [
                {
                    input: "3\nDan Mouse\nEve Keyboard\nEve Monitor\nEve",
                    expected_output: "Keyboard, Monitor"
                }
            ]
        }



    ];

    const questioMap = codingQuestions.reduce((acc, curr) => {
        acc[curr.topic] = curr.id;
        return acc;
    }, {});

    useEffect(() => {
        if (topic.length === 0) {
            setCurrentTopic(topics[0]);
        } else {
            setCurrentTopic(currentTopics[0]);
        }
    }, [topics, topic]);


    return (
        <div className="content-container">
            <div className="inner-topic-container">
                {currentTopic && (
                    <div>
                        <h2 id='main-topic'>{currentTopic?.topic}</h2>
                        <p id='general-defination'>{currentTopic?.explanation}</p>
                    </div>
                )}
            </div>

            <div className="tabs">
                <button
                    className={activeTab === "java" ? "tab active" : "tab"}
                    onClick={() => setActiveTab("java")}
                >
                    Java
                </button>
                <button
                    className={activeTab === "python" ? "tab active" : "tab"}
                    onClick={() => setActiveTab("python")}
                >
                    Python
                </button>
            </div>

            {currentTopic && (
                <div className="inner-container">
                    <div className="general-concept">
                        <ul className='sub-list'>
                            {currentTopic?.subtopics?.map((sub, index) => (
                                <li key={index}>
                                    <div onClick={() => updateTopic(sub)} style={{ cursor: "pointer" }}>
                                        <a href="#down">{sub?.name}</a>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {activeshow && (
                        <>
                            <div className="sub-content" id='down'>
                                <h2>{subTopic.name}</h2>
                                <p>{subTopic?.explanation}</p>
                            </div>

                            <div className="content" id='down'>
                                {activeTab === "java" && (
                                    <div>
                                        <h3>{subTopic?.name} in Java</h3>
                                        <p>{subTopic?.explanation}</p>
                                        <pre className='content-code'>{subTopic?.examples?.java}</pre>
                                        <p><b>Note :- </b>{subTopic?.codeDiffrences?.java}</p>
                                    </div>
                                )}

                                {activeTab === "python" && (
                                    <div>
                                        <h3>{subTopic?.name} in Python</h3>
                                        <p>{subTopic?.explanation}</p>
                                        <pre className='content-code'>{subTopic?.examples?.python}</pre>
                                        <p><b>Note :- </b>{subTopic?.codeDiffrences?.python}</p>
                                    </div>
                                )}

                                <div className="btn-container">

                                    <Link to={`/compiler/${questioMap[currentTopic?.topic]}`}>

                                        <button id='codebtn'> <FaCode style={{ marginRight: "10px" }} />Code here</button>
                                    </Link>
                                    {/* <Link to={() => navigate(`/mcq_page/${questioMap[currentTopic?.topic]}`) }>
                                    <button id='codebtn'>Take Quiz</button>
                                </Link> */}
                                    <Link to={`/mcq_page/${currentTopic.topic}`}>
                                        <button id='codebtn'><TbBulb style={{ marginRight: "10px" }} />Take Quiz</button>
                                    </Link>
                                </div>

                            </div>
                        </>
                    )}
                </div>
            )}
        </div>
    );
};

export default ContentSection;
