import React, { useState, useEffect, useRef } from "react";
import "../styles/Compiler.css";
import axios, { all } from "axios";
import Navbar from "./common/NavBar/Navbar";
import { useParams, Link, useNavigate, Navigate, data } from "react-router-dom";
import { Toaster, toast } from "sonner";
import { useLocation } from "react-router-dom";

// Import new components
import FullScreenLoader from "./CompilerComponents/FullScreenLoader";
// import SidebarHelp from "./CompilerComponents/SidebarHelp";
import EditorToolbar from "./CompilerComponents/EditorToolbar";
import EditorContainer from "./CompilerComponents/EditorContainer";
import InputOutputContainer from "./CompilerComponents/InputOutputContainer";
import FeedbackPopup from "./CompilerComponents/FeedbackPopup";
import InitialPopup from "./CompilerComponents/InitialPopup";
import DescriptionSection from "./CompilerComponents/Description";


// Main Compiler Component
const Compiler = ({ onLogout }) => {
  const { questionId } = useParams();
  const navigate = useNavigate();

  const LS_KEYS = {
    // TIMER: `timer_${questionId}`,
    STATE: `compiler_state_${questionId}`,
    // EDITOR: `current_editor_${questionId}`,  // new key for currentEditor
    ALGORITHM: `algorithm_${questionId}`,
    PSEUDOCODE: `pseudocode_${questionId}`,
    CODE: `code_${questionId}`,
    LANGUAGE: `language_${questionId}`,
  };
  const PROGRESS_KEY = `progress_${questionId}`;

  const [timeLeft, setTimeLeft] = useState(0);
  const [fullPassed, setFullPassed] = useState(false);

  // Load state from localStorage or defaults
  const storedAlgorithm = localStorage.getItem(LS_KEYS.ALGORITHM);
  const storedPseudoCode = localStorage.getItem(LS_KEYS.PSEUDOCODE);
  const storedCode = localStorage.getItem(LS_KEYS.CODE);
  const storedLanguage = localStorage.getItem(LS_KEYS.LANGUAGE);

  // State Management
  const [pythonCode, setPythonCode] = useState("");
  const [javaCode, setJavaCode] = useState("");
  const [javaScriptCode, setJavaScriptCode] = useState("");
  const [typeScriptCode, setTypeScriptCode] = useState("");
  const [code, setCode] = useState(
    storedCode || "// Write your code here \n public class Main { \n}"
  );
  const [pseudoCode, setPseudoCode] = useState(
    storedPseudoCode || "// Write pseudo code first"
  );
  const [language, setLanguage] = useState(storedLanguage || "java");
  const [input, setInput] = useState("");
  const [output, setOutput] = useState(null);
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(false);
  const [checkLoading, setCheckLoading] = useState(false);
  const [checkCodeLoading, setCheckCodeLoading] = useState(false);
  const [algorithmLoading, setAlgorithmLoading] = useState(false);
  const [question, setQuestion] = useState(null);
  const [javaCompleted, setJavaCompleted] = useState(false);
  const [pythonCompleted, setPythonCompleted] = useState(false);
  const [javaScriptCompleted, setJavaScriptCompleted] = useState(false);
  const [typeScriptCompleted, setTypeScriptCompleted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showReport, setShowReport] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [algorithm, setAlgorithm] = useState(
    storedAlgorithm || "// Write algorithm first"
  );
  const [algorithmValidated, setAlgorithmValidated] = useState(false);
  const [pseudoValidated, setPseudoValidated] = useState(true);
  // const [timeLeft, setTimeLeft] = useState(3600); // 1 hour in seconds
  const [feedback, setFeedback] = useState(null);
  const storedEditor = useRef("algorithm");

  const [submissionCount, setSubmissioncount] = useState(0);
  // Resizer states
  const [leftWidth, setLeftWidth] = useState(30);
  const [bottomHeight, setBottomHeight] = useState(30);
  const [isResizing, setIsResizing] = useState(null);
  const [javaSavedCode, setJavaSavedCode] = useState(
    "// Write your code here \n public class Main { \n}"
  );
  const [pythonSavedCode, setPythonSavedCode] = useState(
    "# Write your Python Code here \n"
  );
  const [javaScriptSavedCode, setJavaScriptSavedCode] = useState(
    "// Write your JavaScript Code here \n"
  );
  const [typeScriptSavedCode, setTypeScriptSavedCode] = useState(
    "// Write your TypeScript Code here \n"
  );

  const [passedCount, setPassedCount] = useState(0);
  const [showPopup, setShowPopup] = useState(false);

  const closePopup = () => {
    setFeedback(null);
    setShowPopup(false);
    setIsTimerPaused(false);
  };
  const location = useLocation();
  const [currentEditor, setCurrentEditor] = useState(algorithm);

  const [savedWithoutChange, setSavedWithoutChange] = useState(true);
  const [feedbackLoading, setFeedbackLoading] = useState(false);
  const [betterCode, setBetterCode] = useState("");
  const [improvmentActions, setImprovementActions] = useState([]);
  const [isTimerPaused, setIsTimerPaused] = useState(false);

  const [showInitialPopup, setShowInitialPopup] = useState(false);
  const [hasChosenFlow, setHasChosenFlow] = useState(false);

  const timeSpentOnJava = useRef(0);
  const timeSpentOnPython = useRef(0);
  const timeSpentOnJavaScript = useRef(0);
  const timeSpentOnTypeScript = useRef(0);

  // Show the popup whenever this page mounts
  useEffect(() => {
    setShowInitialPopup(true);
  }, []);

  //setting pseudoValidated and Algorithm Validated
  useEffect(() => {
    (async () => {
      // Immediately invoked async function

      //Setting the current Editor from DataBase

      try {
        const problemId = questionId;
        const response = await axios.get(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/algorithm-submissions/problem/${problemId}/is-correct`
        );

        setAlgorithmValidated(response.data);
      } catch (err) {
        setAlgorithmValidated(false);
      }

      try {
        const problemId = questionId;
        const response = await axios.get(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/pseudocode-submissions/problem/${problemId}/is-correct`
        );

        setPseudoValidated(response.data);
      } catch (err) {
        setPseudoValidated(false);
      }

      storedEditor.current = algorithmValidated
        ? pseudoValidated
          ? "code"
          : "pseudocode"
        : "algorithm";

      // setCurrentEditor(storedEditor.current)
      setCurrentEditor(storedEditor.current);

      //Pseudo Code Fetching from DB

      try {
        const problemId = questionId;
        const response = await axios.get(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/pseudocode-submissions/problem/${problemId}`
        );
        // toast.success("Savodes are generated")
        const pseudoContent = response.data.content;
        if (storedEditor.current == "pseudocode") {
          setTimeLeft(Number(response.data.totalSecondSpent));
        }

        if (pseudoContent != "// Write pseudo code first") {
          setPseudoCode(pseudoContent);
        }
      } catch (err) {
        // toast.error("Failed to generate the saved pseudocodes ")
      }

      //Algorithm fetching from DB

      try {
        const problemId = questionId;
        const response = await axios.get(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/algorithm-submissions/problem/${problemId}`
        );
        // toast.success("Savodes are generated")
        const algorithmContent = response.data.content;

        if (storedEditor.current == "algorithm") {
          setTimeLeft(Number(response.data.totalSecondSpent));
        }
        // initialTime=response.data.totalSecondSpent
        if (algorithmContent != "// Write algorithm first") {
          setAlgorithm(algorithmContent);
        }
      } catch (err) {
        // toast.error("Failed to generate the saved Algorithm ")
      }

      //Codes Fetching from DB

      try {
        const problemId = questionId;
        const response = await axios.get(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/problem-submissions/${problemId}`
        );
        // toast.success("Savodes are generated")
        const codesContent = response;
        const allSavedCodes = codesContent.data.savedCodes;
        setJavaSavedCode(allSavedCodes.java);
        setPythonSavedCode(allSavedCodes.python);
        setJavaScriptSavedCode(allSavedCodes.javascript);
        setTypeScriptSavedCode(allSavedCodes.typescript);

        timeSpentOnJava.current = codesContent.data.javaTimeSeconds;
        timeSpentOnPython.current = codesContent.data.pythonTimeSeconds;
        timeSpentOnJavaScript.current = codesContent.data.javascriptTimeSeconds;
        timeSpentOnTypeScript.current = codesContent.data.typescriptTimeSeconds;
        if (language == "java" && storedEditor.current == "code") {
          setCode(codesContent.data.savedCodes.java);
          setTimeLeft(codesContent.data.javaTimeSeconds);
        } else if (language == "python" && storedEditor.current == "code") {
          setCode(codesContent.data.savedCodes.python);
          setTimeLeft(codesContent.data.pythonTimeSeconds);
        } else if (language == "javascript" && storedEditor.current == "code") {
          setCode(codesContent.data.savedCodes.javascript);
          setTimeLeft(codesContent.data.javascriptTimeSeconds);
        } else if (language == "typescript" && storedEditor.current == "code") {
          setCode(codesContent.data.savedCodes.typescript);
          setTimeLeft(codesContent.data.typescriptTimeSeconds);
        }
      } catch (err) {
        // toast.error("Failed to generate the saved codes ")
      }
    })();
  }, [language, algorithmValidated, pseudoValidated, location.key, questionId]);

  const fetchFeedback = async () => {
    setFeedbackLoading(true);
    try {
      const response = await axios.post(
        `${import.meta.env.VITE_AI_URL}/generate-overall-feedback`,
        {
          question: question?.text,
          user_algorithm: algorithm,
          user_pseudocode: pseudoCode,
          user_code: code,
          code_language: language,
        }
      );

      const data = response.data;

      // Structure feedback for point-by-point display
      setFeedback({
        algorithm_feedback: Array.isArray(data.algorithm_feedback)
          ? data.algorithm_feedback
          : [data.algorithm_feedback || "No algorithm feedback provided."],

        pseudocode_feedback: Array.isArray(data.pseudocode_feedback)
          ? data.pseudocode_feedback
          : [data.pseudocode_feedback || "No pseudocode feedback provided."],

        code_feedback: Array.isArray(data.code_feedback)
          ? data.code_feedback
          : [data.code_feedback || "No code feedback provided."],

        better_code: data.better_code || "",

        actions: Array.isArray(data.actions)
          ? data.actions
          : [data.actions || "No improvement actions provided."],
      });
    } catch (err) {
      setFeedback({
        algorithm_feedback: ["⚠️ Error fetching feedback. Please try again."],
        pseudocode_feedback: [],
        code_feedback: [],
        better_code: "",
        actions: [],
      });
    } finally {
      setFeedbackLoading(false);
    }
  };

  const checkAlgorithm = async () => {
    if (!question) {
      setFeedback("Question not loaded yet. Please wait.");
      return;
    }

    if (!algorithm.trim() || algorithm.trim() === "// Write algorithm first") {
      setFeedback("Please write some algorithm first.");
      return;
    }

    setAlgorithmLoading(true);

    try {
      const res = await axios.post(
        `${import.meta.env.VITE_AI_URL}/check-algorithm`,
        {
          question: question.description,
          algorithm: JSON.stringify(algorithm),
        }
      );

      const data = res?.data;

      if (data?.valid) {
        setAlgorithmValidated(true);
        saveCode();
        setCurrentEditor("pseudocode");
        setTimeLeft(0);
        setFeedback("✅ Your algorithm is correct! Now write pseudocode.");
        setShowPopup(true);
      } else {
        // Format structured feedback with class names
        if (data?.issues || data?.points) {
          const issuesList =
            data.issues
              ?.map((i) => `<li class="feedback-issue-item">${i}</li>`)
              .join("") || "";

          const pointsList =
            data.points
              ?.map((p) => `<li class="feedback-point-item">${p}</li>`)
              .join("") || "";

          const formattedFeedback = `
            <div class="feedback-section">
              ${
                issuesList
                  ? `
                <div class="feedback-issues">
                  <p class="feedback-heading">Issues:</p>
                  <ul class="feedback-issues-list">${issuesList}</ul>
                </div>`
                  : ""
              }
              ${
                pointsList
                  ? `
                <div class="feedback-points">
                  <p class="feedback-heading">Suggestions:</p>
                  <ul class="feedback-points-list">${pointsList}</ul>
                </div>`
                  : ""
              }
            </div>
          `;
          setFeedback(formattedFeedback);
        } else {
          setFeedback(
            `❌ ${data?.feedback || "Algorithm validation failed. Try again."}`
          );
        }
        setShowPopup(true);
      }
    } catch (error) {
      setFeedback("⚠️ Error checking algorithm. Please try again.");
    } finally {
      setAlgorithmLoading(false);
    }
  };

  const checkCode = async () => {
    if (!question) {
      setFeedback("Question not loaded yet. Please wait.");
      return;
    }

    if (
      !pseudoCode.trim() ||
      pseudoCode.trim() === "// Write pseudo code first"
    ) {
      setFeedback("Please write some pseudocode first.");
      return;
    }

    setCheckLoading(true);

    try {
      const res = await axios.post(
        `${import.meta.env.VITE_AI_URL}/check-pseudocode`,
        {
          question: question.description,
          pseudocode: JSON.stringify(pseudoCode),
        }
      );

      const data = res?.data;

      if (data?.valid) {
        setPseudoValidated(true);
        saveCode();
        setCurrentEditor("code");
        setTimeLeft(0);
        setFeedback(
          "✅ Your pseudocode is correct! Now you can solve the question."
        );
        setShowPopup(true);
      } else {
        if (data?.issues || data?.points) {
          const issuesList =
            data.issues
              ?.map((i) => `<li class="feedback-issue-item">${i}</li>`)
              .join("") || "";

          const pointsList =
            data.points
              ?.map((p) => `<li class="feedback-point-item">${p}</li>`)
              .join("") || "";

          const formattedFeedback = `
            <div class="feedback-section">
              ${
                issuesList
                  ? `
                <div class="feedback-issues">
                  <p class="feedback-heading">Issues:</p>
                  <ul class="feedback-issues-list">${issuesList}</ul>
                </div>`
                  : ""
              }
              ${
                pointsList
                  ? `
                <div class="feedback-points">
                  <p class="feedback-heading">Suggestions:</p>
                  <ul class="feedback-points-list">${pointsList}</ul>
                </div>`
                  : ""
              }
            </div>
          `;
          setFeedback(formattedFeedback);
        } else {
          setFeedback(
            `❌ ${data?.feedback || "Pseudocode validation failed. Try again."}`
          );
        }
        setShowPopup(true);
      }
    } catch (error) {
      setFeedback("⚠️ Error checking pseudocode. Please try again.");
    } finally {
      setCheckLoading(false);
    }
  };

  const CodeEditor = async () => {
    if (!question) {
      setFeedback("Question not loaded yet. Please wait.");
      return;
    }

    if (!code.trim()) {
      setFeedback("Please write some code first.");
      return;
    }

    setCheckCodeLoading(true);

    try {
      const response = await axios.post(
        `${import.meta.env.VITE_AI_URL}/check-code`,
        {
          question: question.description,
          code: JSON.stringify(code),
          language,
        },
        { validateStatus: () => true } 
      );

      const data = response.data;

      if (!data) {
        setFeedback(
          `<div class='feedback-error'>⚠️ Empty response from server.</div>`
        );
        return;
      }

      // ✅ Build feedback HTML directly
      if (data.valid) {
        setFeedback(`
          <div class="feedback-success">
            ✅ Great job! Your code passed validation.
          </div>
        `);
        setShowPopup(true);
      } else if (data.issues?.length || data.points?.length) {
        // Build list markup
        const issuesList =
          data.issues
            ?.map((issue) => `<li class="feedback-issue-item">${issue}</li>`)
            .join("") || "";

        const pointsList =
          data.points
            ?.map((point) => `<li class="feedback-point-item">${point}</li>`)
            .join("") || "";

        const formatted = `
          <div class="feedback-section">
            ${
              issuesList
                ? `<div class="feedback-issues">
                    <p class="feedback-heading">Issues:</p>
                    <ul class="feedback-issues-list">${issuesList}</ul>
                  </div>`
                : ""
            }
            ${
              pointsList
                ? `<div class="feedback-points">
                    <p class="feedback-heading">Suggestions:</p>
                    <ul class="feedback-points-list">${pointsList}</ul>
                  </div>`
                : ""
            }
          </div>
        `;

        setFeedback(formatted);
        setShowPopup(true);
      } else if (data.feedback) {
        // Fallback for old response style
        setFeedback(`<div class="feedback-old">❌ ${data.feedback}</div>`);
        setShowPopup(true);
      } else {
        setFeedback(
          `<div class="feedback-generic">⚠️ Could not analyze this response. Try again.</div>`
        );
        setShowPopup(true);
      }
    } catch (error) {
      console.error("🔴 Error checking code:", error);
      setFeedback(
        `<div class="feedback-error">⚠️ Error checking code. Please try again.</div>`
      );
    } finally {
      setCheckCodeLoading(false);
    }
  };

  // Persist data to localStorage when states change
  useEffect(() => {
    localStorage.setItem(LS_KEYS.ALGORITHM, algorithm);
  }, [algorithm, questionId]);

  useEffect(() => {
    localStorage.setItem(LS_KEYS.PSEUDOCODE, pseudoCode);
  }, [pseudoCode, questionId]);

  useEffect(() => {
    localStorage.setItem(LS_KEYS.CODE, code);
  }, [code, questionId]);

  useEffect(() => {
    localStorage.setItem(LS_KEYS.LANGUAGE, language);
  }, [language, questionId]);

  useEffect(() => {
    const savedProgress = JSON.parse(localStorage.getItem(PROGRESS_KEY));
    if (savedProgress) {
      setJavaCompleted(savedProgress.java || false);
      setPythonCompleted(savedProgress.python || false);
      setJavaScriptCompleted(savedProgress.javascript || false);
      setTypeScriptCompleted(savedProgress.typescript || false);
    }
  });

  // Now, in your timer effect, update localStorage every second for current language:
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (isTimerPaused) return prev;
        if (language == "java" && javaCompleted) {
          return prev;
        } else if (language == "python" && pythonCompleted) return prev;
        else if (language == "javascript" && javaScriptCompleted) return prev;
        else if (language == "typescript" && typeScriptCompleted) return prev;
        else return prev + 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [
    language,
    javaCompleted,
    pythonCompleted,
    javaScriptCompleted,
    typeScriptCompleted,
    isTimerPaused,
  ]);

  // Pause timer during algorithm validation
  useEffect(() => {
    setIsTimerPaused(algorithmLoading);
  }, [algorithmLoading]);

  // Pause timer during pseudocode validation
  useEffect(() => {
    setIsTimerPaused(checkLoading);
  }, [checkLoading]);

  // Pause timer during code validation
  useEffect(() => {
    setIsTimerPaused(checkCodeLoading);
  }, [checkCodeLoading]);

  // Pause timer during feedback generation
  useEffect(() => {
    setIsTimerPaused(feedbackLoading);
  }, [feedbackLoading]);

  // Pause timer when feedback popup is shown, resume when closed
  useEffect(() => {
    setIsTimerPaused(showPopup);
  }, [showPopup]);

  const timeSpentOnAlgorithm = useState(0);
  const timeSpentOnPseudoCode = useState(0);

  // Format Time Function
  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, "0")}:${mins
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };


  // Mouse event handlers for resizing
  const handleMouseDown = (type) => (e) => {
    setIsResizing(type);
    e.preventDefault();
  };

  const handleMouseMove = (e) => {
    if (!isResizing) return;

    if (isResizing === "horizontal") {
      const newWidth = (e.clientX / window.innerWidth) * 100;
      if (newWidth > 20 && newWidth < 60) {
        setLeftWidth(newWidth);
      }
    } else if (isResizing === "vertical") {
      const rect = document
        .querySelector(".editor-section")
        ?.getBoundingClientRect();
      if (rect) {
        const newHeight = ((e.clientY - rect.top) / rect.height) * 100;
        if (newHeight > 20 && newHeight < 80) {
          setBottomHeight(100 - newHeight);
        }
      }
    }
  };

  const handleMouseUp = () => {
    setIsResizing(null);
  };

  const setcodesnippet = (lang) => {
    if (lang == "java")
      setCode(
        javaSavedCode ||
          "// Write your Java code here\npublic class Main {\n    public static void main(String[] args) {\n        \n    }\n}"
      );
    else if (lang == "python")
      setCode(pythonSavedCode || "# Write your Python code here\n");
    else if (lang == "javascript")
      setCode(javaScriptSavedCode || "// Write your JavaScript code here\n");
    else setCode(typeScriptSavedCode || "// Write your TypeScript code here\n");
  };

  // Resizing Effect
  useEffect(() => {
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      return () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isResizing]);

  // Editor Change Handlers
  // const handleEditorChange1 = (value) => setCode(value || "");
  const handleEditorChange1 = (value) => {
    // setSavedWithoutChange(false)
    if (language === "java") {
      setJavaCode(value || javaSavedCode);
    } else if (language === "python") {
      setPythonCode(value || pythonSavedCode);
    } else if (language === "javascript") {
      setJavaScriptCode(value || javaScriptSavedCode);
    } else if (language === "typescript") {
      setTypeScriptCode(value || typeScriptSavedCode);
    }
    setCode(value || code);
  };
  const handleEditorChange2 = (value) => setPseudoCode(value || "");
  const handleEditorChange3 = (value) => setAlgorithm(value || "");

  const editorRef = useRef(null);
  function handleEditorDidMount(editor, monacoInstance) {
    editorRef.current = editor;

    // Disable Ctrl+C and Ctrl+V
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyC, () => {});
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyV, () => {});

    // Disable right-click context menu
    editor.updateOptions({ contextmenu: false });

    // Disable copy/paste via DOM events
    const domNode = editor.getDomNode();
    if (domNode) {
      domNode.addEventListener("copy", (e) => e.preventDefault());
      domNode.addEventListener("paste", (e) => e.preventDefault());
    }
  }

  // Language Change Handler
  const handleLanguageChange = (e) => {
    const lang = e.target.value;
    setLanguage(lang);
    // setCode(lang === "java" ? "// Write your Java code here\npublic class Main {\n    public static void main(String[] args) {\n        \n    }\n}" : "# Write your Python code here\n");
    setcodesnippet(lang);
    saveCode();
  };

  // Input Change Handler
  const handleInputChange = (e) => setInput(e.target.value);

  // Save Code Function
  const saveCode = async () => {
    if (currentEditor === "code") {
      try {
        if (language == "java") timeSpentOnJava.current = timeLeft;
        else if (language == "python") timeSpentOnPython.current = timeLeft;
        else if (language == "javascript")
          timeSpentOnJavaScript.current = timeLeft;
        else if (language == "typescript")
          timeSpentOnTypeScript.current = timeLeft;

        const responseDataCode = {
          problemId: questionId,
          savedCodes: {
            java: javaCode || javaSavedCode,
            python: pythonCode || pythonSavedCode,
            javascript: javaScriptCode || javaScriptSavedCode,
            typescript: typeScriptCode || typeScriptSavedCode,
          },
          totalSecondsSpent: 500,
          javaTimeSeconds: timeSpentOnJava.current,
          pythonTimeSeconds: timeSpentOnPython.current,
          javascriptTimeSeconds: timeSpentOnJavaScript.current,
          typescriptTimeSeconds: timeSpentOnTypeScript.current,
        };

        const response = await axios.put(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/problem-submissions/save-code`,
          responseDataCode,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
      } catch (err) {
        // toast.error("Code saving failed")
      }
    }
    if (currentEditor === "algorithm") {
      try {
        const responseDataAlgorithm = {
          problemId: questionId,
          content: algorithm,
          isCorrect: algorithmValidated,
          totalSecondSpent: timeLeft,
        };
        const response = await axios.post(
          `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions`,
          responseDataAlgorithm,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        toast.success("Algorithm saved succesfully");
      } catch (err) {
        toast.error("algorithm saving failed");
      }
    }

    if (currentEditor === "pseudocode") {
      try {
        const responseDataPseudocode = {
          problemId: questionId,
          content: pseudoCode,
          isCorrect: pseudoValidated,
          totalSecondSpent: timeLeft,
        };
        const response = await axios.post(
          `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions`,
          responseDataPseudocode,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        toast.success("Pseudocode saved succesfully");
      } catch (err) {
        toast.error("pseudocode saving failed");
      }
      setSubmissioncount(submissionCount + 1);
    }
  };

  const runCode = async () => {
    if (!code.trim()) {
      toast.error("Please write some code first.");
      return;
    }

    setLoading(true);
    setOutput("Running...");

    try {
      const response = await axios.post(
        `${import.meta.env.VITE_CODE_EXECUTOR_URL}/api/v1/run`,
        {
          language,
          source: code,
          input: input,
        }
      );

      let outputText = response.data.output || "No output received";
      if (response.data.error.startsWith("Malicious code detected:")) {
        outputText = "Malicious code detected! Forbidden keywords used!";
      }
      setOutput(outputText);
    } catch (error) {
      console.error("Run error:", error);
      setOutput(error.response?.data?.error || "Compilation/Runtime Error");
    } finally {
      setLoading(false);
    }
  };

  // Submit Code Function
  const submitCode = async () => {
  if (loading) return;

  if (!code.trim()) {
    toast.error("Please write some code first.");
    return;
  }

  setLoading(true);
  setOutput("Submitting...");

  try {
    const response = await axios.post(
      `${import.meta.env.VITE_CODE_EXECUTOR_URL}/api/v1/submit`,
      {
        language,
        source: code,
        problemId: parseInt(questionId),
      }
    );

    const { results = [], allPassed } = response.data;

    // Build readable output
    let passedCount = 0;
    const formattedResults = results.map((test, index) => {
      if (test.passed) passedCount++;

      return test.passed
        ? `Test Case ${index + 1}: PASSED`
        : `Test Case ${index + 1}: FAILED
Expected: ${test.expectedOutput}
Got: ${test.actualOutput}`;
    });

    setPassedCount(passedCount);
    setOutput(formattedResults.join("\n\n"));
    setFullPassed(allPassed);

    if (allPassed) {
      toast.success(`All ${results.length} test cases passed ✅`);

      if (language === "python") setPythonCompleted(true);
      if (language === "java") setJavaCompleted(true);
      if (language === "javascript") setJavaScriptCompleted(true);
      if (language === "typescript") setTypeScriptCompleted(true);

      try {
        await axios.post(
          `${import.meta.env.VITE_BACKEND_URL}/progress/update`,
          {
            email: localStorage.getItem("email"),
            questionId: parseInt(questionId),
            language,
            title: question.title,
            name: localStorage.getItem("name"),
          }
        );
      } catch (err) {
        console.error("Progress update failed:", err);
      }
    } else {
      toast.error(`${passedCount}/${results.length} test cases passed ❌`);
    }

  
    try {
      await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/submission`,
        {
          problemId: questionId,
          language: language.toUpperCase(),
          code,
          isCorrect: allPassed,
          savedCodes: {
            java: javaCode,
            python: pythonCode,
            javascript: javaScriptCode,
            typescript: typeScriptCode,
          },
          totalSecondsSpent: 0,
          totalTestCasesPassed: passedCount,
          totalTestCases: results.length,
          email: localStorage.getItem("email"),
        },
        { headers: { "Content-Type": "application/json" } }
      );
    } catch (err) {
      if (err?.response?.status === 429) {
        toast.warning(
          err.response.data?.message ||
            "Please wait before submitting again."
        );
      } else {
        toast.error("Failed to save submission");
      }
    }
  } catch (error) {
    console.error("Submit error:", error);
    toast.error(
      error?.response?.data?.message || "Submission failed"
    );
    setOutput("Runtime or compilation error occurred");
  } finally {
    setLoading(false);
  }
};

  // Progress Effect
  useEffect(() => {
    if (javaCompleted && pythonCompleted) setProgress(100);
    else if (javaCompleted || pythonCompleted) setProgress(50);
    else setProgress(0);
  }, [javaCompleted, pythonCompleted]);

  // Topic Map
  const topicMap = {
    Recursion: "https://www.geeksforgeeks.org/recursion/",
    "Linked List": "https://www.geeksforgeeks.org/data-structures/linked-list/",
    "Dynamic Programming": "https://www.geeksforgeeks.org/dynamic-programming/",
    Stacks: "https://www.geeksforgeeks.org/stack-data-structure/",
    Queues: "https://www.geeksforgeeks.org/queue-data-structure/",
  };

  const topicName = question?.topic || "General Programming";
  const referenceLink = topicMap[topicName] || "https://www.geeksforgeeks.org/";

  useEffect(() => {
    (async () => {
      // Immediately invoked async function

      //TickMark Fetching from DB
      try {
        const problemId = questionId;
        const response = await axios.get(
          `${
            import.meta.env.VITE_API_BASE_URL
          }/user/problem-submissions/${problemId}/submissions`
        );
        response.data.forEach((element) => {
          if (element.isCorrect == true) {
            if (element.language == "JAVA") setJavaCompleted(true);
            else if (element.language == "PYTHON") setPythonCompleted(true);
            else if (element.language == "JAVASCRIPT")
              setJavaScriptCompleted(true);
            else if (element.language == "TYPESCRIPT")
              setTypeScriptCompleted(true);
          }
        });
      } catch (err) {}
    })();
  }, [language, location.key]);

  return (
    <div className="compiler-container">
      <Toaster richColors position="top-center" />
      <Navbar onLogout={onLogout} />

      <InitialPopup
        showInitialPopup={showInitialPopup}
        setCurrentEditor={setCurrentEditor}
        setHasChosenFlow={setHasChosenFlow}
        setShowInitialPopup={setShowInitialPopup}
        setAlgorithmValidated={setAlgorithmValidated}
        setPseudoValidated={setPseudoValidated}
        saveCode={saveCode}
        questionId={questionId}
        setAlgorithm={setAlgorithm}
        setPseudoCode={setPseudoCode}
      />

      {/* Full Screen Overlay Loaders */}
      <FullScreenLoader
        isVisible={checkLoading}
        message="Validating Pseudocode"
        subMessage="AI is analyzing your pseudocode logic..."
        loaderType="enhanced"
      />
      <FullScreenLoader
        isVisible={checkCodeLoading}
        message="Validating Code"
        subMessage="AI is analyzing your code logic..."
        loaderType="enhanced"
      />
      <FullScreenLoader
        isVisible={algorithmLoading}
        message="Validating Algorithm"
        subMessage="AI is analyzing your algorithm logic..."
        loaderType="enhanced"
      />

      <FullScreenLoader
        isVisible={loading}
        message="Processing Code"
        subMessage="Running your code against test cases..."
        loaderType="wave"
      />

      <FullScreenLoader
        isVisible={feedbackLoading}
        message="Generating Feedback"
        subMessage="AI is analyzing your code and providing feedback..."
        loaderType="enhanced"
      />

      <main className="compiler-content">
        {/* Left Section - Problem Description */}
          <DescriptionSection
            leftWidth={leftWidth}
            saveCode={saveCode}            
          />
        {/* Horizontal Resizer */}
        <div
          className="horizontal-resizer"
          onMouseDown={handleMouseDown("horizontal")}
        />

        {/* Right Section - Editors and Output */}
        <div
          className="editor-section"
          style={{ width: `${100 - leftWidth}%` }}
        >
          {/* Toolbar */}
          <EditorToolbar
            currentEditor={currentEditor}
            language={language}
            handleLanguageChange={handleLanguageChange}
            timeLeft={timeLeft}
            formatTime={formatTime}
            javaCompleted={javaCompleted}
            pythonCompleted={pythonCompleted}
            javaScriptCompleted={javaScriptCompleted}
            typeScriptCompleted={typeScriptCompleted}
            checkAlgorithm={checkAlgorithm}
            algorithmLoading={algorithmLoading}
            checkCode={checkCode}
            checkLoading={checkLoading}
            CodeEditor={CodeEditor}
            checkCodeLoading={checkCodeLoading}
            runCode={runCode}
            loading={loading}
            submitCode={submitCode}
            cooldown={cooldown}
            setShowPopup={setShowPopup}
            fetchFeedback={fetchFeedback}
            saveCode={saveCode}
            isTimerPaused={isTimerPaused}
            setIsTimerPaused={setIsTimerPaused}
          />

          {/* Editors Container */}
          <EditorContainer
            currentEditor={currentEditor}
            algorithm={algorithm}
            pseudoCode={pseudoCode}
            code={code}
            language={language}
            handleEditorChange1={handleEditorChange1}
            handleEditorChange2={handleEditorChange2}
            handleEditorChange3={handleEditorChange3}
            bottomHeight={bottomHeight}
          />

          {/* Input/Output Container */}
          <InputOutputContainer
            input={input}
            handleInputChange={handleInputChange}
            output={output}
            bottomHeight={bottomHeight}
          />
        </div>
      </main>

      {/* Feedback Popup */}
      {showPopup && (
        <FeedbackPopup
          feedback={feedback}
          setFeedback={setFeedback}
          passedCount={passedCount}
          closePopup={closePopup}
        />
      )}
    </div>
  );
};

export default Compiler;
