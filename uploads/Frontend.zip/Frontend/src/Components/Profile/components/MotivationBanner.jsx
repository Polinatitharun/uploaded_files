import React, { useEffect, useState } from "react";
import "../styles/MotivationBanner.css";

const quotes = [
  "Study while others are enjoying ~Anonymous",
  "Knowledge is power ~Anonymous",
  "Discipline is the bridge between goals and accomplishment ~Anonymous",
  "Push yourself, because no one else is going to do it for you ~Anonymous",
  "Small daily improvements are the key to staggering success ~Anonymous",
  "Don’t watch the clock; do what it does. Keep going ~Anonymous",
  "Success is the sum of small efforts repeated day in and day out ~Anonymous",
  "The expert in anything was once a beginner ~Anonymous",
  "Dreams don’t work unless you do ~Anonymous",
  "Strive for progress, not perfection ~Anonymous",
];

const MotivationBanner = () => {
  const [quote, setQuote] = useState("");

  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    setQuote(quotes[randomIndex]);
  }, []);

  return (
    <div className="motivation-banner">
      <p>{quote}</p>
    </div>
  );
};

export default MotivationBanner;

