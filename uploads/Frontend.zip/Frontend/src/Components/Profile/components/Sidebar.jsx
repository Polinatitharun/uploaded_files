import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/Sidebar.css";

export default function Sidebar() {
  const [userData, setUserData] = useState({
    Name: "",
    EmpId: "",
    Email: "",
    Batch: "",
    totalSolved: 0

  });

  const badges = [
    { title: "Newbie", requirement: 10 },
    { title: "Rookie", requirement: 25 },
    { title: "Apprentice", requirement: 50 },
    { title: "Intermediate", requirement: 75 },
    { title: "Advance", requirement: 100 },
    { title: "Professional", requirement: 150 },
    { title: "Mastery", requirement: 200 },
    { title: "Insane", requirement: 300 },
  ];

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/user/dashboard/stats`)
      .then((res) => {
        const data = res.data;
        setUserData({
          Name: data.userName || "",
          EmpId: data.userId || "",
          Email: data.email, // if email is not in API
          Batch: "Ignite - 46",
          totalSolved: data.totalProblems.solved || 0
        });
      })
      .catch((err) => {
        console.error("Error fetching user stats:", err);
      });
  }, []);

  const goBack = () => window.history.back();

  return (
    <div className="sidebar">
      <button className="sidebar-back-btn" onClick={goBack}>
        ← Back
      </button>
      <br />
      <br />
      <h2>Hello, {userData.Name}</h2>
      <hr />
      <br />
      <p>
        <strong>Emp ID:</strong> {userData.EmpId}
      </p>
      <p>
        <strong>Email:</strong> {userData.Email}
      </p>
      <p>
        <strong>Batch:</strong> {userData.Batch}
      </p>

      <div className="badges-container">
        <h3>Badges</h3>
        <br />
        <div className="badges">
          {badges.map((badge, idx) => {
            const unlocked = userData.totalSolved >= badge.requirement;
            const remaining = badge.requirement - userData.totalSolved;

            return (
              <div
                key={idx}
                className={`badge ${unlocked ? "unlocked" : "locked"}`}
              >
                <strong>{badge.title}</strong>
                <span className="status">
                  {unlocked
                    ? "You have achieved this badge!"
                    : `Complete ${remaining} more problem${remaining > 1 ? "s" : ""} to unlock this badge`}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}