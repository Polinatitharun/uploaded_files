import React, { useState, useEffect } from "react";
import axios from "axios";
import "../styles/SubjectReportConsole.css";

const SubjectReportConsole = () => {
  const [selectedSubject, setSelectedSubject] = useState("Python");
  const [report, setReport] = useState("Fetching report...");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/user/dashboard/stats`
        );
        setData(response.data);
      } catch (err) {
        console.error("Error fetching subject reports:", err);
        setError("Failed to load subject reports.");
      } finally {
        setLoading(false);
      }
    };

    fetchReports();
  }, []);

  useEffect(() => {
    if (!data) return;

    setReport("Generating report...");
    const timer = setTimeout(() => {
      switch (selectedSubject) {
        case "Python":
          setReport(data?.insights?.pythonInsight || "No data available for Python.");
          break;
        case "Java":
          setReport(data?.insights?.javaInsight || "No data available for Java.");
          break;
        case "TS":
          setReport(data?.insights?.typescriptInsight || "No data available for TypeScript.");
          break;
        case "JS":
          setReport(data?.insights?.javascriptInsight || "No data available for JavaScript.");
          break;
        default:
          setReport("Unknown subject.");
      }
    }, 1000); // simulate delay like LLM thinking

    return () => clearTimeout(timer);
  }, [selectedSubject, data]);

  return (
    <div className="subject-report-console">
      <div className="subject-buttons">
        {["Python", "Java", "TS", "JS"].map((subj) => (
          <button
            key={subj}
            className={selectedSubject === subj ? "active" : ""}
            onClick={() => setSelectedSubject(subj)}
          >
            {subj}
          </button>
        ))}
      </div>

      <div className="console">
        {loading ? (
          <p>Loading reports...</p>
        ) : error ? (
          <p style={{ color: "red" }}>{error}</p>
        ) : (
          <p>{report}</p>
        )}
      </div>
    </div>
  );
};

export default SubjectReportConsole;