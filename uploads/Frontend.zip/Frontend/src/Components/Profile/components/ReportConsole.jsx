import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/ReportConsole.css";

export default function ReportConsole({ title }) {
  const [reportData, setReportData] = useState({
    insight: "Fetching your LLM learning report...",
  });

  useEffect(() => {
    const fetchReportData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/user/dashboard/stats`
        );


        // ✅ Update state safely even if data is missing
        setReportData({
          insight:
            response.data.insights.overallInsight ||
            "No learning insights available at the moment.",
        });
      } catch (error) {
        console.error("Error fetching report data:", error);
        setReportData({
          insight:
            "⚠️ Unable to fetch report. Please try again later or check your connection.",
        });
      }
    };

    fetchReportData();
  }, []);

  return (
    <div className="report-console">
      <h3>{title || "User LLM Report"}</h3>
      <div className="report-content">
        <p>{reportData.insight}</p>
      </div>
    </div>
  );
}