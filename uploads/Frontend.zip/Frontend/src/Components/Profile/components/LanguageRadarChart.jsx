import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LabelList,
} from "recharts";
import "../styles/LanguageRadarChart.css";

export default function LanguageRadarChart() {
  const [languageData, setLanguageData] = useState([
    { language: "Java", completed: 0 },
    { language: "Python", completed: 0 },
    { language: "JavaScript", completed: 0 },
    { language: "TypeScript", completed: 0 },
  ]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/user/dashboard/stats`
        );


        const data = response.data;

        setLanguageData([
          { language: "Java", completed: data.languageStats.java || 0 },
          { language: "Python", completed: data.languageStats.python || 0 },
          { language: "JavaScript", completed: data.languageStats.javascript || 0 },
          { language: "TypeScript", completed: data.languageStats.typescript || 0 },
        ]);
      } catch (error) {
        console.error("Error fetching language data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="language-bar-card">
      <h3>Completed Problems by Language</h3>
      <div className="language-bar-chart-container">
        <ResponsiveContainer width="100%" height={250}>
          <BarChart
            data={languageData}
            margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
            barCategoryGap="30%"
          >
            <CartesianGrid stroke="#f0f0f0" vertical={false} />
            <XAxis dataKey="language" tick={{ fill: "#111", fontSize: 14 }} />
            <YAxis tick={{ fill: "#111", fontSize: 14 }} />
            <Tooltip
              formatter={(value) => [`${value} problems`, "Completed"]}
              cursor={{ fill: "rgba(0,0,0,0.05)" }}
            />
            <Bar
              dataKey="completed"
              fill="#4F46E5"
              radius={[8, 8, 0, 0]}
              barSize={40}
            >
              <LabelList
                dataKey="completed"
                position="top"
                style={{ fill: "#111", fontWeight: 600 }}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}