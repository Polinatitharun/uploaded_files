import React, { useEffect, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import axios from "axios";
import "../styles/GraphSection.css";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function GraphSection() {
  const [difficultyData, setDifficultyData] = useState({
    Easy: { completed: 0, total: 0 },
    Medium: { completed: 0, total: 0 },
    Hard: { completed: 0, total: 0 },
  });

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/user/dashboard/stats`)
      .then((res) => {
        const data = res.data;
        setDifficultyData({
          Easy: { completed: data.difficultyStats.easy.solved, total: data.difficultyStats.easy.total },
          Medium: { completed: data.difficultyStats.medium.solved, total: data.difficultyStats.medium.total },
          Hard: { completed: data.difficultyStats.hard.solved, total: data.difficultyStats.hard.total },
        });
      })
      .catch((err) => console.error("API fetch error:", err));
  }, []);

  // Calculate totals for donut
  const totalCompleted = Object.values(difficultyData).reduce(
    (sum, d) => sum + (d.completed || 0),
    0
  );
  const totalProblems = Object.values(difficultyData).reduce(
    (sum, d) => sum + (d.total || 0),
    0
  );

  const donutData = {
    labels: ["Completed", "Remaining"],
    datasets: [
      {
        data: [totalCompleted, totalProblems - totalCompleted],
        backgroundColor: ["#4F46E5", "#E5E5E5"],
        borderWidth: 0,
      },
    ],
  };

  const difficultyKeys = Object.keys(difficultyData);

  return (
    <div className="dashboard-card">
      {/* Donut Chart */}
      <div className="donut-container">
        <Doughnut
          data={donutData}
          options={{
            cutout: "70%",
            plugins: {
              legend: { display: false },
              tooltip: { enabled: true },
            },
          }}
        /> 
        <div className="donut-center">
          <p>Total</p>
          <h3>{totalProblems}</h3>
          <p>Completed</p>
          <h4>{totalCompleted}</h4>
        </div>
      </div>

      {/* Progress Bars */}
      <div className="progress-container">
        {difficultyKeys.map((key, index) => {
          const { completed, total } = difficultyData[key];
          const percentage = total ? ((completed / total) * 100).toFixed(0) : 0;

          return (
            <div key={index} className="progress-bar-wrapper">
              <div className="progress-label">
                <span>
                  {key}{" "}
                  <span style={{ color: "#777", fontSize: "13px" }}>
                    {percentage}%
                  </span>
                </span>
                <span>
                  {completed}/{total}
                </span>
              </div>
              <div className="progress-bar-bg">
                <div
                  className="progress-bar-fill"
                  style={{
                    width: `${percentage}%`,
                    backgroundColor:
                      key === "Easy"
                        ? "#22C55E"
                        : key === "Medium"
                        ? "#FACC15"
                        : "#EF4444",
                  }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}