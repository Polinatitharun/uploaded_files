import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/RankingBox.css";

export default function RankingBox() {
  const [leagueData, setLeagueData] = useState({
    league: "Unranked",
    color: "#aaa",
    nextLeague: "Gold",
    nextColor: "#FFD700",
    percentage: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/user/dashboard/stats`);
        const data = res.data;

        const totalCompleted =
          data.difficultyStats.easy.solved +
          data.difficultyStats.medium.solved +
          data.difficultyStats.hard.solved;

        const totalProblems =
          data.difficultyStats.easy.total +
          data.difficultyStats.medium.total +
          data.difficultyStats.hard.total;

        const percentage =
          totalProblems > 0 ? (totalCompleted / totalProblems) * 100 : 0;

        let league = "";
        let color = "";
        let nextLeague = "";
        let nextColor = "";

        if (percentage < 20) {
          league = "Gold";
          color = "#FFD700";
          nextLeague = "Platinum";
          nextColor = "#4D4F51";
        } else if (percentage < 40) {
          league = "Platinum";
          color = "#4D4F51";
          nextLeague = "Ruby";
          nextColor = "#E0115F";
        } else if (percentage < 60) {
          league = "Ruby";
          color = "#E0115F";
          nextLeague = "Diamond";
          nextColor = "#0078d7";
        } else if (percentage < 80) {
          league = "Diamond";
          color = "#0078d7";
          nextLeague = "Kryptonite";
          nextColor = "#39FF14";
        } else {
          league = "Kryptonite";
          color = "#39FF14";
          nextLeague = "There is no league above";
          nextColor = "black";
        }

        setLeagueData({ league, color, nextLeague, nextColor, percentage });
      } catch (err) {
        console.error("Error fetching user stats:", err);
      }
    };

    fetchStats();
  }, []);

  return (
    <div className="ranking-box">
      <div>
        <p className="league-text">
          League:{" "}
          <span
            className="league-value"
            style={{ color: leagueData.color }}
          >
            {leagueData.league}
          </span>
        </p>
        <p className="next-league-text">
          Next League:{" "}
          <span
            className="next-league-value"
            style={{ color: leagueData.nextColor }}
          >
            {leagueData.nextLeague}
          </span>
        </p>
        <p className="progress-percentage">
          Completion:{" "}
          <strong style={{ color: leagueData.color }}>
            {leagueData.percentage.toFixed(1)}%
          </strong>
        </p>
      </div>
    </div>
  );
}