
import React, { useState } from "react";
import "../styles/ChartCard.css";

export default function ChartCard() {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectedWeek, setSelectedWeek] = useState("");
  const [selectedTopic, setSelectedTopic] = useState("");

  const weeks = {
    "Week 1": ["Data Types", "Variables", "Integers"],
    "Week 2": ["Strings", "Functions"],
    "Week 3": ["Loops", "Conditionals", "Lists"],
    "Week 4": ["Dictionaries", "Modules", "File Handling"],
  };

  const subjects = ["Python", "Java", "JavaScript", "TypeScript"];

  // Random completion data for demo
  const progressData = {
    Python: ["Data Types", "Variables", "Functions", "Loops"],
    Java: ["Variables", "Loops", "Dictionaries"],
    JavaScript: ["Strings", "Functions"],
    TypeScript: ["Data Types", "Modules", "File Handling"],
  };

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const handleWeekClick = (week) => {
    setSelectedWeek(week);
    setSelectedTopic("");
  };

  const handleTopicClick = (topic) => {
    setSelectedTopic(topic);
    setDropdownOpen(false);
  };

  const isCompleted = (subject, topic) =>
    progressData[subject].includes(topic);

  return (
    <div className="chart-wrapper">
      <div className="dropdown-container">
        <div className="dropdown-header" onClick={toggleDropdown}>
          {selectedTopic || selectedWeek || "Quick Weekly Overview"}
          <span className={`arrow ${dropdownOpen ? "up" : "down"}`}>▼</span>
        </div> <p className="p"></p>
        {/* Check your weekly progress here */}

        {dropdownOpen && (
          <div className="dropdown-list">
            {Object.keys(weeks).map((week, i) => (
              <div key={i} className="dropdown-week">
                <div
                  className="week-title"
                  onClick={() => handleWeekClick(week)}
                >
                  {week}
                </div>
                {selectedWeek === week && (
                  <div className="topics-list">
                    {weeks[week].map((topic, j) => (
                      <div
                        key={j}
                        className="topic-item"
                        onClick={() => handleTopicClick(topic)}
                      >
                        {topic}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedTopic && (
        <div className="completion-status">
          <h4>{selectedTopic} — Completion Status</h4>
          <div className="subject-status">
            {subjects.map((subj, i) => (
              <div key={i} className="subject">
                <span
                  className={`status-dot ${
                    isCompleted(subj, selectedTopic) ? "completed" : "pending"
                  }`}
                ></span>
                <p>{subj}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}