import React from "react";

import "./styles/Profile.css";
import {
  Sidebar,
  ChartCard,
  ReportConsole,
  SubjectReportConsole,
  GraphSection,
  MotivationBanner,
  LanguageRadarChart,
  RankingBox,
} from "./utils";
const UserProfile = ({userId}) => {
  
  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="main-content">
        <MotivationBanner />

        {/* Top container: ReportConsole + GraphSection + RankingBox */}
        <div className="top-container">
          {/* <ReportConsole title="General Progress Report" /> */}

          <div className="graph-section-wrapper">
            <GraphSection />
            <div className="graph-ranking-box">
              <RankingBox />
            </div>
          </div>
        </div>

        {/* Other bottom sections if needed, this is checkoing message */}
        <hr color="#09122C"></hr>
        <LanguageRadarChart />
        <SubjectReportConsole />
      </div>
    </div>
  );
};

export default UserProfile;
