import "../styles/QuestionPage.css";
import Navbar from "./common/NavBar/Navbar";
import { FaCode, FaDatabase, FaCogs, FaSyncAlt, FaProjectDiagram } from "react-icons/fa";
import bgcode from '../assets/bgcode.png';
import { Link } from "react-router-dom";

const iconMap = {
  FaCode: <FaCode />,
  FaDatabase: <FaDatabase />,
  FaCogs: <FaCogs />,
  FaSyncAlt: <FaSyncAlt />,
  FaProjectDiagram: <FaProjectDiagram />
};

const TopicCard = () => (
  <div className="topic-card">
    <img className="img-que" src={bgcode} />
    {/* <div className="icon">{iconMap[icon]}</div> */}
    <div className="que-desc">
      <h3 className="title">Tired of theory-heavy learning?</h3>
      <p className="comp-description">Dive into practical, scenario based challenges that mirror real-life problems. Understand concepts deeply. Solve with confidence.</p>
      <p className="comp-tag">Learn once, Code anywhere</p>
      <Link to={`/questions`}>
        <button className="solve-btn">Solve Now</button>
      </Link>
    </div>
  </div>
);

export default function QuestionPage({ onLogout }) {
  return (
    <>
      <Navbar onLogout={onLogout} />
      <div className="question-page-container">
        <div className="card-grid">
            <TopicCard/>
        </div>
      </div>
    </>
  );
}
