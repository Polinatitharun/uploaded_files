import { CiLock, CiUnlock } from "react-icons/ci";
import "./styles.css";
import MarkdownViewer from "../../Markdown/MarkdownViewer";

const Collapse = ({ option, content, lock, onSelect }) => {
  const handleClick = () => {
    onSelect?.(option);
  };

  return (
    <details className="collapse">
      <summary className="collapse-trigger" onClick={handleClick}>
        <span className="label">{option}</span>
        <span className="lock">{lock ? <CiLock /> : <CiUnlock />}</span>
        <span className="chevron" aria-hidden="true"></span>
      </summary>

      <div className="card card-body">
        <MarkdownViewer
          content={
            content ||
            `<span style="color:red; font-weight:700;">No ${option} available for this Question.</span>`
          }
          allowHtml={true}
        />
      </div>
    </details>
  );
};

export default Collapse;
