import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./Navbar.css";
import PersonIcon from "@mui/icons-material/Person";
import LogoutOutlinedIcon from "@mui/icons-material/LogoutOutlined";
import { RiProfileFill } from "react-icons/ri";
import { useAuth } from "../../../(auth)/AuthContext";

const Navbar = ({ }) => {
  const { user} = useAuth() || {};
  
  const path = useLocation().pathname;
  const handleProfileClick = () => {
    // console.log(token);
  };
  const [isOpen, setIsOpen] = useState(false);
  return (
    <nav className="header">
      <div className="logo">Integrated Learning</div>
      <ul className="links">

         <li id="home" className={`nav-link ${path==='/home'?'active-link':''}`}>
            <Link to="/home">Home</Link>
          </li>

        <li id="mcq" className={`nav-link ${path === "/learning" ? "active-link" : ""}`}>
          <Link to="/learning">Learning Path</Link>
        </li>

        <li id="mcq"
          className={`nav-link ${
            path === "/questions/intro" ||
            path === "/questions/all" ||
            path.startsWith("/question")
              ? "active-link"
              : ""
          }`}
        >
          <Link to="/questions/all">Take a Challenge</Link>
        </li>

        <li>
          <div id="profile-icon" onClick={() => setIsOpen(!isOpen)}>
            <PersonIcon sx={{ fontSize: "25px" }} />
          </div>

          {isOpen && (
            <div className="dropdown-menu">
              <p className="username">{user?.name}</p>
              <p className="email">{user?.email}</p>
              <hr />
              <ul>
                <Link to={`/profile/${user?.username.split("@")[0]}`}>
                  <li className="nav-list" onClick={handleProfileClick}>
                    <RiProfileFill />
                    Profile
                  </li>
                </Link>
                <li className="nav-list" onClick={()=>onLogout()}>
                  <LogoutOutlinedIcon />
                  Logout
                </li>
              </ul>
            </div>
          )}
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
