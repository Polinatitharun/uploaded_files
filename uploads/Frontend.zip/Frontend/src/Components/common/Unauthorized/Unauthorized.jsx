import React from "react";
import { Link } from "react-router-dom";
import { useOutletContext } from "react-router-dom";
import "./styles.css";

export default function Unauthorized() {
  const { onLogout } = useOutletContext() || {};

  return (
    <div className="unauth-container">
      <h1 className="unauth-title">Access Denied</h1>

      <p className="unauth-text">You don't have permission to view this page.</p>
      <p className="unauth-text">Please contact your administrator for access.</p>

      <div className="unauth-actions">
        {onLogout && (
          <button className="unauth-button logout-btn" onClick={()=>onLogout()}>
            Logout
          </button>
        )}
      </div>
    </div>
  );
}