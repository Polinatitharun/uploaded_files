import "./description-styles.css";
import React, { useState, useEffect } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import axios from "axios";
import { IoBook, IoBookOutline } from "react-icons/io5";
import { MarkdownViewer } from "../utils";

import { TiArrowBack } from "react-icons/ti";

import Header from "./Header/Header";
import TestCases from "./(public)TestCase";
import { Collapse } from "../../../utils";
import { fetchAssistance, fetchQuestionDetails, fetchQuestionSaveAlgorithm } from "./Service/service";

const DescriptionSection = ({ leftWidth,saveCode }) => {
  const location = useLocation();
  const { questionId } = useParams();

  const [algorithm,setAlgorithm] =useState(null);
  const [pseudocode,setPseudocode] = useState(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedView, setSelectedView] = useState("Question");
  const [question, setQuestion] = useState(null);
  const backTo = location.state?.fromLearningPage
    ? "/learning"
    : "/questions/all";
  const backState = location.state?.fromLearningPage
    ? {
        selectedTopic: location.state?.selectedTopic,
        selectedSubtopic:
          location.state?.selectedSubtopic || location.state?.selectedSubTopic,
      }
    : {
        selectedTopic: location.state?.selectedTopic,
        selectedSubTopic: location.state?.selectedSubTopic,
      };

  const [assistance, setAssistance] = useState();



  useEffect(() => {
    const loadAlgorithm=async ()=>{
      const data=await fetchQuestionSaveAlgorithm(questionId)
      setAlgorithm(data?.content)
    }
    const loadQuestionDetails = async () => {
      const data = await fetchQuestionDetails(questionId);
      setQuestion(data);
    };
    const loadQuestionAssistance = async () => {
      const data = await fetchAssistance(questionId);
      setAssistance(data);
    };
    loadQuestionAssistance();
    loadQuestionDetails();
    loadAlgorithm();
  }, [questionId]);

  const handleSelectAssistance = (option) => {
    console.log(option);
  };

  return (
    <div className="container description" style={{ width: `${leftWidth}%` }}>
      <div className="header">
        <Link to={backTo} state={backState}>
          <button
            className="back-button"
            onClick={() => {
              saveCode();
            }}
          >
            <TiArrowBack size={24} />
            <span>Back</span>
          </button>
        </Link>

        <div className="header assistance">
          <button onClick={() => setShowDropdown(!showDropdown)}>
            {showDropdown ? <IoBook /> : <IoBookOutline />}
          </button>
          {showDropdown && (
            <div className="dropdown">
              {["Question", "Algorithm", "Pseudocode"].map((option) => (
                <div
                  key={option}
                  style={{
                    padding: "8px 12px",
                    cursor: "pointer",
                    backgroundColor:
                      selectedView === option ? "#f0f0f0" : "#fff",
                    borderBottom:
                      option !== "Pseudocode" ? "1px solid #eee" : "none",
                  }}
                  onClick={() => {
                    setSelectedView(option);
                    setShowDropdown(false);
                  }}
                >
                  {option}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <>
        <Header
          question={{
            id: question?.problemId,
            title: question?.title,
            difficulty: question?.difficulty,
            acceptance: question?.acceptance | 0,
          }}
        />
        {selectedView == "Question" && (
          <div>
            <MarkdownViewer content={question?.description} />
            {/* <TestCases question={question} /> */}
            <Collapse
              option={"Concept Explanation"}
              content={assistance?.breakdown}
              onSelect={handleSelectAssistance}
              lock={true}
            />
             <Collapse
              option={"Hints"}
              content={assistance?.breakdown}
              lock={true}
              onSelect={handleSelectAssistance}
            />
            <Collapse
              option={"Break Down"}
              content={assistance?.breakdown}
              onSelect={handleSelectAssistance}
              lock={true}
            />
            <Collapse
              option={"Partial Solution"}
              content={assistance?.breakdown}
              onSelect={handleSelectAssistance}
              lock={true}
            />
          </div>
        )}
        {selectedView == "Algorithm" && (
          <MarkdownViewer content={algorithm || "No saved Algorithm available."} />
        )}
        {selectedView == "Pseudocode" && (
          <MarkdownViewer content={pseudocode || "No saved Pseudocode available."} />
        )}
      </>
    </div>
  );
};

export default DescriptionSection;
