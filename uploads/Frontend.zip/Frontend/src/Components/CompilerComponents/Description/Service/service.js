import axios from "axios";

const baseUrl = import.meta.env.VITE_API_BASE_URL;

export const fetchAssistance = async (id) => {
  if (id) {
    try {
      const response = await axios.get(`${baseUrl}/problem/assistance/${id}`,{withCredentials:true});
      return response?.data?.problem;
    } catch (error) {
      return error?.response?.data;
    }
  }
};

export const fetchQuestionSaveAlgorithm=async(id)=>{
  if(id){
    try {
      const response=await axios.get(`${baseUrl}/user/algorithm-submissions/problem/${id}`,{withCredentials:true})
      return response?.data;
    } catch (error) {
      return error?.response?.data;
    }
  }
}

export const fetchQuestionDetails = async (id) => {
  try {
    const res = await axios.get(`${baseUrl}/user/problem-submissions/${id}`,{withCredentials:true});
    return res.data.problemDTO;
  } catch (error) {
    return error;
  }
};
