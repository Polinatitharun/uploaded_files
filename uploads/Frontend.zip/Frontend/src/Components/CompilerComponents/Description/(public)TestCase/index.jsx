import React from "react";
import "./testcases.css"; // optional; see CSS below

export default function TestCases({ question, title = "Sample Test Cases" }) {
  const publicCases =
    question?.testCases?.filter?.((tc) => tc?.isPublic) ?? [];

  if (!publicCases.length) {
    return <p className="no-testcase">No public test cases available.</p>;
  }

  return (
    <section className="testcases-section" aria-label="Sample Test Cases">
      <h3 className="testcases-title">{title}</h3>

      {publicCases.map((tc, idx) => (
        <article key={tc.testCaseId ?? idx} className="testcase-block">
          <h4 className="testcase-heading">Test Case {idx + 1}</h4>

          <div className="testcase-row">
            <strong className="testcase-label">Input:</strong>
            <pre className="testcase-pre">{tc.input}</pre>
          </div>

          <div className="testcase-row">
            <strong className="testcase-label">Expected Output:</strong>
            <pre className="testcase-pre">{tc.expectedOutput}</pre>
          </div>
        </article>
      ))}
    </section>
  );
}