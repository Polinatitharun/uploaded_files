// Header.jsx
import './header.css';

const difficultyClass = (level = "") => {
  const d = (level || "").toLowerCase();
  if (d === "easy") return "diff-badge easy";
  if (d === "medium") return "diff-badge medium";
  if (d === "hard") return "diff-badge hard";
  return "diff-badge";
};

const acceptanceClass = (pct) => {
  const n = Number(pct);
  if (Number.isFinite(n)) {
    if (n >= 70) return "accept-badge high";
    if (n >= 40) return "accept-badge mid";
    return "accept-badge low";
  }
  return "accept-badge";
};

export default function Header({ question, loading = false }) {
  const { title, difficulty, id, acceptance } = question || {};

  return (
    <div className={`problem-header`}>
      <div className="problem-title-row">
        {id && <span className="problem-id">#{id}</span>}
        <h1 className="problem-title">{title}</h1>
      </div>

      <div className="problem-meta">
        <span className={difficultyClass(difficulty)} aria-label={`Difficulty ${difficulty}`}>
          <span className="pulse-dot" aria-hidden="true" />
          {difficulty}
        </span>

        {typeof acceptance !== "undefined" && (
          <span
            className={acceptanceClass(acceptance)}
            aria-label={`Acceptance ${acceptance}%`}
            title={`Acceptance ${acceptance}%`}
          >
            <span className="pulse-dot" aria-hidden="true" />
            Score: <b>{acceptance}%</b>
          </span>
        )}
      </div>
    </div>
  );
}
