import React from "react";
import { TbBulb } from "react-icons/tb";

const EditorToolbar = ({
  currentEditor,
  language,
  handleLanguageChange,
  timeLeft,
  formatTime,
  javaCompleted,
  pythonCompleted,
  javaScriptCompleted,
  typeScriptCompleted,
  checkAlgorithm,
  algorithmLoading,
  checkCode,
  checkLoading,
  CodeEditor,
  checkCodeLoading,
  runCode,
  loading,
  submitCode,
  setShowPopup,
  fetchFeedback,
  saveCode
}) => {
  return (
    <div className="editor-toolbar">
      {currentEditor === 'code' && (
        <>
          <label htmlFor="language-switcher" className="language-label">Choose Language:</label>
          <select id="language-switcher" className="language-switcher" value={language} onChange={handleLanguageChange}>
            <option value="java">{"Java "}{javaCompleted ? "✔" : ""}</option>
            <option value="python">{"Python "}{pythonCompleted ? "✔" : ""}</option>
            <option value="javascript">{"JavaScript "}{javaScriptCompleted ? "✔" : ""}</option>
            <option value="typescript">{"TypeScript "}{typeScriptCompleted ? "✔" : ""}</option>
          </select>
        </>
      )}
      <div className="timer-span">{formatTime(timeLeft)}</div>

      <div className="editor-buttons">
        {/* <button className="action-button" onClick={() => setShowHelp(true)}>
          <TbBulb />
        </button> */}
        <button className="action-button" onClick={() => {
          if (currentEditor === 'code') {
            saveCode();
          }
        }}>Save</button>

        {currentEditor === 'algorithm' && (
          <>
            <button
              className="action-button"
              onClick={checkAlgorithm}
              disabled={algorithmLoading}
              style={{
                opacity: algorithmLoading ? 0.7 : 1,
                cursor: algorithmLoading ? 'not-allowed' : 'pointer'
              }}
            >
              Validate Algorithm
            </button>
          </>
        )}

        {currentEditor === 'pseudocode' && (
          <>
            <button
              className="action-button"
              onClick={checkCode}
              disabled={checkLoading}
              style={{
                opacity: checkLoading ? 0.7 : 1,
                cursor: checkLoading ? 'not-allowed' : 'pointer'
              }}
            >
              Validate
            </button>
          </>
        )}

        {currentEditor === 'code' && (
          <>
            <button
              className="action-button"
              onClick={CodeEditor}
              disabled={checkCodeLoading}
              style={{
                opacity: checkCodeLoading ? 0.7 : 1,
                cursor: checkCodeLoading ? 'not-allowed' : 'pointer'
              }}
            >
              CheckCode
            </button>

            <button
              className="action-button"
              onClick={runCode}
              disabled={loading}
              style={{
                opacity: loading ? 0.7 : 1,
                cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              Run
            </button>

            <button
              className="action-button"
              onClick={submitCode}
              disabled={loading}
              style={{
                opacity: loading? 0.7 : 1,
                cursor: loading? "not-allowed" : "pointer"
              }}
            >
              Submit
            </button>

            <button
              className="action-button"
              onClick={() => {
                setShowPopup(true);
                fetchFeedback();
              }}
              disabled={!((language === 'java' && javaCompleted) ||
                (language === 'python' && pythonCompleted) ||
                (language === 'javascript' && javaScriptCompleted) ||
                (language === 'typescript' && typeScriptCompleted))}
              style={{
                marginLeft: "10px",
                opacity: ((language === 'java' && javaCompleted) ||
                  (language === 'python' && pythonCompleted) ||
                  (language === 'javascript' && javaScriptCompleted) ||
                  (language === 'typescript' && typeScriptCompleted)) ? 1 : 0.5,
                cursor: ((language === 'java' && javaCompleted) ||
                  (language === 'python' && pythonCompleted) ||
                  (language === 'javascript' && javaScriptCompleted) ||
                  (language === 'typescript' && typeScriptCompleted)) ? 'pointer' : 'not-allowed'
              }}
            >
              Show Feedback
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default EditorToolbar;
