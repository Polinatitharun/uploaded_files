import React from 'react';
import axios from 'axios';
import "../../Styles/InitialPopup.css";

const InitialPopup = ({ showInitialPopup, setCurrentEditor, setHasChosenFlow, setShowInitialPopup, setAlgorithmValidated, setPseudoValidated, saveCode, questionId, setAlgorithm, setPseudoCode }) => {
  if (!showInitialPopup) return null;

  const handleStartWithAlgorithm = () => {
    setCurrentEditor('algorithm');
    setHasChosenFlow(true);
    setShowInitialPopup(false);
  };

  const handleStartWithPseudocode = async () => {
    setCurrentEditor('pseudocode');
    setHasChosenFlow(true);
    setShowInitialPopup(false);
    setAlgorithmValidated(true);
    setPseudoValidated(false);
    setAlgorithm("You skipped writing algorithm");

    // Save skipped algorithm to DB
    try {
      const responseDataAlgorithm = {
        "problemId": questionId,
        "content": "You skipped writing algorithm",
        "isCorrect": true,
        "totalSecondSpent": 0
      };
      await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions`, responseDataAlgorithm, {
        headers: {
          'Content-Type': 'application/json'
        },
      });
    } catch (err) {
      console.error("Failed to save skipped algorithm");
    }

    // Reset pseudocode submission
    try {
      const responseDataPseudocode = {
        "problemId": questionId,
        "content": "// Write pseudo code first",
        "isCorrect": false,
        "totalSecondSpent": 0
      };
      await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions`, responseDataPseudocode, {
        headers: {
          'Content-Type': 'application/json'
        },
      });
    } catch (err) {
      console.error("Failed to save skipped pseudocode");
    }
  };


  const handleJumpToCode = async () => {
    setCurrentEditor('code');
    setHasChosenFlow(true);
    setShowInitialPopup(false);
    setAlgorithmValidated(true);
    setPseudoValidated(true);
    setAlgorithm("You skipped writing algorithm");
    setPseudoCode("You skipped writing pseudocode");

    // Save skipped algorithm to DB
    try {
      const responseDataAlgorithm = {
        "problemId": questionId,
        "content": "You skipped writing algorithm",
        "isCorrect": true,
        "totalSecondSpent": 0
      };
      await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions`, responseDataAlgorithm, {
        headers: {
          'Content-Type': 'application/json'
        },
      });
    } catch (err) {
      console.error("Failed to save skipped algorithm");
    }

    // Save skipped pseudocode to DB
    try {
      const responseDataPseudocode = {
        "problemId": questionId,
        "content": "You skipped writing pseudocode",
        "isCorrect": true,
        "totalSecondSpent": 0
      };
      await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions`, responseDataPseudocode, {
        headers: {
          'Content-Type': 'application/json'
        },
      });
    } catch (err) {
      console.error("Failed to save skipped pseudocode");
    }
  };

  return (
    <div className="initial-popup-overlay">
      <div className="initial-popup">
        <h2>Welcome to the Problem Solver!</h2>
        <p>Choose your approach to solve this problem:</p>
        <div className="initial-popup-buttons">
          <button
            className="initial-popup-btn algorithm-btn"
            onClick={handleStartWithAlgorithm}
          >
            Start with Algorithm
          </button>
          <button
            className="initial-popup-btn pseudocode-btn"
            onClick={handleStartWithPseudocode}
          >
            Start with Pseudocode
          </button>
          <button
            className="initial-popup-btn code-btn"
            onClick={handleJumpToCode}
          >
            Jump to Code
          </button>
        </div>
      </div>
    </div>
  );
};

export default InitialPopup;
