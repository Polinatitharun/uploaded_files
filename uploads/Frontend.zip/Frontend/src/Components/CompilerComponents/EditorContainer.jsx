
import React, { useRef } from "react";
import Editor from "@monaco-editor/react";

const beforeMount = (monaco) => {
  monaco.editor.defineTheme("my-suggest-theme", {
    base: "vs-dark", // keep overall dark look; override just what you need
    inherit: true,
    rules: [],
    colors: {
      "editorSuggestWidget.background": "#ffffff",
      "editorSuggestWidget.foreground": "#222222",
      "editorSuggestWidget.highlightForeground": "#c85400", 
      "editorSuggestWidget.selectedBackground": "#e6f0ff",  
      "editorSuggestWidget.selectedForeground": "#000000",
      "editorSuggestWidget.border": "#cbd5e1",

      "list.dropBackground": "#f0f7ff",
      "list.activeSelectionBackground": "#dbeafe",
      "list.activeSelectionForeground": "#0b0f17",
      "list.focusBackground": "#000",
      "list.focusForeground": "#0b0f17",
      "list.hoverBackground": "#f7fafc",
      "list.hoverForeground": "#0b0f17",
      "list.highlightForeground": "#c85400",

      /** Optional: widget container */
      "editorWidget.background": "#ffffff",
      "editorWidget.border": "#cbd5e1",
    },
  });
};

const EditorContainer = ({
  currentEditor,
  algorithm,
  pseudoCode,
  code,
  language,
  handleEditorChange1,
  handleEditorChange2,
  handleEditorChange3,
  bottomHeight,
}) => {
  const editorRef = useRef(null);

  function handleEditorDidMount(editor, monacoInstance) {
    editorRef.current = editor;

    // Ensure our theme is applied even if mount order changes
    monacoInstance.editor.setTheme("my-suggest-theme");

    // Optional: Disable context menu / copy-paste
    editor.updateOptions({ contextmenu: false });
    const domNode = editor.getDomNode();
    if (domNode) {
      domNode.addEventListener("copy", (e) => e.preventDefault());
      domNode.addEventListener("paste", (e) => e.preventDefault());
    }
  }

  const commonOptions = {
    minimap: { enabled: false },
    fontSize: 14,
    wordWrap: "on",
    lineNumbers: "on",
    // Ensure suggestions appear for languages that support them
    quickSuggestions: true,
    suggestOnTriggerCharacters: true,
  };

  return (
    <div style={{ display: "flex", height: `${100 - bottomHeight}%` }}>
      {currentEditor === "algorithm" && (
        <div className="editor-container" style={{ width: "100%" }}>
          <div
            style={{
              padding: "8px",
              background: "#1e1e1e",
              color: "#fff",
              fontSize: "16px",
              borderBottom: "1px solid #333",
              fontWeight: 700,
            }}
          >
            Algorithm Editor
          </div>
          <Editor
            height="calc(100% - 32px)"
            language="text"              // note: text has minimal suggestions
            value={algorithm}
            theme="my-suggest-theme"    // <-- use custom theme
            beforeMount={beforeMount}   // <-- define theme before mount
            onChange={handleEditorChange3}
            onMount={handleEditorDidMount}
            options={commonOptions}
          />
        </div>
      )}

      {currentEditor === "pseudocode" && (
        <div className="editor-container" style={{ width: "100%" }}>
          <div
            style={{
              padding: "8px",
              background: "#1e1e1e",
              color: "#fff",
              fontSize: "16px",
              borderBottom: "1px solid #333",
              fontWeight: 700,
            }}
          >
            Pseudocode Editor
          </div>
          <Editor
            height="calc(100% - 32px)"
            language="text"
            value={pseudoCode}
            theme="my-suggest-theme"    // <-- switched from vs-dark
            beforeMount={beforeMount}
            onChange={handleEditorChange2}
            onMount={handleEditorDidMount}
            options={commonOptions}
          />
        </div>
      )}

      {currentEditor === "code" && (
        <div className="editor-container" style={{ width: "100%" }}>
          <div
            style={{
              padding: "8px",
              background: "#1e1e1e",
              color: "#fff",
              fontSize: "16px",
              borderBottom: "1px solid #333",
              fontWeight: 700,
            }}
          >
            {language === "java"
              ? "Java"
              : language === "python"
              ? "Python"
              : language === "javascript"
              ? "JavaScript"
              : "TypeScript"}{" "}
            Code Editor
          </div>
          <Editor
            height="calc(100% - 32px)"
            language={language}
            value={code}
            theme="my-suggest-theme"    // <-- switched from vs-dark
            beforeMount={beforeMount}
            onChange={handleEditorChange1}
            onMount={handleEditorDidMount}
            options={{
              ...commonOptions,
              readOnly: false,
            }}
          />
        </div>
      )}
    </div>
  );
};

export default EditorContainer;
