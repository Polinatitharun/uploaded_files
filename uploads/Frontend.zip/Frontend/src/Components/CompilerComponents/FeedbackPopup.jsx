import React from "react";

const FeedbackPopup = ({ feedback, setFeedback, passedCount, closePopup }) => {
  if (!feedback) return null;

  return (
    <>
      {/* Old feedback popup */}
      {passedCount !== undefined && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "300vw",
            height: "100vh",
            backgroundColor: "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000,
          }}
          onClick={closePopup}
        >
          <div
            style={{
              backgroundColor: "#fff",
              padding: "20px",
              borderRadius: "10px",
              width: "350px",
              textAlign: "center",
              boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {passedCount > 0 ? (
              <p style={{ color: "green", fontWeight: "bold" }}>
                ✅ You passed {passedCount} test case{passedCount > 1 ? "s" : ""}!
              </p>
            ) : (
              <p style={{ color: "red", fontWeight: "bold" }}>
                ❌ 0 test cases passed.
              </p>
            )}
            <p style={{ marginTop: "10px", color: "#555" }}>
              Feedback: "Your code looks clean, but optimize your loops.
              need to improve in using the loops and condition updates"
            </p>
            <button
              onClick={closePopup}
              style={{
                marginTop: "15px",
                padding: "6px 12px",
                backgroundColor: "#FBB034",
                color: "#fff",
                border: "none",
                borderRadius: "4px",
                cursor: "pointer",
              }}
            >Close</button>
          </div>
        </div>
      )}

      {/* New feedback popup */}
      <div
        style={{
          height: "100vh",
          width: "100vw",
          backdropFilter: "blur(4px)",
          backgroundColor: "rgba(0,0,0,0.5)",
          position: "fixed",
          top: 0,
          left: 0,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 1000,
        }}
        onClick={closePopup}
      >
        <div
          style={{
            width: "50%",
            maxHeight: "80vh",
            backgroundColor: "#f8f9fa",
            borderRadius: "12px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Heading */}
          <h2
            style={{
              margin: "20px 15px 10px 15px",
              textAlign: "center",
              color: "#333",
            }}
          >
            Feedback
          </h2>

          {/* Feedback Message - Scrollable Section */}
          <div
            className="feedback-box"
            style={{
              flex: 1,
              overflowY: "auto",
              padding: "0 20px 15px 20px",
              textAlign: "left",
              color:
                typeof feedback === "string" &&
                  (feedback.startsWith("✅") || feedback.includes("correct"))
                  ? "#2e7d32"
                  : "#333",
              fontSize: "15px",
            }}
          >
            {/* CASE 1: String feedback (old behavior) */}
            {typeof feedback === "string" && (
              <div dangerouslySetInnerHTML={{ __html: feedback }} />
            )}

            {/* CASE 2: Object feedback (new structured feedback) */}
            {typeof feedback === "object" && (
              <div>
                {feedback.algorithm_feedback && feedback.algorithm_feedback.length > 0 && (
                  <div
                    style={{
                      backgroundColor: "#ede7f6",
                      borderRadius: "8px",
                      padding: "10px 12px",
                      marginBottom: "10px",
                    }}
                  >
                    <h4>Algorithm Feedback</h4>
                    <ul>
                      {feedback.algorithm_feedback.map((item, i) => (
                        <li key={`algo-${i}`}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {feedback.pseudocode_feedback && feedback.pseudocode_feedback.length > 0 && (
                  <div
                    style={{
                      backgroundColor: "#ede7f6",
                      borderRadius: "8px",
                      padding: "10px 12px",
                      marginBottom: "10px",
                    }}
                  >
                    <h4>Pseudocode Feedback</h4>
                    <ul>
                      {feedback.pseudocode_feedback.map((item, i) => (
                        <li key={`pseudo-${i}`}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {feedback.code_feedback && feedback.code_feedback.length > 0 && (
                  <div
                    style={{
                      backgroundColor: "#ede7f6",
                      borderRadius: "8px",
                      padding: "10px 12px",
                      marginBottom: "10px",
                    }}
                  >
                    <h4>Code Feedback</h4>
                    <ul>
                      {feedback.code_feedback.map((item, i) => (
                        <li key={`code-${i}`}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {feedback.better_code && (
                  <div>
                    <h4>Better Code</h4>
                    <pre
                      style={{
                        background: "#000",
                        color: "#fff",
                        padding: "10px",
                        borderRadius: "6px",
                        overflowX: "auto",
                        whiteSpace: "pre-wrap",
                      }}
                    >
                      {feedback.better_code}
                    </pre>
                  </div>
                )}

                {feedback.actions && feedback.actions.length > 0 && (
                  <div
                    style={{
                      backgroundColor: "#ede7f6",
                      borderRadius: "8px",
                      padding: "10px 12px",
                      marginBottom: "10px",
                    }}
                  >
                    <h4>Improvement Actions</h4>
                    <ul>
                      {feedback.actions.map((item, i) => (
                        <li key={`action-${i}`}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Close Button */}
          <div
            style={{
              padding: "10px 0 15px 0",
              borderTop: "1px solid #ddd",
              textAlign: "center",
            }}
          >
            <button
              onClick={closePopup}
              style={{
                padding: "10px 20px",
                backgroundColor: "#dc3545",
                color: "#fff",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                fontWeight: "bold",
              }}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default FeedbackPopup;
