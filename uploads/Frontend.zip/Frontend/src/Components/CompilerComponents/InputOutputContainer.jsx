import React from "react";

const InputOutputContainer = ({ input, handleInputChange, output, bottomHeight }) => {
  return (
    <div
      className="input-output-container"
      style={{ height: `${bottomHeight}%` }}
    >
      <div className="input-output-section">
        <h3>Input</h3>
        <textarea
          className="input-textarea"
          value={input}
          onChange={handleInputChange}
          placeholder="Enter input here"
          onCopy={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          onPaste={(e) => e.preventDefault()}
          style={{
            width: "100%",
            height: "calc(100% - 40px)",
            resize: "none",
            fontFamily: "monospace"
          }}
        />
      </div>

      <div className="input-output-section">
        <h3>Output</h3>
        <textarea
          className="output-textarea"
          value={output || ""}
          readOnly
          placeholder="Output will appear here after running the code"
          style={{
            width: "100%",
            height: "calc(100% - 40px)",
            resize: "none",
            fontFamily: "monospace",
            backgroundColor: "#f8f9fa"
          }}
        />
      </div>
    </div>
  );
};

export default InputOutputContainer;
