import React from 'react';
import '../Styles/Footer.css';

const Footer = () => {
  return (
    <footer>
      <hr className="footer-line" />
      <p className="copyright">&copy; 2025 Tata Consultancy Services. All rights reserved.</p>
    </footer>
  );
};

export default Footer;