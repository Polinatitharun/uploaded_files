
import React from 'react';
import { fmtMin } from '../../utils/format';

export default function TraineeProgressTable({ rows }) {
  return (
    <div className="section">
      <h2>Trainee Progress</h2>
      <div className="table">
        <div className="thead">
          <div>Trainee</div>
          <div>Topics Completed</div>
          <div>Avg Time/Topic</div>
          <div>Languages Used</div>
          <div>Parallel Activity</div>
        </div>
        {rows.map((r) => (
          <div className="trow" key={r.trainee_id}>
            <div>{r.trainee_id}</div>
            <div>{r.topics_completed}</div>
            <div>{fmtMin(r.avg_time_to_complete_ms)}</div>
            <div>{r.languages_count}</div>
            <div>{r.parallel_activity}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
