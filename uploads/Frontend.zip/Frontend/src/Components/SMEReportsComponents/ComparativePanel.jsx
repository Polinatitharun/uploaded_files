
import React from 'react';

export default function ComparativePanel({ rows }) {
  return (
    <div className="section">
      <h2>Comparative Learning (Parallel Mode)</h2>
      <p className="muted">Extend this to show time & success differentials once comparison groups are available.</p>
      <div className="table">
        <div className="thead">
          <div>Trainee</div><div>Parallel Interactions</div><div>Topics Completed</div>
        </div>
        {rows.map((r) => (
          <div className="trow" key={r.trainee_id}>
            <div>{r.trainee_id}</div>
            <div>{r.parallel_activity}</div>
            <div>{r.topics_completed}</div>
          </div>
        ))}
      </div>
    </div>
  );
}