
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function LanguageLeaderboard({ data }) {
  return (
    <div className="section">
      <h2>Language Leaderboard</h2>
      <ResponsiveContainer width="100%" height={320}>
        <BarChart data={data}>
          <XAxis dataKey="language" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="viewed" stackId="a" fill="#8884d8" name="Viewed" />
          <Bar dataKey="mcq_passed" stackId="a" fill="#82ca9d" name="MCQ Passed" />
          <Bar dataKey="coding_completed" stackId="a" fill="#ffc658" name="Coding Passed" />
          <Bar dataKey="topic_completed" stackId="a" fill="#ff8042" name="Topic Completed" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
