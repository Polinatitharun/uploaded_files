
import React from 'react';
import dayjs from 'dayjs';

const batchOptions = ['B44', 'B45', 'B46'];
const topicOptions = [
  { id: 'DSA-Stacks', title: 'Stacks' },
  { id: 'DSA-Queues', title: 'Queues' },
  { id: 'OOP-Classes', title: 'Classes & Objects' },
];
const problemOptions = [
  { id: 'TwoSum', title: 'Two Sum' },
  { id: 'ReverseLL', title: 'Reverse Linked List' },
  { id: 'ValidParentheses', title: 'Valid Parentheses' },
];

export default function FiltersBar({ dateISO, batchId, topicId, problemId, onChange }) {
  return (
    <div className="filters">
      <label>
        Batch :
        <select value={batchId} onChange={(e) => onChange({ batchId: e.target.value })}>
          {batchOptions.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </label>
      <label>
        Date:
        <input type="date" value={dateISO} onChange={(e) => onChange({ dateISO: e.target.value })} />
      </label>
      <label>
        Topic :
        <select value={topicId || ''} onChange={(e) => onChange({ topicId: e.target.value })}>
          <option value="">Select Topic</option>
          {topicOptions.map((option) => (
            <option key={option.id} value={option.id}>
              {option.title}
            </option>
          ))}
        </select>
      </label>
      <label>
        Problem :
        <select value={problemId || ''} onChange={(e) => onChange({ problemId: e.target.value })}>
          <option value="">Select Problem</option>
          {problemOptions.map((option) => (
            <option key={option.id} value={option.id}>
              {option.title}
            </option>
          ))}
        </select>
      </label>
    </div>
  );
}
