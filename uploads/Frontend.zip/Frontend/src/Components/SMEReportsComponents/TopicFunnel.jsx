
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function TopicFunnel({ data, topicId }) {
  return (
    <div className="section">
      <h2>Topic Funnel — {topicId || 'Select a topic'}</h2>
      <ResponsiveContainer width="100%" height={320}>
        <BarChart data={data}>
          <XAxis dataKey="language" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="viewed" fill="#8884d8" name="Viewed" />
          <Bar dataKey="mcq_passed" fill="#82ca9d" name="MCQ Passed" />
          <Bar dataKey="coding_completed" fill="#ffc658" name="Coding Passed" />
          <Bar dataKey="completed" fill="#ff8042" name="Completed" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
