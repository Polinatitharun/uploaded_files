import React from 'react';
import KpiCard from '../SMEReportsComponents/KpiCard';
import { fmtInt, fmtMin } from '../../utils/format';

export default function BatchSummary({ summary }) {
  return (
    <div className="section">
      <h2>Batch Summary</h2>
      <div className="kpi-grid">
        <KpiCard title="Active Trainees" value={fmtInt(summary.activeTrainees)} />
        <KpiCard title="Topic Views" value={fmtInt(summary.topicViews)} />
        <KpiCard title="Topics Completed" value={fmtInt(summary.topicsCompleted)} />
        <KpiCard title="Avg MCQ Time" value={fmtMin(summary.avgMcqDurationMs)} />
        <KpiCard title="Avg Coding Time" value={fmtMin(summary.avgCodingDurationMs)} />
        <KpiCard title="Most Trending Topic" value={summary.mostTrendingTopic} />
        <KpiCard title="Least Trending Topic" value={summary.leastTrendingTopic} />
        <KpiCard title="Most Trending Language" value={summary.mostTrendingLanguage} />
        <KpiCard title="Least Trending Language" value={summary.leastTrendingLanguage} />
      </div>
    </div>
  );
}
