
import React from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function ProblemStats({ data, problemId }) {
  return (
    <div className="section">
      <h2>Problem Analytics — {problemId || 'Select a problem'}</h2>
      <ResponsiveContainer width="100%" height={340}>
        <ComposedChart data={data}>
          <XAxis dataKey="language" />
          <YAxis yAxisId="left" />
          <YAxis yAxisId="right" orientation="right" />
          <Tooltip />
          <Legend />
          <Bar yAxisId="left" dataKey="attempts" fill="#8884d8" name="Attempts" />
          <Bar yAxisId="left" dataKey="solved" fill="#82ca9d" name="Solved" />
          <Line yAxisId="right" type="monotone" dataKey="avgTimeMs" stroke="#ff7300" dot={false} name="Avg Time (ms)" />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
