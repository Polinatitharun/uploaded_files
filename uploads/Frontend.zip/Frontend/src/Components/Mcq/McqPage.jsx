import React, { useEffect, useState, useMemo } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import "./McqPage.css";
import Navbar from "../common/NavBar/Navbar";
import { toast, Toaster } from "sonner";

// --- Utility: Get topicId for quiz fetch ---
const getTopicIdFromSubtopic = (subtopic) => {
  const apiData = JSON.parse(localStorage.getItem("fetchedAPIData") || "[]");
  for (const mainTopic of apiData) {
    if (!mainTopic.subTopics) continue;
    const foundSubtopic = mainTopic.subTopics.find(
      (st) => st.title.trim().toLowerCase() === subtopic.trim().toLowerCase()
    );
    if (foundSubtopic) return foundSubtopic.topicId;
  }
  return 1; // fallback
};

// --- Ensure COURSE_STRUCTURE is available ---
const ensureCourseStructure = () => {
  let structure = JSON.parse(localStorage.getItem("COURSE_STRUCTURE") || "[]");
  if (structure.length === 0) {
    const apiData = JSON.parse(localStorage.getItem("fetchedAPIData") || "[]");
    structure = apiData.map((main) => ({
      mainTopicName: main.mainTopicName,
      subTopicTitles: main.subTopics.map((s) => s.title),
    }));
    localStorage.setItem("COURSE_STRUCTURE", JSON.stringify(structure));
  }
  return structure;
};

// --- Find current topic group and subtopic index ---
const getTopicGroupAndIndex = (subtopic) => {
  const structure = ensureCourseStructure();
  for (const mainTopic of structure) {
    const idx = mainTopic.subTopicTitles.indexOf(subtopic);
    if (idx !== -1) {
      return {
        group: mainTopic.mainTopicName,
        index: idx,
        subTopics: mainTopic.subTopicTitles,
      };
    }
  }
  return null;
};

// --- Get next subtopic ---
const getNextSubtopic = (currentSubtopic) => {
  const info = getTopicGroupAndIndex(currentSubtopic);
  if (!info) return null;
  const { subTopics, index } = info;
  return subTopics[index + 1] || null;
};


function McqPage({ onLogout }) {
  const { topic: quizContentKey } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  //  Read mainTopic, subtopic, and selectedLanguage from state, as passed from LearningPage
  const { mainTopic, subtopic, selectedLanguage } = location.state || {};

  const topicId = useMemo(() => {
    if (subtopic) {
      return getTopicIdFromSubtopic(subtopic);
    }
    return getTopicIdFromSubtopic(quizContentKey);
  }, [subtopic, quizContentKey]);

  const language = useMemo(() => {
    return selectedLanguage ? selectedLanguage.toUpperCase() : 'PYTHON';
  }, [selectedLanguage]);

  // --- State Hooks ---
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [isCorrect, setIsCorrect] = useState(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [loading, setLoading] = useState(true);

  // --- Fetch Questions ---
  const fetchQuestions = async () => {
    if (!topicId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/user/mcqs/topic/${topicId}/language/${language}`
      );

      const rawQuestions = response.data || [];
      const transformed = rawQuestions.map((q) => {
        const options = q.content.options.map((opt) => ({
          id: opt.id, // Adjust to 0-based indexing
          value: opt.value,
        }));
        

        return {
          question: q.content.question,
          options,
          correctOptionId: q.content.correctOptionId, // Adjust to 0-based indexing
          explanation: q.content.explanation,
        };
      });

      const shuffled = [...transformed].sort(() => 0.5 - Math.random());
      const selectedQuestions = shuffled.slice(0, 10);
      setQuestions(selectedQuestions);
    } catch (error) {
      console.error("Error fetching questions:", error);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setScore(0);
    setShowResult(false);
    fetchQuestions();
  }, [topicId]);

  // --- Handle Answer Selection ---
  const handleAnswerSelection = (optionId) => {
    if (isCorrect !== null) return;
    setSelectedAnswer(optionId);
    const correctOptionId = questions[currentQuestion]?.correctOptionId;
    const correct = optionId === correctOptionId;
    setIsCorrect(correct);
    if (correct) setScore((prev) => prev + 1);
  };

  const handleNext = () => {
    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion((prev) => prev + 1);
      setSelectedAnswer(null);
      setIsCorrect(null);
    } else {
      setShowResult(true);
    }
  };

  const handleRetake = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
    setIsCorrect(null);
    fetchQuestions();
  };

  // --- Mark quiz completed (Updates local storage for persistence/other tabs) ---
  const markQuizCompleted = () => {
    if (!mainTopic || !subtopic) return;

    const currentKey = `${mainTopic}::${subtopic}::passed`;
    const saved = JSON.parse(localStorage.getItem("completedQuizzes") || "[]");

    if (!saved.includes(currentKey)) {
      saved.push(currentKey);
      localStorage.setItem("completedQuizzes", JSON.stringify(saved));

      try {
        window.dispatchEvent(new Event("completedQuizzesUpdated"));
      } catch (e) {
        console.warn("Could not dispatch completedQuizzesUpdated event", e);
      }
    }
  };

  // Triggers the local storage update when quiz is passed
  useEffect(() => {
    if (!showResult) return;
    const total = questions.length || 1;
    const percent = (score / total) * 100;
    // We update local storage here, the actual markQuizPassed hook runs on LearningPage.
    if (percent >= 60) {
      markQuizCompleted();
      // Call API to mark MCQ as visited
      const markMcqVisited = async () => {
        try {
          await axios.put(`http://localhost:8081/api/user/learning/progress/${topicId}/mcq-visited?language=${language.toLowerCase()}`);
        } catch (error) {
          console.error("Error marking MCQ as visited:", error);
        }
      };
      markMcqVisited();
    }
  }, [showResult, questions.length, score, mainTopic, subtopic, topicId, language]);

  // --- Handle Navigation (FIXED Logic) ---
  const handleNavigation = (status) => {
    if (!subtopic || !mainTopic) {
      navigate("/teachinghub");
      return;
    }

    if (status === "pass") {
      const nextSub = getNextSubtopic(subtopic);
      const navState = {
        quizPassed: true,
        mainTopic: mainTopic,
        subtopic: nextSub || subtopic // Navigate to next or stay on current
      };

      if (nextSub) {
        toast.success(` You passed! Redirecting to "${nextSub}"...`);
      } else {
        toast.info(" You’ve completed all subtopics in this main topic!");
      }

      setTimeout(() => {
        // ✅ CRITICAL FIX: Pass the state that triggers markQuizPassed on LearningPage
        navigate("/teachinghub", { state: navState });
      }, 1500);
    } else {
      // Revisit subtopic
      navigate("/teachinghub", { state: { subtopic: subtopic } });
    }
  };

  // --- Handle Back Button ---
  const handleBack = () => {
    if (subtopic) {
      navigate("/teachinghub", { state: { subtopic: subtopic } });
    } else {
      navigate("/teachinghub");
    }
  };

  // --- UI ---
  const totalQuestions = questions.length;
  const percent = totalQuestions ? (score / totalQuestions) * 100 : 0;

  return (
    <>
      <Navbar onLogout={onLogout} />
      <Toaster richColors position="top-center" />
      <div className="quiz-container">
        {/* TOPIC HEADER WITH BACK BUTTON */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <h1>Quiz: {subtopic || 'Loading...'}</h1>
          <button onClick={handleBack} className="action-btn retake">Back to Learning</button>
        </div>

        {loading ? (
          <p>Loading questions...</p>
        ) : showResult ? (
          <div className="result-box">
            <h2 id="res-head">Quiz Completed!</h2>
            <p className="result-p">
              <strong className="result-s">Total Questions:</strong>{" "}
              {totalQuestions}
            </p>
            <p className="result-p">
              <strong className="result-s">Correct Answers:</strong> {score}
            </p>
            <p className="result-p">
              <strong className="result-s">Percentage:</strong>{" "}
              {percent.toFixed(2)}%
            </p>
            <p className={`status ${percent >= 60 ? "pass" : "fail"}`}>
              Status: {percent >= 60 ? "Pass" : "Fail"}
            </p>
            <div className="result-buttons">
              <button className="action-btn retake" onClick={handleRetake}>
                Retake Quiz
              </button>
              {percent >= 60 ? (
                <button
                  className="action-btn next"
                  onClick={() => handleNavigation("pass")}
                >
                  Next Subtopic
                </button>
              ) : (
                <button
                  className="action-btn revisit"
                  onClick={() => handleNavigation("fail")}
                >
                  Revisit Subtopic
                </button>
              )}
            </div>
          </div>
        ) : questions.length > 0 ? (
          <div className="question-box">
            <h3>Question {currentQuestion + 1} of {totalQuestions}</h3>
            <p className="question-text">{questions[currentQuestion].question}</p>
            <ul className="options-list">
              {questions[currentQuestion].options.map((option) => (
                <li
                  key={option.id}
                  className={
                    selectedAnswer === option.id
                      ? isCorrect
                        ? "correct"
                        : "incorrect"
                      : ""
                  }
                >
                  <label className="option-item">
                    <input
                      type="radio"
                      name="answer"
                      value={option.id}
                      checked={selectedAnswer === option.id}
                      onChange={() => handleAnswerSelection(option.id)}
                      disabled={isCorrect !== null}
                    />
                    {option.value}
                  </label>
                </li>
              ))}
            </ul>
            {isCorrect !== null && (
              <>
                <div
                  className={`feedback ${isCorrect ? "correct" : "incorrect"}`}
                >
                  {isCorrect ? "Correct!" : "Incorrect!"}
                </div>
                <p id="feedback">{questions[currentQuestion].explanation}</p>
              </>
            )}
            <button
              className="next-button"
              onClick={handleNext}
              disabled={selectedAnswer === null}
            >
              {currentQuestion < questions.length - 1 ? "Next" : "Finish"}
            </button>
          </div>
        ) : (
          <p>No questions available for this topic. Please ensure the topic is correctly configured.</p>
        )}
      </div>
    </>
  );
}

export default McqPage;