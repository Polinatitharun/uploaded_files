import React, { useEffect, useState } from "react";
import { useFetcher, useNavigate } from "react-router-dom";
import "./MCQHome.css";
import Navbar from "../common/NavBar/Navbar";
import { FaJava } from "react-icons/fa";
import { FaPython } from "react-icons/fa";
import { Link } from "react-router-dom";
import axios from "axios";

function MCQHome({ onLogout }) {
  const navigate = useNavigate();
  const [mcqData, setMcqData] = useState([]);
 
  async function fetchGeneratedMCQ() {
    try {
      const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/sme/mcq-getall`);
      setMcqData(response.data);
    } catch (error) {
    }
  }
  useEffect(() => {
      fetchGeneratedMCQ();
    }, []);
  return (
    <>
      <Navbar onLogout={onLogout} />
      <div className="home-container">
        <div className="title-bar">
          <h1 className="title">Test Your Knowledge</h1>
          {/* <button className="report-btn" onClick={() => navigate("/report_page")}>Check your results</button> */}
        </div>

        <div className="quiz-sections">
        {mcqData.length === 0 ? (
              <p>No MCQs found.</p>
            ) : (
              mcqData.map((item, index) => (
                <div key={index} className="llmgen-card">
                  <div className="mcq-card">
                    <p><strong className="mcq-topic">{item.topic}</strong></p>
                    <button onClick={() => navigate(`/mcq_page/${item.topic}`) } className="mcq-btn">Start Quiz</button>
                  </div>
                </div>
              ))
            )}
        </div>
      </div>
    </>
  );
}

export default MCQHome;
