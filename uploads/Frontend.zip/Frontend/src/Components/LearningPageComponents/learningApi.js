import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// ========== A. TOPIC & CONTENT APIs ==========

export const getAllMainTopics = async () => {
    const response = await axios.get(
        `${BASE_URL}/api/user/learning/main-topics`,
        { withCredentials: true }
    );
    return response.data;
};

export const getSubtopicsByMainTopic = async (mainTopicId) => {
    const response = await axios.get(
        `${BASE_URL}/api/user/learning/main-topics/${mainTopicId}/subtopics`,
        { withCredentials: true }
    );
    return response.data;
};

export const getSubtopicContent = async (subtopicId) => {
    const response = await axios.get(
        `${BASE_URL}/api/user/learning/subtopics/${subtopicId}`,
        { withCredentials: true }
    );
    return response.data;
};

// ========== B. TIMER APIs ==========

export const getMainTopicTimer = async (mainTopicId) => {
    const response = await axios.get(
        `${BASE_URL}/api/user/learning/time-tracking/main-topic/${mainTopicId}`,
        { withCredentials: true }
    );
    return response.data;
};

export const sendTimeDelta = async (subtopicId, language, deltaSeconds) => {
    const response = await axios.post(
        `${BASE_URL}/api/user/learning/time-tracking/delta`,
        {
            subtopicId,
            language: language.toUpperCase(),
            deltaSeconds
        },
        { withCredentials: true }
    );
    return response.data;
};

export const sendTimeDeltaBeacon = (subtopicId, language, deltaSeconds) => {
    if (!navigator.sendBeacon) {
        try {
            fetch(`${BASE_URL}/api/user/learning/time-tracking/delta`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify({
                    subtopicId,
                    language: language.toUpperCase(),
                    deltaSeconds
                }),
                keepalive: true
            });
        } catch (error) {
            console.error("Failed to send time delta on unload:", error);
        }
        return;
    }

    const data = JSON.stringify({
        subtopicId,
        language: language.toUpperCase(),
        deltaSeconds
    });

    const blob = new Blob([data], { type: "application/json" });
    return navigator.sendBeacon(
        `${BASE_URL}/api/user/learning/time-tracking/delta`,
        blob
    );
};

// ========== C. PROGRESS / COMPLETION APIs ==========

export const getMarkCompleteStatus = async (mainTopicId, language) => {
    const response = await axios.get(
        `${BASE_URL}/api/user/learning/progress/mark-complete-status`,
        {
            withCredentials: true,
            params: {
                mainTopicId,
                language: language.toUpperCase()
            }
        }
    );
    return response.data;
};

export const markTopicComplete = async (mainTopicId, language) => {
    const response = await axios.put(
        `${BASE_URL}/api/user/learning/progress/${mainTopicId}/mark-complete`,
        null,
        {
            withCredentials: true,
            params: {
                language: language.toUpperCase()
            }
        }
    );
    return response.data;
};

export const getMcqStatus = async (subtopicId) => {
    const response = await axios.get(
        `${BASE_URL}/api/user/learning/progress/mcq-status/${subtopicId}`,
        { withCredentials: true }
    );
    return response.data;
};

export const markMcqVisited = async (subtopicId, language) => {
    const response = await axios.put(
        `${BASE_URL}/api/user/learning/progress/${subtopicId}/mcq-visited`,
        null,
        {
            withCredentials: true,
            params: {
                language: language.toUpperCase()
            }
        }
    );
    return response.data;
};