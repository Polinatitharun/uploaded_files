import React, { useState, useEffect } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { TbCheck } from "react-icons/tb";

export function Sidebar({
    topics,
    selectedTopic,
    setSelectedTopic,
    selectedSubtopic,
    setSelectedSubtopic,
    completedItems,
    selectedLanguage
}) {
    const [openTopic, setOpenTopic] = useState(selectedTopic);

    useEffect(() => setOpenTopic(selectedTopic), [selectedTopic]);

    const toggleTopic = (title) => {
        const newOpenTopic = openTopic === title ? null : title;
        setSelectedTopic(title); // Always update the selectedTopic

        setOpenTopic(newOpenTopic);

        const topicEntry = topics.find(t => t.mainTopicName === title);
        if (newOpenTopic === title && topicEntry && topicEntry.subTopics.length > 0) {
            const isCurrentSubtopicValid = topicEntry.subTopics.some(sub => sub.title === selectedSubtopic);
            if (!isCurrentSubtopicValid) {
                setSelectedSubtopic(topicEntry.subTopics[0].title);
            }
        }
    };

    const selectSubtopic = (subTitle) => {
        // Find the main topic for the selected subtopic
        const newTopic = topics.find(t => t.subTopics.some(s => s.title === subTitle))?.mainTopicName;

        // If the main topic is different, update both topic and openTopic state
        if (newTopic && newTopic !== selectedTopic) {
            setSelectedTopic(newTopic);
            setOpenTopic(newTopic);
        }

        // Always set the new subtopic
        setSelectedSubtopic(subTitle);
    };

    // Checks for subtopic completion (marked as complete for the current selected language)
    const isSubtopicCompleted = (mainTopicName, subTitle) =>
        completedItems.includes(`${mainTopicName}::${selectedLanguage}`);

    // Checks for main topic completion (all subtopics complete)
    const isMainTopicCompleted = (mainTopicName) => {
        const topicData = topics.find(t => t.mainTopicName === mainTopicName);
        if (!topicData) return false;

        // Get all subtopics of this main topic
        const allSubtopics = topicData.subTopics || [];

        // The languages that must be marked as complete by the user
        const allLanguages = ["Java", "Python", "JavaScript", "TypeScript"];

        // Each subtopic must have ALL languages marked complete
        const isEverySubtopicFullyCompleted = allSubtopics.every(sub =>
            allLanguages.every(lang =>
                completedItems.includes(`${mainTopicName}::${lang}`)
            )
        );

        // Return true only if all subtopics across all languages are marked complete
        return isEverySubtopicFullyCompleted;
    };

    return (
        <div
            style={{
                width: 260,
                minWidth: 260,
                background: "#09122C",
                color: "#fff",
                position: "sticky",
                top: 0,
                height: "90vh",
                overflowY: "auto",
                paddingBottom: "100px",
                scrollBehavior: "smooth",
                fontFamily: "sans-serif",
                padding: "20px 0",
                boxSizing: "border-box",
                borderRight: "1px solid rgba(255, 255, 255, 0.1)",
            }}
            className="custom-scrollbar"
        >
            <div
                style={{
                    fontWeight: "bold",
                    textAlign: "center",
                    fontSize: 22,
                    marginBottom: 20,
                    letterSpacing: "0.5px",
                }}
            >
                Topics
            </div>
            
            <style>{`
                .custom-scrollbar::-webkit-scrollbar {
                    width: 6px;
                }
                .custom-scrollbar::-webkit-scrollbar-track {
                    background: rgba(255, 255, 255, 0.05);
                }
                .custom-scrollbar::-webkit-scrollbar-thumb {
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 3px;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                    background: rgba(255, 255, 255, 0.3);
                }
            `}</style>

            <ul style={{ listStyle: "none", padding: 0, margin: "16px 0" }}>
                {topics.map((mainTopic) => {
                    const mainTopicCompleted = isMainTopicCompleted(mainTopic.mainTopicName);
                    return (
                        <li style={{ marginBottom: 14 }} key={mainTopic.mainTopicId}>
                            {/* Main Topic */}
                            <div
                                style={{
                                    marginLeft: 16,
                                    marginRight: 16,
                                    fontWeight: 600,
                                    cursor: "pointer",
                                    transition: "all 0.2s ease",
                                    backgroundColor: selectedTopic === mainTopic.mainTopicName ? "rgba(221, 107, 32, 0.15)" : "transparent",
                                    fontSize: "1.05rem",
                                    borderRadius: "6px",
                                    padding: "10px 12px",
                                    marginBottom: 8,
                                    marginTop: 8,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    border: selectedTopic === mainTopic.mainTopicName ? "1px solid rgba(221, 107, 32, 0.3)" : "1px solid transparent",
                                }}
                                onClick={() => toggleTopic(mainTopic.mainTopicName)}
                                onMouseEnter={(e) => {
                                    if (selectedTopic !== mainTopic.mainTopicName) {
                                        e.currentTarget.style.backgroundColor = "rgba(255, 255, 255, 0.05)";
                                    }
                                }}
                                onMouseLeave={(e) => {
                                    if (selectedTopic !== mainTopic.mainTopicName) {
                                        e.currentTarget.style.backgroundColor = "transparent";
                                    }
                                }}
                            >
                                <span>{mainTopic.mainTopicName}</span>

                                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                    {mainTopicCompleted && <TbCheck style={{ color: "#4ADE80", fontSize: "18px" }} />}
                                    {openTopic === mainTopic.mainTopicName ? (
                                        <FaChevronUp style={{ color: "#fff", fontSize: "12px" }} />
                                    ) : (
                                        <FaChevronDown style={{ color: "#fff", fontSize: "12px" }} />
                                    )}
                                </div>
                            </div>

                            {/* Subtopics */}
                            {openTopic === mainTopic.mainTopicName && mainTopic.subTopics.length > 0 && (
                                <ul style={{ listStyle: "none", margin: "8px 0", paddingLeft: 32, paddingRight: 16 }}>
                                    {mainTopic.subTopics.map((subTopic) => {
                                        const completed = isSubtopicCompleted(
                                            mainTopic.mainTopicName,
                                            subTopic.title
                                        );
                                        return (
                                            <li
                                                key={subTopic.topicId}
                                                style={{
                                                    fontWeight: selectedSubtopic === subTopic.title ? 500 : 400,
                                                    marginTop: 6,
                                                    cursor: "pointer",
                                                    backgroundColor:
                                                        selectedSubtopic === subTopic.title ? "#DD6B20" : "transparent",
                                                    fontSize: "0.95rem",
                                                    borderRadius: "6px",
                                                    padding: "8px 12px",
                                                    transition: "all 0.2s ease",
                                                    display: "flex",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                }}
                                                onClick={() => selectSubtopic(subTopic.title)}
                                                onMouseEnter={(e) => {
                                                    if (selectedSubtopic !== subTopic.title) {
                                                        e.currentTarget.style.backgroundColor = "rgba(255, 255, 255, 0.08)";
                                                    }
                                                }}
                                                onMouseLeave={(e) => {
                                                    if (selectedSubtopic !== subTopic.title) {
                                                        e.currentTarget.style.backgroundColor = "transparent";
                                                    }
                                                }}
                                            >
                                                <span>{subTopic.title}</span>
                                                {completed && <TbCheck style={{ color: "#4ADE80", fontSize: "16px", marginLeft: 8 }} />}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </li>
                    );
                })}
            </ul>
        </div>
    );
}

