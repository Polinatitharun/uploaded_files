import React, { useEffect, useMemo, useState } from 'react';
import * as learningApi from "./learningApi";

export function TopicProgressBar({
  selectedTopic,
  selectedSubtopic,
  selectedLanguage,
  completedItems = [],
  fetchedData = []
}) {
  // Find the topic data
  const topicData = useMemo(
    () => fetchedData?.find((t) => t?.mainTopicName === selectedTopic),
    [fetchedData, selectedTopic]
  );

  if (!topicData) return null;

  const subtopics = topicData.subTopics || [];
  const totalSubtopics = subtopics.length;
  const totalPoints = 10;
  const pointsPerSubtopic = totalSubtopics > 0 ? totalPoints / totalSubtopics : 0;

  // Local state for loading/error and mcqStatus cache
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [loadError, setLoadError] = useState(null);
  const [mcqStatusBySubtopic, setMcqStatusBySubtopic] = useState({});

  // Fetch ALL subtopic contents once so we can compute progress correctly
  useEffect(() => {
    let cancelled = false;

    async function fetchAllSubtopicContents() {
      // If no subtopics or missing API, nothing to do
      if (!Array.isArray(subtopics) || subtopics.length === 0 || !learningApi?.getSubtopicContent) {
        setMcqStatusBySubtopic({});
        return;
      }

      setIsLoadingContent(true);
      setLoadError(null);

      try {
        const results = await Promise.all(
          subtopics.map(async (s) => {
            // Guard against missing topicId
            if (!s?.topicId) {
              return { title: s?.title, mcqStatus: {} };
            }
            try {
              const content = await learningApi.getSubtopicContent(s.topicId);
              return { title: s.title, mcqStatus: content?.mcqStatus || {} };
            } catch (err) {
              // If one fails, keep going; mark empty status for that subtopic
              return { title: s.title, mcqStatus: {} };
            }
          })
        );

        if (!cancelled) {
          const map = results.reduce((acc, { title, mcqStatus }) => {
            if (title) acc[title] = mcqStatus || {};
            return acc;
          }, {});
          setMcqStatusBySubtopic(map);
        }
      } catch (err) {
        if (!cancelled) {
          setLoadError(err?.message || 'Failed to load subtopic contents.');
        }
      } finally {
        if (!cancelled) {
          setIsLoadingContent(false);
        }
      }
    }

    fetchAllSubtopicContents();

    return () => {
      cancelled = true;
    };
    // Re-run when topic changes or learningApi instance changes
  }, [topicData, learningApi]);

  // Pure helper: check if language is ticked for a subtopic
  const isLanguageTicked = (subtopicTitle, lang) => {
    if (!subtopicTitle || !lang) return false;
    const status = mcqStatusBySubtopic?.[subtopicTitle];
    return Boolean(status?.[String(lang).toLowerCase()]);
  };

  // Count completed subtopics: both completion marker & language tick required
  const completedSubtopics = useMemo(() => {
    if (!Array.isArray(subtopics) || subtopics.length === 0) return 0;

    return subtopics.filter((sub) => {
      const completionKey = `${selectedTopic}::${sub.title}::subtopic_complete`;
      const isCompleted = completedItems.includes(completionKey);
      const langTicked = isLanguageTicked(sub.title, selectedLanguage);
      return isCompleted && langTicked;
    }).length;
  }, [subtopics, completedItems, selectedTopic, selectedLanguage, mcqStatusBySubtopic]);

  // Calculate points and percentage
  const earnedPoints = completedSubtopics * pointsPerSubtopic;
  const percentage = totalSubtopics > 0 ? (completedSubtopics / totalSubtopics) * 100 : 0;

  // (Optional) show the selected subtopic's language status to the user
  const selectedLangTicked = isLanguageTicked(selectedSubtopic, selectedLanguage);

  return (
    <div style={{ marginTop: '20px',width: "300px", marginBottom: "10px"}}>
      {/* Optional loading/error banner */}
      {isLoadingContent && (
        <div style={{ textAlign: 'center', color: '#666', marginBottom: '8px' }}>
          Loading subtopic progress…
        </div>
      )}
      {loadError && (
        <div style={{ textAlign: 'center', color: '#B00020', marginBottom: '8px' }}>
          {loadError}
        </div>
      )}

      {/* Points Display */}
      <div
        style={{
          textAlign: 'center',
          fontSize: '14px',
          fontWeight: 'bold',
          color: '#09122C',
          marginBottom: '10px',
        }}
      >
        Points: {earnedPoints.toFixed(1)} / {totalPoints.toFixed(1)}
      </div>

      {/* Progress Bar */}
      <div
        style={{
          width: '100%',
          height: '10px',
          backgroundColor: '#e0e0e0',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        }}
      >
        <div
          style={{
            width: `${percentage}%`,
            height: '100%',
            backgroundColor: '#DD6B20',
            transition: 'width 0.3s ease-in-out',
          }}
        />
      </div>

      {/* Progress Text */}
      <div
        style={{
          textAlign: 'center',
          fontSize: '12px',
          color: '#666',
          marginTop: '5px',
        }}
      >
        {completedSubtopics} / {totalSubtopics} subtopics completed ({percentage.toFixed(1)}%) in {selectedLanguage}
      </div>

      {/* Optional: Selected subtopic language status */}
      {/* {selectedSubtopic && selectedLanguage && (
        <div
          style={{
            textAlign: 'center',
            fontSize: '13px',
            color: selectedLangTicked ? '#2E7D32' : '#B00020',
            marginTop: '6px',
          }}
        >
        “{selectedSubtopic}” in {selectedLanguage}: {selectedLangTicked ? 'Completed' : 'Not completed'}
        </div>
      )} */}
    </div>
  );
}
