import React, { useState, useRef } from 'react';
import Editor from '@monaco-editor/react';
import { FaPlay, FaTimes } from 'react-icons/fa';
import axios from 'axios';

const TryOutEditor = ({ codeSnippet, onClose, language }) => {
    // Create wrapper code based on language
    const [code, setCode] = useState(codeSnippet);
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [isRunning, setIsRunning] = useState(false);

    const beforeMount = (monaco) => {
        monaco.editor.defineTheme("my-suggest-theme", {
            base: "vs",
            inherit: true,
            rules: [],
            colors: {
                "editorSuggestWidget.background": "#ffffff",
                "editorSuggestWidget.foreground": "#222222",
                "editorSuggestWidget.highlightForeground": "#c85400",
                "editorSuggestWidget.selectedBackground": "#e6f0ff",
                "editorSuggestWidget.selectedForeground": "#000000",
                "editorSuggestWidget.border": "#cbd5e1",
                "list.dropBackground": "#f0f7ff",
                "list.activeSelectionBackground": "#dbeafe",
                "list.activeSelectionForeground": "#0b0f17",
                "list.focusBackground": "#000",
                "list.focusForeground": "#0b0f17",
                "list.hoverBackground": "#f7fafc",
                "list.hoverForeground": "#0b0f17",
                "list.highlightForeground": "#078916ff",
                "editorWidget.background": "#ffffff",
                "editorWidget.border": "#cbd5e1",
            },
        });
    };


    const handleRun = async () => {
        if (!code.trim()) {
            setOutput("Please write some code first.");
            return;
        }

        setIsRunning(true);
        setOutput("Running...");

        try {
            const response = await axios.post(`${import.meta.env.VITE_CODE_EXECUTOR_URL}/api/v1/run`, {
                language: language.toLowerCase(),
                source: code,
                input: input.replace(" ", "\n")
            });

            let outputText = response.data.output || "No output received";
            if (response.data.error.startsWith("Malicious code detected:")) {
                outputText = "Malicious code detected! Forbidden keywords used!";
            }
            setOutput(outputText);
        } catch (error) {
            console.error("Run error:", error);
            setOutput(error.response?.data?.error || "Compilation/Runtime Error");
        } finally {
            setIsRunning(false);
        }
    };

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
        }}>
            <div style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '20px',
                width: '80%',
                maxWidth: '1200px',
                height: '80%',
                display: 'flex',
                flexDirection: 'column',
                position: 'relative'
            }}>
                <button
                    onClick={onClose}
                    style={{
                        position: 'absolute',
                        top: '10px',
                        right: '10px',
                        background: 'none',
                        border: 'none',
                        fontSize: '20px',
                        cursor: 'pointer',
                        color: 'black'
                    }}
                >
                    <FaTimes />
                </button>

                <h2>Try Out Editor</h2>

                <div style={{ display: 'flex', flex: 1, gap: '20px', marginTop: '20px' }}>
                    {/* Editor Section */}
                    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                        <h3>Code Editor</h3>
                        <div style={{ flex: 1, border: '1px solid #ccc', borderRadius: '4px' }}>
                            <Editor
                                height="100%"
                                language={language.toLowerCase()}
                                value={code}
                                onChange={setCode}
                                theme="my-suggest-theme"
                                beforeMount={beforeMount}
                                options={{
                                    minimap: { enabled: false },
                                    fontSize: 14,
                                    wordWrap: 'on'
                                }}
                            />
                        </div>
                    </div>

                    {/* Input/Output Section */}
                    <div style={{ flex: 0.5, display: 'flex', flexDirection: 'column', gap: '50px' }}>
                        {/* Input */}
                        <div style={{ flex: 1 }}>
                            <h3>Input</h3>
                            <textarea
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Enter input here..."
                                style={{
                                    width: '100%',
                                    height: '100%',
                                    padding: '10px',
                                    border: '1px solid #ccc',
                                    borderRadius: '4px',
                                    fontFamily: 'monospace',
                                    resize: 'none',
                                    boxSizing: "border-box"
                                }}
                            />
                        </div>

                        {/* Output */}
                        <div style={{ flex: 1, marginBottom: "10px" }}>
                            <h3>Output</h3>
                            <textarea
                                value={output}
                                readOnly
                                placeholder="Output will appear here..."
                                style={{
                                    width: '100%',
                                    height: '100%',
                                    padding: '10px',
                                    border: '1px solid #ccc',
                                    borderRadius: '4px',
                                    fontFamily: 'monospace',
                                    backgroundColor: '#f9f9f9',
                                    resize: 'none'
                                }}
                            />
                        </div>

                        {/* Run Button */}
                        <button
                            onClick={handleRun}
                            disabled={isRunning}
                            style={{
                                padding: '10px 20px',
                                backgroundColor: isRunning ? '#ccc' : '#09122C',
                                color: '#fff',
                                border: 'none',
                                borderRadius: '4px',
                                cursor: isRunning ? 'not-allowed' : 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '10px',
                                width: "100%"
                            }}
                        >
                            <FaPlay />
                            {isRunning ? 'Running...' : 'Run'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TryOutEditor;
