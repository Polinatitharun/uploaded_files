import React, { useState } from "react";
import "../styles/SubtopicModal.css";

const SubtopicModal = ({ subtopic, onClose, onSave, onDelete }) => {
  if (!subtopic) return null;

  const { title, content, topicId } = subtopic;
  const languageDetails = content?.subtopic?.content?.language_details || [];
  const codeDifferenceExplanation = content?.subtopic?.content?.code_difference_explaination || "";

  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(title);
  const [editedExplanation, setEditedExplanation] = useState(codeDifferenceExplanation);
  const [editedLanguageDetails, setEditedLanguageDetails] = useState(languageDetails.map(lang => ({ ...lang })));

  const handleSave = () => {
    const updatedSubtopic = {
      title: editedTitle,
      code_difference_explaination: editedExplanation,
      language_details: editedLanguageDetails
    };
    onSave(topicId, updatedSubtopic, subtopic);
    setIsEditing(false);
    
  };

  const handleCancel = () => {
    setEditedTitle(title);
    setEditedExplanation(codeDifferenceExplanation);
    setEditedLanguageDetails(languageDetails.map(lang => ({ ...lang })));
    setIsEditing(false);
  };

  const updateLanguageDetail = (index, field, value) => {
    const updated = [...editedLanguageDetails];
    updated[index][field] = value;
    setEditedLanguageDetails(updated);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="modal-content"
        onClick={(e) => e.stopPropagation()} // prevent overlay close when clicking inside
      >
        {/* ✅ Fixed Header */}
        <div className="modal-header">
          <button className="modal-close-btn" onClick={onClose}>
            ✕
          </button>

          <div className="modal-header-text">
            <h2 className="modal-title">
              {isEditing ? (
                <input
                  type="text"
                  value={editedTitle}
                  onChange={(e) => setEditedTitle(e.target.value)}
                  style={{ fontSize: "1.5em", fontWeight: "bold", border: "1px solid #ccc", padding: "4px" }}
                />
              ) : (
                title
              )}
            </h2>
          </div>
          <div style={{ display: "flex", gap: "10px" }}>
            {isEditing ? (
              <>
                <button
                  className="info-btn"
                  onClick={handleSave}
                  style={{ backgroundColor: "#28a745", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6 }}
                >
                  Save
                </button>
                <button
                  className="info-btn"
                  onClick={handleCancel}
                  style={{ backgroundColor: "#ffc107", color: "#000", border: "none", padding: "8px 12px", borderRadius: 6 }}
                >
                  Cancel
                </button>
              </>
            ) : (
              <button
                className="info-btn"
                onClick={() => setIsEditing(true)}
                style={{ backgroundColor: "#007bff", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6 }}
              >
                Edit
              </button>
            )}
            <button
              className="info-btn"
              onClick={onClose}
              style={{ backgroundColor: "#ffc107", color: "white", border: "none", padding: "8px 12px", borderRadius: 6 }}
            >
              Cancel
            </button>
          </div>
        </div>

        {/* ✅ Scrollable Body */}
        <div className="modal-body">
          <h3 className="modal-section-title">Language Details</h3>

          {editedLanguageDetails.length > 0 ? (
            <div className="language-list">
              {editedLanguageDetails.map((lang, index) => (
                <div key={index} className="language-block">
                  <h4 className="language-name">
                    {isEditing ? (
                      <input
                        type="text"
                        value={lang.language}
                        onChange={(e) => updateLanguageDetail(index, 'language', e.target.value)}
                        style={{ fontSize: "1.17em", fontWeight: "bold", border: "1px solid #ccc", padding: "4px" }}
                      />
                    ) : (
                      lang.language
                    )}
                  </h4>

                  <div className="language-detail">
                    <p className="language-subtitle">Syntax:</p>
                    {isEditing ? (
                      <textarea
                        value={lang.syntax}
                        onChange={(e) => updateLanguageDetail(index, 'syntax', e.target.value)}
                        style={{ width: "100%", padding: "6px", borderRadius: 6, border: "1px solid #ccc", fontFamily: "monospace" }}
                        rows={4}
                      />
                    ) : (
                      <pre className="language-code">{lang.syntax}</pre>
                    )}
                  </div>

                  <div className="language-detail">
                    <p className="language-subtitle">Example:</p>
                    {isEditing ? (
                      <textarea
                        value={lang.example}
                        onChange={(e) => updateLanguageDetail(index, 'example', e.target.value)}
                        style={{ width: "100%", padding: "6px", borderRadius: 6, border: "1px solid #ccc", fontFamily: "monospace" }}
                        rows={4}
                      />
                    ) : (
                      <pre className="language-code">{lang.example}</pre>
                    )}
                  </div>

                  {index !== editedLanguageDetails.length - 1 && <hr />}
                </div>
              ))}
            </div>
          ) : (
            <p>No language details available.</p>
          )}

          {codeDifferenceExplanation && (
            <>
              <hr className="modal-divider" />
              <h3 className="modal-section-title">
                Code Difference Explanation
              </h3>
              {isEditing ? (
                <textarea
                  value={editedExplanation}
                  onChange={(e) => setEditedExplanation(e.target.value)}
                  style={{ width: "100%", padding: "6px", borderRadius: 6, border: "1px solid #ccc" }}
                  rows={4}
                />
              ) : (
                <p className="modal-diff">
                  {codeDifferenceExplanation}
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default SubtopicModal;
