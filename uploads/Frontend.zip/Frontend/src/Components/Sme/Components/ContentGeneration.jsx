import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/ContentGeneration.css';
import Sidebar from './AdminSidebar';
import ManualContentCreation from './ManualContentCreation';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function ContentGeneration({ onLogout }) {
  const [topics, setTopics] = useState([]);
  const [subtopics, setSubtopics] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState('');
  const [selectedSubtopic, setSelectedSubtopic] = useState('');
  const [selectedSubtopicId, setSelectedSubtopicId] = useState('');
  const [error, setError] = useState('');
  const [creationMode, setCreationMode] = useState(''); // 'llm' or 'manual'
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualForm, setManualForm] = useState({
    explanation: '',
    languageDetails: [
      { language: 'Java', syntax: '', example: '' },
      { language: 'Python', syntax: '', example: '' },
      { language: 'JavaScript', syntax: '', example: '' },
      { language: 'TypeScript', syntax: '', example: '' }
    ],
    codeDifferenceExplanation: ''
  });
  const navigate = useNavigate();

  // ✅ Fetch main topics and subtopics from backend
  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`)
      .then(async (res) => {
        if (!res.ok) {
          throw new Error(`HTTP error! Status: ${res.status}`);
        }
        const data = await res.json();
        setTopics(data);
      })
      .catch((err) => {
        console.error('Error fetching topics:', err);
        toast.error('Failed to fetch topics from backend for content generation.');
      });
  }, []);

  // ✅ When topic is selected, filter its subtopics
  const handleTopicChange = (e) => {
    const selectedMainTopic = e.target.value;
    setSelectedTopic(selectedMainTopic);
    setSelectedSubtopic('');
    setSelectedSubtopicId('');

    const selected = topics.find(
      (topic) => topic.mainTopicName === selectedMainTopic
    );

    if (selected && selected.subTopics) {
      setSubtopics(selected.subTopics.map((s) => ({ title: s.title, id: s.topicId })));
    } else {
      setSubtopics([]);
    }
  };

  // ✅ Handle Submit for LLM
  const handleLLMSubmit = () => {
    if (!selectedTopic || !selectedSubtopic) {
      setError('Please select both topic and subtopic.');
      return;
    }
    setError('');
    navigate(`/generated-content?topic=${selectedTopic}&subtopic=${selectedSubtopic}`);
  };

  // Handle Manual Submit
  const handleManualSubmit = async () => {
    if (!selectedTopic || !selectedSubtopic) {
      setError('Please select both topic and subtopic.');
      return;
    }
    setError('');

    try {
      const payload = {
        topicId: topics.find(t => t.mainTopicName === selectedTopic)?.mainTopicId,
        title: selectedSubtopic,
        content: {
          topic: selectedSubtopic,
          subtopic: {
            name: selectedSubtopic,
            content: {
              explanation: manualForm.explanation,
              code_difference_explaination: manualForm.codeDifferenceExplanation,
              language_details: manualForm.languageDetails
            }
          }
        }
      };

      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/${selectedSubtopicId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      toast.success('Content created successfully!');
      // Reset form
      setManualForm({
        explanation: '',
        languageDetails: [
          { language: 'Java', syntax: '', example: '' },
          { language: 'Python', syntax: '', example: '' },
          { language: 'JavaScript', syntax: '', example: '' },
          { language: 'TypeScript', syntax: '', example: '' }
        ],
        codeDifferenceExplanation: ''
      });
      setIsManualModalOpen(false);
    } catch (err) {
      console.error('Error creating content:', err);
      toast.error('Failed to create content.');
    }
  };

  // ✅ Handle adding language detail
  const addLanguageDetail = () => {
    setManualForm(prev => ({
      ...prev,
      languageDetails: [...prev.languageDetails, { language: '', syntax: '', example: '' }]
    }));
  };

  // ✅ Handle updating language detail
  const updateLanguageDetail = (index, field, value) => {
    setManualForm(prev => ({
      ...prev,
      languageDetails: prev.languageDetails.map((lang, i) =>
        i === index ? { ...lang, [field]: value } : lang
      )
    }));
  };

  // ✅ Handle removing language detail
  const removeLanguageDetail = (index) => {
    setManualForm(prev => ({
      ...prev,
      languageDetails: prev.languageDetails.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="content-gen-whole-container">
      <Sidebar onLogout={onLogout} />
      <div className="content-generate-container">
        <div className="content-generation">
          <h1 className="content-head">Content Generation</h1>

          <label htmlFor="topic">Topic:</label>
          <select
            value={selectedTopic}
            onChange={handleTopicChange}
            className="content-gen-topic"
          >
            <option value="">-- Select Topic --</option>
            {topics.map((topic) => (
              <option key={topic.mainTopicId} value={topic.mainTopicName}>
                {topic.mainTopicName}
              </option>
            ))}
          </select>

          {selectedTopic && (
            <>
              <label>Select Subtopic:</label>
              <select
                value={selectedSubtopic}
                onChange={(e) => {
                  const selectedValue = e.target.value;
                  setSelectedSubtopic(selectedValue);
                  const selectedSubtopicObj = subtopics.find(sub => sub.title === selectedValue);
                  setSelectedSubtopicId(selectedSubtopicObj ? selectedSubtopicObj.id : '');
                  setError('');
                }}
                className="content-gen-topic"
              >
                <option value="">-- Select Subtopic --</option>
                {subtopics.map((sub, idx) => (
                  <option key={idx} value={sub.title}>
                    {sub.title}
                  </option>
                ))}
              </select>

              {!creationMode && (
                <div className="content-gen-button" style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
                  <button
                    className="content-gen-ok-button"
                    onClick={() => setCreationMode('llm')}
                    disabled={!selectedTopic || !selectedSubtopic}
                  >
                    Create using LLM
                  </button>
                  <button
                    className="content-gen-ok-button"
                    onClick={() => setIsManualModalOpen(true)}
                    disabled={!selectedTopic || !selectedSubtopic}
                  >
                    Create Manually
                  </button>
                </div>
              )}

              {creationMode === 'llm' && (
                <>
                  {error && <p className="error-text">{error}</p>}

                  <div className="content-gen-button" style={{ display: 'flex', gap: '10px' }}>
                    <button
                      className="content-gen-ok-button"
                      onClick={handleLLMSubmit}
                      disabled={!selectedTopic || !selectedSubtopic}
                    >
                      Generate with LLM
                    </button>
                    <button
                      className="content-gen-ok-button"
                      onClick={() => setCreationMode('')}
                      style={{ backgroundColor: '#6c757d' }}
                    >
                      Back
                    </button>
                  </div>
                </>
              )}

              {creationMode === 'manual' && (
                <ManualContentCreation
                  manualForm={manualForm}
                  setManualForm={setManualForm}
                  updateLanguageDetail={updateLanguageDetail}
                  handleManualSubmit={handleManualSubmit}
                  error={error}
                  setCreationMode={setCreationMode}
                />
              )}
            </>
          )}
        </div>
      </div>
      <ManualContentCreation
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        manualForm={manualForm}
        setManualForm={setManualForm}
        updateLanguageDetail={updateLanguageDetail}
        handleManualSubmit={handleManualSubmit}
        error={error}
      />
    </div>
  );
}
