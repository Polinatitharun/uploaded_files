import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import "../styles/MCQPreview.css";
import Sidebar from "./AdminSidebar";
import LoadingScreen from "./LoadingScreen";

const MCQPreview = ({onLogout}) => {
  const [questions, setQuestions] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedQuestion, setEditedQuestion] = useState(null);
  const location = useLocation();
  const params = new URLSearchParams(location.search);

  const prompt = params.get("prompt") || "NA";
  const difficulty = params.get("difficulty") || "easy";
  const length = params.get("length") || "1";
  const language = params.get("language") || "Java";

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const constructPrompt = () => {
    if (prompt === "NA" || length === "NA") {
      return "Invalid selection. Please go back and choose valid options.";
    } else {
      return `Generate a MCQ in ${prompt}.`;
    }
  };

  const fetchGeneratedContent = async () => {
    const promptString = constructPrompt();
    if (!promptString || promptString === "Failed to generate content.") {
      // alert("Please give a topic.");
      toast.error("Please give a topic.", {
        position: "top-right"
      });
      return;
    }

    if (promptString.includes("Invalid selection")) {
      setQuestions([]);
      setError(true);
      return;
    }

    setLoading(true);
    setError(false);

    try {
      const response = await axios.post(
        `${import.meta.env.VITE_AI_URL}/quiz-generation`,
        {
          prompt: promptString,
          difficulty,
          length: Number(length),
          language,
        }
      );


      if (Array.isArray(response.data)) {
        setQuestions(response.data);
      } else if (
        response.data &&
        typeof response.data === "object" &&
        Array.isArray(response.data.quizes)
      ) {
        setQuestions(response.data.quizes);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (err) {
      console.error("Fetch error:", err);
      setQuestions([]);
      setError(true);
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchGeneratedContent();
  }, []);

  const handleEdit = (index) => {
    setEditingIndex(index);
    setEditedQuestion({ ...questions[index] });
  };

  const handleDelete = (index) => {
    const updatedQuestions = [...questions];
    updatedQuestions.splice(index, 1);
    setQuestions(updatedQuestions);
    if (editingIndex === index) {
      setEditingIndex(null);
      setEditedQuestion(null);
    }
  };

  const handleSave = () => {
    const updatedQuestions = [...questions];
    updatedQuestions[editingIndex] = editedQuestion;
    setQuestions(updatedQuestions);
    setEditingIndex(null);
    setEditedQuestion(null);
  };

  const handleChange = (field, value) => {
    setEditedQuestion({ ...editedQuestion, [field]: value });
  };

  const handleOptionChange = (index, value) => {
    const updatedOptions = [...editedQuestion.options];
    updatedOptions[index].value = value;
    setEditedQuestion({ ...editedQuestion, options: updatedOptions });
  };

  const regenerate = () => {
    fetchGeneratedContent();
  };
  const save = async () => {
    // const mcqSchema = new mongoose.Schema({
    //   question: { type: String, required: true },
    //   options: [optionSchema],
    //   correctOptionId: { type: Number, required: true },
    // });
    const reqBody = {
      topic: prompt,
      difficulty: difficulty,
      mcqs: questions.map((q) => ({
        question: q.question,
        options: q.options,
        correctOptionId: q.correct_option_id,
        explanation: q.explanation,
      })),
    };
    try {
      await axios.put(`${import.meta.env.VITE_API_BASE_URL}/sme/mcq-save`, reqBody);

      // alert("Content saved successfully!");
      toast.success("Content saved succcessfully!", {
        position: "top-right"
      });
    } catch (error) {
      console.error("Save Error:", error);
      // alert("Failed to save content.");
      toast.error("Failed to save content.", {
        position: "top-right"
      });
    }
  };

  return (
    <div className="preview-container-body">
      <Sidebar onLogout={onLogout}/>
    
    <div className="preview-container">
      <h2 className="preview-title">MCQ Topic : {prompt} - Language: {language}</h2>
      <ToastContainer />
    
      {loading && <LoadingScreen/>}
      {error && (
        <p style={{ color: "red" }}>Error fetching MCQs. Try again later.</p>
      )}

      <button className="regenerate-btn" onClick={regenerate}>
        Regenerate
      </button>
      <button className="regenerate-btn" onClick={save}>
        Save
      </button>

      <div className="question-grid">
        {questions.map((q, index) => (
          <div className="question-card" key={index}>
            {editingIndex === index ? (
              <>
                <textarea
                  className="edit-textarea"
                  value={editedQuestion.question}
                  onChange={(e) => handleChange("question", e.target.value)}
                />
                <ul className="option-list">
                  {editedQuestion.options.map((opt, idx) => (
                    <li key={idx}>
                      <input
                        className="option-input"
                        type="text"
                        value={opt.value}
                        onChange={(e) =>
                          handleOptionChange(idx, e.target.value)
                        }
                      />
                    </li>
                  ))}
                </ul>
                <p>
                  <strong>Correct Option ID:</strong>{" "}
                  <input
                    className="correct-input"
                    type="text"
                    value={editedQuestion.correct_option_id}
                    onChange={(e) =>
                      handleChange("correct_option_id", e.target.value)
                    }
                  />
                </p>
                <textarea
                  className="edit-textarea"
                  value={editedQuestion.explanation}
                  onChange={(e) => handleChange("Explaination", e.target.value)}
                />
                <div className="button-group">
                  <button className="save-btn" onClick={handleSave}>
                    Save
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(index)}
                  >
                    Delete
                  </button>
                </div>
              </>
            ) : (
              <>
                <p className="question-text">
                  <strong>Q{index + 1}:</strong> {q.question}
                </p>
                <ul className="option-list">
                  {Array.isArray(q.options) ? (
                    q.options.map((opt, idx) => (
                      <li
                        key={opt.id || idx}
                        className={`option-item ${
                          opt.id === q.correct_option_id ? "correct" : ""
                        }`}
                      >
                        {opt.value || opt}
                      </li>
                    ))
                  ) : q.options && typeof q.options === "object" ? (
                    Object.entries(q.options).map(([id, value]) => (
                      <li
                        key={id}
                        className={`option-item ${
                          id === q.correct_option_id ? "correct" : ""
                        }`}
                      >
                        {value}
                      </li>
                    ))
                  ) : (
                    <li className="option-item">Options not available</li>
                  )}
                </ul>
                <p className="answer-text">
                  <strong>Answer:</strong>{" "}
                  {Array.isArray(q.options)
                    ? q.options.find((opt) => opt.id === q.correct_option_id)
                        ?.value || "N/A"
                    : typeof q.options === "object"
                    ? q.options[q.correct_option_id] || "N/A"
                    : "N/A"}
                </p>
                <p className="explanation-text">
                  <strong>Explanation:</strong>{" "}
                  {q.explanation || "No explanation provided."}
                </p>
                <div className="button-group">
                  <button
                    className="edit-btn"
                    onClick={() => handleEdit(index)}
                  >
                    Edit
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(index)}
                  >
                    Delete
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
    </div>
  );
};

export default MCQPreview;