import React, { useState, useEffect } from "react";
import "../styles/GeneratedSubtopicsModal.css";
import { toast } from "react-toastify";

const GeneratedSubtopicsModal = ({ topic, subtopics, onClose, onSave, onRegenerate }) => {
  const [subtopicList, setSubtopicList] = useState(subtopics);
  const [isEditing, setIsEditing] = useState(false);

  // ✅ Sync parent-provided subtopics when they change
useEffect(() => {
  setSubtopicList(subtopics);
}, [subtopics]);

  const handleDelete = (index) => {
    const updated = subtopicList.filter((_, i) => i !== index);
    setSubtopicList(updated);
    toast.info("Subtopic removed");
  };

  const handleEditChange = (index, value) => {
    const updated = [...subtopicList];
    updated[index] = value;
    setSubtopicList(updated);
  };

  const handleSave = () => {
    setIsEditing(false);
    onSave(subtopicList);
  };

  return (
    <div className="subtopic-modal-overlay">
      <div className="subtopic-modal">
        {/* Fixed Header */}
        <div className="modal-header">
          <h3>Generated Subtopics of: {topic}</h3>
          <button className="close-btn" onClick={onClose} >×</button>
        </div>

        {/* Scrollable Body */}
        <div className="modal-body">
          {subtopicList.length === 0 ? (
            <p className="no-data">No subtopics available</p>
          ) : (
            subtopicList.map((sub, index) => (
              <div className="subtopic-item" key={index}>
                {isEditing ? (
                  <input
                    type="text"
                    value={sub}
                    onChange={(e) => handleEditChange(index, e.target.value)}
                    className="edit-input"
                  />
                ) : (
                  <span>{sub}</span>
                )}
                <button
                  className="delete-btn"
                  onClick={() => handleDelete(index)}
                >
                  Delete
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="modal-footer">
          <button className="modal-btn edit-btn" onClick={() => setIsEditing(!isEditing)}>
            {isEditing ? "Cancel Edit" : "Edit"}
          </button>
          <button className="modal-btn save-btn" onClick={handleSave}>
            Save
          </button>
          <button className="modal-btn regenerate-btn" onClick={onRegenerate}>
            Regenerate
          </button>
        </div>
      </div>
    </div>
  );
};

export default GeneratedSubtopicsModal;