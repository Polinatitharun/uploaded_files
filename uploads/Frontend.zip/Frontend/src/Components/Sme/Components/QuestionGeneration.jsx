
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles/QuestionGeneration.css";
import Sidebar from "./AdminSidebar";
import ManualQuestionModal from "./ManualQuestionModal"; // ✅ new import
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const QuestionGeneration = ({ onLogout }) => {
  const navigate = useNavigate();

  const [difficulty, setDifficulty] = useState("Easy");
  const [selectedTopic, setSelectedTopic] = useState("");
  const [selectedSubtopic, setSelectedSubtopic] = useState("");
  const [error, setError] = useState("");
  const [topicsData, setTopicsData] = useState([]);
  const [isManualModalOpen, setIsManualModalOpen] = useState(false); // ✅ modal state

  // ✅ Fetch topics and subtopics from backend
  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`
        );
        setTopicsData(response.data);
        
      } catch (err) {
        console.error("Error fetching topics:", err);
        toast.error("Failed to fetch topics from backend for question generation.");
      }
    };
    fetchTopics();
  }, []);

  // ✅ Handle OK button (navigate to Question Preview)
  const handleGenerate = () => {
    if (!selectedTopic || !selectedSubtopic) {
      setError("Please select both topic and subtopic.");
      return;
    }
    setError("");

    const prompt = `${selectedTopic} - ${selectedSubtopic}`;

    const topicId = topicsData
      .find((t) => t.mainTopicName === selectedTopic)
      ?.subTopics.find((s) => s.title === selectedSubtopic)?.topicId;

    if (!topicId) {
      setError("Unable to find selected topic ID. Please try again.");
      return;
    }

    navigate("/question-preview", {
      state: {
        prompt,
        difficulty: difficulty.toLowerCase(),
        topicId,
      },
    });
  };

  return (
    <div className="quesgen-container-body">
      <Sidebar onLogout={onLogout} />
      <ToastContainer position="top-right" autoClose={2000} />

      <div className="quesgen-container">
        <div className="quesgen-card">
          <h2 className="quesgen-title">Generate Coding Questions</h2>

          {/* ✅ Topic selection */}
          <label className="quesgen-label">Select Topic:</label>
          <select
            value={selectedTopic}
            onChange={(e) => {
              setSelectedTopic(e.target.value);
              setSelectedSubtopic("");
              setError("");
            }}
            className="quesgen-input"
          >
            <option value="">-- Select Topic --</option>
            {topicsData.map((topic) => (
              <option key={topic.mainTopicId} value={topic.mainTopicName}>
                {topic.mainTopicName}
              </option>
            ))}
          </select>

          {/* ✅ Subtopic selection */}
          {selectedTopic && (
            <>
              <label className="quesgen-label">Select Subtopic:</label>
              <select
                value={selectedSubtopic}
                onChange={(e) => {
                  setSelectedSubtopic(e.target.value);
                  setError("");
                }}
                className="quesgen-input"
              >
                <option value="">-- Select Subtopic --</option>
                {topicsData
                  .find((t) => t.mainTopicName === selectedTopic)
                  ?.subTopics.map((sub) => (
                    <option key={sub.topicId} value={sub.title}>
                      {sub.title}
                    </option>
                  ))}
              </select>
            </>
          )}

          {error && <p className="error-text">{error}</p>}

          {/* ✅ Difficulty selection */}
          <label className="quesgen-label">Select Difficulty Level:</label>
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
            className="quesgen-input"
          >
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>

          {/* ✅ Buttons */}
          <div className="quesgen-btn-wrapper">
            <button
              className="quesgen-btn"
              onClick={handleGenerate}
              disabled={!selectedTopic || !selectedSubtopic}
            >
              Create Using AI
            </button>

            <button
              className="quesgen-btn manual-btn"
              onClick={() => setIsManualModalOpen(true)}
              //disabled={!selectedTopic || !selectedSubtopic}
            >
              Create Manually
            </button>
          </div>
        </div>
      </div>

      {/* ✅ Manual Question Modal */}
      {isManualModalOpen && (
        <ManualQuestionModal
          onClose={() => setIsManualModalOpen(false)}
          selectedTopic={selectedTopic}
          selectedSubtopic={selectedSubtopic}
          difficulty={difficulty}
          topicsData={topicsData}
        />
      )}
    </div>
  );
};

export default QuestionGeneration;


