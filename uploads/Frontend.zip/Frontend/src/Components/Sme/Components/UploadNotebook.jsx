

import React, { useEffect, useState, useRef } from "react";
import Sidebar from "./AdminSidebar";
import "../styles/UploadNotebook.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UploadNotebook = ({ onLogout }) => {
  const [topics, setTopics] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [selectedMainTopicId, setSelectedMainTopicId] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("");
  const [notebookTitle, setNotebookTitle] = useState("");
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const fileInputRef = useRef(null);

  // ✅ Fetch main topics
  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`
        );
        setTopics(response.data || []);
      } catch (err) {
        console.error("Error fetching topics:", err);
        toast.error("Failed to fetch topics. Please try again.");
      }
    };
    fetchTopics();
  }, []);

  // ✅ When a main topic is selected
  const handleTopicChange = (e) => {
    const mainTopicName = e.target.value;
    setSelectedTopic(mainTopicName);
    const selected = topics.find(
      (topic) => topic.mainTopicName === mainTopicName
    );
    setSelectedMainTopicId(selected ? selected.mainTopicId : "");
  };

  // ✅ Validate file (supports .ipynb and .pdf)
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (!selectedFile) return;

    const validExtensions = [".ipynb", ".pdf"];
    const isValid = validExtensions.some((ext) =>
      selectedFile.name.toLowerCase().endsWith(ext)
    );

    if (!isValid) {
      setError("❌ Please upload a valid file (.ipynb or .pdf).");
      toast.error("Invalid file! Only .ipynb or .pdf allowed.");
      fileInputRef.current.value = "";
      setFile(null);
      return;
    }

    setError("");
    setFile(selectedFile);
  };

  // ✅ Submit notebook or PDF
  const handleSubmit = async () => {
    if (!selectedMainTopicId || !selectedLanguage || !file || !notebookTitle) {
      setError("Please fill all fields and upload the file.");
      toast.error("Please complete all fields.");
      return;
    }

    setError("");

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/sme/notebooks/upload?mainTopicId=${selectedMainTopicId}&language=${selectedLanguage.toUpperCase()}&title=${encodeURIComponent(
          notebookTitle
        )}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      toast.success("✅ File uploaded successfully!");

      // Reset
      setSelectedTopic("");
      setSelectedMainTopicId("");
      setSelectedLanguage("");
      setNotebookTitle("");
      setFile(null);
      fileInputRef.current.value = "";
    } catch (err) {
      console.error("Error uploading file:", err);
      toast.error("❌ Failed to upload file. Try again!");
    }
  };

  return (
    <div className="topic-gen-whole-container">
      <Sidebar onLogout={onLogout} />
      <div className="topic-generate-container">
        <div className="topic-generation">
          <h1 className="topic-head">Upload Notebook / PDF</h1>
          <p className="white-txt">
            Upload your Jupyter Notebook (.ipynb) or PDF file for a specific main topic and language.
          </p>

          {/* Topic Dropdown */}
          <label>Topic:</label>
          <select
            value={selectedTopic}
            onChange={handleTopicChange}
            className="upload-input"
          >
            <option value="">-- Select Topic --</option>
            {topics.map((topic) => (
              <option key={topic.mainTopicId} value={topic.mainTopicName}>
                {topic.mainTopicName}
              </option>
            ))}
          </select>

          {/* Language Dropdown */}
          <label>Language:</label>
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="upload-input"
          >
            <option value="">-- Select Language --</option>
            <option value="JAVA">Java</option>
            <option value="PYTHON">Python</option>
            <option value="JAVASCRIPT">Javascript</option>
            <option value="TYPESCRIPT">Typescript</option>
          </select>

          {/* Notebook Title */}
          <label>File Title:</label>
          <input
            type="text"
            placeholder="Enter file title (e.g. JAVA OOPS Notes)"
            value={notebookTitle}
            onChange={(e) => setNotebookTitle(e.target.value)}
            className="upload-input"
          />

          {/* File Upload */}
          <label>Upload Jupyter Notebook (.ipynb) or PDF:</label>
          <input
            type="file"
            accept=".ipynb, .pdf"
            onChange={handleFileChange}
            ref={fileInputRef}
            className="upload-input"
          />
          {file && <span className="file-name">{file.name}</span>}

          {error && <p className="error-text">{error}</p>}

          {/* Submit Button */}
          <div className="submit-button">
            <button
              className="topic-submit-btn"
              onClick={handleSubmit}
              disabled={
                !selectedMainTopicId ||
                !selectedLanguage ||
                !notebookTitle ||
                !file
              }
            >
              Submit
            </button>
          </div>
        </div>
      </div>

      {/* ✅ Toast Container */}
      <ToastContainer
        position="top-right"
        autoClose={2500}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        pauseOnHover
        draggable
        theme="colored"
      />
    </div>
  );
};

export default UploadNotebook;

