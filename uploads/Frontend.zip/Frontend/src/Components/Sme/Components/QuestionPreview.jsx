
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../styles/QuestionPreview.css";
import Sidebar from "./AdminSidebar";
import LoadingScreen from "./LoadingScreen";

const QuestionPreview = ({ onLogout }) => {
  const location = useLocation();
  const prompt = location.state?.prompt || "";
  const difficulty = location.state?.difficulty || "easy";
  const topicId = location.state?.topicId; // ✅ Received from QuestionGeneration.jsx

  const [isEditMode, setIsEditMode] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [questionResponse, setQuestionResponse] = useState(null);
  const [tempQuestion, setTempQuestion] = useState(null);

  // ✅ Fetch LLM-generated question
  const fetchGeneratedQuestion = async () => {
    if (!prompt) {
      toast.error("Please provide a topic to generate questions.");
      return;
    }

    setIsLoading(true);
    try {
      const response = await axios.post(`${import.meta.env.VITE_AI_URL}/java-python-scenario`, {
        prompt,
        difficulty,
      });

      const data = response.data;
      setQuestionResponse(data);
      setTempQuestion({ ...data });
      setIsLoading(false);
    } catch (err) {
      console.error("Error fetching question:", err);
      toast.error("Failed to fetch question from LLM.");
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchGeneratedQuestion();
  }, []);

  // ✅ Handle Edit Mode
  const handleEditToggle = () => {
    setIsEditMode(!isEditMode);
    setTempQuestion({ ...questionResponse });
  };

  const handleTempChange = (field, value) => {
    setTempQuestion((prev) => ({ ...prev, [field]: value }));
  };

  const handleSampleChange = (index, key, value) => {
    const updated = [...tempQuestion.samples];
    updated[index][key] = value;
    setTempQuestion((prev) => ({ ...prev, samples: updated }));
  };

  const handleTestcaseChange = (index, key, value) => {
    const updated = [...tempQuestion.testcase];
    updated[index][key] = value;
    setTempQuestion((prev) => ({ ...prev, testcase: updated }));
  };

  const handleTempSave = () => {
    setQuestionResponse({ ...tempQuestion });
    setIsEditMode(false);
    toast.success("Changes saved temporarily.");
  };

  // ✅ Save to Database (Spring Boot + PostgreSQL)
  const handleFinalSave = async () => {
    try {
    //   if (!topicId) {
    //     toast.error("Topic ID missing. Please regenerate question.");
    //     return;
    //   }
  
    //   // ✅ Combine test cases from both sample & hidden
    //   const allTestCases = [
    //     ...(questionResponse.samples || []).map((s) => ({
    //       input: s.input,
    //       expectedOutput: s.expectedOutput,
    //       isPublic: true,
    //     })),
    //     ...(questionResponse.testcase || []).map((t) => ({
    //       input: t.input,
    //       expectedOutput: t.expectedOutput,
    //       isPublic: false,
    //     })),
    //   ];
  
    //   // ✅ Match backend DTO
    //   const finalData = {
    //     title: questionResponse.title || "Untitled Problem",
    //     description:
    //       `${questionResponse.question || ""}\n\nInput: ${
    //         questionResponse.inputDescription || ""
    //       }\nOutput: ${questionResponse.outputDescription || ""}`,
    //     difficulty: difficulty.toUpperCase(),
    //     testCases: allTestCases,
    //     createdUsing: "LLM",
    //     hint: questionResponse.hint || null,
    //   };
  
    //   // ✅ Call your new backend endpoint
    //   const backendUrl = `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/topic/${topicId}`;
  
    //   const res = await axios.post(backendUrl, finalData, {
    //     headers: { "Content-Type": "application/json" },
    //   });
  
    //   if (res.status === 201) {
    //     toast.success("Question saved to database successfully!");
    //   } else {
    //     toast.warn("Saved with warnings — check backend logs.");
    //   }
    // } catch (err) {
    //   console.error("❌ Error saving question:", err);
    //   toast.error("Failed to save question to DB.");
    // }


    if (!topicId) {
      toast.error("Topic ID missing. Please regenerate question.");
      return;
    }

    // ✅ Combine test cases from both sample & hidden
    const allTestCases = [
      ...(questionResponse.samples || []).map((s) => ({
        input: s.input,
        expectedOutput: s.expectedOutput,
        isPublic: true,
      })),
      ...(questionResponse.testcase || []).map((t) => ({
        input: t.input,
        expectedOutput: t.expectedOutput,
        isPublic: false,
      })),
    ];

    // ✅ Ensure hint is always an array
    const normalizedHint = Array.isArray(questionResponse.hint)
      ? questionResponse.hint
      : questionResponse.hint
      ? [questionResponse.hint]
      : [];

    // ✅ Match backend DTO
    const finalData = {
      title: questionResponse.title || "Untitled Problem",
      description: `${questionResponse.question || ""}\n\nInput: ${
        questionResponse.inputDescription || ""
      }\nOutput: ${questionResponse.outputDescription || ""}`,
      difficulty: difficulty.toUpperCase(),
      testCases: allTestCases,
      createdUsing: "LLM",
      hint: normalizedHint, // ✅ JSON array
    };


    const backendUrl = `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/topic/${topicId}`;

    const res = await axios.post(backendUrl, finalData, {
      headers: { "Content-Type": "application/json" },
    });

    if (res.status === 201) {
      toast.success("✅ Question saved to database successfully!");
    } else {
      toast.warn("⚠️ Saved with warnings — check backend logs.");
    }
  } catch (err) {
    console.error("❌ Error saving question:", err);
    toast.error("Failed to save question to DB.");
  }
  };

  const handleRegenerate = () => {
    fetchGeneratedQuestion();
  };

  if (isLoading) {
    return (
      <div className="preview-wrapper">
        <Sidebar onLogout={onLogout} />
        <LoadingScreen />
      </div>
    );
  }

  if (!questionResponse) return null;

  return (
    <div className="preview-wrapper">
      <Sidebar onLogout={onLogout} />
      <div className="preview-card">
        <h2>Generated Question</h2>

        <div className="form-section">
          {/* ✅ Title */}
          {isEditMode ? (
            <input
              value={tempQuestion.title}
              onChange={(e) => handleTempChange("title", e.target.value)}
              placeholder="Enter title"
            />
          ) : (
            <h3>{questionResponse.title}</h3>
          )}

          {/* ✅ Question Description */}
          {isEditMode ? (
            <textarea
              value={tempQuestion.question}
              onChange={(e) => handleTempChange("question", e.target.value)}
              placeholder="Enter problem statement"
            />
          ) : (
            <p>{questionResponse.question}</p>
          )}

          {/* ✅ Input / Output Description */}
          <div className="format-section">
            {isEditMode ? (
              <>
                <input
                  value={tempQuestion.inputDescription}
                  onChange={(e) => handleTempChange("inputDescription", e.target.value)}
                  placeholder="Input Format"
                />
                <input
                  value={tempQuestion.outputDescription}
                  onChange={(e) => handleTempChange("outputDescription", e.target.value)}
                  placeholder="Output Format"
                />
              </>
            ) : (
              <>
                <p><strong className="txt">Input:</strong> {questionResponse.inputDescription}</p>
                <p><strong className="txt">Output:</strong> {questionResponse.outputDescription}</p>
              </>
            )}
          </div>

          {/* ✅ Sample Test Cases (is_public = true) */}
          <h4>Sample Test Cases</h4>
          {questionResponse.samples.map((sample, i) => (
            <div className="test-box" key={i}>
              {isEditMode ? (
                <>
                  <input
                    value={tempQuestion.samples[i].input}
                    onChange={(e) => handleSampleChange(i, "input", e.target.value)}
                    placeholder="Sample Input"
                  />
                  <input
                    value={tempQuestion.samples[i].output}
                    onChange={(e) => handleSampleChange(i, "output", e.target.value)}
                    placeholder="Sample Output"
                  />
                </>
              ) : (
                <>
                  <p><strong className="txt">Input:</strong> {sample.input}</p>
                  <p><strong className="txt">Output:</strong> {sample.output}</p>
                </>
              )}
            </div>
          ))}

          {/* ✅ Hidden Test Cases (is_public = false) */}
          <h4>Hidden Test Cases</h4>
          {questionResponse.testcase.map((test, i) => (
            <div className="test-box" key={i}>
              {isEditMode ? (
                <>
                  <input
                    value={tempQuestion.testcase[i].input}
                    onChange={(e) => handleTestcaseChange(i, "input", e.target.value)}
                    placeholder="Hidden Input"
                  />
                  <input
                    value={tempQuestion.testcase[i].expectedOutput}
                    onChange={(e) => handleTestcaseChange(i, "expectedOutput", e.target.value)}
                    placeholder="Expected Output"
                  />
                </>
              ) : (
                <>
                  <p><strong className="txt">Input:</strong> {test.input}</p>
                  <p><strong className="txt">Expected Output:</strong> {test.expectedOutput}</p>
                </>
              )}
            </div>
          ))}

          {/* ✅ Hint Section */}
          {/* {isEditMode ? (
            <input
              value={tempQuestion.hints || ""}
              onChange={(e) => handleTempChange("hints", e.target.value)}
              placeholder="Hint (optional)"
            />
          ) : (
            questionResponse.hints && (
              <p><strong className="txt">Hint:</strong> {questionResponse.hints}</p>
            )
          )} */}

          {/* ✅ Hints Section */}
{questionResponse.hint?.length > 0 && (
  <div className="hint-section">
    <h4>Hints</h4>
    {questionResponse.hint.map((h, i) => (
      <p key={i}>
        <strong>Hint {i + 1}:</strong> {h}
      </p>
    ))}
  </div>
)}
        </div>

        {/* ✅ Action Buttons */}
        <div className="btn-group">
          {isEditMode ? (
            <>
              <button className="btn save" onClick={handleTempSave}>Save</button>
              <button className="btn cancel" onClick={handleEditToggle}>Cancel</button>
            </>
          ) : (
            <>
              <button className="btn edit" onClick={handleEditToggle}>Edit</button>
              <button className="btn regen" onClick={handleRegenerate}>Regenerate</button>
              <button className="btn save" onClick={handleFinalSave}>Save to DB</button>
            </>
          )}
        </div>

        <ToastContainer />
      </div>
    </div>
  );
};

export default QuestionPreview;