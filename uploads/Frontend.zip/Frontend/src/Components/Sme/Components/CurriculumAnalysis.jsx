
// import {
//   BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell
// } from "recharts";

// import React, { useState, useRef, useEffect } from "react";
// import Sidebar from "./AdminSidebar";
// import axios from "axios";
// import { height, width } from "@mui/system";

// const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8E44AD", "#FF6347"];
// const BACKEND_URL = "http://localhost:8000";

// //all states

// const CurriculumAnalysis = ({ onLogout }) => {
//   const [file, setFile] = useState(null);
//   const [selectedBatch, setSelectedBatch] = useState("");
//   const [newBatch, setNewBatch] = useState(""); // new batch input
//   const [error, setError] = useState("");
//   const [backendMsg, setBackendMsg] = useState("");
//   const [chartData, setChartData] = useState([]);
//   const [activeChart, setActiveChart] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [batches, setBatches] = useState([]);
//   const fileRef = useRef(null);


//   const [selectedLang, setSelectedLang] = useState("");
//   const [topics, setTopics] = useState([]);
//   const [selectedTopic, setSelectedTopic] = useState("");


//   const [compareData, setCompareData] = useState([]);

//   // --------------------------
//   // Load batches from backend on mount
//   // --------------------------
//   useEffect(() => {
//     fetchBatches();
//   }, []);

//   const fetchBatches = async () => {
//     try {
//       const res = await axios.get(`${BACKEND_URL}/batches`);
//       setBatches(res.data);
//     } catch (err) {
//       console.error("Failed to fetch batches:", err);
//     }
//   };

//   // --------------------------
//   // File handlers
//   // --------------------------
//   const handleFileChange = (event) => {
//     const selectedFile = event.target.files[0];
//     if (selectedFile && !selectedFile.name.match(/\.(xlsx|xls)$/)) {
//       setError("Please upload a valid Excel file (.xlsx or .xls).");
//       fileRef.current.value = "";
//       return;
//     }
//     setFile(selectedFile);
//     setError("");
//     setBackendMsg("");
//     setChartData([]);
//     setActiveChart(null);
//   };

//   const handleSubmit = async () => {
//     if (!file) { setError("Please upload a topic Excel file before submitting."); return; }
//     if (!selectedBatch) { setError("Please select a batch before uploading."); return; }

//     setLoading(true);
//     setError("");
//     setBackendMsg("");

//     const formData = new FormData();
//     formData.append("file", file);
//     formData.append("batch", selectedBatch);

//     try {
//       const res = await axios.post(`${BACKEND_URL}/upload/`, formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       });
//       setBackendMsg(
//         <>
//           {`${res.data.message}`}<br />
//           {res.data.inserted} rows inserted<br />
//           {res.data.updated} rows updated<br />
//           {res.data.skipped} rows skipped
//         </>
//       );
//       setFile(null);
//       if (fileRef.current) fileRef.current.value = "";
//     } catch (err) {
//       console.error(err);
//       setError(err.response?.data?.detail || "Failed to upload and process the file.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // --------------------------
//   // Chart handlers
//   // --------------------------
//   const fetchChartData = async (endpoint, chartType) => {
//     if (!selectedBatch) { setError("Please select a batch before viewing analysis."); return; }
//     setLoading(true);
//     setError("");
//     setBackendMsg("");

//     try {
//       const res = await axios.get(`${BACKEND_URL}/api/${endpoint}?batch=${selectedBatch}`);
//       if (!Array.isArray(res.data)) {
//         setError("Backend returned invalid data.");
//         setChartData([]);
//         setActiveChart(null);
//       } else {
//         setChartData(res.data);
//         setActiveChart(chartType);
//         setBackendMsg(`Loaded ${endpoint} data for ${selectedBatch}`);
//       }
//     } catch (err) {
//       console.error(err);
//       setError("Failed to fetch analysis data.");
//     } finally {
//       setLoading(false);
//     }
//   };


//   // --------------------------
//   // Fetch comparison analytics
//   // --------------------------
//   const fetchComparisonData = async () => {
//     try {
//       const res = await axios.get(`${BACKEND_URL}/compare-analytics`);
//       setCompareData(res.data.data || []);
//     } catch (err) {
//       console.error("Error fetching comparison data:", err);
//       setError("Failed to fetch comparison analytics data");
//     }
//   };

//   // --------------------------
//   // Batch handlers with validation
//   // --------------------------
//   const handleAddBatch = async () => {
//     if (!newBatch) {
//       setError("⚠️ Please enter a batch name!");
//       return;
//     }

//     const batchFormat = /^Batch_\d+$/;
//     if (!batchFormat.test(newBatch)) {
//       setError("❌ Invalid format! Use: Batch_<number> (e.g., Batch_47)");
//       return;
//     }

//     if (batches.includes(newBatch)) {
//       setError("⚠️ This batch already exists!");
//       return;
//     }

//     try {
//       await axios.post(`${BACKEND_URL}/batches`, { name: newBatch });
//       setBatches([...batches, newBatch]);
//       setSelectedBatch(newBatch);
//       setNewBatch("");
//       setError("");
//     } catch (err) {
//       setError(err.response?.data?.detail || "Failed to add batch");
//     }
//   };

//   const handleDeleteBatch = async () => {
//     if (!selectedBatch) { setError("⚠️ Please select a batch to delete!"); return; }
//     const confirmDelete = window.confirm(`Are you sure you want to delete ${selectedBatch}?`);
//     if (!confirmDelete) return;

//     try {
//       await axios.delete(`${BACKEND_URL}/batches/${selectedBatch}`);
//       setBatches(batches.filter(b => b !== selectedBatch));
//       setSelectedBatch("");
//       setError("");
//     } catch (err) {
//       setError(err.response?.data?.detail || "Failed to delete batch");
//     }
//   };


//   // const fetchMergedComparison = async () => {
//   //   if (!selectedBatch || !selectedLang) {
//   //     setError("Please select batch and language first!");
//   //     return;
//   //   }
  
//   //   setLoading(true);
//   //   setError("");
//   //   setCompareData([]);
  
//   //   try {
//   //     // Fetch data from both APIs
//   //     const [res1, res2] = await Promise.all([
//   //       axios.get(`${BACKEND_URL}/compare-analytics`),
//   //       axios.get(`${BACKEND_URL}/api/chart-data?language=${selectedLang}&batch=${selectedBatch}`)
//   //     ]);
  
//   //     const data1 = res1.data.data || [];
//   //     const data2 = res2.data || [];
  
//   //     // Step 2: Merge both by topic name
//   //     const merged = mergeByTopic(data1, data2);
  
//   //     setCompareData(merged);
//   //   } catch (err) {
//   //     console.error("Error fetching comparison data:", err);
//   //     setError("Failed to fetch merged comparison data");
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };

//   const fetchMergedComparison = async () => {
//     if (!selectedBatch || !selectedLang) {
//       setError("Please select batch and language first!");
//       return;
//     }
  
//     setLoading(true);
//     setError("");
//     setCompareData([]);
  
//     try {
//       // Fetch both APIs
//       const [res1, res2] = await Promise.all([
//         axios.get(`${BACKEND_URL}/compare-analytics`),
//         axios.get(`${BACKEND_URL}/api/chart-data?language=${selectedLang}&batch=${selectedBatch}`)
//       ]);
  
//       const data1 = res1.data.data || [];
//       const data2 = res2.data || [];
  
//       // ✅ Merge both datasets topic-wise, using selected language
//       const merged = mergeByTopic(data1, data2, selectedLang);
  
//       setCompareData(merged);
//     } catch (err) {
//       console.error("Error fetching comparison data:", err);
//       setError("Failed to fetch merged comparison data");
//     } finally {
//       setLoading(false);
//     }
//   };




//   // --------------------------
//   // Render chart
//   // --------------------------
//   const renderChart = () => {
//     if (activeChart === "bar" && chartData.length > 0) {
//       return (
//         <ResponsiveContainer width="100%" height={350}>
//           <BarChart data={chartData}>
//             <CartesianGrid strokeDasharray="3 3" />
//             <XAxis dataKey="topic" />
//             <YAxis />
//             <Tooltip />
//             <Legend />
//             <Bar dataKey="hours_spent" fill="#8884d8" name="Total Hours Spent" />
//           </BarChart>
//         </ResponsiveContainer>
//       );
//     }
//     return <p>No data available</p>;
//   };


//   // const renderComparisonChart = () => {
//   //   if (compareData.length === 0) return <p>No comparison data available</p>;

//   //   return (
//   //     <ResponsiveContainer width="100%" height={350}>
//   //       <BarChart data={compareData}>
//   //         <CartesianGrid strokeDasharray="3 3" />
//   //         <XAxis dataKey="mainTopicTitle" />
//   //         <YAxis label={{ value: "Hours", angle: -90, position: "insideLeft" }} />
//   //         <Tooltip />
//   //         <Legend />
//   //         <Bar dataKey="avgJavaTime" fill="#8884d8" name="Java (hrs)" />
//   //         <Bar dataKey="avgPythonTime" fill="#82ca9d" name="Python (hrs)" />
//   //         <Bar dataKey="avgTotalTime" fill="#ffc658" name="Total (hrs)" />
//   //       </BarChart>
//   //     </ResponsiveContainer>
//   //   );
//   // };

//   const renderComparisonChart = () => {
//     if (compareData.length === 0) return <p>No comparison data available</p>;
  
//     return (
//       <ResponsiveContainer width="100%" height={400}>
//         <BarChart data={compareData}>
//           <CartesianGrid strokeDasharray="3 3" />
//           <XAxis dataKey="topic" />
//           <YAxis label={{ value: "Hours", angle: -90, position: "insideLeft" }} />
//           <Tooltip />
//           <Legend />
//           <Bar dataKey="api1Hours" fill="#00BCD4" name="CBL Application" />
//           <Bar dataKey="api2Hours" fill="#8884d8" name="Ignite Curriculum" />
//         </BarChart>
//       </ResponsiveContainer>
//     );
//   };

//   // const mergeByTopic = (api1Data, api2Data) => {
//   //   const map = new Map();
  
//   //   // Add API 1 data (compare-analytics)
//   //   api1Data.forEach(item => {
//   //     const topic = item.mainTopicTitle || item.topic;
//   //     map.set(topic, {
//   //       topic,
//   //       api1Hours: item.avgTotalTime || item.hours_spent || 0,
//   //       api2Hours: 0,
//   //     });
//   //   });
  
//   //   // Merge API 2 data (chart-data)
//   //   api2Data.forEach(item => {
//   //     const topic = item.topic;
//   //     if (map.has(topic)) {
//   //       map.get(topic).api2Hours = item.hours_spent || 0;
//   //     } else {
//   //       map.set(topic, {
//   //         topic,
//   //         api1Hours: 0,
//   //         api2Hours: item.hours_spent || 0,
//   //       });
//   //     }
//   //   });
  
//   //   return Array.from(map.values());
//   // };
//   const mergeByTopic = (api1Data, api2Data, selectedLang) => {
//     const map = new Map();
  
//     // determine which language field to use
//     const langKey = selectedLang === "Java" ? "avgJavaTime" :
//                     selectedLang === "Python" ? "avgPythonTime" :
//                     "avgTotalTime"; // fallback
  
//     api1Data.forEach(item => {
//       const topic = item.mainTopicTitle || item.topic;
//       let langHours = item[langKey] || 0;
  
//       // convert minutes → hours for comparison
      
  
//       map.set(topic, {
//         topic,
//         api1Hours: langHours, // Ignite (Analytics)
//         api2Hours: 0
//       });
//     });
  
//     api2Data.forEach(item => {
//       const topic = item.topic;
//       let hours = item.hours_spent || 0;
//       map.has(topic)
//         ? (map.get(topic).api2Hours = hours)
//         : map.set(topic, { topic, api1Hours: 0, api2Hours: hours });
//     });
  
//     return Array.from(map.values());
//   };

//   return (
//     <div style={styles.pageContainer}>
//       <Sidebar onLogout={onLogout} />
//       <div style={styles.mainContainer}>
//         <div style={styles.card}>
//           <h1 style={styles.heading}>Curriculum Analysis</h1>
//           <p style={styles.subText}>
//             Upload a single Excel file containing topic data (.xlsx or .xls).
//           </p>

//           {/* Batch Management */}
//           <div style={styles.uploadBox}>
//             {/* Select Batch + Delete Button on the same line */}
//             <div style={{ display: "flex", gap: "10px", marginBottom: "17px", width: "102%", marginLeft: "-20px" }}>
//               <label style={{ ...styles.label, marginRight: "10px", whiteSpace: "nowrap" }}></label>
//               <select
//                 style={{ ...styles.select, flex: "1" }}
//                 value={selectedBatch}
//                 onChange={(e) => setSelectedBatch(e.target.value)}
//               >
//                 <option value="">-- Select Batch --</option>
//                 {batches.map((batch, i) => (
//                   <option key={i} value={batch}>{batch}</option>
//                 ))}
//               </select>
//               <button style={styles.deleteBtn} onClick={handleDeleteBatch}>Delete Batch</button>
//             </div>

//             {/* New Batch Input */}
//             <div style={{ display: "flex", gap: "10px", height: "45px", marginTop: "20px" }}>
//               <input
//                 type="text"
//                 placeholder="Batch_<number> e.g., Batch_47"
//                 value={newBatch}
//                 onChange={(e) => setNewBatch(e.target.value)}
//                 style={{ flexGrow: 1, padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
//               />
//               <button style={{ ...styles.addBtn, padding: "10px 16px" }} onClick={handleAddBatch}>Add Batch</button>
//             </div>

//             {/* <label style={styles.label}>Select Topic File</label> */}

//             {/* <label style={{...styles.label , marginRight:"10px", whiteSpace:"nowrap"}}>Select Topic File</label>

//             <input 
//             type="file" 
//             accept=".xlsx,.xls" 
//             onChange={handleFileChange} 
//             ref={fileRef} 
//             style={{ 
//               flexGrow:1,
//               padding:"10px",
//               border:"2px dashed #bbb", 
//               borderRadius:"10px",
//               backgroundColor:"#fafafa"}} />
//             {file && <p style={styles.fileName}>📄 {file.name}</p>} */}
//             <div style={{ display: "flex", alignItems: "center", gap: "10px", marginTop: "20px" }}>
//               <label style={{ ...styles.label, marginRight: "10px", whiteSpace: "nowrap" }}>
//                 Select Topic File:
//               </label>

//               <input
//                 type="file"
//                 accept=".xlsx,.xls"
//                 onChange={handleFileChange}
//                 ref={fileRef}
//                 style={{
//                   flexGrow: 1,
//                   padding: "10px",
//                   border: "2px dashed #bbb",
//                   borderRadius: "10px",
//                   backgroundColor: "#fafafa",
//                   marginLeft:"-150px",
//                   height:"40px"

//                 }}
//               />

//               { <button
//                 style={{
//                   backgroundColor: "#007bff",
//                   color: "#fff",
//                   border: "none",
//                   padding: "10px 16px",
//                   borderRadius: "8px",
//                   cursor: "pointer",
//                   fontWeight: "bold",
//                   height: "40px",
//                   whiteSpace: "nowrap",
//                   // marginTop:"3px"
//                 }}
//                 onClick={handleSubmit}
//                 disabled={loading}
//               >
//                 {loading ? "Processing..." : "Upload & Save"}
//               </button> }
//             </div>
//           </div>

//           {error && <p style={styles.error}>{error}</p>}
//           {backendMsg && <p style={styles.success}>{backendMsg}</p>}


//           {/* Upload & Save Button */}
//           <div style={{

//           }}>
//             {/* <button
//               style={styles.button}
//               onClick={handleSubmit}
//               disabled={loading}>
//               {loading ? "Processing..." : "Upload & Save"}
//             </button> */}


//             <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "10px", marginTop: "20px" }}>
//               {/* Language Dropdown */}
//               <select
//                 value={selectedLang}
//                 onChange={async (e) => {
//                   const lang = e.target.value;
//                   setSelectedLang(lang);
//                   setSelectedTopic("");
//                   if (lang && selectedBatch) {
//                     try {
//                       const res = await axios.get(`${BACKEND_URL}/api/topics?language=${lang}&batch=${selectedBatch}`);
//                       setTopics(res.data);
//                     } catch (err) {
//                       console.error("Failed to fetch topics:", err);
//                       setTopics([]);
//                     }
//                   }
//                 }}
//                 style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc", height: "45px" }}
//               >
//                 <option value="">-- Select Language --</option>
//                 <option value="Python">Python</option>
//                 <option value="Java">Java</option>
//               </select>

//               {/* Topic Dropdown */}
//               {/* <select
//                 value={selectedTopic}
//                 onChange={(e) => setSelectedTopic(e.target.value)}
//                 style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
//                 disabled={!selectedLang}
//               >
//                 <option value="">-- Select Topic --</option>
//                 {topics.map((topic, i) => (
//                   <option key={i} value={topic}>{topic}</option>
//                 ))}
//               </select> */}

//               {/* Batch Dropdown */}
//               <select
//                 value={selectedBatch}
//                 onChange={(e) => setSelectedBatch(e.target.value)}
//                 style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc", height: "45px" }}
//               >
//                 <option value="">-- Select Batch --</option>
//                 {batches.map((batch, i) => (
//                   <option key={i} value={batch}>{batch}</option>
//                 ))}
//               </select>

//               {/* Show Analysis Button */}
//               <button
//                 style={{
//                   backgroundColor: "#007bff",
//                   color: "#fff",
//                   padding: "10px 16px",
//                   borderRadius: "6px",
//                   border: "none",
//                   fontWeight: "bold",
//                   cursor: "pointer",
//                   height: "45px",
//                   marginTop: "5px",
//                   marginBottom: "5px"
//                 }}
//                 onClick={async () => {
//                   if (!selectedLang || !selectedBatch) {
//                     setError("Please select Language and Batch");
//                     return;
//                   }
//                   setError("");
//                   try {
//                     const res = await axios.get(`${BACKEND_URL}/api/chart-data?language=${selectedLang}&batch=${selectedBatch}`);
//                     setChartData(res.data);
//                     setActiveChart("bar");
//                   } catch (err) {
//                     console.error("Failed to load chart:", err);
//                     setError("Failed to load chart data");
//                   }
//                 }}
//               >
//                 Show Analysis
//               </button>

//               <button
//                 style={{
//                   backgroundColor: "#6f42c1",
//                   color: "#fff",
//                   padding: "10px 16px",
//                   borderRadius: "6px",
//                   border: "none",
//                   fontWeight: "bold",
//                   cursor: "pointer",
//                   height: "45px",
//                   marginTop: "5px",
//                   marginBottom: "5px"
//                   // width:"35px"
//                 }}
//                 onClick={fetchMergedComparison}
//               >
//                 Compare Analytics
//               </button>


//             </div>




//             {/* <button style={{ ...styles.button, backgroundColor: "#28a745" }} disabled={loading}
//               onClick={() => fetchChartData("chart-data", "chart-data")}>
//               {loading ? "Loading..." : "Show Analysis"}
//             </button> */}
//           </div>

//           {chartData.length > 0 && <div style={{ marginTop: "30px" }}>{renderChart()}</div>}

//           {compareData.length > 0 && (
//             <div style={{ marginTop: "50px" }}>
//               <h3 style={{ textAlign: "center", color: "#333", marginBottom: "10px" }}>
//                 Ignite vs CBL Application
//               </h3>
//               {renderComparisonChart()}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// // --------------------------
// // Styles
// // --------------------------
// const styles = {
//   pageContainer: { display: "flex", backgroundColor: "#f5f6fa", minHeight: "100vh" },
//   mainContainer: { flex: 1, padding: "40px", display: "flex", justifyContent: "center", alignItems: "center" },
//   card: { backgroundColor: "#fff", padding: "30px", borderRadius: "16px", boxShadow: "0 4px 12px rgba(0,0,0,0.1)", width: "100%", maxWidth: "700px", textAlign: "center" },
//   heading: { fontSize: "26px", marginBottom: "10px", color: "#333" },
//   subText: { color: "#666", marginBottom: "20px" },
//   uploadBox: { marginBottom: "20px" },
//   label: { display: "block", fontWeight: "600" },
//   input: { width: "100%", padding: "10px", border: "2px dashed #bbb", borderRadius: "10px", cursor: "pointer", backgroundColor: "#fafafa" },
//   fileName: { marginTop: "10px", fontStyle: "italic", color: "#444" },
//   error: { color: "red", marginBottom: "10px" },
//   success: { color: "green", fontWeight: "bold", marginBottom: "10px" },
//   button: { backgroundColor: "#007bff", color: "#fff", border: "none", padding: "6px 12px", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", height: "45px", marginTop: "25px", marginBottom: "5px" },
//   addBtn: { backgroundColor: "#28a745", color: "#fff", border: "none", padding: "10px 12px", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", height: "38px", width: "150px", marginBottom: "30px", marginTop: "9px" },
//   deleteBtn: { backgroundColor: "#dc3545", color: "#fff", border: "none", padding: "10px 12px", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", height: "38px", width: "120px", marginBottom: "10px", marginTop: "-2px" },
//   select: { width: "100%", padding: "10px", borderRadius: "8px", border: "1px solid #ccc", marginBottom: "15px", cursor: "pointer" },
//   buttonGroup: { display: "flex", justifyContent: "center", gap: "10px" },
// };

// export default CurriculumAnalysis;


import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";
import React, { useState, useRef, useEffect } from "react";
import Sidebar from "./AdminSidebar";
import axios from "axios";

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8E44AD", "#FF6347"];
const BACKEND_URL = import.meta.env.VITE_AI_URL;

const CurriculumAnalysis = ({ onLogout }) => {
  const [file, setFile] = useState(null);
  const [selectedBatch, setSelectedBatch] = useState("");
  const [newBatch, setNewBatch] = useState("");
  const [error, setError] = useState("");
  const [backendMsg, setBackendMsg] = useState("");
  const [chartData, setChartData] = useState([]);
  const [activeChart, setActiveChart] = useState(null);
  const [loading, setLoading] = useState(false);
  const [batches, setBatches] = useState([]);
  const fileRef = useRef(null);
  const [selectedLang, setSelectedLang] = useState("");
  const [topics, setTopics] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [compareData, setCompareData] = useState([]);

  useEffect(() => {
    fetchBatches();
  }, []);

  const fetchBatches = async () => {
    try {
      const res = await axios.get(`${BACKEND_URL}/batches`);
      setBatches(res.data);
    } catch (err) {
      console.error("Failed to fetch batches:", err);
    }
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && !selectedFile.name.match(/\.(xlsx|xls)$/)) {
      setError("Please upload a valid Excel file (.xlsx or .xls).");
      fileRef.current.value = "";
      return;
    }
    setFile(selectedFile);
    setError("");
    setBackendMsg("");
    setChartData([]);
    setActiveChart(null);
  };

  const handleSubmit = async () => {
    if (!file) { setError("Please upload a topic Excel file before submitting."); return; }
    if (!selectedBatch) { setError("Please select a batch before uploading."); return; }

    setLoading(true);
    setError("");
    setBackendMsg("");

    const formData = new FormData();
    formData.append("file", file);
    formData.append("batch", selectedBatch);

    try {
      const res = await axios.post(`${BACKEND_URL}/upload/`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setBackendMsg(
        <>
          {`${res.data.message}`}<br />
          {res.data.inserted} rows inserted<br />
          {res.data.updated} rows updated<br />
          {res.data.skipped} rows skipped
        </>
      );
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.detail || "Failed to upload and process the file.");
    } finally {
      setLoading(false);
    }
  };

  const fetchChartData = async (endpoint, chartType) => {
    if (!selectedBatch) { setError("Please select a batch before viewing analysis."); return; }
    setLoading(true);
    setError("");
    setBackendMsg("");

    try {
      const res = await axios.get(`${BACKEND_URL}/api/${endpoint}?batch=${selectedBatch}`);
      if (!Array.isArray(res.data)) {
        setError("Backend returned invalid data.");
        setChartData([]);
        setActiveChart(null);
      } else {
        setChartData(res.data);
        setActiveChart(chartType);
        setBackendMsg(`Loaded ${endpoint} data for ${selectedBatch}`);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to fetch analysis data.");
    } finally {
      setLoading(false);
    }
  };

  const fetchComparisonData = async () => {
    try {
      const res = await axios.get(`${BACKEND_URL}/compare-analytics`);
      setCompareData(res.data.data || []);
    } catch (err) {
      console.error("Error fetching comparison data:", err);
      setError("Failed to fetch comparison analytics data");
    }
  };

  const handleAddBatch = async () => {
    if (!newBatch) {
      setError("⚠️ Please enter a batch name!");
      return;
    }

    const batchFormat = /^Batch_\d+$/;
    if (!batchFormat.test(newBatch)) {
      setError("❌ Invalid format! Use: Batch_<number> (e.g., Batch_47)");
      return;
    }

    if (batches.includes(newBatch)) {
      setError("⚠️ This batch already exists!");
      return;
    }

    try {
      await axios.post(`${BACKEND_URL}/batches`, { name: newBatch });
      setBatches([...batches, newBatch]);
      setSelectedBatch(newBatch);
      setNewBatch("");
      setError("");
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to add batch");
    }
  };

  const handleDeleteBatch = async () => {
    if (!selectedBatch) { setError("⚠️ Please select a batch to delete!"); return; }
    const confirmDelete = window.confirm(`Are you sure you want to delete ${selectedBatch}?`);
    if (!confirmDelete) return;

    try {
      await axios.delete(`${BACKEND_URL}/batches/${selectedBatch}`);
      setBatches(batches.filter(b => b !== selectedBatch));
      setSelectedBatch("");
      setError("");
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to delete batch");
    }
  };

  const fetchMergedComparison = async () => {
    if (!selectedBatch || !selectedLang) {
      setError("Please select batch and language first!");
      return;
    }
  
    setLoading(true);
    setError("");
    setCompareData([]);
  
    try {
      const [res1, res2] = await Promise.all([
        axios.get(`${BACKEND_URL}/compare-analytics`),
        axios.get(`${BACKEND_URL}/api/chart-data?language=${selectedLang}&batch=${selectedBatch}`)
      ]);
  
      const data1 = res1.data.data || [];
      const data2 = res2.data || [];
      const merged = mergeByTopic(data1, data2, selectedLang);
  
      setCompareData(merged);
    } catch (err) {
      console.error("Error fetching comparison data:", err);
      setError("Failed to fetch merged comparison data");
    } finally {
      setLoading(false);
    }
  };

  const renderChart = () => {
    if (activeChart === "bar" && chartData.length > 0) {
      return (
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="topic" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="hours_spent" fill="#8884d8" name="Total Hours Spent" />
          </BarChart>
        </ResponsiveContainer>
      );
    }
    return <p>No data available</p>;
  };

  const renderComparisonChart = () => {
    if (compareData.length === 0) return <p>No comparison data available</p>;
  
    return (
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={compareData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="topic" />
          <YAxis label={{ value: "Hours", angle: -90, position: "insideLeft" }} />
          <Tooltip />
          <Legend />
          <Bar dataKey="api1Hours" fill="#00BCD4" name="CBL Application" />
          <Bar dataKey="api2Hours" fill="#8884d8" name="Ignite Curriculum" />
        </BarChart>
      </ResponsiveContainer>
    );
  };

  const mergeByTopic = (api1Data, api2Data, selectedLang) => {
    const map = new Map();
  
    const langKey = selectedLang === "Java" ? "avgJavaTime" :
                    selectedLang === "Python" ? "avgPythonTime" :
                    "avgTotalTime";
  
    api1Data.forEach(item => {
      const topic = item.mainTopicTitle || item.topic;
      let langHours = item[langKey] || 0;
  
      map.set(topic, {
        topic,
        api1Hours: langHours,
        api2Hours: 0
      });
    });
  
    api2Data.forEach(item => {
      const topic = item.topic;
      let hours = item.hours_spent || 0;
      map.has(topic)
        ? (map.get(topic).api2Hours = hours)
        : map.set(topic, { topic, api1Hours: 0, api2Hours: hours });
    });
  
    return Array.from(map.values());
  };

  return (
    <div className="page-container">
      <Sidebar onLogout={onLogout} />
      <div className="main-container">
        <div className="card">
          <h1 className="heading">Curriculum Analysis</h1>
          <p className="sub-text">
            Upload a single Excel file containing topic data (.xlsx or .xls).
          </p>

          {/* Batch Management Section */}
          <div className="section">
            <div className="form-row">
              <div className="form-group">
                <label className="label">Select Batch</label>
                <select
                  className="select"
                  value={selectedBatch}
                  onChange={(e) => setSelectedBatch(e.target.value)}
                >
                  <option value="">-- Select Batch --</option>
                  {batches.map((batch, i) => (
                    <option key={i} value={batch}>{batch}</option>
                  ))}
                </select>
              </div>
              <button className="delete-btn" onClick={handleDeleteBatch}>Delete Batch</button>
            </div>

            <div className="form-row">
              <div className="form-group flex-1">
                <label className="label" style={{"marginTop": "10px"}}>Add New Batch</label>
                <input
                  type="text"
                  placeholder="Batch_<number> e.g., Batch_47"
                  value={newBatch}
                  onChange={(e) => setNewBatch(e.target.value)}
                  className="input"
                />
              </div>
              <button className="add-btn" onClick={handleAddBatch}>Add Batch</button>
            </div>
          </div>

          {/* File Upload Section */}
          <div className="section">
            <div className="form-row">
              <div className="form-group flex-1">
                <label className="label">Select Topic File</label>
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileChange}
                  ref={fileRef}
                  className="file-input"
                />
              </div>
              <button
                className="upload-btn"
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? "Processing..." : "Upload & Save"}
              </button>
            </div>
            {file && <p className="file-name">📄 {file.name}</p>}
          </div>

          {error && <p className="error">{error}</p>}
          {backendMsg && <p className="success">{backendMsg}</p>}

          {/* Analysis Controls Section */}
          <div className="section">
            <div className="form-row">
              <div className="form-group">
                <label className="label">Language</label>
                <select
                  value={selectedLang}
                  onChange={async (e) => {
                    const lang = e.target.value;
                    setSelectedLang(lang);
                    setSelectedTopic("");
                    if (lang && selectedBatch) {
                      try {
                        const res = await axios.get(`${BACKEND_URL}/api/topics?language=${lang}&batch=${selectedBatch}`);
                        setTopics(res.data);
                      } catch (err) {
                        console.error("Failed to fetch topics:", err);
                        setTopics([]);
                      }
                    }
                  }}
                  className="select"
                >
                  <option value="">-- Select Language --</option>
                  <option value="Python">Python</option>
                  <option value="Java">Java</option>
                </select>
              </div>

              <div className="form-group">
                <label className="label">Batch</label>
                <select
                  value={selectedBatch}
                  onChange={(e) => setSelectedBatch(e.target.value)}
                  className="select"
                >
                  <option value="">-- Select Batch --</option>
                  {batches.map((batch, i) => (
                    <option key={i} value={batch}>{batch}</option>
                  ))}
                </select>
              </div>

              <button
                className="analysis-btn"
                onClick={async () => {
                  if (!selectedLang || !selectedBatch) {
                    setError("Please select Language and Batch");
                    return;
                  }
                  setError("");
                  try {
                    const res = await axios.get(`${BACKEND_URL}/api/chart-data?language=${selectedLang}&batch=${selectedBatch}`);
                    setChartData(res.data);
                    setActiveChart("bar");
                  } catch (err) {
                    console.error("Failed to load chart:", err);
                    setError("Failed to load chart data");
                  }
                }}
              >
                Show Analysis
              </button>

              <button
                className="compare-btn"
                onClick={fetchMergedComparison}
              >
                Compare Analytics
              </button>
            </div>
          </div>

          {/* Charts Section */}
          {chartData.length > 0 && (
            <div className="chart-section">
              {renderChart()}
            </div>
          )}

          {compareData.length > 0 && (
            <div className="chart-section">
              <h3 className="chart-title">Ignite vs CBL Application</h3>
              {renderComparisonChart()}
            </div>
          )}
        </div>
      </div>

      <style jsx>{`
        .page-container {
          display: flex;
          background-color: #f5f6fa;
          min-height: 100vh;
        }

        .main-container {
          flex: 1;
          padding: 40px;
          display: flex;
          justify-content: center;
          align-items: flex-start;
        }

        .card {
          background-color: #fff;
          padding: 30px;
          border-radius: 16px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          width: 100%;
          max-width: 900px;
        }

        .heading {
          font-size: 26px;
          margin-bottom: 10px;
          color: #333;
          text-align: center;
        }

        .sub-text {
          color: #666;
          margin-bottom: 30px;
          text-align: center;
        }

        .section {
          margin-bottom: 25px;
          padding: 20px;
          border: 1px solid #eaeaea;
          border-radius: 10px;
          background-color: #fafafa;
        }

        .form-row {
          display: flex;
          gap: 15px;
          align-items: flex-end;
          flex-wrap: wrap;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          flex: 1;
          min-width: 150px;
        }

        .flex-1 {
          flex: 1;
        }

        .label {
          font-weight: 600;
          margin-bottom: 8px;
          margin-bottom: 8px;
          color: #333;
          font-size: 14px;
        }

        .select, .input, .file-input {
          padding: 12px;
          border: 1px solid #ccc;
          border-radius: 6px;
          font-size: 14px;
          height: 45px;
          box-sizing: border-box;
        }

        .file-input {
          border: 2px dashed #bbb;
          background-color: #fafafa;
          cursor: pointer;
        }

        .add-btn {
          background-color: #28a745;
          color: #fff;
          border: none;
          padding: 12px 20px;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          height: 45px;
          white-space: nowrap;
          min-width: 120px;
        }

        .delete-btn {
          background-color: #dc3545;
          color: #fff;
          border: none;
          padding: 12px 20px;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          height: 45px;
          white-space: nowrap;
          min-width: 120px;
          align-self: flex-end;
        }

        .upload-btn {
          background-color: #007bff;
          color: #fff;
          border: none;
          padding: 12px 20px;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          height: 45px;
          white-space: nowrap;
          min-width: 140px;
        }

        .analysis-btn {
          background-color: #007bff;
          color: #fff;
          border: none;
          padding: 12px 20px;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          height: 45px;
          white-space: nowrap;
          min-width: 140px;
        }

        .compare-btn {
          background-color: #6f42c1;
          color: #fff;
          border: none;
          padding: 12px 20px;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          height: 45px;
          white-space: nowrap;
          min-width: 160px;
        }

        .file-name {
          margin-top: 10px;
          font-style: italic;
          color: #444;
          text-align: center;
        }

        .error {
          color: #dc3545;
          margin: 15px 0;
          padding: 10px;
          background-color: #f8d7da;
          border: 1px solid #f5c6cb;
          border-radius: 6px;
          text-align: center;
        }

        .success {
          color: #155724;
          margin: 15px 0;
          padding: 10px;
          background-color: #d4edda;
          border: 1px solid #c3e6cb;
          border-radius: 6px;
          text-align: center;
        }

        .chart-section {
          margin-top: 30px;
          padding: 20px;
          border: 1px solid #eaeaea;
          border-radius: 10px;
          background-color: #fff;
        }

        .chart-title {
          text-align: center;
          color: #333;
          margin-bottom: 20px;
          font-size: 20px;
        }

        button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        button:hover:not(:disabled) {
          opacity: 0.9;
          transform: translateY(-1px);
          transition: all 0.2s ease;
        }

        @media (max-width: 768px) {
          .form-row {
            flex-direction: column;
            align-items: stretch;
          }
          
          .main-container {
            padding: 20px;
          }
          
          .card {
            padding: 20px;
          }
        }
      `}</style>
    </div>
  );
};

export default CurriculumAnalysis;
