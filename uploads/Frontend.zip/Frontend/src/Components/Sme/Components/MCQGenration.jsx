
import React, { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "./AdminSidebar";
import LoadingScreen from "./LoadingScreen";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../styles/MCQGenration.css";

const MCQGeneration = ({ onLogout }) => {
  const [numQuestions, setNumQuestions] = useState("4");
  const [difficulty, setDifficulty] = useState("all");
  const [selectedLanguage, setSelectedLanguage] = useState("Java");
  const [quizData, setQuizData] = useState(null);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [selectedSubtopic, setSelectedSubtopic] = useState("");
  const [topicsData, setTopicsData] = useState([]);
  const [error, setError] = useState("");
  const [validationMode, setValidationMode] = useState(false);
  const [editedQuizData, setEditedQuizData] = useState([]);
  const [editModes, setEditModes] = useState([]);
  const [loading, setLoading] = useState(false);

  // ✅ Fetch topics from backend
  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`
          
        );
        setTopicsData(response.data);
        
      } catch (err) {
        console.error("Error fetching topics:", err);
        toast.error("Failed to fetch topics from backend for mcq genration.");
      }
    };
    fetchTopics();
  }, []);

  // ✅ Generate MCQs via FastAPI
  const handleGenerate = async () => {
    try {
      if (!selectedTopic || !selectedSubtopic) {
        setError("Please select both topic and subtopic.");
        return;
      }
      setError("");
      setLoading(true);

      const prompt = `${selectedSubtopic}`;
      const response = await axios.post(`${import.meta.env.VITE_AI_URL}/quiz-generation`, {
        prompt: prompt,
        difficulty,
        length: Number(numQuestions),
        language: selectedLanguage,
      });

      setQuizData(response.data);
      setEditedQuizData(response.data.quizes);
      setEditModes(new Array(response.data.quizes.length).fill(false));
      setValidationMode(true);
      localStorage.setItem("quizData", JSON.stringify(response.data));
      toast.success("✅ Quiz generated successfully!");
    } catch (error) {
      console.error("Error fetching quiz:", error);
      toast.error("❌ Failed to generate quiz. Check backend server.");
    } finally {
      setLoading(false);
    }
  };

  // ✅ Save MCQs to PostgreSQL via Spring Boot
  const handleSaveAll = async () => {
    try {
      if (!selectedSubtopic || !selectedTopic) {
        toast.warn("Please select both topic and subtopic.");
        return;
      }

      const selectedMainTopic = topicsData.find(
        (t) => t.mainTopicName === selectedTopic
      );
      const selectedSubtopicObj = selectedMainTopic?.subTopics.find(
        (sub) => sub.title === selectedSubtopic
      );

      if (!selectedSubtopicObj) {
        toast.error("Invalid subtopic selection.");
        return;
      }

      const topicId = selectedSubtopicObj.topicId;

      const mcqDTOs = editedQuizData.map((q) => ({
        topicId: topicId,
        language: selectedLanguage.toUpperCase(),
        content: {
          question: q.question,
          options: q.options,
          correctOptionId: q.correct_option_id,
          explanation: q.explanation,
        },
      }));

      await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/mcqs/topic/${topicId}/batch`,
        mcqDTOs
      );

      toast.success("✅ MCQs saved successfully to backend!");
      setValidationMode(false);
      setQuizData(null);
      setEditedQuizData([]);
      setEditModes([]);
      setSelectedTopic("");
      setSelectedSubtopic("");
      setDifficulty("all");
      setSelectedLanguage("Java");
      setNumQuestions("4");
      setError("");
    } catch (error) {
      console.error("Error saving MCQs:", error);
      toast.error("❌ Failed to save MCQs. Please try again.");
    }
  };

  // ✅ Edit/Update/Delete local quiz data before saving
  const handleEdit = (index) => {
    const newEditModes = [...editModes];
    newEditModes[index] = !newEditModes[index];
    setEditModes(newEditModes);
    if (newEditModes[index]) {
      toast.info(`✏️ Editing question ${index + 1}`);
    } else {
      toast.success(`💾 Question ${index + 1} updated successfully`);
    }
  };

  const handleDelete = (index) => {
    const newEditedQuizData = editedQuizData.filter((_, i) => i !== index);
    const newEditModes = editModes.filter((_, i) => i !== index);
    setEditedQuizData(newEditedQuizData);
    setEditModes(newEditModes);
    toast.warn(`🗑️ Deleted question ${index + 1}`);
  };

  const handleBack = () => {
    setValidationMode(false);
    setQuizData(null);
    setEditedQuizData([]);
    setEditModes([]);
    toast.info("🔙 Returned to form.");
  };

  const updateQuestion = (index, value) => {
    const newEditedQuizData = [...editedQuizData];
    newEditedQuizData[index].question = value;
    setEditedQuizData(newEditedQuizData);
  };

  const updateOption = (qIndex, oIndex, value) => {
    const newEditedQuizData = [...editedQuizData];
    newEditedQuizData[qIndex].options[oIndex].value = value;
    setEditedQuizData(newEditedQuizData);
  };

  const updateCorrectOption = (index, value) => {
    const newEditedQuizData = [...editedQuizData];
    newEditedQuizData[index].correct_option_id = parseInt(value);
    setEditedQuizData(newEditedQuizData);
  };

  const updateExplanation = (index, value) => {
    const newEditedQuizData = [...editedQuizData];
    newEditedQuizData[index].explanation = value;
    setEditedQuizData(newEditedQuizData);
  };

  // ✅ Show loading screen
  if (loading) {
    return (
      <div className="mcq-gen-whole-container">
        <Sidebar onLogout={onLogout} />
        <div className="loading-screen-container">
          <LoadingScreen />
          <p style={{ color: "#fff", textAlign: "center", marginTop: "20px" }}>
            
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mcq-gen-whole-container">
      <Sidebar onLogout={onLogout} />
      <ToastContainer position="top-right" autoClose={2000} />
      <div
        className={`mcq-generate-container ${
          validationMode ? "mcq-listing-container" : "mcq-form-container"
        }`}
      >
        {!validationMode ? (
          <div className="mcq-generation">
            <h1 className="mcq-head">AI-Powered MCQ Generation</h1>

            <label htmlFor="topic">Topic:</label>
            <select
              id="topic"
              value={selectedTopic}
              onChange={(e) => {
                setSelectedTopic(e.target.value);
                setSelectedSubtopic("");
                setError("");
              }}
              className="mcq-gen-topic"
            >
              <option value="">-- Select Topic --</option>
              {topicsData.map((topic) => (
                <option key={topic.mainTopicId} value={topic.mainTopicName}>
                  {topic.mainTopicName}
                </option>
              ))}
            </select>

            {selectedTopic && (
              <>
                <label>Select Subtopic:</label>
                <select
                  value={selectedSubtopic}
                  onChange={(e) => {
                    setSelectedSubtopic(e.target.value);
                    setError("");
                  }}
                  className="mcq-gen-topic"
                >
                  <option value="">-- Select Subtopic --</option>
                  {topicsData
                    .find((t) => t.mainTopicName === selectedTopic)
                    ?.subTopics.map((sub) => (
                      <option key={sub.topicId} value={sub.title}>
                        {sub.title}
                      </option>
                    ))}
                </select>
              </>
            )}

            <label>Select difficulty:</label>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
              className="mcq-gen-topic"
            >
              <option value="all">Mixed (All Difficulties)</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>

            <label>Select language:</label>
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="mcq-gen-topic"
            >
              <option value="Java">Java</option>
              <option value="Python">Python</option>
              <option value="JavaScript">JavaScript</option>
              <option value="TypeScript">TypeScript</option>
            </select>

            <label>Number of questions:</label>
            <input
              type="number"
              min="1"
              max="20"
              value={numQuestions}
              onChange={(e) => setNumQuestions(e.target.value)}
              placeholder="Enter number (e.g., 5)"
              className="mcq-gen-topic"
            />

            {error && <p className="error-text">{error}</p>}

            <div className="mcq-gen-button">
              <button
                className="mcq-gen-ok-button"
                onClick={handleGenerate}
                disabled={!selectedTopic || !selectedSubtopic}
              >
                Generate
              </button>
            </div>
          </div>
        ) : (
          <div className="mcq-generation">
            <h1 className="mcq-head">Validate and Edit MCQs</h1>
            <button
              onClick={handleBack}
              className="mcq-gen-ok-button"
              style={{ marginBottom: "20px" }}
            >
              Back to Form
            </button>

            <div style={{ marginTop: "20px" }}>
              <h3>Generated Quiz</h3>
              {editedQuizData.map((q, index) => (
                <div key={index} className="mcq-gen-quiz-item">
                  {editModes[index] ? (
                    <>
                      <label>Question:</label>
                      <input
                        type="text"
                        value={q.question}
                        onChange={(e) => updateQuestion(index, e.target.value)}
                        className="mcq-gen-topic"
                      />
                      <label>Options:</label>
                      {q.options.map((opt, oIndex) => (
                        <input
                          key={oIndex}
                          type="text"
                          value={opt.value}
                          onChange={(e) =>
                            updateOption(index, oIndex, e.target.value)
                          }
                          className="mcq-gen-topic"
                        />
                      ))}
                      <label>Correct Option ID:</label>
                      <input
                        type="number"
                        value={q.correct_option_id}
                        onChange={(e) =>
                          updateCorrectOption(index, e.target.value)
                        }
                        className="mcq-gen-topic"
                      />
                      <label>Explanation:</label>
                      <textarea
                        value={q.explanation}
                        onChange={(e) =>
                          updateExplanation(index, e.target.value)
                        }
                        className="mcq-gen-topic"
                      />
                    </>
                  ) : (
                    <>
                      <p>
                        <b>Q{index + 1}:</b> {q.question}
                      </p>
                      <ul>
                        {q.options.map((opt) => (
                          <li key={opt.id}>{opt.value}</li>
                        ))}
                      </ul>
                      <p>
                        <b>Answer:</b> Option {q.correct_option_id}
                      </p>
                      <p>
                        <b>Explanation:</b> {q.explanation}
                      </p>
                    </>
                  )}
                  <div className="mcq-gen-quiz-buttons">
                    <button
                      onClick={() => handleEdit(index)}
                      className="edit"
                    >
                      {editModes[index] ? "Save" : "Edit"}
                    </button>
                    <button
                      onClick={() => handleDelete(index)}
                      className="delete"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}

              <div className="mcq-gen-button">
                <button className="mcq-gen-ok-button" onClick={handleSaveAll}>
                  Save All
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MCQGeneration;