
import React, { useEffect, useMemo, useState } from 'react';
import dayjs from 'dayjs';
import '../styles/SMEReports.css';

import { fetchEvents } from '../../../api/mock';
import AdminSidebar from './AdminSidebar';
import FiltersBar from '../../SMEReportsComponents/FiltersBar';
import BatchSummary from '../../SMEReportsComponents/BatchSummary';
import LanguageLeaderboard from '../../SMEReportsComponents/LanguageLeaderboard';
import TopicFunnel from '../../SMEReportsComponents/TopicFunnel';
import ProblemStatsComp from '../../SMEReportsComponents/ProblemStats';
import TraineeProgressTable from '../../SMEReportsComponents/TraineeProgressTable';
import ComparativePanel from '../../SMEReportsComponents/ComparativePanel';
import DropoffChart from '../../SMEReportsComponents/DropoffChart';

import {
  filterByDate,
  computeBatchSummary,
  languageEngagement,
  topicFunnelByLanguage,
  problemStats,
  traineeProgress,
  dropoff,
} from '../../../utils/aggregations';

export default function SMEReports() {
  const [dateISO, setDateISO] = useState(dayjs().format('YYYY-MM-DD'));
  const [batchId, setBatchId] = useState('B2025-12');
  const [topicId, setTopicId] = useState('DSA-Stacks');
  const [problemId, setProblemId] = useState('TwoSum');

  const [loading, setLoading] = useState(false);
  const [events, setEvents] = useState([]);
  const [meta, setMeta] = useState({});

  const handleFilterChange = (patch) => {
    if (patch.dateISO !== undefined) setDateISO(patch.dateISO);
    if (patch.batchId !== undefined) setBatchId(patch.batchId);
    if (patch.topicId !== undefined) setTopicId(patch.topicId);
    if (patch.problemId !== undefined) setProblemId(patch.problemId);
  };

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const { events, meta } = await fetchEvents({ batchId, dateISO });
        setEvents(events);
        setMeta(meta);
      } finally {
        setLoading(false);
      }
    })();
  }, [batchId, dateISO]);

  // Derived data for the selected day
  const dayEvents = useMemo(() => filterByDate(events, dateISO), [events, dateISO]);
  const summary = useMemo(() => computeBatchSummary(dayEvents), [dayEvents]);
  const langBoard = useMemo(() => languageEngagement(dayEvents), [dayEvents]);
  const funnel = useMemo(() => topicFunnelByLanguage(dayEvents, { topicId }), [dayEvents, topicId]);
  const probStats = useMemo(() => problemStats(dayEvents, { problemId }), [dayEvents, problemId]);
  const traineeRows = useMemo(() => traineeProgress(dayEvents), [dayEvents]);
  const dropoffData = useMemo(() => dropoff(dayEvents, { topicId }), [dayEvents, topicId]);

  return (
    <div className="reports-layout">
      <AdminSidebar />
      <div className="main-content">
        <div className="container">

          <FiltersBar
            dateISO={dateISO}
            batchId={batchId}
            topicId={topicId}
            problemId={problemId}
            onChange={handleFilterChange}
          />

          {loading && <div className="loading">Loading data…</div>}

          {!loading && (
            <>
              <BatchSummary summary={summary} />

              <LanguageLeaderboard data={langBoard} />

              <TopicFunnel data={funnel} topicId={topicId} />

              <ProblemStatsComp data={probStats} problemId={problemId} />

              <DropoffChart data={dropoffData} topicId={topicId} />

              <TraineeProgressTable rows={traineeRows} />

              <ComparativePanel rows={traineeRows} />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
