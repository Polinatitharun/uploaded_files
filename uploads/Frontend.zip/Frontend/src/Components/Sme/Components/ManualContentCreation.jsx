import React from 'react';
import '../styles/ManualContentCreation.css';

const ManualContentCreation = ({
  isOpen,
  onClose,
  manualForm,
  setManualForm,
  updateLanguageDetail,
  handleManualSubmit,
  error
}) => {
  if (!isOpen) return null;

  return (
    <div className="manual-modal-overlay">
      <div className="manual-modal">
        <h2 className="manual-modal-title">Create Content Manually</h2>

        <label className="manual-label">Explanation:</label>
        <textarea
          value={manualForm.explanation}
          onChange={(e) => setManualForm(prev => ({ ...prev, explanation: e.target.value }))}
          className="manual-textarea"
          rows="4"
          placeholder="Enter explanation"
        />

        <label className="manual-label">Language Details:</label>
        {manualForm.languageDetails.map((lang, index) => (
          <div key={index} className="language-detail">
            <h4>{lang.language}</h4>

            
              <>
                <textarea
                  value={lang.syntax}
                  onChange={(e) => updateLanguageDetail(index, 'syntax', e.target.value)}
                  placeholder="Syntax"
                  rows="4"
                  className="manual-textarea"
                />

                <textarea
                  value={lang.example}
                  onChange={(e) => updateLanguageDetail(index, 'example', e.target.value)}
                  placeholder="Example"
                  rows="4"
                  className="manual-textarea"
                />
              </>
          </div>
        ))}

        <label className="manual-label">Code Difference Explanation:</label>
        <textarea
          value={manualForm.codeDifferenceExplanation}
          onChange={(e) => setManualForm(prev => ({ ...prev, codeDifferenceExplanation: e.target.value }))}
          className="manual-textarea"
          rows="4"
          placeholder="Enter code difference explanation"
        />

        {error && <p className="error-text">{error}</p>}

        <div className="manual-modal-buttons">
          <button
            className="save-btn"
            onClick={handleManualSubmit}
          >
            Create Content
          </button>
          <button
            className="cancel-btn"
            onClick={onClose}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ManualContentCreation;
