import React from "react";
import "../styles/DetailedReportModal.css";

const DetailedReportModal = ({ user, report, onClose }) => {
  return (
    <div className="modal-overlay">
      <div className="modal-content detailed-modal">
        <h2>Detailed Report for {user.userName}</h2>
        <p><strong className="txt">Overall Performance Score:</strong> {report.overall_performance_score}</p>

        <h3>Suggested Streams:</h3>
        <ul>
          {report.suggested_streams.map((stream, idx) => (
            <li key={idx}>{stream}</li>
          ))}
        </ul>

        <h3>Language Summary:</h3>
        {report.language_summary.map((lang, idx) => (
          <div key={idx} className="lang-summary">
            <p><strong className="txt">Language:</strong> {lang.language}</p>
            <p><strong className="txt">Performance Score:</strong> {lang.performance_score}</p>
            <p><strong className="txt">Average Difficulty Mastered:</strong> {lang.avg_difficulty_mastered}</p>
            <p><strong className="txt">Total Attempts:</strong> {lang.total_attempts}</p>
          </div>
        ))}

        <h3> General Recommendations:</h3>
        <p>{report.general_recommendations}</p>

        <button className="close-btn" onClick={onClose}>
          X
        </button>
      </div>
    </div>
  );
};

export default DetailedReportModal;