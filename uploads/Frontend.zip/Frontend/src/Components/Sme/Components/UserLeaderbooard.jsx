import * as React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import "../styles/UserLeaderboard.css";
import Sidebar from "./AdminSidebar";
import ViewReportModal from "./ViewReportModal";
import DetailedReportModal from "./DetailedReportModal"; // 👈 new modal

function UserLeaderboard({ onLogout }) {
  const [users, setUsers] = useState([]);
  const [sortBy, setSortBy] = useState("total");
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [detailedReportUser, setDetailedReportUser] = useState(null);
  const [detailedReport, setDetailedReport] = useState(null);

  const [adminUsers, setAdminUsers] = useState([]);

  const [platformStats, setPlatformStats] = useState({
    totalUsers: 0,
    totalSolvedInJava: 0,
    totalSolvedPython: 0,
    totalSolvedJavaScript: 0,
    totalSolvedTypeScript: 0,
  });

  // ✅ Toggle dummy data ON/OFF
  const useDummyData = false;

  // ✅ Dummy Data
  const dummyUsers = [
    { username: "Alice", email: "alice@example.com", javaScore: 12, pythonScore: 9, totalScore: 21 },
    { username: "Bob", email: "bob@example.com", javaScore: 5, pythonScore: 7, totalScore: 12 },
    { username: "Charlie", email: "charlie@example.com", javaScore: 15, pythonScore: 5, totalScore: 20 },
  ];

  const dummyAdminUsers = [
    { userId: "2854134", userName: "Gopanwar Srikanth", batchName: "Ignite Batch", userProblemReportDTOS: [] },
    { userId: "2853304", userName: "Debasish Routray", batchName: "Ignite Batch", userProblemReportDTOS: [] },
  ];

  const dummyPlatformStats = {
    totalUsers: 3,
    totalSolvedInJava: 4,
    totalSolvedPython: 3,
    totalSolvedJavaScript: 0,
    totalSolvedTypeScript: 0,
  };

  const fetchUserProgress = async () => {
    if (useDummyData) {
      // 🧩 Load Dummy Data
      setUsers(dummyUsers);
      return;
    }
    try {
      setLoading(true);
      const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/progress/`);
      const data = res.data;
      const userMap = {};

      data.forEach((row) => {
        const email = row.email;
        const username = row.username || email;
        if (!userMap[email]) {
          userMap[email] = { username, email, javaScore: 0, pythonScore: 0 };
        }
        if (row.javaCompleted) userMap[email].javaScore++;
        if (row.pythonCompleted) userMap[email].pythonScore++;
      });

      const groupedData = Object.values(userMap).map((user) => ({
        ...user,
        totalScore: user.javaScore + user.pythonScore,
      }));

      setUsers(groupedData);
    } catch (error) {
      console.error("Error fetching user progress", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAllUserStats = async () => {
    if (useDummyData) {
      setAdminUsers(dummyAdminUsers);
      return;
    }
    try {
      const res = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/admin/dashboard`
      );
      setAdminUsers(res.data || []);
    } catch (error) {
      console.error("Error fetching admin user stats", error);
      setAdminUsers([]);
    }
  };

  const fetchPlatformStats = async () => {
    if (useDummyData) {
      setPlatformStats(dummyPlatformStats);
      return;
    }
    try {
      const res = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/admin/dashboard/platform-stats`
      );
      const data = res.data;
      setPlatformStats({
        totalUsers: data.totalUsers || 0,
        totalSolvedInJava: data.totalSolvedInJava || 0,
        totalSolvedPython: data.totalSolvedPython || 0,
        totalSolvedJavaScript: data.totalSolvedJavaScript || 0,
        totalSolvedTypeScript: data.totalSolvedTypeScript || 0,
      });
    } catch (error) {
      console.error("Error fetching platform stats", error);
    }
  };

  useEffect(() => {
    // Simulate network delay for dummy data
    setLoading(true);
    setTimeout(() => {
      fetchUserProgress();
      fetchAllUserStats();
      fetchPlatformStats();
      setLoading(false);
    }, useDummyData ? 800 : 0);
  }, []);

  const sortedUsers = [...users].sort((a, b) => {
    if (sortBy === "total") return b.totalScore - a.totalScore;
    if (sortBy === "java") return b.javaScore - a.javaScore;
    if (sortBy === "python") return b.pythonScore - a.pythonScore;
    return 0;
  });

  const filteredUsers = adminUsers.filter((user) => {
    const userIdStr = String(user.userId || "").toLowerCase();
    const userNameStr = String(user.userName || "").toLowerCase();
    return (
      userIdStr.includes(search.toLowerCase()) ||
      userNameStr.includes(search.toLowerCase())
    );
  });

  return (
    <div className="content-gen-whole-container">
      <Sidebar onLogout={onLogout} />

      <div className="leaderboard-main">
        {/* --- Header --- */}
        <div className="leaderboard-header">
          <div className="header-content">
            <h1 className="leaderboard-title">
              <span className="title-icon">🏆</span> User Leaderboard
            </h1>
            <p className="leaderboard-subtitle">
              Track your progress and compete with fellow learners
            </p>
          </div>

          {/* --- Stats Section --- */}
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-number">{platformStats.totalUsers}</div>
              <div className="stat-label">Total Users</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{platformStats.totalSolvedInJava}</div>
              <div className="stat-label">Java Questions Solved</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{platformStats.totalSolvedPython}</div>
              <div className="stat-label">Python Questions Solved</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{platformStats.totalSolvedJavaScript}</div>
              <div className="stat-label">JavaScript Questions Solved</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{platformStats.totalSolvedTypeScript}</div>
              <div className="stat-label">TypeScript Questions Solved</div>
            </div>
          </div>
        </div>

        {/* --- Admin Dashboard --- */}
        <div className="admin-dashboard-section">
          <h2 className="dashboard-title">Admin Dashboard</h2>

          <input
            type="text"
            placeholder="Search by UserID or Username"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="search-bar"
          />

          <table className="user-table">
            <thead>
              <tr>
                <th>UserID</th>
                <th>Username</th>
                <th>Batch Name</th>
                <th>Problem Reports</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <tr key={user.userId}>
                    <td>{user.userId}</td>
                    <td>{user.userName}</td>
                    <td>{user.batchName}</td>
                    <td>
                      <button onClick={() => setSelectedUser(user)}>View ({user.userProblemReportDTOS?.length || 0})</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" style={{ textAlign: "center", padding: "10px" }}>
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* --- Modals --- */}
        {selectedUser && (
          <ViewReportModal user={selectedUser} onClose={() => setSelectedUser(null)} />
        )}
        {detailedReportUser && detailedReport && (
          <DetailedReportModal
            user={detailedReportUser}
            report={detailedReport}
            onClose={() => {
              setDetailedReportUser(null);
              setDetailedReport(null);
            }}
          />
        )}
      </div>
    </div>
  );
}

export default UserLeaderboard;