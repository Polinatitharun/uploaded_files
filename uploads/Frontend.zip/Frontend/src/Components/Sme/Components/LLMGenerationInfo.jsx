import "../styles/Welcome.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "./AdminSidebar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import SubtopicModal from "./SubtopicModal"; // ✅ newly added import
import NotebookSection from "./NotebookSection";
import DeleteModal from "./DeleteModal";

function LLMGenerationInfo({ onLogout }) {
  const [activeType, setActiveType] = useState("content");

  // Content (main topics)
  const [contentData, setContentData] = useState([]);
  const [filteredContent, setFilteredContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  // MCQ states
  const [mcqSearchTerm, setMcqSearchTerm] = useState("");
  const [allMcqs, setAllMcqs] = useState([]);
  const [mcqLoading, setMcqLoading] = useState(false);
  // MCQ editing state
  const [editingMcqId, setEditingMcqId] = useState(null);
  const [editedMcq, setEditedMcq] = useState(null);

  // Question (Problem) states
  const [questionSearchTerm, setQuestionSearchTerm] = useState("");
  const [allQuestions, setAllQuestions] = useState([]);
  const [questionLoading, setQuestionLoading] = useState(false);
  const [editingProblemId, setEditingProblemId] = useState(null);
  const [editedProblem, setEditedProblem] = useState({});

  // Content editing states
  const [editingMainTopicId, setEditingMainTopicId] = useState(null);
  const [editedMainTopic, setEditedMainTopic] = useState({});
  const [editingSubtopicId, setEditingSubtopicId] = useState(null);
  const [editedSubtopic, setEditedSubtopic] = useState({});

  
  // Delete confirmation modal states
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteAction, setDeleteAction] = useState(null);
  const [deleteMessage, setDeleteMessage] = useState('');
  const [deleteTitle, setDeleteTitle] = useState('');

  const [toggle, setToggle] = useState(false);

  // ✅ Modal states for subtopic details
  const [selectedSubtopic, setSelectedSubtopic] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openSubtopicModal = (subtopic) => {
    setSelectedSubtopic(subtopic);
    setIsModalOpen(true);
  };

  const closeSubtopicModal = () => {
    setIsModalOpen(false);
    setSelectedSubtopic(null);
  };

  // --- Fetch main topics (content)
  async function fetchGeneratedContent() {
    try {
      setLoading(true);
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`
      );
      setContentData(response.data || []);
      setFilteredContent(response.data || []);
    } catch (err) {
      console.error("Failed to fetch main topics:", err);
      setContentData([]);
      setFilteredContent([]);
    } finally {
      setLoading(false);
    }
  }
  //MCQ EDIT save 
  const saveEditedMcq = async (topicId, mcqId, mcqPayload) => {
    try {
      const res = await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/mcqs/${mcqId}`,
        mcqPayload,
        { headers: { "Content-Type": "application/json" } }
      );

      toast.success("MCQ updated successfully!");
      setToggle((prev) => !prev); 
      setEditingMcqId(null);
      setEditedMcq(null);
    } catch (err) {
      console.error("Error updating MCQ:", err);
      toast.error("Failed to update MCQ");
    }
  };

  // --- Fetch MCQs for all topics
  async function fetchAllMcqsByTopics(topics) {
    setMcqLoading(true);
    try {
      const aggregated = [];
      for (const t of topics) {
        try {
          const res = await axios.get(
            `${import.meta.env.VITE_API_BASE_URL}/api/sme/mcqs/topic/${t.topicId}`
          );
          if (Array.isArray(res.data) && res.data.length > 0) {
            aggregated.push({
              topicId: t.topicId,
              topicTitle: t.title,
              mcqs: res.data.map((m) => ({
                mcqId: m.mcqId,
                content: m.content || {},
              })),
            });
          }

        } catch (err) {
          console.error(`Error fetching MCQs for topic ${t.title}:`, err);
        }
      }
      setAllMcqs(aggregated);


    } finally {
      setMcqLoading(false);
    }
  }

  // --- Fetch Problems (questions) for all topics
  async function fetchAllQuestionsByTopics(topics) {
    setQuestionLoading(true);
    try {
      const aggregated = [];
      for (const t of topics) {
        try {
          const res = await axios.get(
            `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/topic/${t.topicId}`
          );
          if (Array.isArray(res.data) && res.data.length > 0) {
            aggregated.push({
              topicId: t.topicId,
              topicTitle: t.title,
              problems: res.data,
            });
          }
        } catch (err) {
          console.error(`Error fetching problems for topic ${t.title}:`, err);
        }
      }
      setAllQuestions(aggregated);
    } finally {
      setQuestionLoading(false);
    }
  }


  //edit button in question section
  const saveEditedProblem = async (topicId, problemId, editedData) => {
    try {
      const res = await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/${problemId}`,
        editedData
      );
      toast.success("Problem updated successfully!");

      // Refresh updated list
      fetchAllQuestionsByTopics(
        contentData.flatMap((main) =>
          (main.subTopics || []).map((t) => ({
            topicId: t.topicId,
            title: t.title,
          }))
        )
      );
    } catch (err) {
      console.error("Error updating problem:", err);
      toast.error("Failed to update problem");
    }
  };

  // --- Component mount
  useEffect(() => {
    fetchGeneratedContent();
  }, [toggle]);

  // --- When contentData changes, fetch MCQs & Questions
  useEffect(() => {
    if (!contentData || contentData.length === 0) {
      setAllMcqs([]);
      setAllQuestions([]);
      return;
    }

    const topics = contentData.flatMap((main) =>
      (main.subTopics || []).map((t) => ({
        topicId: t.topicId,
        title: t.title,
      }))
    );

    if (topics.length === 0) {
      setAllMcqs([]);
      setAllQuestions([]);
      return;
    }

    fetchAllMcqsByTopics(topics);
    fetchAllQuestionsByTopics(topics);
  }, [contentData, toggle]);

  // --- Search
  function handleSearch(e) {
    const value = e.target.value || "";
    setSearchTerm(value);
    const filtered = (contentData || []).filter((item) =>
      (item.mainTopicName || "").toLowerCase().includes(value.toLowerCase())
    );
    setFilteredContent(filtered);
  }

  // --- Delete helpers (unchanged)
  async function deleteTopicMcqs(topicId, topicTitle) {
    try {
      await axios.delete(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/mcqs/topic/${topicId}`
      );
      setAllMcqs((prev) => prev.filter((t) => t.topicId !== topicId));
      toast.success(`Deleted all MCQs for "${topicTitle}"`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete topic MCQs");
    }
  }

  async function deleteSingleMcq(topicId, mcqId) {
    try {
      await axios.delete(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/mcqs/${mcqId}`
      );
      setAllMcqs((prev) =>
        prev.map((t) =>
          t.topicId === topicId
            ? { ...t, mcqs: t.mcqs.filter((m) => m.mcqId !== mcqId) }
            : t
        )
      );
      toast.success("MCQ deleted successfully");
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete MCQ");
    }
  }

  async function deleteTopicQuestions(topicId, topicTitle) {
    try {
      await axios.delete(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/topic/${topicId}`
      );
      setAllQuestions((prev) => prev.filter((t) => t.topicId !== topicId));
      toast.success(`Deleted all questions for "${topicTitle}"`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete topic questions");
    }
  }

  async function deleteSingleQuestion(topicId, problemId) {
    try {
      await axios.delete(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/${problemId}`
      );
      setAllQuestions((prev) =>
        prev.map((t) =>
          t.topicId === topicId
            ? {
              ...t,
              problems: t.problems.filter((p) => p.problemId !== problemId),
            }
            : t
        )
      );
      toast.success("Question deleted successfully");
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete question");
    }
  }

  // --- Delete subtopic
  async function deleteSubtopic(topicId, subtopicTitle) {
    try {
      await axios.delete(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/${topicId}`,
      );
      setContentData((prev) =>
        prev.map((mt) => ({
          ...mt,
          subTopics: mt.subTopics.filter((st) => st.topicId !== topicId),
        }))
      );
      setToggle((prev) => !prev); 
      toast.success(`Deleted subtopic "${subtopicTitle}"`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete subtopic");
    }
  }

  // --- Save edited main topic
  const saveEditedMainTopic = async (mainTopicId, payload) => {
    try {
      await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics/${mainTopicId}`,
        payload
      );
      toast.success("Main topic updated successfully!");
      setToggle((prev) => !prev);
      setEditingMainTopicId(null);
      setEditedMainTopic({});
    } catch (err) {
      console.error(err);
      toast.error("Failed to update main topic");
    }
  };

  // --- Save edited subtopic
  const saveEditedSubtopic = async (topicId, payload, subtopic) => {
    try {
      // Build the full payload as per the API format
      const currentContent = subtopic.content || {};
      const updatedContent = {
        ...currentContent,
        topic: payload.title || currentContent.topic,
        subtopic: {
          ...currentContent.subtopic,
          name: payload.title || currentContent.subtopic?.name,
          content: {
            ...currentContent.subtopic?.content,
            explanation: payload.explanation || currentContent.subtopic?.content?.explanation,
            code_difference_explanation: payload.code_difference_explanation || currentContent.subtopic?.content?.code_difference_explanation,
            language_details: payload.language_details || currentContent.subtopic?.content?.language_details,
          },
        },
      };

      const fullPayload = {
        topicId: topicId,
        title: payload.title || subtopic.title,
        content: updatedContent,
      };

      await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/${topicId}`,
        fullPayload,
        { headers: { "Content-Type": "application/json" } }
      );
      toast.success("Subtopic updated successfully!");
      setToggle((prev) => !prev);
      setEditingSubtopicId(null);
      setEditedSubtopic({});
    } catch (err) {
      console.error(err);
      toast.error("Failed to update subtopic");
    }
  };


  // --- Filtered arrays
  const filteredContentToRender =
    searchTerm.trim() === ""
      ? filteredContent
      : (filteredContent || []).filter((item) =>
        (item.mainTopicName || "")
          .toLowerCase()
          .includes(searchTerm.trim().toLowerCase())
      );

  const filteredMcqs =
    mcqSearchTerm.trim() === ""
      ? allMcqs
      : (allMcqs || []).filter((topicSet) =>
        (topicSet.topicTitle || "")
          .toLowerCase()
          .includes(mcqSearchTerm.trim().toLowerCase())
      );

  const filteredQuestions =
    questionSearchTerm.trim() === ""
      ? allQuestions
      : (allQuestions || []).filter((topicSet) =>
        (topicSet.problems || []).some((q) =>
          (q.title || "")
            .toLowerCase()
            .includes(questionSearchTerm.trim().toLowerCase())
        )
      );

  return (
    <div className="llmgen-container">
      <Sidebar onLogout={onLogout} />

      <ToastContainer position="top-right" autoClose={3000} theme="colored" />

      <div className="llmgen-main">
        <h2 className="llmgen-title">Dashboard</h2>

        <div className="llmgen-button-group">
          <button
            onClick={() => setActiveType("content")}
            className={activeType === "content" ? "active-tab" : ""}
          >
            Content
          </button>

          <button
            onClick={() => setActiveType("mcq")}
            className={activeType === "mcq" ? "active-tab" : ""}
          >
            MCQ
          </button>

          <button
            onClick={() => setActiveType("question")}
            className={activeType === "question" ? "active-tab" : ""}
          >
            Question
          </button>
          <button
            onClick={() => setActiveType("notebook")}
            className={activeType === "notebook" ? "active-tab" : ""}
          >
            Notebook
          </button>

        </div>

        {/* ========== CONTENT SECTION ========== */}
        {activeType === "content" && (
          <section className="llmgen-section">
            <h3>Main Topics and Subtopics</h3>

            <div style={{ marginBottom: 20 }}>
              <input
                type="text"
                placeholder="Search by main topic title..."
                value={searchTerm}
                onChange={handleSearch}
                style={{
                  width: "60%",
                  padding: 10,
                  borderRadius: 8,
                  border: "1px solid #ccc",
                }}
              />
            </div>

            {loading ? (
              <p>Loading...</p>
            ) : filteredContentToRender.length === 0 &&
              searchTerm.trim() !== "" ? (
              <p style={{ fontStyle: "italic", color: "gray" }}>
                No data found matching your search.
              </p>
            ) : filteredContentToRender.length === 0 ? (
              <p>No topics found.</p>
            ) : (
              filteredContentToRender.map((mainTopic) => {
                const isEditingMain = editingMainTopicId === mainTopic.mainTopicId;
                const isEditingSub = editingSubtopicId !== null;

                return (
                  <div key={mainTopic.mainTopicId} className="llmgen-card">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <h3 style={{ color: "#007bff", margin: 0 }}>
                        {isEditingMain ? (
                          <input
                            type="text"
                            value={editedMainTopic.mainTopicName || mainTopic.mainTopicName}
                            onChange={(e) => setEditedMainTopic({ ...editedMainTopic, mainTopicName: e.target.value })}
                            style={{ fontSize: "1.17em", fontWeight: "bold", color: "#007bff", border: "1px solid #ccc", padding: "4px" }}
                          />
                        ) : (
                          mainTopic.mainTopicName
                        )}
                      </h3>
                      <div style={{ display: "flex", gap: "10px" }}>
                        {isEditingMain ? (
                          <>
                            <button
                              className="info-btn"
                              onClick={() => saveEditedMainTopic(mainTopic.mainTopicId, editedMainTopic)}
                              style={{ backgroundColor: "#28a745", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6 }}
                            >
                              Save
                            </button>
                            <button
                              className="info-btn"
                              onClick={() => {
                                setEditingMainTopicId(null);
                                setEditedMainTopic({});
                              }}
                              style={{ backgroundColor: "#ffc107", color: "#000", border: "none", padding: "8px 12px", borderRadius: 6 }}
                            >
                              Cancel
                            </button>
                          </>
                        ) : (
                          <button
                            className="info-btn"
                            onClick={() => {
                              setEditingMainTopicId(mainTopic.mainTopicId);
                              setEditedMainTopic({
                                mainTopicName: mainTopic.mainTopicName,
                                mainTopicDescription: mainTopic.mainTopicDescription
                              });
                            }}
                            style={{ backgroundColor: "#007bff", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6 }}
                          >
                            Edit
                          </button>
                        )}
                      </div>
                    </div>
                    <p>
                      <strong className="txt">Description:</strong>{" "}
                      {isEditingMain ? (
                        <textarea
                          value={editedMainTopic.mainTopicDescription || mainTopic.mainTopicDescription || ""}
                          onChange={(e) => setEditedMainTopic({ ...editedMainTopic, mainTopicDescription: e.target.value })}
                          style={{ width: "100%", padding: "6px", borderRadius: 6, border: "1px solid #ccc" }}
                          rows={2}
                        />
                      ) : (
                        mainTopic.mainTopicDescription || "No description provided"
                      )}
                    </p>
                    <h4>Subtopics:</h4>
                    {mainTopic.subTopics && mainTopic.subTopics.length > 0 ? (
                      mainTopic.subTopics.map((sub) => {
                        const isEditingThisSub = editingSubtopicId === sub.topicId;

                        return (
                          <div
                            key={sub.topicId}
                            className="llmgen-subtopic"
                            style={{
                              marginLeft: 20,
                              padding: 10,
                              borderLeft: "3px solid #ddd",
                              marginBottom: 10,
                              cursor: "pointer",
                              transition: "background 0.2s ease",
                              position: "relative"
                            }}
                            onMouseEnter={(e) =>
                              (e.currentTarget.style.background = "#f1f8ff")
                            }
                            onMouseLeave={(e) =>
                              (e.currentTarget.style.background = "transparent")
                            }
                          >
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                              <div style={{ flex: 1 }}>
                                <p>
                                  <strong className="txt">Title:</strong>{" "}
                                  {isEditingThisSub ? (
                                    <input
                                      type="text"
                                      value={editedSubtopic.title || sub.title}
                                      onChange={(e) => setEditedSubtopic({ ...editedSubtopic, title: e.target.value })}
                                      style={{ width: "100%", padding: "4px", border: "1px solid #ccc", borderRadius: 4 }}
                                    />
                                  ) : (
                                    sub.title
                                  )}
                                </p>
                                <p>
                                  <strong className="txt">Explanation:</strong>{" "}
                                  {isEditingThisSub ? (
                                    <textarea
                                      value={editedSubtopic.explanation || sub.content?.subtopic?.content?.explanation || ""}
                                      onChange={(e) => setEditedSubtopic({ ...editedSubtopic, explanation: e.target.value })}
                                      style={{ width: "100%", padding: "6px", borderRadius: 6, border: "1px solid #ccc" }}
                                      rows={2}
                                    />
                                  ) : (
                                    sub.content?.subtopic?.content?.explanation || "No explanation provided"
                                  )}
                                </p>
                                {!isEditingThisSub && (
                                  <p
                                    style={{
                                      color: "#007bff",
                                      fontSize: "13px",
                                      marginTop: "5px",
                                    }}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openSubtopicModal(sub);
                                    }}
                                  >
                                    Click to view language details →
                                  </p>
                                )}
                              </div>
                              <div style={{ display: "flex", gap: "10px", marginLeft: 10 }}>
                                {isEditingThisSub ? (
                                  <>
                                    <button
                                      className="info-btn"
                                      onClick={() => saveEditedSubtopic(sub.topicId, editedSubtopic, sub)}
                                      style={{ backgroundColor: "#28a745", color: "#fff", border: "none", padding: "6px 10px", borderRadius: 6, fontSize: "12px" }}
                                    >
                                      Save
                                    </button>
                                    <button
                                      className="info-btn"
                                      onClick={() => {
                                        setEditingSubtopicId(null);
                                        setEditedSubtopic({});
                                      }}
                                      style={{ backgroundColor: "#ffc107", color: "#000", border: "none", padding: "6px 10px", borderRadius: 6, fontSize: "12px" }}
                                    >
                                      Cancel
                                    </button>
                                  </>
                                ) : (
                                  <button
                                    className="info-btn"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setEditingSubtopicId(sub.topicId);
                                      setEditedSubtopic({
                                        title: sub.title,
                                        explanation: sub.content?.subtopic?.content?.explanation || ""
                                      });
                                    }}
                                    style={{ backgroundColor: "#007bff", color: "#fff", border: "none", padding: "6px 10px", borderRadius: 6, fontSize: "12px" }}
                                  >
                                    Edit
                                  </button>
                                )}
                                <button
                                  className="info-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDeleteAction(() => () => deleteSubtopic(sub.topicId, sub.title));
                                    setDeleteTitle("Delete Subtopic");
                                    setDeleteMessage(`Are you sure you want to delete the subtopic "${sub.title}"? This action cannot be undone.`);
                                    setShowDeleteModal(true);
                                  }}
                                  style={{ backgroundColor: "#dc3545", color: "white", border: "none", padding: "6px 10px", borderRadius: 6, fontSize: "12px" }}
                                >
                                  Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <p style={{ marginLeft: 20 }}>No subtopics found.</p>
                    )}
                  </div>
                );
              })
            )}
          </section>
        )}

        {/* MCQ & QUESTION sections remain unchanged */}
        {/* ========== MCQ ========== */}
        {activeType === "mcq" && (
          <section className="llmgen-section">
            <h3>MCQ Questions</h3>

            <div style={{ marginBottom: 20 }}>
              <input
                type="text"
                placeholder="Search by topic name..."
                value={mcqSearchTerm}
                onChange={(e) => setMcqSearchTerm(e.target.value)}
                style={{ width: "60%", padding: 10, borderRadius: 8, border: "1px solid #ccc" }}
              />
            </div>

            {mcqLoading ? (
              <p>Loading MCQs...</p>
            ) : filteredMcqs.length === 0 && mcqSearchTerm.trim() !== "" ? (
              <p style={{ fontStyle: "italic", color: "gray" }}>No MCQs found matching your search.</p>
            ) : allMcqs.length === 0 ? (
              <p>No MCQs found.</p>
            ) : (
              filteredMcqs.map((topicSet) => (
                <div key={topicSet.topicId} className="llmgen-card" style={{ marginBottom: 16 }}>
                  <div className="data-manp" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <h4>Topic: {topicSet.topicTitle} (ID: {topicSet.topicId})</h4>
                    <button
                      className="info-btn"
                      onClick={() => deleteTopicMcqs(topicSet.topicId, topicSet.topicTitle)}
                      style={{ backgroundColor: "#dc3545", color: "white", border: "none", padding: "8px 12px", borderRadius: 6 }}
                    >
                      Delete Topic MCQs
                    </button>
                  </div>

                  {topicSet.mcqs.map((mcq, idx) => {
                    const content = mcq.content || {};
                    const isEditing = editingMcqId === mcq.mcqId;

                    // local values for editing
                    const local = isEditing ? editedMcq : {
                      question: content.question || "",
                      options: Array.isArray(content.options) ? [...content.options] : [],
                      correct_answer: content.correct_answer || "",
                      explanation: content.explanation || ""
                    };

                    return (
                      <div key={mcq.mcqId || idx} className="llmgen-mcq" style={{ marginTop: 12, padding: 12, borderLeft: "3px solid #eee", background: "#fff" }}>
                        {/* question header */}
                        <strong className="txt">Q{idx + 1}:</strong>{" "}
                        <div style={{ marginBottom: 8, width: "100%" }}>
                          <p style={{ margin: 0 }}>

                            {isEditing ? (
                              <textarea
                                type="text"
                                value={local.question}
                                onChange={(e) => setEditedMcq(prev => ({ ...prev, question: e.target.value }))}
                                style={{ width: "80%", padding: "6px", fontSize: 14, marginTop: "6px" }}
                              ></textarea>
                            ) : (
                              content.question || "No question available"
                            )}
                          </p>
                        </div>

                        {/* options */}

                        {isEditing ? (
                          <div style={{ marginTop: 8 }}>
                            {/* Options Editor */}
                            <label style={{ fontWeight: 600 }}>Options:</label>
                            {local.options.map((opt, oidx) => {
                              const optVal = typeof opt === "object" ? (opt.value ?? "") : opt ?? "";
                              return (
                                <div
                                  key={oidx}
                                  style={{ display: "flex", gap: 8, marginTop: 8, alignItems: "center" }}
                                >
                                  <input
                                    type="text"
                                    value={optVal}
                                    onChange={(e) => {
                                      const newValue = e.target.value;
                                      const newOpts = [...local.options];

                                      if (typeof opt === "object") {
                                        newOpts[oidx] = { ...opt, value: newValue };
                                      } else {
                                        newOpts[oidx] = newValue;
                                      }

                                      const prevCorrect = local.correct_answer ?? "";
                                      const newCorrect =
                                        prevCorrect === optVal ? newValue : prevCorrect;

                                      setEditedMcq((prev) => ({
                                        ...prev,
                                        options: newOpts,
                                        correct_answer: newCorrect,
                                      }));
                                    }}
                                    style={{ flex: 1, padding: 6 }}
                                  />

                                  <button
                                    className="info-btn"
                                    onClick={() => {
                                      const newOpts = local.options.filter((_, i) => i !== oidx);
                                      const prevCorrect = local.correct_answer ?? "";
                                      const wasCorrect = prevCorrect === optVal;

                                      const newCorrect = wasCorrect ? "" : prevCorrect;

                                      setEditedMcq((prev) => ({
                                        ...prev,
                                        options: newOpts,
                                        correct_answer: newCorrect,
                                      }));
                                    }}
                                    style={{
                                      backgroundColor: "#ffc107",
                                      border: "none",
                                      padding: "6px 8px",
                                      borderRadius: 6,
                                    }}
                                  >
                                    Remove
                                  </button>
                                </div>
                              );
                            })}

                            <button
                              className="info-btn"
                              onClick={() =>
                                setEditedMcq((prev) => ({
                                  ...prev,
                                  options: [...(prev.options || []), ""],
                                }))
                              }
                              style={{
                                marginTop: 10,
                                backgroundColor: "#007bff",
                                color: "#fff",
                                border: "none",
                                padding: "8px 12px",
                                borderRadius: 6,
                              }}
                            >
                              + Add Option
                            </button>

                            {/* Correct Answer Dropdown */}
                            <div style={{ marginTop: 12, display: "flex" }}>
                              <label style={{ fontWeight: 600, marginRight: 8, color: "#000" }}>
                                Correct answer:
                              </label>
                              <select
                                value={
                                  // If correct_answer is empty, auto-select first non-empty option
                                  (local.correct_answer ?? "") ||
                                  (local.options
                                    .map((opt) => (typeof opt === "object" ? (opt.value ?? "") : opt ?? ""))
                                    .find((v) => v) || "")
                                }
                                onChange={(e) =>
                                  setEditedMcq((prev) => ({
                                    ...prev,
                                    correct_answer: e.target.value,
                                  }))
                                }
                                style={{ padding: "6px 8px" }}
                              >
                                {local.options.map((opt, idx) => {
                                  const val = typeof opt === "object" ? (opt.value ?? "") : opt ?? "";
                                  return (
                                    <option key={idx} value={val}>
                                      {val || "(empty)"}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>

                            {/* Explanation */}
                            <div style={{ marginTop: 12 }}>
                              <label style={{ fontWeight: 600 }}>Explanation (optional):</label>
                              <textarea
                                rows={3}
                                value={local.explanation}
                                onChange={(e) =>
                                  setEditedMcq((prev) => ({ ...prev, explanation: e.target.value }))
                                }
                                style={{ width: "100%", padding: 6, marginTop: 6 }}
                              />
                            </div>
                          </div>
                        ) : (
                          <>
                            {Array.isArray(content.options) && content.options.length > 0 ? (
                              <ul style={{ listStyleType: "disc", marginLeft: 25 }}>
                                {content.options.map((opt, oidx) => {
                                  const cleanValue = String(opt.value || opt).replace(/^"|"$/g, "").trim();
                                  const isCorrect = content.correct_answer && String(opt).trim().toLowerCase() === String(content.correct_answer).trim().toLowerCase();
                                  return (
                                    <li key={oidx} style={{ color: isCorrect ? "green" : "black", fontWeight: isCorrect ? "bold" : "normal", marginBottom: 4 }}>
                                      {cleanValue}
                                    </li>
                                  );
                                })}
                              </ul>
                            ) : (
                              <p style={{ fontStyle: "italic" }}>No options available for this MCQ.</p>
                            )}

                            {content.explanation && <p><strong className="txt">Explanation:</strong> {content.explanation}</p>}
                          </>
                        )}

                        {/* buttons */}
                        <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 12 }}>
                          {isEditing ? (
                            <>
                              <button
                                className="info-btn"
                                onClick={() => {
                                  // build payload
                                  const payload = {
                                    content: {
                                      question: editedMcq.question,
                                      options: editedMcq.options,
                                      correct_answer: editedMcq.correct_answer,
                                      explanation: editedMcq.explanation
                                    }
                                  };
                                  saveEditedMcq(topicSet.topicId, mcq.mcqId, payload);
                                }}
                                style={{ backgroundColor: "#28a745", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6 }}
                              >
                                Save
                              </button>
                              <button
                                className="info-btn"
                                onClick={() => {
                                  setEditingMcqId(null);
                                  setEditedMcq(null);
                                }}
                                style={{ backgroundColor: "#ffc107", color: "#000", border: "none", padding: "8px 12px", borderRadius: 6 }}
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                className="info-btn"
                                onClick={() => {
                                  setEditingMcqId(mcq.mcqId);
                                  setEditedMcq({
                                    question: content.question || "",
                                    options: Array.isArray(content.options) ? [...content.options] : [],
                                    correct_answer: content.correct_answer || "",
                                    explanation: content.explanation || ""
                                  });
                                }}
                                style={{ backgroundColor: "#007bff", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6 }}
                              >
                                Edit
                              </button>

                              <button
                                className="info-btn"
                                onClick={() => deleteSingleMcq(topicSet.topicId, mcq.mcqId)}
                                style={{ backgroundColor: "#6c757d", color: "white", border: "none", padding: "8px 12px", borderRadius: 6 }}
                              >
                                Delete
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))
            )}
          </section>
        )}

        {/* === QUESTION Section === */}
        {/* === QUESTION Section === */}
        {activeType === "question" && (
          <section className="llmgen-section">
            <h3>Generated Questions</h3>

            {/* 🔍 Search Bar */}
            <div style={{ marginBottom: 20 }}>
              <input
                type="text"
                placeholder="Search by question title..."
                value={questionSearchTerm}
                onChange={(e) => setQuestionSearchTerm(e.target.value)}
                style={{
                  width: "60%",
                  padding: 10,
                  borderRadius: 8,
                  border: "1px solid #ccc",
                }}
              />
            </div>

            {/* ✅ Conditional Rendering */}
            {questionLoading ? (
              <p>Loading questions...</p>
            ) : filteredQuestions.length === 0 && questionSearchTerm.trim() !== "" ? (
              <p style={{ fontStyle: "italic", color: "gray" }}>
                No questions found matching your search.
              </p>
            ) : allQuestions.length === 0 ? (
              <p>No questions found.</p>
            ) : (
              filteredQuestions.map((topicSet) => (
                <div
                  key={topicSet.topicId}
                  className="llmgen-card"
                  style={{ marginBottom: 16 }}
                >
                  <div
                    className="data-manp"
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <h4>
                      Topic: {topicSet.topicTitle} (ID: {topicSet.topicId})
                    </h4>
                    <button
                      className="info-btn"
                      onClick={() =>
                        deleteTopicQuestions(topicSet.topicId, topicSet.topicTitle)
                      }
                      style={{
                        backgroundColor: "#dc3545",
                        color: "white",
                        border: "none",
                        padding: "8px 12px",
                        borderRadius: 6,
                      }}
                    >
                      Delete Topic Questions
                    </button>
                  </div>

                  {/* 🧩 Questions List */}
                  {topicSet.problems.map((problem, idx) => {
                    const isEditing = editingProblemId === problem.problemId;

                    return (
                      <div
                        key={problem.problemId || idx}
                        className="llmgen-mcq"
                        style={{
                          marginTop: 12,
                          padding: 16,
                          borderLeft: "3px solid #eee",
                          background: "#fff",
                          position: "relative",
                          borderRadius: 8,
                          boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
                        }}
                      >
                        {/* ✅ Header */}
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "flex-start",
                            marginBottom: 8,
                          }}
                        >
                          <p style={{ margin: 0 }}>
                            <strong className="txt">Q{idx + 1}:</strong>{" "}
                            {/* ❌ Title Not Editable */}
                            {problem.title}
                          </p>

                          <span
                            style={{
                              fontSize: "12px",
                              backgroundColor:
                                problem.createdUsing === "LLM"
                                  ? "#e6f4ff"
                                  : problem.createdUsing === "MANUAL"
                                    ? "#fff3cd"
                                    : "#f8f9fa",
                              color:
                                problem.createdUsing === "LLM"
                                  ? "#007bff"
                                  : problem.createdUsing === "MANUAL"
                                    ? "#856404"
                                    : "#6c757d",
                              padding: "4px 8px",
                              borderRadius: "20px",
                              fontWeight: 500,
                              whiteSpace: "nowrap",
                            }}
                          >
                            {problem.createdUsing
                              ? `Created By: ${problem.createdUsing}`
                              : "Created By: Unknown"}
                          </span>
                        </div>

                        {/* ✅ Description */}
                        <p>
                          <strong className="txt">Description:</strong>{" "}
                          {isEditing ? (
                            <textarea
                              rows="2"
                              value={editedProblem.description || problem.description}
                              onChange={(e) =>
                                setEditedProblem({
                                  ...editedProblem,
                                  description: e.target.value,
                                })
                              }
                              style={{
                                width: "100%",
                                padding: "6px",
                                borderRadius: 6,
                                fontSize: 14,
                              }}
                            />
                          ) : (
                            problem.description
                          )}
                        </p>

                        {/* ✅ Difficulty */}
                        <p>
                          <strong className="txt">Difficulty:</strong>{" "}
                          {isEditing ? (
                            <select
                              value={editedProblem.difficulty || problem.difficulty}
                              onChange={(e) =>
                                setEditedProblem({
                                  ...editedProblem,
                                  difficulty: e.target.value,
                                })
                              }
                              style={{
                                padding: "4px",
                                borderRadius: 6,
                              }}
                            >
                              <option value="EASY">EASY</option>
                              <option value="MEDIUM">MEDIUM</option>
                              <option value="HARD">HARD</option>
                            </select>
                          ) : (
                            problem.difficulty
                          )}
                        </p>

                        {/* ✅ Hints */}
                        {problem.hint && (
                          <div>
                            <strong className="txt">Hints:</strong>{" "}
                            {isEditing ? (
                              <textarea
                                rows="2"
                                value={
                                  Array.isArray(editedProblem.hint)
                                    ? editedProblem.hint.join("\n")
                                    : editedProblem.hint ||
                                    (Array.isArray(problem.hint)
                                      ? problem.hint.join("\n")
                                      : problem.hint)
                                }
                                onChange={(e) =>
                                  setEditedProblem({
                                    ...editedProblem,
                                    hint: e.target.value.split("\n"),
                                  })
                                }
                                style={{
                                  width: "100%",
                                  padding: "6px",
                                  borderRadius: 6,
                                  fontSize: 14,
                                }}
                              />
                            ) : Array.isArray(problem.hint) ? (
                              problem.hint.map((h, i) => (
                                <p key={i} style={{ marginLeft: "10px" }}>
                                  • {h}
                                </p>
                              ))
                            ) : (
                              problem.hint
                            )}
                          </div>
                        )}

                        {/* ✅ Test Cases */}

                        {problem.testCases && problem.testCases.length > 0 && (
                          <>
                            <h4 style={{
                              margin: "16px 0 8px",
                              fontSize: 18,
                              color: "#1f2937",
                              fontWeight: 700,
                            }}>
                              Test Cases
                            </h4>

                            <ul style={{
                              marginLeft: 0,
                              paddingLeft: 0,
                              listStyle: "none",
                              display: "grid",
                              gap: 12,
                            }}>
                              {problem.testCases.map((tc, tidx) => {
                                const baseList = editedProblem.testCases || problem.testCases;
                                const currentTc = baseList?.[tidx] ?? tc;
                                const isPublic = typeof currentTc.isPublic === "boolean" ? currentTc.isPublic : !!tc.isPublic;

                                const handleDelete = () => {
                                  const safeList = [...(editedProblem.testCases || problem.testCases || [])];
                                  const nextList = safeList.filter((_, i) => i !== tidx);
                                  setEditedProblem({ ...editedProblem, testCases: nextList });
                                };

                                return (
                                  <li
                                    key={tidx}
                                    style={{
                                      background: "#ffffff",
                                      border: "1px solid #e5e7eb",
                                      borderRadius: 10,
                                      padding: 16,
                                      boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
                                    }}
                                  >
                                    {/* Header row: Title, Type control (or badge), Delete button */}
                                    <div style={{
                                      display: "grid",
                                      gridTemplateColumns: "1fr auto auto",
                                      alignItems: "center",
                                      gap: 8,
                                      marginBottom: 12,
                                    }}>
                                      <strong style={{ fontSize: 14, color: "#111827" }}>
                                        Test Case #{tidx + 1}
                                      </strong>

                                      {/* Type control when editing, else badge */}
                                      {isEditing ? (
                                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                          <label
                                            htmlFor={`tc-type-${tidx}`}
                                            style={{ fontSize: 12, fontWeight: 600, color: "#374151" }}
                                          >
                                            Type:
                                          </label>
                                          <select
                                            id={`tc-type-${tidx}`}
                                            value={isPublic ? "sample" : "hidden"}
                                            onChange={(e) => {
                                              const updated = [...(editedProblem.testCases || problem.testCases)];
                                              const nextIsPublic = e.target.value === "sample";
                                              updated[tidx] = { ...updated[tidx], isPublic: nextIsPublic };
                                              setEditedProblem({ ...editedProblem, testCases: updated });
                                            }}
                                            style={{
                                              fontSize: 12,
                                              padding: "6px 8px",
                                              borderRadius: 8,
                                              border: "1px solid #d1d5db",
                                              background: "#f9fafb",
                                              color: "#111827",
                                            }}
                                          >
                                            <option value="sample">Sample</option>
                                            <option value="hidden">Hidden</option>
                                          </select>
                                        </div>
                                      ) : (
                                        <span
                                          style={{
                                            justifySelf: "end",
                                            fontSize: 12,
                                            padding: "2px 8px",
                                            borderRadius: 999,
                                            background: isPublic ? "#ecfeff" : "#fef3c7",
                                            color: isPublic ? "#155e75" : "#92400e",
                                            border: `1px solid ${isPublic ? "#a5f3fc" : "#fcd34d"}`,
                                          }}
                                          aria-label={`Type: ${isPublic ? "Sample" : "Hidden"}`}
                                          title={isPublic ? "Visible to users as sample" : "Hidden (used for evaluation)"}
                                        >
                                          {isPublic ? "Sample" : "Hidden"}
                                        </span>
                                      )}

                                      {/* Delete icon (only in editing mode) */}
                                      {isEditing && (
                                        <button
                                          onClick={handleDelete}
                                          aria-label={`Delete Test Case #${tidx + 1}`}
                                          title="Delete test case"
                                          style={{
                                            justifySelf: "end",
                                            display: "inline-flex",
                                            alignItems: "center",
                                            gap: 6,
                                            background: "#fee2e2",   /* red-100 */
                                            color: "#b91c1c",        /* red-700 */
                                            border: "1px solid #fecaca", /* red-200 */
                                            padding: "6px 8px",
                                            borderRadius: 8,
                                            cursor: "pointer",
                                          }}
                                        >
                                          {/* Small trash SVG icon */}
                                          <svg
                                            width="14"
                                            height="14"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                            aria-hidden="true"
                                          >
                                            <path d="M9 3h6m5 4h-16m1 0l1 13a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2l1-13M10 11v6M14 11v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                          </svg>
                                          <span style={{ fontSize: 12, fontWeight: 600 }}>Delete</span>
                                        </button>
                                      )}
                                    </div>

                                    {/* --- Rest of the card content remains the same (input/output editors or read-only) --- */}
                                    {isEditing ? (
                                      <>
                                        <div style={{ marginBottom: 10 }}>
                                          <label
                                            htmlFor={`tc-input-${tidx}`}
                                            style={{ display: "block", fontWeight: 600, color: "#374151", marginBottom: 6 }}
                                          >
                                            Input
                                          </label>
                                          <textarea
                                            id={`tc-input-${tidx}`}
                                            rows={4}
                                            value={editedProblem.testCases?.[tidx]?.input ?? tc.input}
                                            onChange={(e) => {
                                              const updated = [...(editedProblem.testCases || problem.testCases)];
                                              updated[tidx] = { ...updated[tidx], input: e.target.value };
                                              setEditedProblem({ ...editedProblem, testCases: updated });
                                            }}
                                            style={{
                                              width: "100%",
                                              padding: "8px 10px",
                                              borderRadius: 8,
                                              border: "1px solid #d1d5db",
                                              background: "#f9fafb",
                                              color: "#111827",
                                              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                                              fontSize: 13,
                                              resize: "vertical",
                                              outline: "none",
                                            }}
                                          />
                                        </div>

                                        <div style={{ marginBottom: 4 }}>
                                          <label
                                            htmlFor={`tc-output-${tidx}`}
                                            style={{ display: "block", fontWeight: 600, color: "#374151", marginBottom: 6 }}
                                          >
                                            Expected Output
                                          </label>
                                          <textarea
                                            id={`tc-output-${tidx}`}
                                            rows={4}
                                            value={editedProblem.testCases?.[tidx]?.expectedOutput ?? tc.expectedOutput}
                                            onChange={(e) => {
                                              const updated = [...(editedProblem.testCases || problem.testCases)];
                                              updated[tidx] = { ...updated[tidx], expectedOutput: e.target.value };
                                              setEditedProblem({ ...editedProblem, testCases: updated });
                                            }}
                                            style={{
                                              width: "100%",
                                              padding: "8px 10px",
                                              borderRadius: 8,
                                              border: "1px solid #d1d5db",
                                              background: "#f9fafb",
                                              color: "#111827",
                                              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                                              fontSize: 13,
                                              resize: "vertical",
                                              outline: "none",
                                            }}
                                          />
                                        </div>
                                      </>
                                    ) : (
                                      <>
                                        <div style={{ marginBottom: 10 }}>
                                          <span style={{ fontWeight: 600, color: "#374151" }}>Input:</span>
                                          <pre
                                            style={{
                                              margin: "6px 0 0",
                                              background: "#f9fafb",
                                              border: "1px solid #e5e7eb",
                                              borderRadius: 8,
                                              padding: 10,
                                              whiteSpace: "pre-wrap",
                                              wordBreak: "break-word",
                                              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                                              fontSize: 13,
                                              color: "#111827",
                                            }}
                                          >
                                            {tc.input}
                                          </pre>
                                        </div>

                                        <div>
                                          <span style={{ fontWeight: 600, color: "#374151" }}>Expected Output:</span>
                                          <pre
                                            style={{
                                              margin: "6px 0 0",
                                              background: "#f9fafb",
                                              border: "1px solid #e5e7eb",
                                              borderRadius: 8,
                                              padding: 10,
                                              whiteSpace: "pre-wrap",
                                              wordBreak: "break-word",
                                              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                                              fontSize: 13,
                                              color: "#111827",
                                            }}
                                          >
                                            {tc.expectedOutput}
                                          </pre>
                                        </div>
                                      </>
                                    )}
                                  </li>
                                );
                              })}
                            </ul>

                            {/* ➕ Add New Test Case (only in editing mode) */}
                            {isEditing && (
                              <div style={{ marginTop: 12 }}>
                                <button
                                  className="info-btn"
                                  onClick={() => {
                                    const base = editedProblem.testCases ?? problem.testCases ?? [];
                                    const newTc = { input: "", expectedOutput: "", isPublic: true };
                                    setEditedProblem({ ...editedProblem, testCases: [...base, newTc] });
                                  }}
                                  style={{
                                    backgroundColor: "#10b981",
                                    color: "#fff",
                                    border: "none",
                                    padding: "8px 12px",
                                    borderRadius: 8,
                                    fontWeight: 600,
                                  }}
                                >
                                  + Add New Test Case
                                </button>
                              </div>
                            )}
                          </>
                        )}




                        {/* ✅ Buttons */}
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "flex-end",
                            gap: "10px",
                            marginTop: 12,
                          }}
                        >
                          {isEditing ? (
                            <>
                              <button
                                className="info-btn"
                                onClick={() => {
                                  saveEditedProblem(
                                    topicSet.topicId,
                                    problem.problemId,
                                    editedProblem
                                  );
                                  setEditingProblemId(null);
                                }}
                                style={{
                                  backgroundColor: "#28a745",
                                  color: "white",
                                  border: "none",
                                  padding: "8px 12px",
                                  borderRadius: 6,
                                }}
                              >
                                Save
                              </button>
                              <button
                                className="info-btn"
                                onClick={() => {
                                  setEditingProblemId(null);
                                  setEditedProblem({});
                                }}
                                style={{
                                  backgroundColor: "#ffc107",
                                  color: "#000",
                                  border: "none",
                                  padding: "8px 12px",
                                  borderRadius: 6,
                                }}
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <button
                              className="info-btn"
                              onClick={() => {
                                setEditingProblemId(problem.problemId);
                                setEditedProblem(problem);
                              }}
                              style={{
                                backgroundColor: "#007bff",
                                color: "white",
                                border: "none",
                                padding: "8px 12px",
                                borderRadius: 6,
                              }}
                            >
                              Edit
                            </button>
                          )}

                          <button
                            className="info-btn"
                            onClick={() =>
                              deleteSingleQuestion(topicSet.topicId, problem.problemId)
                            }
                            style={{
                              backgroundColor: "#6c757d",
                              color: "white",
                              border: "none",
                              padding: "8px 12px",
                              borderRadius: 6,
                            }}
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))
            )}
          </section>
        )}
        {activeType === "notebook" && <NotebookSection />}

      </div>

      {/* ✅ Modal Render */}
      {isModalOpen && (
        <SubtopicModal
          subtopic={selectedSubtopic}
          onClose={closeSubtopicModal}
          onSave={saveEditedSubtopic}
          onDelete={deleteSubtopic}
        />
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <DeleteModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          onConfirm={() => {
            deleteAction();
            setShowDeleteModal(false);
          }}
          title={deleteTitle}
          message={deleteMessage}
        />
      )}
      {/* ✅ Notebook Section */}

      {/* {activeType === "notebook" && <NotebookSection />} */}
    </div>
  );

}

export default LLMGenerationInfo;