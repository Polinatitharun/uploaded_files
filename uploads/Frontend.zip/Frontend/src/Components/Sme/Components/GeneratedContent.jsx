
  import React, { useEffect, useState } from "react";
  import { ToastContainer, toast } from "react-toastify";
  import "react-toastify/dist/ReactToastify.css";
  import axios from "axios";
  import "../styles/GeneratedContent.css";
  import Sidebar from "./AdminSidebar";
  import LoadingScreen from "./LoadingScreen";
  import { useLocation, useNavigate } from "react-router-dom";

  const GeneratedContent = ({ onLogout }) => {
    const [contentData, setContentData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [topicId, setTopicId] = useState(null);
    const [mainTopicsCache, setMainTopicsCache] = useState([]);
    const location = useLocation();
    const navigate = useNavigate();
    const params = new URLSearchParams(location.search);

    const mainTopicTitle = params.get("topic") || "NA";
    const subtopicTitle = params.get("subtopic") || "NA";

    const BACKEND_URL = import.meta.env.VITE_API_BASE_URL;
    const LLM_URL = import.meta.env.VITE_AI_URL;

    // ✅ Fetch content from LLM
    const fetchGeneratedContent = async () => {
      setLoading(true);
      try {
        const response = await axios.post(`${import.meta.env.VITE_AI_URL}/gen-sme-content`, {
          topic: mainTopicTitle,
          subtopic: subtopicTitle,
        });
        if (response.data && response.data.topic) {
          setContentData(response.data);
        } else {
          throw new Error("Invalid LLM response format");
        }
      } catch (error) {
        console.error("❌ Error fetching from LLM:", error);
        toast.error("Failed to fetch from LLM");
      } finally {
        setLoading(false);
      }
    };

    // ✅ Fetch all main topics
    const fetchMainTopics = async () => {
      try {
        const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`);
        setMainTopicsCache(res.data || []);
      } catch (err) {
        console.error("❌ Error fetching main topics:", err);
      }
    };

    // ✅ Resolve topicId
    const resolveTopicIdFromMainTopics = (mainTopicsList, mainTitle, subTitle) => {
      // First, try to find by exact main and sub
      const main = mainTopicsList.find(
        (mt) => mt.mainTopicName.trim().toLowerCase() === mainTitle.trim().toLowerCase()
      );
      if (main) {
        const sub = main.subTopics?.find(
          (st) => st.title.trim().toLowerCase() === subTitle.trim().toLowerCase()
        );
        if (sub) return sub.topicId;
      }
      // If not found, search all subtopics for the subTitle (handles mismatched mainTitle)
      for (const mt of mainTopicsList) {
        const sub = mt.subTopics?.find(
          (st) => st.title.trim().toLowerCase() === subTitle.trim().toLowerCase()
        );
        if (sub) return sub.topicId;
      }
      return null;
    };

    const ensureTopicId = async () => {
      let resolved = resolveTopicIdFromMainTopics(
        mainTopicsCache,
        mainTopicTitle,
        subtopicTitle
      );
      if (resolved) {
        setTopicId(resolved);
        return resolved;
      }

      const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`);
      const list = res.data || [];
      const directResolved = resolveTopicIdFromMainTopics(
        list,
        mainTopicTitle,
        subtopicTitle
      );
      if (directResolved) {
        setMainTopicsCache(list);
        setTopicId(directResolved);
        return directResolved;
      }
      return null;
    };

    // ✅ Save content to backend
    const saveContent = async () => {
      if (!contentData) {
        toast.error("Nothing to save");
        return;
      }
      setLoading(true);
      try {
        let resolvedId = topicId;
        if (!resolvedId) resolvedId = await ensureTopicId();
        if (!resolvedId) {
          toast.error("Could not resolve topic ID");
          setLoading(false);
          return;
        }
        const payload = {
          title: subtopicTitle,
          content: contentData,
        };
        await axios.put(`${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/${resolvedId}`, payload);
        toast.success("Content saved successfully!");
        setIsEditing(false);
      } catch (err) {
        console.error("❌ Save error:", err);
        toast.error("Failed to save content");
      } finally {
        setLoading(false);
      }
    };

    // ✅ Delete action → redirect to content generation
    const handleDelete = () => {
      navigate("/content-generation");
    };

    useEffect(() => {
      fetchMainTopics();
      fetchGeneratedContent();
    }, []);

    if (loading || !contentData) {
      return (
        <div className="preview-wrapper">
        <Sidebar onLogout={onLogout} />
        <LoadingScreen />
      </div>
      );
    }

    // ✅ Change handler for editable content fields
    const handleChange = (field, value) => {
      setContentData((prev) => ({
        ...prev,
        subtopic: {
          ...prev.subtopic,
          content: {
            ...prev.subtopic.content,
            [field]: value,
          },
        },
      }));
    };

    return (
      <div className="generated-container-body">
        <Sidebar onLogout={onLogout} />
        <div className="generated-container">
          {/* ✅ Top Buttons */}
          <div className="content-details">
            <button className="save-btn1" onClick={saveContent}>
              Save All
            </button>
            <button className="save-btn1" onClick={fetchGeneratedContent}>
              Regenerate
            </button>
          </div>

          <ToastContainer />

          {/* ✅ Topic */}
          <div className="generated-card">
            <h2>Topic: {contentData.topic}</h2>
            {isEditing ? (
              <textarea
                value={contentData.explanation || ""}
                onChange={(e) =>
                  setContentData({ ...contentData, explanation: e.target.value })
                }
              />
            ) : (
              <p style={{ color: "#000" }}>{contentData.explanation}</p>
            )}
          </div>

          {/* ✅ Subtopic */}
          {contentData.subtopic && (
            <div className="sub-card">
              <h3>Subtopic: {contentData.subtopic.name}</h3>
              {isEditing ? (
                <textarea
                  value={contentData.subtopic.content.explanation || ""}
                  onChange={(e) => handleChange("explanation", e.target.value)}
                />
              ) : (
                <p style={{ color: "#000" }}>
                  {contentData.subtopic.content.explanation}
                </p>
              )}

              {/* ✅ Language Details */}
              {contentData.subtopic.content.language_details?.map((lang, idx) => (
                <div key={idx} className="language-card">
                  <h4>{lang.language}</h4>
                  {isEditing ? (
                    <>
                      <p>
                        <strong>Syntax:</strong>
                      </p>
                      <textarea
                        value={lang.syntax || ""}
                        onChange={(e) => {
                          const updated = [
                            ...contentData.subtopic.content.language_details,
                          ];
                          updated[idx].syntax = e.target.value;
                          setContentData({
                            ...contentData,
                            subtopic: {
                              ...contentData.subtopic,
                              content: {
                                ...contentData.subtopic.content,
                                language_details: updated,
                              },
                            },
                          });
                        }}
                      />
                      <p>
                        <strong>Example:</strong>
                      </p>
                      <textarea
                        value={lang.example || ""}
                        onChange={(e) => {
                          const updated = [
                            ...contentData.subtopic.content.language_details,
                          ];
                          updated[idx].example = e.target.value;
                          setContentData({
                            ...contentData,
                            subtopic: {
                              ...contentData.subtopic,
                              content: {
                                ...contentData.subtopic.content,
                                language_details: updated,
                              },
                            },
                          });
                        }}
                      />
                    </>
                  ) : (
                    <>
                      <p>
                        <strong className="txt">Syntax:</strong>
                      </p>
                      <pre>{lang.syntax}</pre>
                      <p>
                        <strong className="txt">Example:</strong>
                      </p>
                      <pre>{lang.example}</pre>
                    </>
                  )}
                </div>
              ))}

              {/* ✅ Code Difference Section (inside same card area) */}
              <div className="generated-card" style={{ marginTop: "25px" }}>
                <h4>Code Difference Explanation</h4>
                {isEditing ? (
                  <textarea
                    value={
                      contentData.subtopic.content
                        .code_difference_explaination || ""
                    }
                    onChange={(e) =>
                      handleChange(
                        "code_difference_explaination",
                        e.target.value
                      )
                    }
                  />
                ) : (
                  <p style={{ color: "#000" }}>
                    {
                      contentData.subtopic.content
                        .code_difference_explaination
                    }
                  </p>
                )}
              </div>

              {/* ✅ Bottom Edit/Delete inside container */}
              <div
                className="content-details"
                style={{ marginTop: "25px", justifyContent: "flex-end" }}
              >
                {!isEditing ? (
                  <>
                    <button
                      className="save-btn1"
                      style={{ backgroundColor: "#007bff" }}
                      onClick={() => setIsEditing(true)}
                    >
                      Edit
                    </button>
                    <button
                      className="save-btn1"
                      style={{ backgroundColor: "#dc3545" }}
                      onClick={handleDelete}
                    >
                      Delete
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      className="save-btn1"
                      onClick={saveContent}
                      style={{ backgroundColor: "#28a745" }}
                    >
                      Save Changes
                    </button>
                    <button
                      className="save-btn1"
                      style={{ backgroundColor: "#6c757d" }}
                      onClick={() => setIsEditing(false)}
                    >
                      Cancel
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  export default GeneratedContent;