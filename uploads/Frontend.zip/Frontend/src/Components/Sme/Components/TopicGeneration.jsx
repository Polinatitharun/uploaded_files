


import React, { useEffect, useState } from "react";
import Sidebar from "./AdminSidebar";
import "../styles/TopicGeneration.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import GeneratedSubtopicsModal from "./GeneratedSubtopicsModal";

const TopicGeneration = ({ onLogout }) => {
  const [topicsData, setTopicsData] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [error, setError] = useState("");
  const [generatedSubtopics, setGeneratedSubtopics] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTopicId, setSelectedTopicId] = useState(null);
  let loadingToastId=null;

  // ✅ Fetch topics from backend 
  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/main-topics`
        );
        if (response.data && Array.isArray(response.data)) {
          setTopicsData(response.data);
        } else {
          toast.error("Invalid data format from server");
        }
      } catch (err) {
        console.error("Error fetching topics:", err);
        toast.error("Failed to fetch topics from backend for topic generation.");
      }
    };
    fetchTopics();
  }, []);

  // ✅ Generate subtopics via LLM
  const handleGenerateSubtopics = async () => {
    if (!selectedTopic) {
      setError("Please select a topic first.");
      return;
    }
    setError("");

    try {
      //  Show loading toast
      loadingToastId = toast.loading("⏳ Generating subtopics, please wait...");
      const res = await axios.post(
         
        `${import.meta.env.VITE_AI_URL}/generate-basic-subtopics`,
        { topic: selectedTopic }
      );
      //  Dismiss loading toast once done
      toast.dismiss(loadingToastId);


      if (res.data?.subtopics?.length > 0) {
        setGeneratedSubtopics(res.data.subtopics);
        setIsModalOpen(true);

        // Find mainTopicId
        const topicObj = topicsData.find(
          (t) => t.mainTopicName === selectedTopic
        );
        if (topicObj) {
          setSelectedTopicId(topicObj.mainTopicId);
        }
      } else {
        toast.error("No valid subtopics returned from API");
      }
    } catch (err) {
      console.error("Error generating subtopics:", err);
      toast.error("Failed to generate subtopics.");
    }
  };

  // ✅ Regenerate inside modal
  const handleRegenerateSubtopics = async () => {
    if (!selectedTopic) return;
    try {
      const res = await axios.post(
        `${import.meta.env.VITE_AI_URL}/generate-basic-subtopics`,
        { topic: selectedTopic }
      );
      if (res.data?.subtopics?.length > 0) {
        setGeneratedSubtopics(res.data.subtopics);
        toast.info("Subtopics regenerated!");
      }
    } catch (err) {
      console.error("Regenerate error:", err);
      toast.error("Failed to regenerate subtopics.");
    }
  };

  // ✅ Save subtopics to backend
  const handleSaveSubtopics = async (updatedSubtopics) => {
    if (!selectedTopicId) {
      toast.error("Main topic ID not found. Please reselect a topic.");
      return;
    }

    try {
      const payload = updatedSubtopics.map((title) => ({
        title,
        createdUsing: "LLM",
        content: {}, // default empty JSON content
      }));

      const response = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/api/sme/topics/batch/${selectedTopicId}`,
        payload,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.status === 201) {
        toast.success("Subtopics saved successfully!");
      } else {
        toast.info("Subtopics updated in database!");
      }

      setIsModalOpen(false);
    } catch (err) {
      console.error("Error saving subtopics:", err);
      toast.error("Failed to save subtopics to database.");
    }
  };

  return (
    <div className="topic-gen-whole-container">
      <Sidebar onLogout={onLogout} />

      <div className="topic-generate-container">
        <div className="topic-generation">
          <h1 className="topic-head">Sub Topic Generation</h1>

          {/* ✅ Dropdown for topics */}
          <div className="dropdown-section">
            <label htmlFor="topic-select" className="dropdown-label">
              Select Topic:
            </label>
            <select
              id="topic-select"
              className="dropdown-select"
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
            >
              <option value="">-- Choose a topic --</option>
              {topicsData.map((t) => (
                <option key={t.mainTopicId} value={t.mainTopicName}>
                  {t.mainTopicName}
                </option>
              ))}
            </select>
          </div>

          {error && <p className="error-text">{error}</p>}

          {/* ✅ Button to create subtopics */}
          <div className="submit-button">
            <button className="topic-submit-btn" onClick={handleGenerateSubtopics}>
              Create Subtopics
            </button>
          </div>
        </div>
      </div>

      {/* ✅ Modal Integration */}
      {isModalOpen && (
        <GeneratedSubtopicsModal
          topic={selectedTopic}
          subtopics={generatedSubtopics}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveSubtopics}
          onRegenerate={handleRegenerateSubtopics}
        />
      )}

      <ToastContainer position="top-right" autoClose={2000} />
    </div>
  );
};

export default TopicGeneration;
