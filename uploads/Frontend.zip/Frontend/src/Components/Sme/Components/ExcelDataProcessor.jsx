import React, { useState } from "react";
import * as XLSX from "xlsx";

const ExcelDataProcessor = ({onLogout}) => {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);

  // Function to handle file upload
  const handleFileUpload = (e) => {
    const file = e.target.files[0]; // Get the uploaded file
    if (!file) return;

    // Read the file using FileReader
    const reader = new FileReader();
    reader.onload = (event) => {
      const binaryString = event.target.result;
      const workbook = XLSX.read(binaryString, { type: "binary" });

      // Get the first sheet in the workbook (change index if necessary)
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      
      // Convert the sheet to JSON format
      const sheetData = XLSX.utils.sheet_to_json(sheet);

      // Update state with the parsed data
      setData(sheetData);
      setError(null); // Clear previous errors if successful
    };

    reader.onerror = () => {
      setError("Error reading the file.");
      setData([]);
    };

    reader.readAsBinaryString(file); // Read the file as binary string
  };

  // Function to render the formatted data (this will display the data in a table)
  const renderFormattedData = () => {
    if (data.length === 0) return <p>No data available or invalid file format</p>;

    return (
      <table border="1">
        <thead>
          <tr>
            {Object.keys(data[0]).map((key) => (
              <th key={key}>{key}</th> // Column headers from keys of the first row
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {Object.values(row).map((value, colIndex) => (
                <td key={colIndex}>{value}</td> // Data cells from values of each row
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div>
      <h2>Upload and View Excel Data</h2>
      {/* Input for file selection */}
      <input type="file" accept=".xlsx,.xls" onChange={handleFileUpload} />
      
      {/* Display any errors */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Render the formatted data */}
      {renderFormattedData()}
    </div>
  );
};

export default ExcelDataProcessor;
