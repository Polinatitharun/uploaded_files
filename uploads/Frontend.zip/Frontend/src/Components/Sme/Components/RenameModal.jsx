import React, { useState } from "react";
import "../styles/RenameModal.css";

const RenameModal = ({ notebook, onClose, onSave }) => {
  const [newTitle, setNewTitle] = useState(notebook.title);

  const handleSubmit = () => {
    if (!newTitle.trim()) return;
    onSave(notebook.notebookId, newTitle);
  };

  return (
    <div className="rename-modal-overlay">
      <div className="rename-modal">
        <h3>Rename Notebook</h3>
        <p>Current Title: <strong>{notebook.title}</strong></p>
        <input
          type="text"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="Enter new title"
        />
        <div className="rename-modal-buttons">
          <button onClick={onClose} className="cancel-btn">Cancel</button>
          <button onClick={handleSubmit} className="save-btn">Save</button>
        </div>
      </div>
    </div>
  );
};

export default RenameModal;
