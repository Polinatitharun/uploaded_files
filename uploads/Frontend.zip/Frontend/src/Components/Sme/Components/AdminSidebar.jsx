import { NavLink } from "react-router-dom";
import { FaCogs, FaClipboardList, FaQuestionCircle, FaFileUpload } from "react-icons/fa";
import { TbLayoutDashboardFilled } from "react-icons/tb";
import LogoutOutlinedIcon from "@mui/icons-material/LogoutOutlined";
import { MdLeaderboard, MdFileUpload } from "react-icons/md";
import "../styles/Sidebar.css";
import SMEReports from "./SMEReports";

const Sidebar = ({ onLogout }) => {
  const handleLogout = () => {
    onLogout();
  };

  const navItems = [
    { name: "Dashboard", icon: <TbLayoutDashboardFilled /> },
    { name: "Reports", icon: <MdLeaderboard /> },
    { name: "User Leaderboard", icon: <MdLeaderboard /> },
    { name: "Sub Topic Generation", icon: <FaFileUpload /> },
    { name: "Content Generation", icon: <FaCogs /> },
    { name: "MCQ Generation", icon: <FaClipboardList /> },
    { name: "Question Generation", icon: <FaQuestionCircle /> },
    { name: "Upload Notebook", icon: <MdFileUpload /> },
{ name: "Curriculum Analysis", icon: <FaCogs /> }
  ];

  return (
    <div className="sidebar-container">
      <nav className="navbar">
        <h2>Hello, SME!</h2>
        <ul style={{ overflowY: 'scroll', height: '80vh' }}>
          {navItems.map((item, index) => (
            <li key={index}>
              <NavLink
                to={`/${item.name.toLowerCase().replace(/ /g, "-")}`}
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                {item.icon}
                <span>{item.name}</span>
              </NavLink>
            </li>
          ))}

          <li className="sme-logout" onClick={handleLogout}>
            <LogoutOutlinedIcon />
            Logout
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
