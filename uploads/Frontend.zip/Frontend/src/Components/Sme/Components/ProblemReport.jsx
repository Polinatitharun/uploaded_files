// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import "../styles/ProblemReport.css";

// function UserProblemReportModal({ userId, problem, onClose }) {
//   const [report, setReport] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   const fetchProblemReport = async () => {
//     try {
//       setLoading(true);
//       const res = await axios.get(
//         `${import.meta.env.VITE_API_BASE_URL}/api/admin/dashboard/user-problem-report?userId=${userId}&problemId=${problem.id}`
//       );
//       setReport(res.data);
//     } catch (err) {
//       console.error("Error fetching problem report:", err);
//       setError("Failed to fetch report data");
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchProblemReport();
//   }, [userId, problem]);

//   return (
//     <div className="modal-overlay">
//       <div className="modal-content large-modal">
//         <div className="modal-header">
//           <h2>User Problem Report</h2>
//           <button className="close-btn" onClick={onClose}>
//             ✖
//           </button>
//         </div>

//         <div className="modal-body">
//           {loading ? (
//             <p className="loading-text">Loading problem report...</p>
//           ) : error ? (
//             <p className="error-text">{error}</p>
//           ) : !report ? (
//             <p>No report available for this problem.</p>
//           ) : (
//             <div className="report-container">
//               {/* Top Info */}
//               <div className="report-header">
//                 <h3>User ID: {userId}</h3>
//                 <h4>Problem Title: {problem.title}</h4>
//               </div>

//               {/* Algorithm Summary */}
//               <div className="report-section">
//                 <h5>Algorithm & Pseudocode Summary</h5>
//                 <p>{report.algorithm_pseudocode_match_summary}</p>
//               </div>

//               {/* Language Performance Cards */}
//               <div className="language-performance-grid">
//                 {report.language_performances?.map((lang, idx) => (
//                   <div key={idx} className="language-card">
//                     <h4 className="lang-title">
//                       {lang.language.toUpperCase()}
//                     </h4>
//                     <p><strong className="txt">Code Match Score:</strong> {lang.code_match_score}</p>
//                     <p><strong className="txt">Performance Score:</strong> {lang.proficiency_score}</p>
//                     <p className="performance-notes"><strong className="txt">Performance Notes:</strong>
//                       {lang.performance_notes}
//                     </p>
//                   </div>
//                 ))}
//               </div>

//               {/* Key Skills */}
//               {/* <div className="report-section">
//                 <h5>Key Skills Demonstrated</h5>
//                 <ul>
//                   {report.key_skills_demonstrated?.map((skill, i) => (
//                     <li key={i}>{skill}</li>
//                   ))}
//                 </ul>
//               </div> */}

//               {/* Optimized Approach */}
//               <div className="report-section">
//                 <h5>Optimized Approach Exists</h5>
//                 <p>
//                   {report.optimized_approach_exists
//                     ? "✅ Yes"
//                     : "❌ No"}
//                 </p>
//               </div>

//               {/* Project Stream Suggestion */}
//               {/* <div className="report-section">
//                 <h5>Project Stream Suggestion</h5>
//                 <p>{report.project_stream_suggestion}</p>
//               </div> */}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default UserProblemReportModal;


import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/ProblemReport.css";

function UserProblemReportModal({ userId, problem, onClose }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const useDummyData = true; // ✅ toggle for dummy data

  const dummyReport = {
    algorithm_pseudocode_match_summary:
      "The submitted solution follows the expected pseudocode structure and implements efficient looping mechanisms.",
    language_performances: [
      {
        language: "Java",
        code_match_score: 95,
        proficiency_score: 90,
        performance_notes:
          "Great use of collections and streams. Could improve variable naming consistency.",
      },
      {
        language: "Python",
        code_match_score: 89,
        proficiency_score: 86,
        performance_notes:
          "Clean implementation. Consider using list comprehensions for optimization.",
      },
      {
        language: "JavaScript",
        code_match_score: 80,
        proficiency_score: 78,
        performance_notes:
          "Correct logic but some unnecessary DOM manipulations detected.",
      },
    ],
    optimized_approach_exists: true,
    project_stream_suggestion: "Recommended for full-stack web development.",
  };

  const fetchProblemReport = async () => {
    try {
      setLoading(true);
      setError(null);

      if (useDummyData) {
        await new Promise((res) => setTimeout(res, 600)); // fake delay
        setReport(dummyReport);
        setLoading(false);
        return;
      }

      const res = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/admin/dashboard/user-problem-report?userId=${userId}&problemId=${problem.problemId}`
      );
      setReport(res.data);
    } catch (err) {
      console.error("Error fetching problem report:", err);
      setError("Failed to fetch report data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (problem && userId) fetchProblemReport();
  }, [userId, problem]);

  return (
    <div className="modal-overlay">
      <div className="modal-content large-modal">
        <div className="modal-header">
          <h2>User Problem Report</h2>
          <button className="close-btn" onClick={onClose}>
            ✖
          </button>
        </div>

        <div className="modal-body">
          {loading ? (
            <p className="loading-text">Loading problem report...</p>
          ) : error ? (
            <p className="error-text">{error}</p>
          ) : !report ? (
            <p>No report available for this problem.</p>
          ) : (
            <div className="report-container">
              <div className="report-header">
                <h3>User ID: {userId}</h3>
                <h4>Problem Title: {problem.title}</h4>
              </div>

              <div className="report-section">
                <h5>Algorithm & Pseudocode Summary</h5>
                <p>{report.algorithm_pseudocode_match_summary}</p>
              </div>

              <div className="language-performance-grid">
                {report.language_performances?.map((lang, idx) => (
                  <div key={idx} className="language-card">
                    <h4 className="lang-title">{lang.language.toUpperCase()}</h4>
                    <p><strong className="txt ">Code Match Score:</strong> {lang.code_match_score}%</p>
                    <p><strong className="txt">Performance Score:</strong> {lang.proficiency_score}%</p>
                    <p className="performance-notes">
                      <strong className="txt">Notes:</strong> {lang.performance_notes}
                    </p>
                  </div>
                ))}
              </div>

              <div className="report-section">
                <h5>Optimized Approach Exists</h5>
                <p>{report.optimized_approach_exists ? "✅ Yes" : "❌ No"}</p>
              </div>

              <div className="report-section">
                <h5>Project Stream Suggestion</h5>
                <p>{report.project_stream_suggestion}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default UserProblemReportModal;