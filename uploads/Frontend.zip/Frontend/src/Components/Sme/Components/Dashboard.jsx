// import "../styles/UpdatedDashboard.css";
import "../styles/Welcome.css";
import AdminSidebar from './AdminSidebar';
import LLMGenerationInfo from "./LLMGenerationInfo";


const Welcome = ({onLogout}) => {
  
  
  return (
    <>
    <div className="dashboard-block">
      <AdminSidebar onLogout={onLogout}/>
      <LLMGenerationInfo onLogout={onLogout}/>
    </div>
    </>
  );
};

export default Welcome;