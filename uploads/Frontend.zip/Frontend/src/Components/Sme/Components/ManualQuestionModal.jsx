import React, { useState } from "react";
import "../styles/ManualQuestionModal.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ManualQuestionModal = ({
  onClose,
  selectedTopic,
  selectedSubtopic,
  difficulty,
  topicsData,
}) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hints, setHints] = useState([""]); // ✅ multiple hints array
  const [testCases, setTestCases] = useState([
    { input: "", expectedOutput: "", isPublic: true },
  ]);

  // ✅ Add new test case
  const addTestCase = () => {
    setTestCases([
      ...testCases,
      { input: "", expectedOutput: "", isPublic: false },
    ]);
  };

  // ✅ Update test case
  const updateTestCase = (index, field, value) => {
    const updated = [...testCases];
    updated[index][field] = value;
    setTestCases(updated);
  };

  // ✅ Remove test case
  const removeTestCase = (index) => {
    const updated = [...testCases];
    updated.splice(index, 1);
    setTestCases(updated);
    toast.info("🗑️ Test case removed successfully!", {
      position: "top-right",
      autoClose: 2000,
      theme: "colored",
    });
  };

  // ✅ Hint management
  const addHint = () => setHints([...hints, ""]);
  const updateHint = (index, value) => {
    const updated = [...hints];
    updated[index] = value;
    setHints(updated);
  };
  const removeHint = (index) => {
    const updated = hints.filter((_, i) => i !== index);
    setHints(updated);
    toast.info("🗑️ Hint removed successfully!", {
      position: "top-right",
      autoClose: 2000,
      theme: "colored",
    });
  };

  // ✅ Find topicId
  const topicId = topicsData
    .find((t) => t.mainTopicName === selectedTopic)
    ?.subTopics.find((s) => s.title === selectedSubtopic)?.topicId;

  // ✅ Save question
  const handleSave = async () => {
    if (!title || !description) {
      toast.error("Please fill in all required fields.");
      return;
    }
  
    if (!topicId) {
      toast.error("Topic ID missing. Please select topic again.");
      return;
    }
  
    // ✅ Clean up hint array (remove empty ones)
    const cleanedHints = hints.filter((h) => h.trim() !== "");
    const finalData = {
      title,
      description,
      difficulty: difficulty.toUpperCase(),
      testCases,
      createdUsing: "MANUAL",
      hint: cleanedHints.length > 0 ? cleanedHints : [], // ✅ JSON array always
    };
  
  
    try {
      const backendUrl = `${import.meta.env.VITE_API_BASE_URL}/api/sme/problems/topic/${topicId}`;
      await axios.post(backendUrl, finalData, {
        headers: { "Content-Type": "application/json" },
      });
  
      toast.success("✅ Manual question saved successfully!", {
        position: "top-right",
        autoClose: 2000,
        theme: "colored",
      });
  
      setTimeout(() => onClose(), 1200);
    } catch (err) {
      console.error("Error saving manual question:", err);
      toast.error("❌ Failed to save manual question.");
    }  };

  return (
    <div className="manual-modal-overlay">
      <div className="manual-modal">
        <ToastContainer position="top-right" autoClose={2000} theme="colored" />
        <h2 className="manual-modal-title">Create Question Manually</h2>

        {/* Title */}
        <label className="manual-label">Title:</label>
        <input
          type="text"
          className="manual-input"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter question title"
        />

        {/* Description */}
        <label className="manual-label">Description:</label>
        <textarea
          className="manual-textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Enter question description"
        ></textarea>

        {/* ✅ Multiple Hints */}
        <label className="manual-label">Hints:</label>
        {hints.map((hint, index) => (
          <div key={index} className="hint-item">
            <textarea
              className="manual-input"
              value={hint}
              onChange={(e) => updateHint(index, e.target.value)}
              placeholder={`Hint ${index + 1}`}
            ></textarea>
            <button
              className="remove-btn small-btn"
              onClick={() => removeHint(index)}
            >
              ✖
            </button>
            
          </div>
        ))}
        <button className="add-testcase-btn" onClick={addHint}>
          ➕ Add Hint
        </button>

        {/* ✅ Test Cases */}
        <h3 className="testcase-title">Test Cases</h3>
        <div className="testcase-container">
          {testCases.map((tc, index) => (
            <div key={index} className="testcase-item">
              <div className="testcase-header">
                <span className="testcase-number">Test Case #{index + 1}</span>
                <button
                  className="remove-btn"
                  onClick={() => removeTestCase(index)}
                >
                  Remove
                </button>
              </div>

              <textarea
                className="manual-input"
                placeholder="Input"
                value={tc.input}
                onChange={(e) => updateTestCase(index, "input", e.target.value)}
              ></textarea>
              <textarea
                className="manual-input"
                placeholder="Expected Output"
                value={tc.expectedOutput}
                onChange={(e) =>
                  updateTestCase(index, "expectedOutput", e.target.value)
                }
              ></textarea>

              <div className="radio-inline">
                <label className="txt">
                  <input
                    type="radio"
                    checked={tc.isPublic === true}
                    onChange={() => updateTestCase(index, "isPublic", true)}
                  />
                  Sample Test Case
                </label>
                <label className="txt">
                  <input
                    type="radio"
                    checked={tc.isPublic === false}
                    onChange={() => updateTestCase(index, "isPublic", false)}
                  />
                  Hidden Test Case
                </label>
              </div>
            </div>
          ))}
        </div>

        <button className="add-testcase-btn" onClick={addTestCase}>
          ➕ Add Test Case
        </button>

        {/* Footer buttons */}
        <div className="manual-modal-buttons">
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>
          <button className="save-btn" onClick={handleSave}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default ManualQuestionModal;