import React, { useEffect, useState } from 'react';
import "../styles/UserProfile.css";
import { useParams, useSearchParams } from "react-router-dom"
import axios from "axios"
function UserProfile() {
  const {id}=useParams()
  const[name,setName]=useState("")
  
  const[isJava,setIsJava]=useState(false)
  const[isPython,setIsPython]=useState(false)
  const [python,setPython]=useState([])
  const [java,setJava]=useState([])
  const [res,setRes]=useState([])
  useEffect(() => {
    ;(async()=>{
      const url=window.location.href?.toString().split("/")
      const id=url[url.length-1];
      const response=await axios.get(`http://127.0.0.1:5000/progress/${id}`);
      setRes(response?.data)
      const names=response?.data[0].name.split(" ")
      setName(names[0][0]+names[1][0])
      
      
      
      setJava(response?.data?.filter((e)=>e.javaCompleted===true))
      setPython(response?.data?.filter((e)=>e.pythonCompleted===true))
      
      
      setIsJava(response?.data?.any((val)=>val.javaCompleted===true))
      setIsPython(response?.data?.any((val)=>val.pythonCompleted===true))
    })();
  }, []);
  return (
    <div className="user-profile-container">
      {/* Header Section */}
      <div className="header-section">
        <div className="header-content">
          <button className="back-button" onClick={() => window.history.back()}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="m12 19-7-7 7-7" />
              <path d="m19 12H5" />
            </svg>
            Back
          </button>

          <div className="user-info-card">
            <div className="profile-avatar">
              <span className="avatar-text">{name}</span>
            </div>

            <div className="user-details">
              <h1 className="user-name">{res[0]?.name}</h1>
              <div className="user-meta">
                <div className="meta-item">
                  <span className="meta-label">Email:</span>
                  <span className="meta-value">{res[0]?.email}</span>
                </div>
                {/* <div className="meta-item">
                  <span className="meta-label">Batch:</span>
                  <span className="meta-value">45 - Subbatch A3</span>
                </div>
                <div className="meta-row">
                  <div className="meta-item">
                    <span className="meta-label">TA:</span>
                    <span className="meta-value">N/A</span>
                  </div>
                  <div className="meta-item">
                    <span className="meta-label">Floor:</span>
                    <span className="meta-value">N/A</span>
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Section */}
      <div className="performance-section">
        <h2 className="section-title">Performance Overview</h2>

        <div className="performance-grid">
          {/* Java Performance */}
          <div className="performance-card java-card">
            <div className="card-header">
              <div className="language-icon java-icon">
                <span>☕</span>
              </div>
              <h3>Java</h3>
            </div>
{/* 
            <div className="stats-container">
              <div className="stat-card">
                <div className="stat-number">16</div>
                <div className="stat-label">Questions Solved</div>
              </div>

              <div className="stat-card">
                <div className="proficiency-badge intermediate">
                  Intermediate
                </div>
                <div className="stat-label">Proficiency Level</div>
              </div>
            </div> */}

            {/* <div className="insights">
              <div className="insight-item">
                <span className="insight-label">Strengths:</span>
                <span className="insight-value">Object-oriented programming, Collections</span>
              </div>
              <div className="insight-item">
                <span className="insight-label">Areas to improve:</span>
                <span className="insight-value">Exception handling, Multithreading</span>
              </div>
            </div> */}
            <div className="insights">
              {java.map(e=>(<div className="insight-item">
                
                <span className="insight-value">{e.title}</span>
              </div>
              ))}
            </div>
          </div> 

          {/* Python Performance */}
          <div className="performance-card python-card">
            <div className="card-header">
              <div className="language-icon python-icon">
                <span>🐍</span>
              </div>
              <h3>Python</h3>
            </div>

            {/* <div className="stats-container">
              <div className="stat-card">
                <div className="stat-number">50</div>
                <div className="stat-label">Questions Solved</div>
              </div>

              <div className="stat-card">
                <div className="proficiency-badge expert">
                  Expert
                </div>
                <div className="stat-label">Proficiency Level</div>
              </div>
            </div> */}

            <div className="insights">
            {python.map(e=>(<div className="insight-item">
                
                <span className="insight-value">{e.title}</span>
              </div>
              ))}
              
            </div>
          </div>

          {/* <div className="performance-card logic-card">
            <div className="card-header">
              <div className="language-icon logic-icon">
                <span>🧠</span>
              </div>
              <h3>Problem Solving</h3>
            </div>

            <div className="stats-container">
              <div className="stat-card">
                <div className="stat-number">24</div>
                <div className="stat-label">Questions Solved</div>
              </div>

              <div className="stat-card">
                <div className="proficiency-badge intermediate">
                  Intermediate
                </div>
                <div className="stat-label">Proficiency Level</div>
              </div>
            </div>

            <div className="insights">
              <div className="insight-item">
                <span className="insight-label">Strengths:</span>
                <span className="insight-value">Logical thinking, Pattern recognition</span>
              </div>
              <div className="insight-item">
                <span className="insight-label">Areas to improve:</span>
                <span className="insight-value">Complex algorithm design</span>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </div>

          )}

export default UserProfile