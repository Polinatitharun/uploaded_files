
import React, { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import RenameModal from "./RenameModal";
import "../styles/NotebookSection.css";

const NotebookSection = () => {
  const [notebooks, setNotebooks] = useState([]);
  const [notebookLoading, setNotebookLoading] = useState(false);
  const [isRenameModalOpen, setIsRenameModalOpen] = useState(false);
  const [selectedNotebook, setSelectedNotebook] = useState(null);

  // ✅ Fetch all notebooks
  const fetchAllNotebooks = async () => {
    try {
      setNotebookLoading(true);
      const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/sme/notebooks`);

      // 🧠 Fix: handle empty or 204 response gracefully
      if (!res.data || (Array.isArray(res.data) && res.data.length === 0)) {
        setNotebooks([]);
        return;
      }

      setNotebooks(res.data || []);
    } catch (err) {
      console.error("Error fetching notebooks:", err);
      // Only show toast if not a 204 (empty list)
      if (err.response?.status !== 204) {
        toast.error("Failed to fetch notebooks.");
      }
    } finally {
      setNotebookLoading(false);
    }
  };

  // ✅ Delete notebook
  const handleDeleteNotebook = async (id) => {
    try {
      await axios.delete(`${import.meta.env.VITE_API_BASE_URL}/sme/notebooks/${id}`);
      toast.success("Notebook deleted successfully!");
      fetchAllNotebooks();
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete notebook.");
    }
  };

  // ✅ Rename notebook
  const handleRenameNotebook = async (id, newTitle) => {
    try {
      await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/sme/notebooks/${id}/title`,
        null,
        { params: { newTitle } }
      );
      toast.success("Notebook title updated successfully!");
      fetchAllNotebooks();
      setIsRenameModalOpen(false);
    } catch (err) {
      console.error(err);
      toast.error("Failed to rename notebook.");
    }
  };

  // ✅ Download notebook / PDF with correct extension
  const handleDownloadNotebook = async (id, title) => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/sme/notebooks/download/${id}`,
        { responseType: "blob" } // important for binary files
      );

      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;

      // 🧠 Detect filename from response headers
      const contentDisposition = response.headers["content-disposition"];
      let filename = title;

      if (contentDisposition) {
        const match = contentDisposition.match(/filename="?(.+)"?/);
        if (match && match[1]) filename = match[1];
      } else {
        // 🧠 Fallback based on content type
        const contentType = response.headers["content-type"];
        if (contentType?.includes("pdf")) {
          filename = title.endsWith(".pdf") ? title : `${title}.pdf`;
        } else if (contentType?.includes("json")) {
          filename = `${title}.json`;
        } else {
          filename = title.endsWith(".ipynb") ? title : `${title}.ipynb`;
        }
      }

      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      toast.success(`📥 ${filename} downloaded successfully!`);
    } catch (err) {
      console.error("Error downloading notebook:", err);
      toast.error("❌ Failed to download notebook.");
    }
  };

  useEffect(() => {
    fetchAllNotebooks();
  }, []);

  return (
    <section className="llmgen-section">
      <h3>Uploaded Notebooks</h3>

      {notebookLoading ? (
        <p>Loading notebooks...</p>
      ) : notebooks.length === 0 ? (
        <p>No notebooks uploaded yet.</p>
      ) : (
        <div className="notebook-list">
          {notebooks.map((nb) => (
            <div key={nb.notebookId} className="llmgen-card">
              <h4 style={{ color: "#003366" }}>{nb.title}</h4>
              <p><strong className="txt ">Language:</strong> {nb.language}</p>
              <p><strong  className="txt">Uploaded By:</strong> {nb.uploadedBy ? "SME" : "Unknown"}</p>
              <p>
                <strong className="txt">Uploaded At:</strong>{" "}
                {new Date(nb.uploadedAt).toLocaleString()}
              </p>

              <div className="data-manp">
                <button
                  className="info-btn"
                  style={{
                    backgroundColor: "#007bff",
                    color: "white",
                    padding: "8px 12px",
                    borderRadius: 6,
                    border: "none",
                  }}
                  onClick={() => {
                    setSelectedNotebook(nb);
                    setIsRenameModalOpen(true);
                  }}
                >
                  Rename
                </button>

                <button
                  className="info-btn"
                  style={{
                    backgroundColor: "#dc3545",
                    color: "white",
                    padding: "8px 12px",
                    borderRadius: 6,
                    border: "none",
                  }}
                  onClick={() => handleDeleteNotebook(nb.notebookId)}
                >
                  Delete
                </button>

                <button
                  className="info-btn"
                  style={{
                    backgroundColor: "#28a745",
                    color: "white",
                    padding: "8px 12px",
                    borderRadius: 6,
                    border: "none",
                  }}
                  onClick={() =>
                    handleDownloadNotebook(nb.notebookId, nb.title)
                  }
                >
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ✅ Rename Modal */}
      {isRenameModalOpen && selectedNotebook && (
        <RenameModal
          notebook={selectedNotebook}
          onClose={() => setIsRenameModalOpen(false)}
          onSave={handleRenameNotebook}
        />
      )}
    </section>
  );
};

export default NotebookSection;