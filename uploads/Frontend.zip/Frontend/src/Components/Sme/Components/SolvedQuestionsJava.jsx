import React from 'react';
import "../styles/SolvedQuestions.css";

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';



function createData(sl, questions, status, time) {
  return { sl, questions, status, time };
}

const rows = [
  createData(1, 'Question 1', 'Complete', '3:48'),
  createData(1, 'Question 1', 'Complete', '3:48'),
  createData(1, 'Question 1', 'Complete', '3:48'),
  createData(1, 'Question 1', 'Complete', '3:48'),
  createData(1, 'Question 1', 'Complete', '3:48'),
];

function SolvedQuestionsJava({onLogout}) {
  return (
    <div>
      <h2 className='heading'>Solved Question status</h2>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Sl.No.</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Time Taken</TableCell>
              <TableCell>Question</TableCell>
            </TableRow>
          </TableHead>


          <TableBody>
            {rows.map((row) => (
              <TableRow key={row.sl}>
                <TableCell>{row.sl}</TableCell>
                <TableCell>{row.questions}</TableCell>
                <TableCell>{row.status}</TableCell>
                <TableCell>{row.time}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  )
}

export default SolvedQuestionsJava
