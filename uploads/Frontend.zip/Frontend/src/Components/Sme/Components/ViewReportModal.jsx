import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/ViewReportModal.css";
import ProblemReport from "./ProblemReport";// ✅ Detailed report modal

function ViewReportModal({ user, onClose }) {
  const [problems, setProblems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedProblem, setSelectedProblem] = useState(null);

  const useDummyData = true; // ✅ toggle ON/OFF for dummy data

  const dummyProblems = [
    { problemId: 1, title: "Two Sum" },
    { problemId: 2, title: "Reverse a String" },
    { problemId: 3, title: "Find Maximum Subarray" },
  ];

  const fetchUserProblems = async () => {
    try {
      setLoading(true);
      setError(null);

      if (useDummyData) {
        await new Promise((r) => setTimeout(r, 700)); // simulate API delay
        setProblems(dummyProblems);
        setLoading(false);
        return;
      }

      const res = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/admin/dashboard/problemInfo/${user.userId}?userId=${user.userId}`
      );
      setProblems(res.data || []);
    } catch (err) {
      console.error("Error fetching user problems:", err);
      setError("Failed to fetch problem data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) fetchUserProblems();
  }, [user]);

  return (
    <>
      <div className="modal-overlay">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Problems Solved by {user?.userName || "John Doe"}</h2>
            <button className="close-btn" onClick={onClose}>✖</button>
          </div>

          <div className="modal-body">
            {loading ? (
              <p className="loading-text">Loading problems...</p>
            ) : error ? (
              <p className="error-text">{error}</p>
            ) : problems.length === 0 ? (
              <p>No problems found for this user.</p>
            ) : (
              <ul className="problem-list">
                {problems.map((problem) => (
                  <li
                    key={problem.problemId}
                    className="problem-item"
                    onClick={() => setSelectedProblem(problem)} // ✅ open detailed modal
                  >
                    <span className="problem-title">{problem.title}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      {/* ✅ Nested Modal: Problem Report */}
      {selectedProblem && (
        <ProblemReport
          userId={user?.userId || 101}
          problem={selectedProblem}
          onClose={() => setSelectedProblem(null)}
        />
      )}
    </>
  );
}

export default ViewReportModal;