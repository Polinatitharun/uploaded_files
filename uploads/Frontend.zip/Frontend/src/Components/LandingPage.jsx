import '../styles/LandingPage.css';

import { useNavigate } from 'react-router';
import TerminalCard from './TerminalCard'
const featuresData = [
    { title: 'Compare, Learn & Code', desc: '', detail: 'Learn multiple lanuages together by comparing syntax and concepts.' },
    { title: 'Ideal for beginners', desc: '', detail: 'By focusing on concept-based learning, it ensures a gradual learning experience.' },
    { title: 'Hands on Practice', desc: '', detail: 'The platform features an inbuilt compiler that allows you to study, write, and practice code.' },

];

const title = "Concept Based Learning"

const LandingPage = ({ onLogin }) => {
    const navigate = useNavigate();
    const handlelogin = (e) => {
        e.preventDefault()
        navigate(onLogin())
    }

    return (
        <div className="landing-page">
            <header className="landing-header">
                <div className="logo">
                    <h1>Integrated Learning Platform</h1>
                </div>
            </header>

            <div className="landing-content">
                <div className="terminal-wrapper">
                    <div className="background-card"></div>
                    <div className="terminal-container java">
                        <TerminalCard
                            language="Java"
                            command="import java.util.*;"
                        />
                    </div>
                    <div className="terminal-container python">
                        <TerminalCard
                            language="Python"
                            command="print('Hello')"
                        />
                    </div>
                </div>

                <div className='landing-hero'>
                    <section className="hero">
                        <h1 className='landing-heading'>{title}</h1>
                        <p><strong>Tale of Two Titans </strong>– Exploring Power, Performance, and Versatility!</p>
                    </section>
                    <button onClick={handlelogin} className='landing-btn'>
                        Get Started
                    </button>
                </div>
            </div>

            <section className="features">
                {featuresData.map((feature, index) => (
                    <div className="feature-card" key={index}>
                        <div className="feature" key={index}>
                            <h3>{feature.title}</h3>
                            {feature.desc && <p><strong>{feature.desc}</strong></p>}
                            <p>{feature.detail}</p>
                        </div>
                    </div>
                ))}
            </section>
        </div>
    );
};

export default LandingPage;
