import React,{ useEffect } from "react";
import '../Styles/Feature.css'
import 'aos/dist/aos.css'
import Aos from 'aos';

  function Feature(){
    useEffect(() =>{
          Aos.init({duration: 2});
        }, [])
  return (
    <><div className="allfeature">
    <h2 className="feature-head_2">Feature</h2>
    <div className="featurepage">
      <div className="feature-project" data-aos="flip-down">
        <header  >
          <svg
            width="50"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#23ce6b"
            strokeWidth="1"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {" "}
            <title>Folder</title>{" "}
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>{" "}
          </svg>
        </header>
        <div className="feature-contain">
          <h3 className="feature-head_3">Hand-On Learning</h3>
          <p className="feature-first">
            The platform emphasizes "Learn by Doing!" through "Hnad-On Practice
            sessions.These sessions immerse users in "real-world challenges."
            Activites includes "taking coding exercise,
          </p>
        </div>
      </div>
       <div className="feature-project" data-aos="flip-down">
        <header>
          <svg
            width="50"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#23ce6b "
            strokeWidth="1"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <title>Folder</title>{" "}
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>{" "}
          </svg>
        </header>
        <div className="feature-contain">
          <h3 className="feature-head_3">Learn by Doing!</h3>
          <p className="feature-first">
            Our Hands-On Practice sessions
            immerse you in real-world challenges. Tackle coding exercises, build
            projects, and engage in simulations that bring your learning to
            life. Experience the thrill of applying your knowledge and watch
            your skills soar!
          </p>
        </div>
      </div>
      <div className="feature-project" data-aos="flip-down">
        <header>
          <svg
            width="50"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#23ce6b"
            strokeWidth="1"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <title>Folder</title>
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
          </svg>
        </header>
        <div className="feature-contain">
          <h3 className="feature-head_3">Test Your Skills and Boost Your Confidence!</h3>
          <p className="feature-first">
            Put your knowledge to the test with our fun and interactive MCQ
            Tests! These quizzes are strategically placed throughout your
            learning journey to help you track your progress and reinforce what
            you’ve learned. Get instant feedback and explanations that turn
            every question into a learning opportunity!
          </p>
        </div> 
      </div>
      </div>
      </div>
      </>
  );
};

export default Feature;
