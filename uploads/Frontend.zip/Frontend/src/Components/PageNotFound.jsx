import React from 'react'
import '../Styles/PageNotFound.css';
function PageNotFound() {
  return (
    <div className="not-found-container">
      <h1 className="error-code">404</h1>
      <p className="error-message">Oops! The page you are looking for doesn't exist.</p>
      <a href="/" className="home-link">Go Back to Home</a>
    </div>
  )
}

export default PageNotFound
