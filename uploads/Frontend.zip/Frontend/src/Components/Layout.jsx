import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import '../Styles/Layout.css';

const Layout = ({ children ,onLogout,name,email}) => {
  return (
    <div className="layout">

      <Navbar onLogout={onLogout} email={email} name={name}  />

       <div className="main-content">
        <div className="page-content">
          {children}
        </div>
      </div>

     
      <Footer />
    </div>
  );
};

export default Layout;