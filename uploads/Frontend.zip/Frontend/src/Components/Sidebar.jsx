import React, { useEffect, useState } from 'react';
import '../Styles/Sidebar.css';
import { useTopic } from '../context/topicContext';
import Cookies from "js-cookie"

const Sidebar = ({ onTopicChange }) => {
  const {getApi,topics,updateTopic} = useTopic();
  const token=Cookies.get("token");
  const topicArray=[]  
  topics.map((topic)=>{
    topicArray.push(topic)
  })
  
  const [result,setResult]=useState([])
  const [searchTopic,setSearchTopic]=useState("")
  useEffect(()=>{
    if(token){
      getApi(token);
    }
  },[])
  useEffect(()=>{
    if(searchTopic==='')
    {
        setResult(topicArray)
    }
    
    const handleSearch=async()=>{
      const filteredTopic=topicArray.filter((e)=>{
          if(e.topic.toLowerCase().includes(searchTopic.toLowerCase())){
            return e
          }
      })
      setResult(filteredTopic)
    }
    handleSearch()

  },[searchTopic,topics])

  return (
    <div className="sidebar">
      <input
        type="text"
        placeholder="Search..."
        id="search_box"
        onChange={(e)=>setSearchTopic(e.target.value)
        } 
      />

      <h3 id='side-topic'>Topics</h3>
      <ul className='topics-list'>
        {result.map((topic,index) => (
          <li key={index}>

            <div
              className="main-topic" 
              onClick={()=>updateTopic(topic,topic?.subtopics[0])
              }
            >
              {topic.topic}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;