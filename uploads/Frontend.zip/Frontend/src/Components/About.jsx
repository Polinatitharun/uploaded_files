// import python from "../assets/Python.svg.png";
// import java from "../assets/java.svg";
// import reactIcon from "../assets/react-icon.svg";
// import angular from "../assets/Angular_full_color_logo.svg.png";
// import javascript from "../assets/js-icon.svg";
// import cssIcon from "../assets/css-icon.svg";
import "../Styles/About.css";
// import 'aos/dist/a@tsparticles/slimcos.css'
import React,{ useEffect } from 'react';
import Aos from 'aos';



  function About(){
    useEffect(() =>{
      Aos.init({duration:3});
    }, [])
  return (
    <div className="aboutpage">
      <h2 className="about-head2" data-aos="fade-right" data-aos-offset="300" data-aos-easing="eas-in-sine" >About Us</h2>
  
      <div className="about-container">
        <br></br>
        <p className="about-para1" data-aos="fade-right" data-aos-offset="300" data-aos-easing="eas-in-sine">
          Hi there! Welcome to Integrated Development Platform
        </p>
       
        <p className="about-para1" data-aos="fade-right" data-aos-offset="300" data-aos-easing="eas-in-sine">
          Your one-stop solution for mastering diverse tech tracks! Our
          innovative platform empowers learners to explore a variety of subjects
          simultaneously, offering a blend of generic knowledge and specialized
          content.
        </p>
       
        <p className="about-para1" data-aos="fade-right" data-aos-offset="300" data-aos-easing="eas-in-sine">
          With engaging multiple-choice questions and interactive learning
          materials, IDP makes tech education accessible and enjoyable. Join us
          on your journey to becoming a tech-savvy professional and unlock your
          potential today!
        </p>

        <br></br>
        <br></br>
        
      </div>
    </div>
    
  );
};
export default About;
