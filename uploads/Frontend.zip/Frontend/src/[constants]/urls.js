export const ai_service_url=import.meta.env.VITE_AI_URL;
export const port=import.meta.env.VITE_PORT;
export const backend_service_url=import.meta.env.VITE_API_BASE_URL;
export const excutor_service_url=import.meta.env.VITE_CODE_EXECUTOR_URL;
