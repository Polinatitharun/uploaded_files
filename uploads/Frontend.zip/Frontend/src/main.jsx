import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { ToastContainer } from "react-toastify";
import { TopicProvider } from "./context/topicContext.jsx";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./(auth)/AuthContext.jsx";


createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <AuthProvider>
      <TopicProvider>
        <App />
        <ToastContainer />
      </TopicProvider>
    </AuthProvider>
  </BrowserRouter>
);
