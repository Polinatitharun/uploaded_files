import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "./AuthContext";

export const RoleGate = ({
  allow = [],
  redirectUnauth = "/",
  redirectUnauthorized = "/unauthorized",
}) => {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return <div className="loading">Loading…</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to={redirectUnauth} replace />;
  }

  const hasAccess =
    allow.length === 0 ||
    allow.some((role) => user?.roles?.includes(role));

  if (!hasAccess) {
    return <Navigate to={redirectUnauthorized} replace />;
  }

  return <Outlet />;
};