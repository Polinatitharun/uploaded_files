import { Outlet } from "react-router-dom";
import { useAuth } from "./AuthContext";

const ProtectedRoute = ({ roles = [] }) => {
  const { user, loading, login } = useAuth();

  if (loading) {
    return <h2>Loading...</h2>;
  }

  if (!user) {
    login();
    return null;
  }

  if (
    roles.length > 0 &&
    !roles.some((role) => user.roles?.includes(role))
  ) {
    return <h2>Unauthorized</h2>;
  }

  return <Outlet />;
};

export default ProtectedRoute;