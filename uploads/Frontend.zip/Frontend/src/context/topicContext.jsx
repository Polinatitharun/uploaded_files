import { createContext, useContext,useState,useEffect } from "react";
import {toast} from "react-toastify";
import axios from 'axios';
import Cookies from "js-cookie"


const TopicContext = createContext()


export const TopicProvider = ({children})=>{
    const [topics,setTopics] = useState([]);
    const [topic,setTopic] = useState([]);
    const [subtopic,setSubTopic] = useState([]);
    const [activeshow, setActiveShow] = useState(false);
    

    
    

    const updateTopic = (topic,subtopic)=>{
      setTopic(topic);
      setSubTopic(subtopic)
      setActiveShow(false)
    }
    let token=Cookies.get('token')



    const getApi = async(t) => {

      try {
        if(t){
          token=t;
        }

        // const response = await axios.get(`http://10.59.52.146:3000/topics?token=${token}`);
        const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/topics`);
        setTopics(response.data);
        topics.map((key)=>{
          return key.examples;
        })
      } catch (error) {
        toast.error(`Error while fetching ${error.message}`);
      }
    }

     
      
    const value = {
      topics,
      topic,
      subtopic,
      setActiveShow,
      activeshow,
      setTopic,
      updateTopic,
      getApi
    }

    return(
        <TopicContext.Provider value={value}>
            {children}
        </TopicContext.Provider>
    )
}

export function useTopic() {
    const context = useContext(TopicContext)

    if(!context){
         throw new Error("useTopic is outside the Provider")
    }

    return context
}


