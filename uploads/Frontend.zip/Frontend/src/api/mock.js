import dayjs from 'dayjs';

const languages = ['python', 'java', 'javascript', 'typescript'];

// Helper: random int
const ri = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// Generate a small synthetic dataset for a single batch & day
export function generateMockEvents({ dateISO = dayjs().format('YYYY-MM-DD'), batchId = 'B2025-12' }) {
  const trainees = ['T001', 'T002', 'T003', 'T004', 'T005'];
  const topics = [
    { id: 'DSA-Stacks', title: 'Stacks' },
    { id: 'DSA-Queues', title: 'Queues' },
    { id: 'OOP-Classes', title: 'Classes & Objects' },
  ];
  const problems = [
    { id: 'TwoSum', title: 'Two Sum' },
    { id: 'ReverseLL', title: 'Reverse Linked List' },
    { id: 'ValidParentheses', title: 'Valid Parentheses' },
  ];

  const events = [];

  trainees.forEach((tid) => {
    const mode = Math.random() < 0.5 ? 'vertical' : 'parallel';
    const sessionId = `S-${tid}-${ri(100, 999)}`;

    topics.forEach((t) => {
      const lang = languages[ri(0, languages.length - 1)];
      const base = dayjs(`${dateISO}T09:00:00`);

      // topic_view
      events.push({
        event: 'topic_view',
        ts: base.add(ri(0, 90), 'minute').toISOString(),
        trainee_id: tid,
        batch_id: batchId,
        topic_id: t.id,
        language: lang,
        mode,
        session_id: sessionId,
        source: 'learning_path',
      });

      // mcq_start -> mcq_submit
      const mcqStart = base.add(ri(5, 30), 'minute');
      const mcqPass = Math.random() < 0.7;
      events.push({
        event: 'mcq_start',
        ts: mcqStart.toISOString(),
        trainee_id: tid,
        topic_id: t.id,
        language: lang,
        mcq_id: `${t.id}-MCQ-01`,
      });
      events.push({
        event: 'mcq_submit',
        ts: mcqStart.add(ri(2, 6), 'minute').toISOString(),
        trainee_id: tid,
        topic_id: t.id,
        language: lang,
        mcq_id: `${t.id}-MCQ-01`,
        passed: mcqPass,
        score: ri(3, 5),
        total: 5,
        duration_ms: ri(120, 480) * 1000,
      });

      // coding_start -> coding_submit (only if MCQ passed typically, but allow noise)
      const codingStart = mcqStart.add(ri(7, 20), 'minute');
      const testPassed = Math.random() < (mcqPass ? 0.8 : 0.4);
      events.push({
        event: 'coding_start',
        ts: codingStart.toISOString(),
        trainee_id: tid,
        topic_id: t.id,
        language: lang,
        editor_mode: 'embedded',
        template_used: Math.random() < 0.5,
      });
      events.push({
        event: 'coding_submit',
        ts: codingStart.add(ri(10, 40), 'minute').toISOString(),
        trainee_id: tid,
        topic_id: t.id,
        language: lang,
        test_passed: testPassed,
        attempts: ri(1, 5),
        duration_ms: ri(600, 2400) * 1000,
        error_breakdown: { compile: ri(0, 2), runtime: ri(0, 2), test_fail: ri(0, 3) },
      });

      // topic_complete (only if both passed)
      if (mcqPass && testPassed) {
        events.push({
          event: 'topic_complete',
          ts: codingStart.add(ri(20, 60), 'minute').toISOString(),
          trainee_id: tid,
          topic_id: t.id,
          language: lang,
          mcq_passed: true,
          coding_done: true,
          time_from_first_view_ms: ri(900, 3600) * 1000,
        });
      }
    });

    // Problems (language-wise attempts)
    problems.forEach((p) => {
      const lang = languages[ri(0, languages.length - 1)];
      const base = dayjs(`${dateISO}T11:00:00`);
      events.push({
        event: 'problem_view',
        ts: base.add(ri(0, 60), 'minute').toISOString(),
        trainee_id: tid,
        problem_id: p.id,
        language: lang,
      });
      const attempts = ri(1, 4);
      for (let a = 1; a <= attempts; a++) {
        events.push({
          event: 'problem_attempt',
          ts: base.add(a * ri(2, 10), 'minute').toISOString(),
          trainee_id: tid,
          problem_id: p.id,
          language: lang,
          attempt_no: a,
        });
      }
      const solved = Math.random() < 0.65;
      events.push({
        event: 'problem_submit',
        ts: base.add(ri(15, 50), 'minute').toISOString(),
        trainee_id: tid,
        problem_id: p.id,
        language: lang,
        solved,
        duration_ms: ri(300, 1800) * 1000,
        attempts,
        hint_used: Math.random() < 0.3,
        solution_viewed: Math.random() < 0.2,
        error_breakdown: { compile: ri(0, 2), runtime: ri(0, 2), test_fail: ri(0, 3) },
      });
    });
  });

  return { events, meta: { batchId, dateISO, languages } };
}

// API facade (mock)
export async function fetchEvents({ batchId, dateISO }) {
  // Simulate latency
  await new Promise((r) => setTimeout(r, 400));
  return generateMockEvents({ batchId, dateISO });
}
