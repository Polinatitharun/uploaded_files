import { Routes, Route, Navigate, Outlet } from "react-router-dom";
import { Suspense } from "react";
import "./App.css";

import {
  ProtectedRoute,
  RoleGate,
  Home,
  About,
  Feature,
  ParticleBackground,
  McqPage,
  MCQHome,
  QuestionsList,
  MCQGeneration,
  Dashboard,
  MCQPreview,
  QuestionGeneration,
  LandingPage,
  PageNotFound,
  Compiler,
  SMEReports,
  CurriculumAnalysis,
  UploadNotebook,
  LearningPage,
  SolvedQuestionsJava,
  SolvedQuestionsPython,
  UserLeaderbooard,
  TopicGeneration,
  GeneratedContent,
  ExcelDataProcessor,
  ContentGeneration,
  UserProfile,
} from "./utils";

import { ROUTES } from "./routes/routes.constants";
import Unauthorized from "./components/common/Unauthorized/Unauthorized";
import { useAuth } from "./(auth)/AuthContext";
import { Api } from "@mui/icons-material";

function App() {
  const { user, loading, login } = useAuth();


  const LearnerLayout = () => <Outlet />;
  const SMELayout = () => <Outlet />;

  const RootRedirect = () => {
    if (loading) return <div>Loading...</div>;

    if (!user) {
      return <LandingPage onLogin={login} />;
    }

    if (user.roles?.includes("SME")) {
      return <Navigate to={ROUTES.DASHBOARD} replace />;
    }

    return <Navigate to={ROUTES.HOME} replace />;
  };

  // you can call an Api
  // store a response in context

  return (
    <div className="main">
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path={ROUTES.ROOT} element={<RootRedirect />} />

          <Route element={<ProtectedRoute />}>
            {/* ---------------- SME ROUTES ---------------- */}
            <Route element={<RoleGate allow={["SME"]} />}>
              <Route element={<SMELayout />}>
                <Route path={ROUTES.DASHBOARD} element={<Dashboard />} />
                <Route path={ROUTES.SME_MCQs} element={<MCQGeneration />} />
                <Route
                  path={ROUTES.SME_MCQs_PREVIEW}
                  element={<MCQPreview />}
                />
                <Route
                  path={ROUTES.SME_QUESTION_GEN}
                  element={<QuestionGeneration />}
                />
                <Route
                  path={ROUTES.SME_CONTENT_GEN}
                  element={<ContentGeneration />}
                />
                <Route
                  path={ROUTES.SME_TOPIC_GEN}
                  element={<TopicGeneration />}
                />
                <Route
                  path={ROUTES.SME_EXCEL}
                  element={<ExcelDataProcessor />}
                />
                <Route
                  path={ROUTES.SME_GENERATED_CONTENT}
                  element={<GeneratedContent />}
                />
                <Route
                  path={ROUTES.USER_LEADERBOARD}
                  element={<UserLeaderbooard />}
                />
                <Route
                  path={ROUTES.SME_SOLVED_JAVA()}
                  element={<SolvedQuestionsJava />}
                />
                <Route
                  path={ROUTES.SME_SOLVED_PY()}
                  element={<SolvedQuestionsPython />}
                />
                <Route
                  path={ROUTES.UPLOAD_NOTEBOOK}
                  element={<UploadNotebook />}
                />
                <Route
                  path={ROUTES.CURRICULUM}
                  element={<CurriculumAnalysis />}
                />
                <Route path={ROUTES.REPORTS} element={<SMEReports />} />
              </Route>
            </Route>

            <Route
              element={
                <RoleGate
                  allow={[
                    "Learner",
                    "USER",
                    "Employee",
                    "Default",
                    "Trainee",
                  ]}
                />
              }
            >
              <Route element={<LearnerLayout />}>
                <Route path={ROUTES.LEARNING} element={<LearningPage />} />
                <Route path={ROUTES.MCQ} element={<MCQHome />} />
                <Route path={ROUTES.MCQ_TOPIC()} element={<McqPage />} />

                <Route path={ROUTES.QUESTIONS}>
                  <Route path="all" element={<QuestionsList />} />
                  <Route
                    path=":questionId/solve"
                    element={<Compiler />}
                  />
                </Route>

                <Route
                  path={ROUTES.HOMEBG}
                  element={<ParticleBackground />}
                />
                <Route path={ROUTES.HOME} element={<Home />} />
                <Route path={ROUTES.ABOUT} element={<About />} />
                <Route path={ROUTES.FEATURE} element={<Feature />} />
                <Route
                  path={ROUTES.PROFILE()}
                  element={<UserProfile />}
                />
              </Route>
            </Route>

            <Route path={ROUTES.UNAUTHORIZED} element={<Unauthorized />} />
            <Route path="*" element={<PageNotFound />} />
          </Route>

          <Route path="*" element={<Navigate to={ROUTES.HOME} replace />} />
        </Routes>
      </Suspense>
    </div>
  );
}

export default App;
``