export const fmtInt = (n) => (n ?? 0).toLocaleString();
export const fmtMs = (ms) => `${Math.round((ms ?? 0) / 1000)}s`;
export const fmtMin = (ms) => `${Math.round((ms ?? 0) / 60000)} min`;
