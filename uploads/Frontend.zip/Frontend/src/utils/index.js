import Collapse from "../components/common/CollapseComponent/Collapse.jsx";
import PageNotFound from "../components/PageNotFound";
import Compiler from "../components/Compiler";
import QuestionGeneration from "../components/Sme/Components/QuestionGeneration.jsx";
import QuestionPreview from "../components/Sme/Components/QuestionPreview.jsx";
import ContentGeneration from "../components/Sme/Components/ContentGeneration";
import ExcelDataProcessor from "../components/Sme/Components/ExcelDataProcessor.jsx";
import GeneratedContent from "../components/Sme/Components/GeneratedContent.jsx";
import TopicGeneration from "../components/Sme/Components/TopicGeneration.jsx";
import UserLeaderbooard from "../components/Sme/Components/UserLeaderbooard.jsx";
import SolvedQuestionsJava from "../components/Sme/Components/SolvedQuestionsJava.jsx";
import SolvedQuestionsPython from "../components/Sme/Components/SolvedQuestionsPython.jsx";
import LearningPage from "../components/LearningPage.jsx";
// import UserDashboard from "../components/UserDashboard.jsx";
import UploadNotebook from "../components/Sme/Components/UploadNotebook.jsx";
import CurriculumAnalysis from "../components/Sme/Components/CurriculumAnalysis.jsx";
import SMEReports from "../components/Sme/Components/SMEReports.jsx";
import MarkdownEditor from "../components/Markdown/MarkdownEditor.jsx";
import ProtectedRoute from "../(auth)/ProtectedRoute.jsx";
import Home from "../components/Home";
import About from "../components/About";
import Feature from "../components/Feature";
import ParticleBackground from "../components/ParticleBackground";
import MCQHome from "../components/Mcq/MCQHome";
import McqPage from "../components/Mcq/McqPage";
import QuestionPage from "../components/QuestionPage.jsx";
import QuestionsList from "../components/Problem/QuestionList/QuestionsList.jsx";
import MCQGeneration from "../components/Sme/Components/MCQGenration";
import Dashboard from "../components/Sme/Components/Dashboard.jsx";
import MCQPreview from "../components/Sme/Components/MCQPreview.jsx";
import LandingPage from "../Components/LandingPage.jsx";
import UserProfile from "../components/Profile/index.jsx";
import { RoleGate } from "../(auth)/RoleGate.jsx";

export{
    RoleGate,
    UserProfile,
    ProtectedRoute,
    Home,
    About,
    Feature,
    ParticleBackground,
    McqPage,
    MCQHome,
    QuestionPage,
    QuestionsList,
    MCQGeneration,
    Dashboard,
    MCQPreview,
    QuestionGeneration,
    Collapse,
    LandingPage,
    PageNotFound,
    Compiler,
    MarkdownEditor,
    SMEReports,
    CurriculumAnalysis,
    UploadNotebook,
    LearningPage,
    SolvedQuestionsJava,
    SolvedQuestionsPython,
    UserLeaderbooard,
    TopicGeneration,
    GeneratedContent,
    ExcelDataProcessor,
    ContentGeneration,
    QuestionPreview,

}