import dayjs from 'dayjs';

// Filter by date (UTC date string)
export function filterByDate(events, dateISO) {
  return events.filter(e => dayjs(e.ts).format('YYYY-MM-DD') === dateISO);
}

export function computeBatchSummary(events) {
  const activeTrainees = new Set();
  let topicViews = 0;
  let topicsCompleted = 0;
  let totalCodingDuration = 0, codingCnt = 0;
  let totalMcqDuration = 0, mcqCnt = 0;

  const topicViewMap = {};
  const languageUsageMap = {};
  events.forEach(e => {
    if (e.trainee_id) activeTrainees.add(e.trainee_id);
    if (e.event === 'topic_view') {
      topicViews++;
      topicViewMap[e.topic_id] = (topicViewMap[e.topic_id] || 0) + 1;
    }
    if (e.event === 'topic_complete') topicsCompleted++;
    if (e.event === 'coding_submit' && e.duration_ms) { totalCodingDuration += e.duration_ms; codingCnt++; }
    if (e.event === 'mcq_submit' && e.duration_ms) { totalMcqDuration += e.duration_ms; mcqCnt++; }
    if (e.language) {
      languageUsageMap[e.language] = (languageUsageMap[e.language] || 0) + 1;
    }
  });

  const sortedTopics = Object.entries(topicViewMap).sort((a, b) => b[1] - a[1]);
  const mostTrendingTopic = sortedTopics[0] ? sortedTopics[0][0] : 'N/A';
  const leastTrendingTopic = sortedTopics[sortedTopics.length - 1] ? sortedTopics[sortedTopics.length - 1][0] : 'N/A';

  const sortedLanguages = Object.entries(languageUsageMap).sort((a, b) => b[1] - a[1]);
  const mostTrendingLanguage = sortedLanguages[0] ? sortedLanguages[0][0] : 'N/A';
  const leastTrendingLanguage = sortedLanguages[sortedLanguages.length - 1] ? sortedLanguages[sortedLanguages.length - 1][0] : 'N/A';

  return {
    activeTrainees: activeTrainees.size,
    topicViews,
    topicsCompleted,
    avgCodingDurationMs: codingCnt ? Math.round(totalCodingDuration / codingCnt) : 0,
    avgMcqDurationMs: mcqCnt ? Math.round(totalMcqDuration / mcqCnt) : 0,
    mostTrendingTopic,
    leastTrendingTopic,
    mostTrendingLanguage,
    leastTrendingLanguage,
  };
}

export function languageEngagement(events) {
  const map = {};
  events.forEach(e => {
    const lang = e.language || 'unknown';
    map[lang] ||= { language: lang, viewed: 0, mcq_started: 0, mcq_passed: 0, coding_started: 0, coding_completed: 0, topic_completed: 0 };
    if (e.event === 'topic_view') map[lang].viewed++;
    if (e.event === 'mcq_start') map[lang].mcq_started++;
    if (e.event === 'mcq_submit' && e.passed) map[lang].mcq_passed++;
    if (e.event === 'coding_start') map[lang].coding_started++;
    if (e.event === 'coding_submit' && e.test_passed) map[lang].coding_completed++;
    if (e.event === 'topic_complete') map[lang].topic_completed++;
  });
  return Object.values(map);
}

export function topicFunnelByLanguage(events, { topicId }) {
  const map = {};
  events.filter(e => e.topic_id === topicId)
    .forEach(e => {
      const lang = e.language || 'unknown';
      map[lang] ||= { language: lang, viewed: 0, mcq_passed: 0, coding_completed: 0, completed: 0 };
      if (e.event === 'topic_view') map[lang].viewed++;
      if (e.event === 'mcq_submit' && e.passed) map[lang].mcq_passed++;
      if (e.event === 'coding_submit' && e.test_passed) map[lang].coding_completed++;
      if (e.event === 'topic_complete') map[lang].completed++;
    });
  return Object.values(map);
}

export function problemStats(events, { problemId }) {
  const languages = ['python', 'java', 'javascript', 'typescript'];
  const map = {};
  languages.forEach(lang => {
    map[lang] = { language: lang, attempts: 0, solved: 0, timeTotal: 0, submits: 0 };
  });
  events.filter(e => e.problem_id === problemId)
    .forEach(e => {
      const lang = e.language || 'unknown';
      if (map[lang]) {
        if (e.event === 'problem_attempt') map[lang].attempts++;
        if (e.event === 'problem_submit') {
          map[lang].solved += e.solved ? 1 : 0;
          map[lang].timeTotal += e.duration_ms || 0;
          map[lang].submits++;
        }
      }
    });
  return Object.values(map).map(x => ({
    language: x.language,
    attempts: x.attempts,
    solved: x.solved,
    avgTimeMs: x.submits ? Math.round(x.timeTotal / x.submits) : 0,
  }));
}

export function traineeProgress(events) {
  const map = {};
  events.forEach(e => {
    const t = e.trainee_id;
    if (!t) return;
    map[t] ||= { trainee_id: t, topics_completed: 0, avg_time_to_complete_ms: 0, completeCnt: 0, modeParallelCnt: 0, languages: new Set() };
    if (e.event === 'topic_complete') {
      map[t].topics_completed++;
      if (e.time_from_first_view_ms) {
        map[t].avg_time_to_complete_ms += e.time_from_first_view_ms;
        map[t].completeCnt++;
      }
    }
    if (e.mode === 'parallel') map[t].modeParallelCnt++;
    if (e.language) map[t].languages.add(e.language);
  });

  return Object.values(map).map(x => ({
    trainee_id: x.trainee_id,
    topics_completed: x.topics_completed,
    avg_time_to_complete_ms: x.completeCnt ? Math.round(x.avg_time_to_complete_ms / x.completeCnt) : 0,
    languages_count: x.languages.size,
    parallel_activity: x.modeParallelCnt,
  }));
}

export function dropoff(events, { topicId }) {
  const viewed = events.filter(e => e.topic_id === topicId && e.event === 'topic_view').length;
  const mcq = events.filter(e => e.topic_id === topicId && e.event === 'mcq_submit' && e.passed).length;
  const coding = events.filter(e => e.topic_id === topicId && e.event === 'coding_submit' && e.test_passed).length;
  const completed = events.filter(e => e.topic_id === topicId && e.event === 'topic_complete').length;
  return [
    { stage: 'Viewed', count: viewed },
    { stage: 'MCQ Passed', count: mcq },
    { stage: 'Coding Passed', count: coding },
    { stage: 'Completed', count: completed },
  ];
}

export const msToMin = (ms) => Math.round(ms / 60000);
