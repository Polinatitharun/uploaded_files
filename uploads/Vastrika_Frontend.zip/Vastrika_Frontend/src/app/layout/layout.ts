import { Component } from '@angular/core';
import { MenuItem } from '../models/menu-item';
import { RouterModule, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-layout',
  imports: [RouterModule, CommonModule],
  templateUrl: './layout.html',
  styleUrl: './layout.css',
})
export class Layout {
  
menuItems: MenuItem[] = [
    { label: 'Dashboard', route: '/dashboard' },
    { label: 'Wardrobe', route: '/wardrobe' },
    { label: 'Style Profile', route: '/measurement' },
    { label: 'Measurements', route: '/tailor' },
    { label: 'Chat History', route: '/chathistory' }
  ];

}
