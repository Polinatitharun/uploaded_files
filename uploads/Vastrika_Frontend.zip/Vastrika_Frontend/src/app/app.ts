import { Component, signal } from '@angular/core';
import { RouterOutlet, Router } from '@angular/router';
import { AuthService } from './auth/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `<router-outlet></router-outlet>`
})
export class App {
  isLoggedIn = signal(false);

  constructor(private authService: AuthService, private router: Router) {
    this.authService.userLoggedInSubject.subscribe(loggedIn => {
      this.isLoggedIn.set(loggedIn);
    });
  }
}
