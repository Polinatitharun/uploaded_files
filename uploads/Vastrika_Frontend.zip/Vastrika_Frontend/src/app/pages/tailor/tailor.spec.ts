import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TailorComponent } from './tailor';

describe('Tailor', () => {
  let component: TailorComponent;
  let fixture: ComponentFixture<TailorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TailorComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TailorComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
