import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tailor',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tailor.html',
  styleUrls: ['./tailor.css']
})
export class TailorComponent {

  userName = 'User';
  activeItem = 'Style New';

  menuItems = [
    'Style New',
    'Measurement',
    'Favourites',
    'Tailor',
    'Chat History',
    'Wardrobe'
  ];
  measurements = [
  { name: 'Measurement_1.pdf', date: '25 Apr 2026' },
  { name: 'Measurement_2.pdf', date: '24 Apr 2026' },
  { name: 'Measurement_3.pdf', date: '23 Apr 2026' }
];

  selectItem(item: string) {
  this.activeItem = item;
  }

}