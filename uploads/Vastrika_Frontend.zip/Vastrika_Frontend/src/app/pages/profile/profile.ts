import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  imports: [],
  templateUrl: './profile.html',
  styleUrl: './profile.css',
})
export class Profile implements OnInit {

  // These will later come from APIs
  styleDna = {
    faceShape: 'Oval',
    bodyType: 'Athletic',
    skinTone: 'Medium',
    hairType: 'Curly',
    age: 28,
    gender: 'Male'
  };

  measurements = {
    chest: 40,
    waist: 32,
    hip: 38
  };

  preferences = {
    preferredStyle: 'Casual',
    preferredColors: 'Blue, Black',
    preferredOccasion: 'Office, Party',
    preferredHairStyle: 'Short',
    region: 'Tamil Nadu'
  };

  constructor(private router: Router) {}

  ngOnInit(): void {}

  editProfile() {
    this.router.navigate(['/measurement']);
  }
}