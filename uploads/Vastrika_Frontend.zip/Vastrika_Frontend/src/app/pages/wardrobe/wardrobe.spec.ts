import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardrobeComponent } from './wardrobe';

describe('Wardrobe', () => {
  let component: WardrobeComponent;
  let fixture: ComponentFixture<WardrobeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WardrobeComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(WardrobeComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
