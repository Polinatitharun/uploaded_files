import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WardrobeService, WardrobeItem } from '../../service/wardrobe.service';

@Component({
  selector: 'app-wardrobe',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './wardrobe.html',
  styleUrls: ['./wardrobe.css']
})
export class WardrobeComponent implements OnInit  {

  // ✅ SIGNALS
  items = signal<WardrobeItem[]>([]);
  loading = signal<boolean>(false);

  // ✅ NORMAL STATE
  showForm = false;
  errorMsg = '';

  newItem: WardrobeItem = {
    itemName: '',
    category: '',
    color: '',
    imageUrl: ''
  };

  constructor(private wardrobeService: WardrobeService) {}

  ngOnInit(): void {
    this.loadItems();
  }

  /* ---------------- LOAD ---------------- */
  loadItems(): void {
    this.loading.set(true);

    this.wardrobeService.getMyItems().subscribe({
      next: (data) => {
        this.items.set(data);          // ✅ correct signal update
        this.loading.set(false);
      },
      error: () => {
        this.errorMsg = 'Failed to load wardrobe';
        this.loading.set(false);
      }
    });
  }

  /* ---------------- MODAL ---------------- */
  openForm(open: boolean = true): void {
    this.showForm = open;
    this.errorMsg = '';
  }

  /* ---------------- IMAGE ---------------- */
  onImageUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) {
      this.newItem.imageUrl = URL.createObjectURL(file);
    }
  }

  /* ---------------- ADD ---------------- */
  addItem(): void {
    if (!this.newItem.itemName || !this.newItem.imageUrl) {
      this.errorMsg = 'Name and image required';
      return;
    }

    this.loading.set(true);

    this.wardrobeService.addItem(this.newItem).subscribe({
      next: () => {

        // ✅ signal-safe optimistic update
        this.items.update(items => [
          {
            ...this.newItem,
            createdAt: new Date().toISOString()
          },
          ...items
        ]);

        // ✅ reset
        this.newItem = {
          itemName: '',
          category: '',
          color: '',
          imageUrl: ''
        };

        this.showForm = false;
        this.loading.set(false);
      },
      error: (err) => {
        this.errorMsg = err.error || 'Add failed';
        this.loading.set(false);
      }
    });
  }

  /* ---------------- DELETE ---------------- */
deleteItem(itemId?: number) {
  if (!itemId) return;

  this.items.update(items =>
    items.filter(i => i.itemId !== itemId)
  );

  this.wardrobeService.deleteItem(itemId).subscribe({
    error: () => {
      this.loadItems();
    }
  });
}
}