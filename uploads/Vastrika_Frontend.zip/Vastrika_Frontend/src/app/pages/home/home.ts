import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';



@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class Home {

  userName = 'User';

  isSidebarOpen = false;
  activeItem = 'Style New';

  menuItems = [

    'Style New',
    'Measurement',
    'Favourites',
    'Tailor',
    'Chat History',
    'Wardrobe'
  ];

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  closeSidebar() {
    this.isSidebarOpen = false;
  }

  selectItem(item: string) {
    this.activeItem = item;
  }



getRoute(item: string) {
  switch(item) {
    case 'Style New': return '/';
    case 'Measurement': return '/measurement';
    case 'Favourites': return '/favourites';
    case 'Tailor': return '/tailor';
    case 'Chat History': return '/chat';
    case 'Wardrobe': return '/wardrobe';
    default: return '/';
  }
}
}