import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ChatItem {
  title: string;
  desc: string;
  time: string;
}

@Component({
  selector: 'app-chat-history',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chathistory.html',
  styleUrls: ['./chathistory.css']
})
export class Chathistory {

  showChatbot = false;
  searchTerm = '';

  chats: ChatItem[] = [
    {
      title: 'Wedding Outfit Ideas',
      desc: 'Suggested lehenga and matching jewellery.',
      time: '2 mins ago'
    },
    {
      title: 'Office Wear Suggestions',
      desc: 'Formal shirt and trouser combinations.',
      time: '10 mins ago'
    },
    {
      title: 'Festival Collection',
      desc: 'Kurti and saree styling ideas.',
      time: '1 hour ago'
    }
  ];

  get filteredChats(): ChatItem[] {
    const term = this.searchTerm.toLowerCase();
    return this.chats.filter(chat =>
      chat.title.toLowerCase().includes(term) ||
      chat.desc.toLowerCase().includes(term)
    );
  }

  openNewChat(): void {
    this.showChatbot = true;
  }

  closeChat(): void {
    this.showChatbot = false;
  }
}