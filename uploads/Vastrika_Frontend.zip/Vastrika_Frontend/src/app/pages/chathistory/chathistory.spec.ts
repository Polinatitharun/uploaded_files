import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Chathistory } from './chathistory';

describe('Chathistory', () => {
  let component: Chathistory;
  let fixture: ComponentFixture<Chathistory>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Chathistory],
    }).compileComponents();

    fixture = TestBed.createComponent(Chathistory);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
