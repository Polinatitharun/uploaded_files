import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StylePreferenceService, StylePreference } from '../../service/style-preference.service';

@Component({
  selector: 'app-measurement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './measurement.html',
  styleUrls: ['./measurement.css']
})
export class MeasurementComponent implements OnInit {
  activeModal: 'dna' | 'measure' | 'pref' | null = null;
  loading = false;
  errorMsg = '';

  
states: string[] = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar',
    'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana',
    'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala',
    'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya',
    'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana',
    'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
    'Delhi', 'Puducherry', 'Ladakh', 'Jammu & Kashmir'
  ];


  formData: StylePreference = {
    preferredStyle: '',
    preferredHairStyle: '',
    preferredColors: '',
    preferredOccasion: '',
    chest: 0,
    waist: 0,
    hip: 0,
    faceShape: '',
    bodyType: '',
    skinTone: '',
    hairType: '',
    age: 0,
    gender: 'Male',
    region: ''
  };

  constructor(private styleService: StylePreferenceService) {}

  ngOnInit() {
    this.loadPreferences();
  }

  loadPreferences() {
    this.loading = true;
    this.styleService.getPreferences().subscribe({
      next: prefs => {
        Object.assign(this.formData, prefs);
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load preferences';
        this.loading = false;
      }
    });
  }

  openModal(type: 'dna' | 'measure' | 'pref') {
    this.activeModal = type;
  }

  closeModal() {
    this.activeModal = null;
  }

  onSave() {
    this.loading = true;
    this.styleService.updatePreferences(this.formData).subscribe({
      next: () => {
        this.closeModal();
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Save failed';
        this.loading = false;
      }
    });
  }

  onReset() {
    Object.keys(this.formData).forEach(
      k => (this.formData as any)[k] = ''
    );
  }
}