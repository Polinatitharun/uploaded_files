import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface WardrobeItem {
  itemId?: number;
  itemName: string;
  category: string;
  color: string;
  imageUrl: string;
  createdAt?: string;
}

@Injectable({
  providedIn: 'root'
})
export class WardrobeService {
  private apiUrl = 'http://127.0.0.1:8080/api/v1/wardrobe';

  constructor(private http: HttpClient) { }

  addItem(item: WardrobeItem): Observable<string> {
    return this.http.post<string>(`${this.apiUrl}/add`, item);
  }

  getMyItems(): Observable<WardrobeItem[]> {
    return this.http.get<WardrobeItem[]>(`${this.apiUrl}/my-items`);
  }

  deleteItem(itemId: number) {
    return this.http.delete(`${this.apiUrl}/${itemId}`);
  }
}

