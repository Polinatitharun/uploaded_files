import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface StylePreference {
  preferredStyle: string;
  preferredHairStyle: string;
  preferredColors: string;
  preferredOccasion: string;
  chest: number;
  waist: number;
  hip: number;
  faceShape: string;
  bodyType: string;
  skinTone: string;
  hairType: string;
  hairStyle?: string;
  age: number;
  gender: string;
  region: string;
  religion?: string;
  preferredHair?: string;
  colors?: string[];
  occasion?: string;
}

@Injectable({
  providedIn: 'root'
})
export class StylePreferenceService {
  private apiUrl = 'http://127.0.0.1:8080/api/v1';

  constructor(private http: HttpClient) {}

  savePreferences(prefs: StylePreference): Observable<string> {
    return this.http.post<string>(`${this.apiUrl}/stylerequest`, prefs);
  }

  getPreferences(): Observable<StylePreference> {
    return this.http.get<StylePreference>(`${this.apiUrl}/view`);
  }

  updatePreferences(prefs: StylePreference): Observable<string> {
    return this.http.put<string>(`${this.apiUrl}/update`, prefs);
  }
}

