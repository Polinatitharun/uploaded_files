import { Routes } from '@angular/router';

import { Landing } from './pages/landing/landing';
import { Register } from './pages/register/register';
import { LoginComponent } from './pages/login/login';
import { Layout } from './layout/layout';
import { Dashboard } from './pages/dashboard/dashboard';
import { Profile } from './pages/profile/profile';
import { guestGuard } from './auth/guest.guard';
import { MeasurementComponent } from './pages/measurement/measurement';
import { WardrobeComponent } from './pages/wardrobe/wardrobe';
import { TailorComponent } from './pages/tailor/tailor';
import { Chathistory } from './pages/chathistory/chathistory';

// export const routes: Routes = [
//   {path:'', component: Landing},
//   {path: 'login', component: LoginComponent},
//   {path: 'register', component: Register},
//   {path:'home', component: Layout},
//   {path:'profile', component: Profile},
//   {path:'measurement', component: MeasurementComponent},
//   {path:'wardrobe', component: WardrobeComponent},
//   {path:'tailor', component: TailorComponent},
//   {path:'chathistory', component: Chathistory},
//   {path: '**', redirectTo: '/home'}
// ];



export const routes: Routes = [

  /* Public pages  */
  { path: '', component: Landing, canActivate: [guestGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: Register },

  /* App pages */
  {
    path: '',
    component: Layout,
    children: [
      { path: 'dashboard', component: Dashboard },
      { path: 'profile', component: Profile },
      { path: 'measurement', component: MeasurementComponent },
      { path: 'wardrobe', component: WardrobeComponent },
      { path: 'tailor', component: TailorComponent },
      { path: 'chathistory', component: Chathistory },
    ]
  },

  { path: '**', redirectTo: '' }
];


