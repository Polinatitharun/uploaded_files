venv\Scripts\activate
set http_proxy=http://proxy.tcs.com:8080
set https_proxy=http://proxy.tcs.com:8080
pip install -r requirements.txt
set http_proxy=
set https_proxy=
set no_proxy=172.*
python -m fastapi run main.py