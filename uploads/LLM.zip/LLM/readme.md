# Project Title

LearnX

## Project Description

Provides a platform where users can learn about react and angular. This application will help user understand implementing MVC flow in both technologies. SME can also generate content by using Large Language Models.

To build this application, we have mainly used Angular, SpringBoot and Postgres. For the LLM part, we have used Python and FastAPI.

The challenges we personally faced were co-ordination between team members as everyone was working on differnet components.

## Tech Stack

**Server:** FastAPI


## Installation and Running the Project

### Prerequisites

Before you begin, ensure you have the following installed on your machine:

- [Python](https://www.python.org/) (Python 3.10)

### Clone the Project

To get started, clone the repository to your local machine:

```bash
git clone <repository-link>
```

### Navigate to the Project Directory

Change into the project directory:


#### Install LLM-API Dependencies

Navigate to the llm-api directory, create a virtual environment and install the necessary dependencies:

```bash
cd ../llm-api
python -m venv venv
source/Scripts/activate
pip install -r requirements.txt
```

#### Start LLM Server

In one terminal window, navigate to the llm-api directory and run:

```bash
cd llm-api
python -m fastapi run main.py -p 8000
```






## pseudocode-check sample: 
{
  "question": "Check whether a number is an Armstrong number or not",
  "pseudocode": "number = 153\nsum = 0\ntemp = number\nwhile temp > 0:\n    digit = temp % 10\n    sum = sum + digit ** 3\n    temp = temp // 10\nif sum == number:\n    print('Armstrong number')\nelse:\n    print('Not an Armstrong number')"
}


## code check sample:
{
  "question": "How can I implement a class hierarchy in Python where a base class handles reading from a file and a derived class processes the data to compute statistics like mean and median?",
  "code": "import statistics\n\nclass FileReader:\n    def __init__(self, filename):\n        self.filename = filename\n\n    def read_data(self):\n        with open(self.filename, 'r') as file:\n            return [float(line.strip()) for line in file if line.strip()]\n\nclass DataAnalyzer(FileReader):\n    def compute_statistics(self):\n        data = self.read_data()\n        return {\n            'mean': statistics.mean(data),\n            'median': statistics.median(data)\n        }\n\n# Example usage:\n# analyzer = DataAnalyzer('data.txt')\n# stats = analyzer.compute_statistics()\n# print(stats)",
  "language": "Python"
}
