from enum import Enum
import json
import logging
import os
from typing import List, Tuple, Optional
from dotenv import load_dotenv
from fastapi import FastAPI, status
from ollama import Client
from pydantic import BaseModel, Field
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import requests
import re

from fastapi import FastAPI, UploadFile, File, HTTPException, Form, Query
from sqlalchemy import (
    create_engine, Table, Column, Integer, String, Float, MetaData, text, select, inspect
)
import pandas as pd
from io import BytesIO
import re
import requests

load_dotenv()

app = FastAPI()

# -------------------------------
# ✅ CORS Configuration
# -------------------------------

origins = os.getenv("CORS_ORIGINS", "").split(",")
# print("Allowed CORS Origins : ", origins)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------
# ✅ Database Configuration
# -------------------------------

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")

if not all([DB_USER, DB_PASS, DB_HOST, DB_NAME]):
    raise ValueError("Missing required database environment variables: DB_USER, DB_PASS, DB_HOST, DB_NAME")

default_engine = create_engine(f"postgresql+psycopg2://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/postgres")
with default_engine.connect() as conn:
    conn.execute(text("COMMIT"))
    result = conn.execute(text(f"SELECT 1 FROM pg_database WHERE datname = '{DB_NAME}'"))
    if not result.scalar():
        conn.execute(text(f"CREATE DATABASE {DB_NAME}"))
    conn.commit()

engine = create_engine(f"postgresql+psycopg2://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
metadata = MetaData()

# -------------------------------
# ✅ Create Batch Table
# -------------------------------
batch_table = Table(
    "batch_name", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String(50), unique=True, nullable=False)
)
metadata.create_all(engine)

# -------------------------------
# ✅ Pydantic Model
# -------------------------------
class Batch(BaseModel):
    name: str

# -------------------------------
# 🟩 Get All Batches
# -------------------------------
@app.get("/batches")
def get_batches():
    with engine.connect() as conn:
        result = conn.execute(text("SELECT name FROM batch_name ORDER BY id ASC")).fetchall()
        return [r[0] for r in result]

# -------------------------------
# 🟦 Add New Batch
# -------------------------------
@app.post("/batches")
def add_batch(batch: Batch):
    # Validate format: must start with 'Batch_' and end with a number
    if not re.match(r"^Batch_\d+$", batch.name):
        raise HTTPException(status_code=400, detail="Invalid batch format. Use format like Batch_45")

    with engine.begin() as conn:
        exists = conn.execute(text("SELECT 1 FROM batch_name WHERE name = :name"), {"name": batch.name}).fetchone()
        if exists:
            raise HTTPException(status_code=400, detail="Batch already exists")
        conn.execute(text("INSERT INTO batch_name (name) VALUES (:name)"), {"name": batch.name})
    return {"message": f"{batch.name} added successfully"}

# -------------------------------
# 🟥 Delete Batch
# -------------------------------
@app.delete("/batches/{batch_name}")
def delete_batch(batch_name: str):
    with engine.begin() as conn:
        deleted = conn.execute(text("DELETE FROM batch_name WHERE name = :name"), {"name": batch_name})
        if deleted.rowcount == 0:
            raise HTTPException(status_code=404, detail="Batch not found")
    return {"message": f"{batch_name} deleted successfully"}

# -------------------------------
# Curriculum Logic (Your Existing Code)
# -------------------------------
SESSION_HOUR_THRESHOLD = 3
TOTAL_HOUR_THRESHOLD = 8

def get_batch_table_name(batch: str) -> str:
    if not batch or not isinstance(batch, str):
        raise ValueError("Invalid batch name")
    cleaned = re.sub(r'\W+', '_', batch.strip().lower())
    return f"curriculum_{cleaned}"

def get_or_create_batch_table(batch: str) -> Table:
    table_name = get_batch_table_name(batch)
    inspector = inspect(engine)
    if table_name not in inspector.get_table_names():
        table = Table(
            table_name, metadata,
            Column("id", Integer, primary_key=True),
            Column("sheet_name", String(50)),
            Column("topic", String(255)),
            Column("session_hour", Float),
            Column("lab_hour", Float),
            Column("total_hours", Float)
        )
        metadata.create_all(engine, tables=[table])
    else:
        table = Table(table_name, metadata, autoload_with=engine)
    return table

def validate_and_clean_dataframe(df: pd.DataFrame, sheet: str) -> pd.DataFrame:
    required_cols = ["Topics", "Session Hour", "Lab Hour", "Total Hours"]

    # Clean column names and data
    df.columns = df.columns.str.strip()
    df = df.where(pd.notnull(df), None)
    if not all(col in df.columns for col in required_cols):
        raise HTTPException(status_code=400, detail=f"Missing columns in '{sheet}'")
    if df[required_cols].isnull().any().any():
        raise HTTPException(status_code=400, detail=f"Some rows in '{sheet}' have missing values.")
    for col in ["Session Hour", "Lab Hour", "Total Hours"]:
        numeric_series = pd.to_numeric(df[col], errors="coerce")
        if not numeric_series.notnull().all():
            raise HTTPException(status_code=400, detail=f"Invalid numeric data in column '{col}'")
        df[col] = numeric_series.astype(float)
    for _, row in df.iterrows():
        if row["Session Hour"] > SESSION_HOUR_THRESHOLD or row["Total Hours"] > TOTAL_HOUR_THRESHOLD:
            raise HTTPException(status_code=400, detail=f"Threshold exceeded in topic {row['Topics']}")
        if round(row["Session Hour"] + row["Lab Hour"], 2) != round(row["Total Hours"], 2):
            raise HTTPException(status_code=400, detail=f"Mismatch in total hours for topic {row['Topics']}")
    return df

@app.post("/upload/")
async def upload_curriculum(file: UploadFile = File(...), batch: str = Form(...)):
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Upload only Excel files")
    curriculum_table = get_or_create_batch_table(batch)
    content = await file.read()
    excel_data = pd.ExcelFile(BytesIO(content))
    target_sheets = [s for s in excel_data.sheet_names if s in ["Python", "Java"]]
    if not target_sheets:
        raise HTTPException(status_code=400, detail="No 'Python' or 'Java' sheets found.")
    inserted_count = updated_count = skipped_count = 0
    with engine.begin() as conn:
        for sheet in target_sheets:
            df = validate_and_clean_dataframe(excel_data.parse(sheet), sheet)

            for _, row in df.iterrows():
                topic = str(row["Topics"]).strip()
                session_hr = float(row["Session Hour"])
                lab_hr = float(row["Lab Hour"])
                total_hr = float(row["Total Hours"])
                existing = conn.execute(
                    select(curriculum_table).where(
                        (curriculum_table.c.sheet_name == sheet) &
                        (curriculum_table.c.topic == topic)
                    )
                ).fetchone()
                if existing:
                    same_data = (
                        float(existing.session_hour) == session_hr and
                        float(existing.lab_hour) == lab_hr and
                        float(existing.total_hours) == total_hr
                    )    
                    if same_data:
                        skipped_count += 1
                    else:
                        conn.execute(
                            curriculum_table.update()
                            .where(
                                (curriculum_table.c.sheet_name == sheet) &
                                (curriculum_table.c.topic == topic)
                            )
                            .values(session_hour=session_hr, lab_hour=lab_hr, total_hours=total_hr)
                        )
                        updated_count += 1
                else:
                    conn.execute(curriculum_table.insert().values(
                        sheet_name=sheet, topic=topic,
                        session_hour=session_hr, lab_hour=lab_hr, total_hours=total_hr
                    ))
                    inserted_count += 1
    return {
        "message": f"✅ File processed successfully for {batch}",
        "inserted": inserted_count,
        "updated": updated_count,
        "skipped": skipped_count
    }

# ------------------------
# Analysis APIs
# ------------------------

@app.get("/api/languages")
def get_languages():
    """Return available languages (sheet names)."""
    return ["Python", "Java"]


@app.get("/api/topics")
def get_topics(language: str = Query(...), batch: str = Query(...)):
    """Return topics for a specific language and batch."""
    table_name = get_batch_table_name(batch)
    inspector = inspect(engine)
    if table_name not in inspector.get_table_names():
        raise HTTPException(status_code=404, detail=f"No data found for batch {batch}")

    table = Table(table_name, metadata, autoload_with=engine)
    with engine.connect() as conn:
        result = conn.execute(
            select(table.c.topic)
            .where(table.c.sheet_name == language)
            .order_by(table.c.topic.asc())
        ).fetchall()

    return [r[0] for r in result]


@app.get("/api/chart-data")
def get_chart_data(language: str = Query(...), batch: str = Query(...)):
    """Return topic-wise total hours for a given language & batch."""
    table_name = get_batch_table_name(batch)
    inspector = inspect(engine)
    if table_name not in inspector.get_table_names():
        raise HTTPException(status_code=404, detail=f"No data found for batch {batch}")

    table = Table(table_name, metadata, autoload_with=engine)
    with engine.connect() as conn:
        result = conn.execute(
            select(
                table.c.topic,
                table.c.total_hours
            ).where(table.c.sheet_name == language)
        ).fetchall()

    data = [{"topic": r.topic, "hours_spent": r.total_hours} for r in result]
    return data


@app.get("/compare-analytics")
def compare_analytics():
    try:
        # Load URL from .env file
        external_url = os.getenv("URL")
        if not external_url:
            raise HTTPException(status_code=500, detail="URL not found in environment variables")

        # Fetch data from external analytics API
        response = requests.get(external_url)
        response.raise_for_status()
        data = response.json()

        # Extract required fields & convert minutes → hours
        cleaned_data = []
        for item in data:
            java_hours = round(item.get("avgJavaTime", 0) / 3600 , 2)
            python_hours = round(item.get("avgPythonTime", 0) / 3600, 2)
            total_hours = round(java_hours + python_hours, 2)  # Only Java + Python

            cleaned_data.append({
                "mainTopicTitle": item.get("mainTopicTitle", "Unknown"),
                "avgJavaTime": java_hours,
                "avgPythonTime": python_hours,
                "avgTotalTime": total_hours
            })

        return {"message": "Data fetched successfully", "data": cleaned_data}

    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Error fetching external data: {e}")


@app.get("/")
def root():
    return {"message": "🚀 Curriculum API with batch persistence running successfully"}


logging.basicConfig(level=logging.DEBUG)

load_dotenv()

base_url = os.environ.get("BASE_URL")

if not base_url:
    raise "Environment variable not set"

client = Client(host=os.environ.get("BASE_URL"))


class Option(BaseModel):
    id: int
    value: str


class Quiz(BaseModel):
    id: int
    question: str
    options: Tuple[Option, Option, Option, Option]
    correct_option_id: int
    explanation: str = Field(
        description="Explaination of the quiz in markdown format with heading like h1, h2 etc",
    )


class DifficultyEnum(str, Enum):
    ALL = "all"
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class JavaPythonQuizes(BaseModel):
    quizes: List[Quiz]
    difficulty: DifficultyEnum
    length: int


class JavaPythonQuizBody(BaseModel):
    prompt: str
    difficulty: DifficultyEnum = DifficultyEnum.EASY
    length: int = 5
    language: str


# class Quizes(BaseModel):
#     track: str = Field(
#         "Url safe category of the quiz (lowercase, hyphen-seperated). For example. angular, react, react-vs-angular"
#     )
#     topic: str = Field(
#         "Url safe topic for the track (lowercase, hyphen-seperated). For example. state-management, routing, event-handling"
#     )
#     difficulty: DifficultyEnum
#     quizes: List[Quiz]
#     length: int


class JavaPythonCodeExample(BaseModel):
    java: str
    python: str
    javascript : str
    typescript : str #Tuesday


class JavaPythonCodeDifferenceExplaination(BaseModel):
    java: str
    python: str
    javascript : str
    typescript : str #Tuesday




class JavaPythonSubTopic(BaseModel):
    name: str
    explaination: str
    codeExample: JavaPythonCodeExample
    codeDifferenceExplaination: JavaPythonCodeDifferenceExplaination


class JavaPythonContent(BaseModel):
    topic: str
    explaination: str
    subtopic: List[JavaPythonSubTopic]


class LLMBody(BaseModel):
    prompt: str


class QuizBody(BaseModel):
    track: str
    topic: str
    difficulty: DifficultyEnum = DifficultyEnum.EASY
    length: int = 5
    prompt: str = "None"


def check_ollama_running():
    print("check_ollama_running")
    try:
        response = requests.get(base_url, timeout=5)
        print(response.text)
        if "Ollama is running" in response.text:
            print("returned true")
            return True
        else:
            return False
    except:
        return False


class TrackEnum(str, Enum):
    ANGULAR = "angular"
    REACT = "react"
    REACTVSANGULAR = "react-vs-angular"
    SPRINGBOOT="springboot"
    EXPRESS="express"
    SPRINGBOOTVSEXPRESS="springboot-vs-express"
    MYSQL="mysql"
    MONGODB="mongodb"
    MQSQLVSMONGODB="mysql-vs-mongodb"


class ReactAngularMetadata(BaseModel):
    track: TrackEnum
    title: str = Field(description="Title of the content in plain text format")
    slug: str = Field(
        description="Url-friendly version of the title (lowercase, hyphen-seperated). It should not contain any `/`. eg. routing, state-management"
    )
    description: str = Field(
        description="A short description of the content. Do not include phrases like `In this course`, `In this tutorial`, `we will cover`, `you will learn`, or any first-person or second-person language. eg. Understanding React Router DOM, navigation and routing, Understanding the state, it's types and it's functionality"
    )


class ReactAngularContent(ReactAngularMetadata):
    content: str


class LanguageEnum(str, Enum):
    python = "python"
    java = "java"
    javascript="javascript"
    typescript="typescript" #tuesday

class PseudocodeRequest(BaseModel):
    question: str = Field(..., description="The coding problem statement.")
    pseudocode: str = Field(..., description="The pseudocode written by the user.")

class CodeRequest(BaseModel):
    question: str = Field(..., description="The coding problem statement.")
    code: str = Field(..., description="The actual code implementation.")
    language: LanguageEnum = Field(..., description="Programming language focus.")

class AlgorithmRequest(BaseModel):
    question: str = Field(..., description="The coding problem statement.")
    algorithm: str = Field(..., description="The high-level algorithm steps written by the user.")






#-----------------------------------------------------------------------------------------------------------
#--------------------------------------------feedback-------------------------------------------------------
# THE FEEDBACKK NEW CLASSES
# ----------------------------------------------------------------------------------------------------------
class FeedbackRequest(BaseModel):
    question: Optional[str] = None
    user_algorithm: Optional[str] = None
    user_pseudocode: Optional[str] = None
    user_code: Optional[str] = None
    code_language: Optional[LanguageEnum] = None

# app = FastAPI()
# origins = ["*"]
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )


@app.post("/quiz-java-python")
def gen_quiz_java_python(body: JavaPythonQuizBody):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )

    prompt = body.prompt
    difficulty = body.difficulty
    length = body.length
    resp = client.chat(
        messages=[
            {
                "role": "user",
                "content": f"Generate quiz for java vs python vs javascript vs typescript study. topic = {prompt}, difficulty={difficulty}, length={length}",
            }
        ],
        model="mistral:latest",
        format=JavaPythonQuizes.model_json_schema(),
    )
    print(resp.message.content)
    # quizes = Quizes.model_validate(resp.message.content)
    quizes = json.loads(resp.message.content)
    return quizes

#----------------------------MCQ GENERATION----------------------------------------------------------
# @app.post("/quiz-generation")
# def gen_quiz_java_python(body: JavaPythonQuizBody):
#     if not check_ollama_running():
#         return JSONResponse(
#             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             content={"message": "Ollama server seems to be down"},
#         )

#     prompt = body.prompt
#     difficulty = body.difficulty
#     length = body.length

#     resp = client.chat(
#         messages=[
#             {
#                 "role": "user",
#                 "content": f"""
# You are an expert **programming instructor** and **assessment designer**.

# Your task is to generate **multiple-choice questions (MCQs)** on the topic: "{prompt}"

# ### INPUT:
# total_questions: {length}
# difficulty: "{difficulty}"  // One of: Easy | Medium | Hard | All
# supported_languages: ["Python", "Java", "JavaScript", "TypeScript"]

# ### OUTPUT FORMAT:
# Return a valid **pure JSON array** of exactly {length} items.
# Each item must have:
# "question": string  
#   - It **must include a short, properly formatted code snippet** inside triple backticks (
# )  
#   - Example:  
#     "question": "What will be the output of the following code?\\n
# java\\nint a = 10; int b = 20; System.out.println(a + b);\\n```"
# "options": list of 4 strings
# "answer": integer (index of correct option, 0–3)
# "language": one of ["Python", "Java", "JavaScript", "TypeScript"]

# ⚠️ **Do not include explanations, markdown headings, or any text outside the JSON array.**

# ### DIFFICULTY LOGIC:
# Easy → All easy-level questions  
# Medium → All medium-level questions  
# Hard → All tricky, code-heavy, or debug-based questions  
# All → Balanced mix:
#   - 4 Easy, 4 Medium, 2 Hard  
#   - Language mix: 3 Python, 3 Java, 2 JavaScript, 2 TypeScript

# ### DESIGN RULES:
# 1. **At least 70% of questions must include code snippets.**
# 2. Hard questions should involve tricky logic, edge cases, or non-obvious results.
# 3. Code snippets ≤ 6 lines and syntactically correct.
# 4. Avoid duplication or vague rewording.
# 5. Only **one correct answer** per question.
# 6. Code must be placed inside **triple backticks** followed by the language name (e.g.,
# java).

# ### FINAL OUTPUT EXAMPLE:
# [
#   {{
#     "question": "What will be printed by the following code?\\n
# python\\nx = 5\\nprint(x ** 2)\\n```",
#     "options": ["5", "10", "25", "Error"],
#     "answer": 2,
#     "language": "Python"
#   }},
#   ...
# ]
# """
#             }
#         ],
#         model="mistral:latest",
#         format=JavaPythonQuizes.model_json_schema(),
#     )

#     quizes = json.loads(resp.message.content)
#     return quizes

@app.post("/quiz-generation")
def gen_quiz_java_python(body: JavaPythonQuizBody):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )

    prompt = body.prompt
    difficulty = body.difficulty
    length = body.length
    language = body.language  # ✅ New field from request body

    # Validate language input
    supported_languages = ["Python", "Java", "JavaScript", "TypeScript"]
    if language not in supported_languages:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"message": f"Invalid language. Supported: {supported_languages}"},
        )

    resp = client.chat(
        messages=[
            {
                "role": "user",
                "content": f"""
You are an expert **programming instructor** and **assessment designer**.

Your task is to generate **multiple-choice questions (MCQs)** on the topic: "{prompt}"

### INPUT:
total_questions: {length}
difficulty: "{difficulty}"  // One of: Easy | Medium | Hard | All
language: "{language}"  // ✅ Only this language should be used

### OUTPUT FORMAT:
Return a valid **pure JSON array** of exactly {length} items.
Each item must have:
"question": string  
  - It **must include a short, properly formatted code snippet** inside triple backticks (
)  
  - Example:  
    "question": "What will be the output of the following code?\\n
{language.lower()}\\nint a = 10; int b = 20; System.out.println(a + b);\\n```"
"options": list of 4 strings
"answer": integer (index of correct option, 0–3)
"language": "{language}"

⚠️ **Do not include explanations, markdown headings, or any text outside the JSON array.**

### DIFFICULTY LOGIC:
Easy → All easy-level questions  
Medium → All medium-level questions  
Hard → All tricky, code-heavy, or debug-based questions  
All → Balanced mix but still in "{language}" only

### DESIGN RULES:
1. **At least 70% of questions must include code snippets.**
2. Hard questions should involve tricky logic, edge cases, or non-obvious results.
3. Code snippets ≤ 6 lines and syntactically correct.
4. Avoid duplication or vague rewording.
5. Only **one correct answer** per question.
6. Code must be placed inside **triple backticks** followed by the language name (e.g.,
{language.lower()}).

### FINAL OUTPUT EXAMPLE:
[
  {{
    "question": "What will be printed by the following code?\\n
{language.lower()}\\nx = 5\\nprint(x ** 2)\\n```",
    "options": ["5", "10", "25", "Error"],
    "answer": 2,
    "language": "{language}"
  }},
  ...
]
"""
            }
        ],
        model="mistral:latest",
        format=JavaPythonQuizes.model_json_schema(),
    )

    quizes = json.loads(resp.message.content)
    return quizes

class ScenerioSample(BaseModel):
    input: str = Field(
        description="Sample input for the problem statement. eg. 5\n1 1 2 2 4"
    )
    output: str = Field(description="Sample output for the problem statement. eg. 2")
    explanation: str = Field(
        description="Explanation for the sample output. eg. In this example Songs of singer 1 and 2 appear 2 times(which is max) in this playlist. Therefore the answer is 2"
    )


class ScenerioTestcase(BaseModel):
    input: str = Field(description="Input for the testcases. eg.5\n 2 3 4 4 5")
    expectedOutput: str = Field(description="Expecte output for the testcase. eg. 1")


class JavaPythonScenerio(BaseModel):
    title: str = Field(description="Title for the problem")
    question: str = Field(
        description=f"""Detailed Problem statement for the question. eg. Bob has a playlist of N songs, each song has a singer associated with it (denoted by an integer)
Favourite singer of Bob is the one whose songs are the most on the playlist
Count the number of Favourite Singers of Bob
"""
    )
    constraints: str = Field(
        description="Constraints for the input. eg. 1 <= N <= 10^5"
    )
    inputDescription: str = Field(
        description="Text describing the input format for the question. eg. The first line contains an integer N (the number of songs in the playlist).\nThe second line contains N integers, where each integer represents the singer of each song."
    )
    outputDescription: str = Field(
        description="Text describing the output format for the solution. Output a single integer, which is the count of favourite singers."
    )
    samples: List[ScenerioSample]
    testcase: List[ScenerioTestcase]
    hints: str = List[str]
    algorithm: str
#---------------------------------NEW QUESTIONS--------------------------------------------------------------------------------

class JavaPythonScenerioBody(BaseModel):
    prompt: str
    difficulty: DifficultyEnum = DifficultyEnum.EASY


@app.post("/java-python-scenario")
def gen_java_python_scenerio(body: JavaPythonScenerioBody):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )
    prompt = body.prompt
    difficulty = body.difficulty
    resp = client.chat(
        messages=[
            {
                "role": "user",
                "content": f"""
You are a Subject Matter Expert and curriculum designer creating **scenario-based programming challenges**.

Your task is to generate **a JSON object** for a **real-world, intermediate-level programming problem** in **Java**, **Python**, **JavaScript**, or **TypeScript**, based on the given **topic** and **subtopic**.  
The problem must strongly relate to these concepts and test the learner’s logical thinking (like comparisons, loops, conditional flows, string handling, or data manipulation).

 **Inputs:**
- topic = {prompt}
- difficulty = {difficulty}

---

### Objective:
Create a **real-world scenario problem** that applies concepts from the given topic and subtopic. Avoid toy problems (like simple arithmetic). Be creative and ensure it requires actual reasoning.

---

###  Strict Output Format (JSON only):

{{
    "title": "...",
    "question": "...",
    "input_desc": "...",
    "output_desc": "...",
    "sample_input": "...",
    "sample_output": "...",
    "syntax_breakdown": "...",
    "hints": ["...", "..."],
    "testcases": [
        {{"input": "...", "expected_output": "..."}},
        {{"input": "...", "expected_output": "..."}}
    ],
    "solution": "...\n...\n...\n"
}}

---

###  Requirements:
- The problem **must clearly reflect the topic and subtopic** concepts.
- Must be **solvable in Java, Python, JavaScript, and TypeScript**.
- Must **require logical reasoning** (comparisons, loops, conditionals, or string operations).
- **Sample input/output** should be realistic and easy to understand.
- **Testcases** must be different from the sample input/output.
- **Hints** should gradually lead the learner toward the solution — each hint should add new insight, not repetition.
- **Solution** should be **pseudocode in Python style**, line-by-line, readable by students.
- Every JSON field must be **present**, **non-empty**, and the output must be **valid JSON only** — no text outside the object.

---

 **Extra Rules:**
- No generic or repeated problems.
- Keep the tone **educational yet engaging**, with a relatable context (daily life, technology, or problem-solving situations).
- The learner should gain **new conceptual understanding** from solving it — not just syntax recall.

Return **only the valid JSON object** — nothing else.
"""
            }
        ],
        model="mistral:latest",
        format=JavaPythonScenerio.model_json_schema(),
    )
    print(resp.message.content)
    # content = JavaPythonContent.model_validate(resp.message.content)
    content = json.loads(resp.message.content)
    return content

@app.post("/java-python-content")
def gen_java_python_content(body: LLMBody):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )
    prompt = body.prompt
    resp = client.chat(
        messages=[
            {
                "role": "user",
                "content": f"Generate content for java vs python vs javascript vs typescript comparative study. The explaination should be short and concise topic = {prompt}",
            }
        ],
        model="mistral:latest",
        format=JavaPythonContent.model_json_schema(),
    )
    print(resp.message.content)
    # content = JavaPythonContent.model_validate(resp.message.content)
    content = json.loads(resp.message.content)
    return content




class ReactAngularContentBody(LLMBody):
    track: TrackEnum


@app.post("/gen-react-angular-content")
def gen_angular_react_content(body: ReactAngularContentBody):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )
    prompt = body.prompt
    track = body.track
    resp_markdown = client.chat(
        messages=[
            {
                "role": "user",
                "content": f"Generate course content in Markdown Format with proper headings, tables and code blocks as required.  Do not include output other than markdown. Do not include `==` character as heading level 1, it's not valid markdown. Instead of using jsx, tsx or typescript in the markdown code block, just use javascript as it has more support for parsing. Do not give any table of contents. Do not include any internal or external link in the markdown. Do not give any other explanation. track = {track}, topic = {prompt}",
            }
        ],
        model="mistral:latest",
    )
    markdown = resp_markdown.message.content
    markdown_sanitized = "\n".join(
        [
            line
            for line in markdown.splitlines()
            if not line.strip().startswith("=") and not line.strip().endswith("=")
        ]
    )
    resp_metadata = client.chat(
        messages=[
            {
                "role": "user",
                "content": f"content=\n{resp_markdown.message.content}\n\ntrack={track}, topic={prompt}",
            }
        ],
        model="mistral:latest",
        format=ReactAngularMetadata.model_json_schema(),
    )

    # print(resp_metadata.message.content)
    metadata = ReactAngularMetadata.model_validate_json(resp_metadata.message.content)
    content_with_metadata = ReactAngularContent(
        track=metadata.track,
        title=metadata.title,
        slug=metadata.slug,
        description=metadata.description,
        content=markdown_sanitized,
    )

    return content_with_metadata


def query_ollama(prompt: str) -> str:
    logging.debug("Sending prompt to Ollama...")
    response = client.generate(model="gpt-oss:20b", prompt=prompt, stream=False)
    return response["response"]


def safe_json_loads(result: str):
    # Step 1: Remove code fences if present
    cleaned = result.strip()
    if cleaned.startswith("```"):
        parts = re.split(r"```(?:json)?", cleaned)
        cleaned = "".join(parts).strip()

    # Step 2: If it's a string containing escaped JSON, unescape it
    try:
        # Try parsing directly
        return json.loads(cleaned)
    except json.JSONDecodeError:
        try:
            # Try parsing as a string containing JSON
            unescaped = json.loads(cleaned)  # This turns the string into a raw JSON string
            return json.loads(unescaped)     # Now parse the actual JSON
        except Exception as e:
            logging.error(f"Double JSON parsing failed. Cleaned text: {cleaned}")
            raise ValueError(f"Invalid JSON from LLM: {e}")




#----------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------Akashh---------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------
@app.post("/check-pseudocode")
def check_pseudocode(payload: PseudocodeRequest):
    is_pseudocode_empty = not payload.pseudocode or not payload.pseudocode.strip()

    if is_pseudocode_empty:
        # Case 1: Empty pseudocode
        prompt_content = f"""
        You are a helpful algorithm and problem-solving assistant.
        The user has not provided any pseudocode for the following question.
        Your task is to give only a high-level idea, not pseudocode.
        Your task is to provide a high-level approach or a key idea to solve the problem, without giving the full pseudocode.
        Respond only with valid JSON. All keys and strings MUST use double quotes, NO single quotes.

        Respond ONLY with valid JSON using double quotes.

        Question:
        {payload.question}

        Output format:
        {{
          "valid": false,
          "feedback": "It seems you haven't entered any pseudocode yet. Here's an idea to get you started: [brief idea here]"
        }}
        """
    else:
        
        prompt_content = f"""
        You are an expert pseudocode evaluator.

        Question:
        {payload.question}

        User Input:
        {payload.pseudocode}

        Your tasks:
        1. Determine whether the user's input is:
           - a proper pseudocode (structured with IF, ELSE, FOR, WHILE, PRINT, etc.)
           - or just an algorithm (step list or plain English description).
        2. Respond ONLY with valid JSON. Use double quotes for all keys and values.
        3. Behaviors:
           - If the text is actually an algorithm, return:
             {{
               "valid": false,
               "feedback": "Your input looks more like an algorithm. Try converting it into pseudocode using structured commands such as INPUT, IF-ELSE, and PRINT."
             }}
           - If the pseudocode is logically correct, return:
             {{
               "valid": true,
               "feedback": "Great job! Your pseudocode is logically correct and well-structured."
             }}

        Strict rules for JSON output:
            1. Output JSON only (no markdown, no text outside JSON, no code fences).
            2. JSON must have exactly three keys: "valid", "issues" and "points".
            3. "valid" should be a boolean value, either the algorithm is correct or not.
            4. "issues" should be a JSON array of short, clear sentences describing conceptual errors (not syntax errors).
            5. Each issue should focus on one conceptual mistake only (such as missing step, incorrect order, or significant logical flaw).
            6. "points" should be a JSON array of short, clear improvement suggestions — one per array element.
            7. Feedback must address only the first fundamental conceptual error found.
            8. Responses must be strictly valid JSON (use double quotes for keys and string values).
            9. Do not include explanations, apologies, or any text outside the JSON.
        """

    try:
        result = query_ollama(prompt_content)
        parsed = safe_json_loads(result)
        return JSONResponse(content=parsed, status_code=status.HTTP_200_OK)
    except Exception as e:
        logging.error(f"Error in /check-pseudocode: {e}")
        return JSONResponse(
            content={"error": str(e), "raw_response": result if 'result' in locals() else None},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )    

@app.post("/check-code")
def check_code(payload: CodeRequest):

    is_code_empty = not payload.code or not payload.code.strip()

    if is_code_empty:
        prompt_content = f"""
        You are a helpful programming assistant.
        The user has not provided any code for the following problem.
        Your task is to provide a high-level approach or a key idea to solve the problem, specifically tailored to the `{payload.language}` language, without giving the full code.
        Respond only with valid JSON. All keys and strings MUST use double quotes, NO single quotes.

        Question:
        {payload.question}

        Language Focus: {payload.language}

        Your Task:
        Provide a concise "idea" or "approach" that helps solve this problem using `{payload.language}` concepts. Do NOT provide a full code solution.

        Strictly return JSON in this format:
        {{
          "valid": false,
          "feedback": "It seems you haven't entered any code yet. Here's an idea to get you started in {payload.language}: [Your high-level idea here]"
        }}
        """
    else:
        prompt_content = f"""
        You are a **strict code reviewer and compiler**.
        Analyze the following code for both **syntax and logic**.
        Don't be too harsh and check whether it is correct or close to correct.
        You are a JSON only generator. Always respond with valid JSON. Give property names properly enclosed in double quotes.

        Question:
        {payload.question}

        User's Code:
        {payload.code}

        Language: {payload.language}

        Your Tasks:
        1. Check if the code has:
           - **Syntax errors** (compilation issues, invalid constructs, indentation errors, braces).
           - **Logical errors** (wrong conditions, incorrect loop termination, misuse of data structures).
           - **Runtime risks** (infinite loops, division by zero, null references).
           - **Edge case handling** (empty inputs, large inputs, invalid inputs).

        2. If the user's code is **correct or acceptable**, return JSON:
           {{
             "valid": true,
             "feedback": "Your code is logically and syntactically sound for the most part. [Optional: Explain why it works, edge cases covered, and any minor optimization suggestions.]"
           }}

        3. If the user's code is **incorrect or has significant flaws**, return JSON:
           {{
             "valid": false,
             "error_line_number": "The line number where the first significant error occurs (if applicable, otherwise null)",
             "corrected_code_snippet": "A small, corrected code snippet for the first problematic part (e.g., 1-3 lines), do NOT provide the full corrected code.",
             "feedback": "Your code has issues. Here's feedback for the first significant error: [Explain the specific issue (syntax, logic, runtime, edge case) and how to fix THAT particular part]. Do NOT list all mistakes line by line. Only address the first significant error. Do NOT provide the full corrected code."
           }}

        Rules:
        1. Output ONLY a valid JSON object with keys in double quotes — no markdown, code fences, or extra text.
        2. The JSON must contain exactly three keys: "valid", "issues", and "points".
        3. "valid" must be a boolean indicating whether the CODE is logically and conceptually correct (not pseudocode or algorithm description).
        4. "issues" must be an array of short, clear sentences describing conceptual or logical problems in the code (not syntax errors).
        5. Each issue should focus on one conceptual mistake only, such as incorrect logic, wrong condition, or missing implementation detail.
        6. "points" must be an array of short, actionable improvement suggestions — one per array element.
        7. Only the first significant conceptual error should be reported; ignore minor ones until it is fixed.
        8. If incorrect, include ONLY a small corrected code snippet for the first problematic part, not the full corrected code.
        9. Even inefficient logic or poor variable names should be flagged if they significantly affect readability or performance.
        10. If the provided code is empty, this analysis path should not be triggered.
        11. Always ensure strict JSON validity — all keys and string values must use double quotes, and no text or formatting outside the JSON.
        12. The analysis should focus strictly on executable code behavior — not on algorithm design or pseudocode intent.
        """

    try:
        result = query_ollama(prompt_content) # Use prompt_content here
        parsed = safe_json_loads(result)
        return JSONResponse(content=parsed, status_code=status.HTTP_200_OK)
    except Exception as e:
        logging.error(f"Error in /check-code: {e}")
        return JSONResponse(
            content={"error": str(e), "raw_response": result if 'result' in locals() else None},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
#  ------------------------------
# Endpoint 3: Check Algorithm
# ------------------------------
@app.post("/check-algorithm")
def check_algorithm(payload: AlgorithmRequest):

    is_algorithm_empty = not payload.algorithm or not payload.algorithm.strip()

    if is_algorithm_empty:
        prompt_content = f"""
        You are a helpful algorithm design assistant.
        The user has not provided any algorithm steps for the following problem.
        Your task is to provide a high-level conceptual approach or a key strategy to solve the problem, without detailing step-by-step implementation.
        Respond only with valid JSON. All keys and strings MUST use double quotes, NO single quotes.

        Question:
        {payload.question}

        Your Task:
        Provide a concise "idea" or "conceptual strategy" that helps solve this problem. Do NOT provide detailed steps or full pseudocode.

        Strictly return JSON in this format:
        {{
          "valid": false,
          "feedback": "It seems you haven't outlined your algorithm yet. Here's a high-level conceptual strategy to consider: [Your high-level idea here]"
        }}
        """
    else:
        prompt_content = f"""
        You are a **highly critical and precise senior algorithm reviewer**.
        Your sole purpose is to evaluate the provided high-level algorithm steps for **absolute logical soundness and complete correctness**.
        Any conceptual flaw, missing critical step, or logical inconsistency, no matter how minor, renders the algorithm invalid.
        You are a JSON only generator. Always respond with valid JSON. Give property names properly enclosed in double quotes.

        Question:
        {payload.question}

        User's Algorithm Steps:
        {payload.algorithm}

        Your Tasks:
        1. Rigorously check each algorithm step for:
           - **Absolute Conceptual Correctness**: Every step must logically contribute to a correct solution.
           - **Completeness**: No critical steps can be missing or implicitly assumed.
           - **Order of Operations**: Steps must be in the exact, correct sequence for the algorithm to function.
           - **Efficiency (if applicable)**: If a significantly more optimal and standard approach is completely overlooked or implemented poorly, it counts as a flaw.

        2. If the user's algorithm is **100% conceptually correct and complete**, return JSON strictly in this format:
           {{
             "valid": true,
             "feedback": "Your algorithm is conceptually sound and complete. It correctly addresses the problem."
           }}

         Strict rules for JSON output:
            1. Output JSON only (no markdown, no text outside JSON, no code fences).
            2. JSON must have exactly three keys: "valid", "issues" and "points".
            3. "valid" should be a boolean value, either the algorithm is correct or not.
            4. "issues" should be a JSON array of short, clear sentences describing conceptual errors (not syntax errors).
            5. Each issue should focus on one conceptual mistake only (such as missing step, incorrect order, or significant logical flaw).
            6. "points" should be a JSON array of short, clear improvement suggestions — one per array element.
            7. Feedback must address only the first fundamental conceptual error found.
            8. Responses must be strictly valid JSON (use double quotes for keys and string values).
            9. Do not include explanations, apologies, or any text outside the JSON.

       
        """

    try:
        result = query_ollama(prompt_content)
        parsed = safe_json_loads(result)
        return JSONResponse(content=parsed, status_code=status.HTTP_200_OK)
    except Exception as e:
        logging.error(f"Error in /check-algorithm: {e}")
        return JSONResponse(
            content={"error": str(e), "raw_response": result if 'result' in locals() else None},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
#=============================================<< fEEDBACK >>========================================================== 
@app.post("/generate-overall-feedback")
def generate_overall_feedback(payload: FeedbackRequest):
    """
    Accepts:
      - question: Coding problem statement
      - user_algorithm: User's algorithm steps
      - user_pseudocode: User's submitted pseudocode
      - user_code: User's code
      - code_language: Language (e.g. python, java...)

    Returns AI feedback with concise, simple review, improved code, and action steps.
    """
    prompt = f"""
You are a senior software engineering mentor.

The user attempted the SAME problem in MULTIPLE programming languages.
You must evaluate:
1. Algorithm understanding (language-agnostic)
2. Pseudocode clarity
3. Code quality SEPARATELY for each language
4. Compare attempts and give an OVERALL summary

Problem Statement:
{payload.question}

User Algorithm:
{payload.user_algorithm or "Not submitted"}

User Pseudocode:
{payload.user_pseudocode or "Not submitted"}

User Code Attempts:
{payload.attempts}

Rules:
- Do NOT mix languages
- Feedback for each language must respect its conventions
- Improved code must stay in the SAME language
- Use simple, beginner-friendly language

Respond ONLY as strict JSON:

{{
  "algorithm_feedback": [...],
  "pseudocode_feedback": [...],
  "language_feedback": {{
    "python": {{
      "code_feedback": [...],
      "better_code": "..."
    }},
    "java": {{
      "code_feedback": [...],
      "better_code": "..."
    }}
  }},
  "overall_summary": "...",
  "actions": ["...", "..."]
}}
"""

    try:
        result = query_ollama(prompt)
        parsed = safe_json_loads(result)
        return JSONResponse(content=parsed, status_code=status.HTTP_200_OK)
    except Exception as e:
        logging.error(f"Feedback error: {e}")
        return JSONResponse(
            content={
                "feedback_report": f"⚠️ Error: Could not generate feedback ({e})",
                "better_code": "",
                "actions": []
            },
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

# Optionally: root health check
@app.get("/")
def read_root():
    return {"message": "Ollama LLM FastAPI Feedback API is running."}
### <<< ---------- AISWARYA USERREPORT ------------------------------ >>>
class AttemptDetail(BaseModel):
    language: LanguageEnum
    code: str
    time_taken: int 
    no_test_cases_passed: int = Field(alias="is_test_cases_passed") 
    total_no_test_cases: int

class SMEAssessment(BaseModel):
    language: LanguageEnum
    code_match_score: int
    performance_score: int
    performance_notes: str

class SMEReport(BaseModel):
    algorithm_pseudocode_match_summary: str = Field(
        ...,
        description="A concise summary and feedback (2-3 sentences) on the user's algorithm and pseudocode logic, noting its correctness and quality."
    )
    optimized_solution_exists: bool = Field(
        ...,
        description="True if a solution with better time complexity (e.g., O(log n) instead of O(n)) exists for this problem, otherwise False. For this problem, the optimal is O(n)."
    )
    language_performances: List[SMEAssessment]

class SMEReportRequest(BaseModel):
    question: str
    user_algorithm: str
    user_pseudocode: str
    attempts: List[AttemptDetail]


@app.post("/generate-sme-report", response_model=SMEReport)
def generate_sme_report(payload: SMEReportRequest):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )

    attempts_str = json.dumps([a.model_dump(by_alias=True) for a in payload.attempts], indent=2)

    prompt = f"""
    You are a **Subject Matter Expert (SME) Report Generator**. Your task is to analyze a user's entire problem-solving process and generate a detailed, structured report for an administrator.

    **Problem Statement:**
    {payload.question}

    **User's Algorithm (Conceptual Plan):**
    {payload.user_algorithm}

    **User's Pseudocode (Detailed Plan):**
    {payload.user_pseudocode}

    **User's Coding Attempts and Results (for scoring):**
    {attempts_str}

    **Your Tasks:**
    1.  **Planning Analysis:**
        * Provide a **concise summary and feedback** on the Algorithm and Pseudocode combined (2-3 sentences).
        * Determine if a **more optimized solution exists** (e.g., $O(n \log n)$ or better) compared to the current plan. For this specific 'adjacent product' problem, the user's iterative $O(n)$ approach is optimal, so the answer should be **False**.

    2.  **Code Assessment (for EACH attempt):**
        * **Code Match Score (0-100):** Assess how well the submitted code adheres to the logic described in the user's plan.
        * **Performance Score (0-100):** Evaluate based on **Test Cases Passed** (high weight) and **Time Taken** (penalty for long times like >30 mins).
        * **Performance Notes:** Provide a concise analysis (5-7 sentences) for the SME, linking the quality of the initial plan to the outcome of the code.

    **STRICT Output Format:**
    Generate a JSON object that strictly adheres to the Pydantic schema structure provided below. Ensure the planning_analysis adheres to the requested focus.

    Pydantic Schema for the required output:
    {SMEReport.model_json_schema()}

    **Constraint:** Return ONLY the valid JSON object. Do not include any extra text, commentary, or markdown fences (
json).
    """

    try:
        resp = client.chat(
            messages=[{"role": "user", "content": prompt}],
            model="mistral:latest",
            format=SMEReport.model_json_schema(),
        )
        report_data = json.loads(resp.message.content)

        return SMEReport(**report_data)

    except Exception as e:
        logging.error(f"Error in /generate-sme-report: {e}")
        error_context = {"error": str(e), "raw_response": resp.message.content if 'resp' in locals() else None}
        return JSONResponse(
            content=error_context,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


### <<<------------- AISWARYA USERREPORT! --------------------------------------------->>>

### <<< ------------ AISWARYA SME OVERALL REPORT -------------------------------------- >>>

logging.basicConfig(level=logging.INFO)

class LanguageEnum(str, Enum):
    python = "python"
    java = "java"
    javascript = "javascript"
    typescript = "typescript"

class AttemptDetail(BaseModel):
    """Details of a single attempt at a question."""
    language: LanguageEnum
    code: str
    time_taken: int 


class PastSession(BaseModel):
    """Encapsulates one full user problem-solving session."""
    question: str
    difficulty: str = Field(..., description="The difficulty level of the question, e.g., 'Easy', 'Medium', 'Hard'.")
    attempts: List[AttemptDetail]

class MultiSessionReportRequest(BaseModel):
    """The full history of user sessions submitted for analysis."""
    sessions: List[PastSession] = Field(..., alias="list_of_questions", description="A list of all past user problem-solving sessions.")


class SMELanguageSummary(BaseModel):
    """Summary statistics and expert feedback for a single programming language."""
    language: str 
    performance_score: int = Field(..., description="Average performance score across all attempts for this language (0-100).")
    avg_difficulty_mastered: str = Field(..., description="The calculated average difficulty level mastered in this language (e.g., 'Easy-Intermediate', 'Hard').")
    total_attempts: int = Field(..., description="Total number of attempts made in this language.")
    strengths: List[str] = Field(..., description="Specific, detailed technical strengths demonstrated in this language (e.g., 'Clean Pythonic syntax', 'Effective concurrent state management').")
    areas_for_improvement: List[str] = Field(..., description="Key technical areas needing immediate attention in this language (e.g., 'Handling boundary conditions in lists', 'Refactoring redundant Java I/O code').")
    weak_topics:  List[str] = Field(..., description="Topics needing attention or lacking knowledge after going through the codes(e.g., 'Recursion', 'Linked Lists', 'Sorting').")

class SMEMultiSessionReport(BaseModel):
    """The final, aggregated SME report, providing technical depth and stream suggestions."""
    overall_performance_score: int = Field(
        ...,
        description="A single score (0-100) representing the user's cumulative performance across all languages and sessions."
    )
    suggested_streams: List[str] = Field(
        ...,
        description="A list of suggested technical career streams based on performance, problem type, and language preference."
    )
    language_summary: List[SMELanguageSummary]
    general_recommendations: str = Field(
        ...,
        description="A detailed paragraph summarizing the key findings, focusing on core technical aptitude and rationale for stream suggestions."
    )
    summary: str = Field(
        ...,
        description="A friendly, encouraging, and easy-to-read summary of the user's overall performance, strengths, and most actionable next steps, written directly to the user."
    )

@app.post("/generate-sme-multi-session-report", response_model=SMEMultiSessionReport)
def generate_sme_multi_session_report(payload: MultiSessionReportRequest):
    """
    Generates a comprehensive, subject-focused report combining all user history
    with detailed technical strengths and weaknesses for each language.
    """
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )

    history_json = json.dumps([s.model_dump(by_alias=True) for s in payload.sessions], indent=2)

    prompt = f"""
    You are a **Multi-Session Subject Matter Expert (SME) Analyst**. Your task is to analyze the user's complete coding history, aggregate the results by programming language, and provide a deep technical report suitable for an SME or technical lead.

    **Input Data (All Past User Sessions):**
    {history_json}

    **Analysis Requirements (Follow these steps precisely):**

    1.  **Calculate Language Performance Metrics:**
        * For each unique language: Calculate the **Average Performance Score** (0-100). This should be based on accuracy and include a **time penalty** (e.g., -5 points) for any attempt taking longer than 30 minutes (1800 seconds).
        * Determine the **Average Difficulty Mastered** based on successful attempts ('Easy', 'Medium', 'Hard').
        * Calculate total_attempts.

    2.  **Qualitative Technical Assessment (CRITICAL):**
        * For each language, analyze the types of problems attempted (DSA, concurrency, data structures) and the success/failure patterns to generate **3 specific technical strengths** (e.g., 'Recursion accuracy', 'Lock-free algorithm design') and **3 specific technical areas for improvement** (e.g., 'Array boundary checks', 'Efficient hash map usage').

    3.  **Overall Scoring and Stream Suggestion:**
        * Calculate the final overall_performance_score.
        * Suggest **2-3 career streams** based on the user's best-performing language, highest accuracy, and the types of problems they excelled at.

    4.  **General Recommendations:**
        * Write a detailed summary paragraph (3-5 sentences) that ties the technical strengths directly to the stream suggestions and justifies the areas for improvement.

    **STRICT Output Format:**
    Generate a JSON object that strictly adheres to the provided SMEMultiSessionReport Pydantic schema structure.

    Pydantic Schema for the required output:
    {SMEMultiSessionReport.model_json_schema()}

    **Constraint:** Return ONLY the valid JSON object. Do not include any extra text, commentary, or markdown fences.
    """

    try:
        resp = client.chat(
            messages=[{"role": "user", "content": prompt}],
            model="mistral:latest",
            format=SMEMultiSessionReport.model_json_schema(),
        )
        report_data = json.loads(resp.message.content)
        return SMEMultiSessionReport(**report_data)

    except Exception as e:
        logging.error(f"Error in /generate-sme-multi-session-report: {e}")
        return JSONResponse(
            content={"error": str(e)},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )



### <<< --------------- AISWARYA SME OVERALL REPORT ! --------------------------- >>>

### <<< ----------- AISWARYA CONTENT GENERATION ------------------------------------------ >>> 


class LanguageDetail(BaseModel):
    """Details for a specific programming language."""
    language: str = Field(description="The name of the programming language (e.g., Java, Python, JavaScript, TypeScript).")
    syntax: str = Field(description="The primary syntax/method call for the subtopic in this language. Should be concise.")
    example: str = Field(description="A full, working code example for the subtopic in this language, including imports and print statements where necessary. Use '\\n' for newlines.")

class SubtopicContent(BaseModel):
    """Detailed content for the specific subtopic, across languages."""
    explanation: str = Field(description="A concise explanation of how the subtopic concept works or what it achieves.")
    language_details: List[LanguageDetail]
    code_difference_explaination: str = Field(description="A brief explanation comparing the implementation differences across the listed languages.")

class SmeSubtopic(BaseModel):
    """Structure for the subtopic itself."""
    name: str = Field(description="The name of the subtopic (e.g., 'capitalize', 'slicing').")
    content: SubtopicContent

class SmeContent(BaseModel):
    """The final content structure for the SME output."""
    topic: str = Field(description="The main programming topic (e.g., 'Strings', 'Arrays').")
    explanation: str = Field(description="A brief, language-agnostic explanation of the main topic.")
    subtopic: SmeSubtopic

class SmeContentRequest(BaseModel):
    """Input payload for the SME content generation endpoint."""
    topic: str = Field(..., description="The main programming topic (e.g., 'Strings', 'Arrays').")
    subtopic: str = Field(..., description="The subtopic for which content is needed (e.g., 'capitalize', 'slicing').")
       
@app.post("/gen-sme-content", response_model=SmeContent)
def gen_sme_content(body: SmeContentRequest):
    if not check_ollama_running():
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )

    topic = body.topic
    subtopic = body.subtopic
    prompt = f"""
    You are a **Subject Matter Expert (SME)** in programming languages and curriculum design. 
    Your task is to generate highly accurate, comparative, and structured educational content for a platform that teaches language-agnostic concepts.

    **Strict Factual and Format Rules:**
    1. **Factual Accuracy is Paramount:** The syntax and code examples for each language MUST be absolutely correct and valid. Specifically address the correct method for the requested '{subtopic}' on the topic of '{topic}' in **Java, Python, JavaScript, and TypeScript**.
    2. **Avoid Hallucination:** Double-check all language-specific methods. For example, standard Java **does not** have a built-in slicing operator (arrayName[startIndex:endIndex]) like Python. A Java example for slicing should use Arrays.copyOfRange() or equivalent logic, not invented syntax.
    3. **Completeness:** Ensure ALL fields in the required JSON schema are present and non-empty.
    4. **Output Format:** The final output MUST be a VALID JSON object that adheres strictly to the provided Pydantic JSON schema. Do not include markdown fences (
json) or any preamble/explanation outside the JSON object.


    **Content Requirements:**
    - **Topic Explanation:** A short, language-agnostic definition of the main topic.
    - **Subtopic Content:**
        - **Explanation:** How the specific subtopic operation works.
        - **Language Details:** Provide details for **Java, Python, JavaScript, and TypeScript**.
        - **Syntax:** The most common or idiomatic way to perform the operation.
        - **Example:** A complete, runnable code snippet demonstrating the syntax. Use \\n for newlines in the string.
        - **Code Difference Explanation:** Explain why the implementation differs (e.g., "Java uses a static method from the Arrays utility class while Python has dedicated built-in slicing syntax.").

    **Request:**
    - Main Topic: **{topic}**
    - Subtopic Operation: **{subtopic}**
    """

    try:
        resp = client.chat(
            messages=[
                {
                    "role": "user",
                    "content": prompt,
                }
            ],
    
            model="mistral:latest", 
            format=SmeContent.model_json_schema(),
        )
        
        content = safe_json_loads(resp.message.content)
    
        return content

    except Exception as e:
        logging.error(f"Error in /gen-sme-content for {topic}/{subtopic}: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": str(e), "message": "Failed to generate SME content from LLM.", "raw_response": resp.message.content if 'resp' in locals() else None},
        )

### <<< ------------ AISWARYA CONTENT GENERATION ! ----------------- >>>

### <<< ------------ AISWARYA SUBTOPIC GENERATION ------------------ >>>

class SubtopicRequest(BaseModel):
    """Input structure for the topic to be broken down."""
    topic: str = Field(..., description="The high-level subject for which basic subtopics are required.")

class SubtopicResponse(BaseModel):
    """Output structure containing the generated list of basic subtopics."""
    topic: str = Field(..., description="The high-level subject for which basic subtopics are required.")
    subtopics: List[str] = Field(..., description="A list of primitive subtopics.")

@app.post("/generate-basic-subtopics", response_model=SubtopicResponse)
def generate_basic_subtopics(payload: SubtopicRequest):
    """
    Generates a list of primitive subtopics for a given subject.
    """
    if not check_ollama_running():
       
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Ollama server seems to be down"},
        )

    topic_name = payload.topic

    prompt_content = f"""
    You are an expert Curriculum Designer specializing in introductory technical education. Your task is to break down the given topic into a list of its most basic, primitive subtopics. 

    The subject is: **{topic_name}**

    CRITICAL CONSTRAINTS:
    1. SCOPE: The subtopics must strictly adhere to the provided topic. Do not mix unrelated domains.
    2. CONCISENESS: Each subtopic MUST be extremely concise:
        - Prioritize a single word (e.g., 'Variables', 'Methods', 'Inheritance').
        - Only use two words if absolutely necessary for technical accuracy (e.g., 'Access Modifiers', 'Data Types').
        - **NEVER use more than two words.**
    3. OUTPUT FORMAT: The final output MUST be a VALID JSON object that strictly adheres to the provided schema.

    Generate the basic subtopics now.
    """

    try:
        resp = client.chat(
            messages=[
               
                {"role": "user", "content": prompt_content.strip()}
            ],
            model="mistral:latest",
            
            format=SubtopicResponse.model_json_schema(), 
        )
       
        report_data = safe_json_loads(resp.message.content)
        
        return SubtopicResponse(**report_data)

    except Exception as e:
        
        error_message = f"LLM or Processing Failed: {type(e).__name__}: {str(e)}"
        logging.error(f"Error in /generate-basic-subtopics: {e}")
       
        raw_response = resp.message.content if 'resp' in locals() and hasattr(resp.message, 'content') else None
        
        return JSONResponse(
            content={
                "error": error_message, 
                "topic_requested": topic_name, 
                "raw_llm_output": raw_response
            },
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

### <<< ------------------- AISWARYA SUBTOPIC GENERATION ! ------------------------- >>>
