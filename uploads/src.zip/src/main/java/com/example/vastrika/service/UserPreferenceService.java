package com.example.vastrika.service;

import com.example.vastrika.dto.UserPreferenceRequest;
import com.example.vastrika.dto.UserPreferenceResponse;

public interface UserPreferenceService {

    boolean getUserPreferences(UserPreferenceRequest request);

    UserPreferenceResponse getMyPreferences();

    String updateUserPreferences(UserPreferenceRequest request);
}