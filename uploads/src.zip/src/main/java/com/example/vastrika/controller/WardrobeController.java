package com.example.vastrika.controller;

import com.example.vastrika.dto.WardrobeRequest;
import com.example.vastrika.entity.WardrobeItem;
import com.example.vastrika.service.WardrobeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/wardrobe")
public class WardrobeController {


        @Autowired
        private WardrobeService service;

        @PostMapping("/add")
        public ResponseEntity<String> add(@RequestBody WardrobeRequest request) {
            return ResponseEntity.ok(service.addItem(request));
        }

        @GetMapping("/my-items")
        public ResponseEntity<List<WardrobeItem>> get() {
            return ResponseEntity.ok(service.getMyItems());
        }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> removeItem(@PathVariable Long id) {
        return ResponseEntity.ok(service.removeItem(id));
    }



}
