package com.example.vastrika.dto;

import com.example.vastrika.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthResponse {
    private String token;
    private UserDetailsDTO userDetails;
}
