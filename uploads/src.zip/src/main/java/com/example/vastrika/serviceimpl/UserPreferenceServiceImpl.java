package com.example.vastrika.serviceimpl;

import com.example.vastrika.dto.UserPreferenceRequest;
import com.example.vastrika.dto.UserPreferenceResponse;
import com.example.vastrika.entity.Measurements;
import com.example.vastrika.entity.StyleDNA;
import com.example.vastrika.entity.StylePreference;
import com.example.vastrika.entity.User;
import com.example.vastrika.repository.MeasurementsRepository;
import com.example.vastrika.repository.StyleDNARepository;
import com.example.vastrika.repository.StylePrefernceRepository;
import com.example.vastrika.repository.UserRepository;
import com.example.vastrika.service.UserPreferenceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import org.springframework.security.core.context.SecurityContextHolder;

@Service
@Slf4j
public class UserPreferenceServiceImpl implements UserPreferenceService {

    @Autowired
    private MeasurementsRepository measurementsRepository;

    @Autowired
    private StylePrefernceRepository stylePrefernceRepository;

    @Autowired
    private StyleDNARepository styleDNARepository;

    @Autowired
    private UserRepository userRepository;

    //  find user with JWT
    private User getLoggedInUser() {
        String username = SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();

        return userRepository.findByEmail(username)
                .orElseThrow(() -> new IllegalArgumentException("User Not Found"));
    }

    //  SAVE
    @Override
    @Transactional
    public boolean getUserPreferences(UserPreferenceRequest request) {

        User userDetails = getLoggedInUser();

        try {
            // STYLE
            StylePreference stylePreference = StylePreference.builder()
                    .user(userDetails)
                    .preferredStyle(request.getPreferredStyle())
                    .preferredOccasions(request.getPreferredOccasion())
                    .preferredHairStyle(
                            request.getPreferredHairStyle() != null ? request.getPreferredHairStyle() : "Not Specified"
                    )
                    .preferredColor(
                            request.getPreferredColors() != null ? request.getPreferredColors().toString() : "Black"
                    )
                    .build();

            stylePrefernceRepository.save(stylePreference);

            // MEASUREMENTS
            Measurements measurements = Measurements.builder()
                    .user(userDetails)
                    .chest(request.getChest() != null ? request.getChest() : 0)
                    .waist(request.getWaist() != null ? request.getWaist() : 0)
                    .hip(request.getHip() != null ? request.getHip() : 0)
                    .build();

            Measurements savedM = measurementsRepository.save(measurements);

            // DNA
            StyleDNA styleDNA = StyleDNA.builder()
                    .user(userDetails)
                    .measurement(savedM)
                    .faceShape(request.getFaceShape())
                    .bodytype(request.getBodyType())
                    .skinTone(request.getSkinTone())
                    .gender(request.getGender())
                    .age(request.getAge())
                    .hairType(request.getHairType() != null ? request.getHairType() : "Unknown")
                    .region(request.getRegion() != null ? request.getRegion() : "India")
                    .build();

            styleDNARepository.save(styleDNA);

            return true;

        } catch (Exception e) {
            log.error("Error while saving", e);
            throw new IllegalArgumentException("Something Went Wrong");
        }
    }

    // VIEW with JWT
    @Override
    public UserPreferenceResponse getMyPreferences() {

        User user = getLoggedInUser();

        StylePreference style = stylePrefernceRepository.findByUser(user);
        Measurements m = measurementsRepository.findByUser(user);
        StyleDNA dna = styleDNARepository.findByUser(user);

        return UserPreferenceResponse.builder()
                .preferredStyle(style != null ? style.getPreferredStyle() : "")
                .preferredHairStyle(style != null ? style.getPreferredHairStyle() : "")
                .preferredColors(style != null ? style.getPreferredColor() : "")
                .preferredOccasion(style != null ? style.getPreferredOccasions() : "")
                .chest(m != null ? m.getChest() : 0)
                .waist(m != null ? m.getWaist() : 0)
                .hip(m != null ? m.getHip() : 0)
                .faceShape(dna != null ? dna.getFaceShape() : "")
                .bodyType(dna != null ? dna.getBodytype() : "")
                .skinTone(dna != null ? dna.getSkinTone() : "")
                .hairType(dna != null ? dna.getHairType() : "")
                .gender(dna != null ? dna.getGender() : "")
                .age(dna != null ? dna.getAge() : 0)
                .region(dna != null ? dna.getRegion() : "")
                .userId(dna!=null ? dna.getUser().getId() : 0)
                .build();
    }

    //  UPDATE with JWT
    @Override
    public String updateUserPreferences(UserPreferenceRequest request) {

        User user = getLoggedInUser();

        // STYLE
        StylePreference style = stylePrefernceRepository.findByUser(user);
        if (style != null) {
            style.setPreferredStyle(request.getPreferredStyle());
            style.setPreferredHairStyle(request.getPreferredHairStyle());
            style.setPreferredColor(request.getPreferredColors());
            style.setPreferredOccasions(request.getPreferredOccasion());
            stylePrefernceRepository.save(style);
        }

        // MEASUREMENTS
        Measurements m = measurementsRepository.findByUser(user);
        if (m != null) {
            m.setChest(request.getChest() != null ? request.getChest() : m.getChest());
            m.setWaist(request.getWaist() != null ? request.getWaist() : m.getWaist());
            m.setHip(request.getHip() != null ? request.getHip() : m.getHip());
            measurementsRepository.save(m);
        }

        // DNA
        StyleDNA dna = styleDNARepository.findByUser(user);
        if (dna != null) {
            dna.setFaceShape(request.getFaceShape());
            dna.setBodytype(request.getBodyType());
            dna.setSkinTone(request.getSkinTone());
            dna.setHairType(request.getHairType());
            dna.setGender(request.getGender());
            dna.setAge(request.getAge());
            dna.setRegion(request.getRegion());
            styleDNARepository.save(dna);
        }

        return "Updated Successfully";
    }
}