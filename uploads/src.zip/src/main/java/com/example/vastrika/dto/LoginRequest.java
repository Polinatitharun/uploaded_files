package com.example.vastrika.dto;

import jakarta.validation.constraints.Email;
import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class LoginRequest {

    @NotBlank(message= "Email is required")
    @Email(message = "Please Enter Valid Email")
    private String email;

    @NotBlank(message= "Password is required")
    private String password;
}


