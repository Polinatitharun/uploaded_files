package com.example.vastrika.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="style_preference")
@Builder
public class StylePreference {
    @Id
    @Column(name="preference_id")
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID preferenceId;
    @ManyToOne(optional = false,fetch = FetchType.LAZY)
    @JoinColumn(name="user_id")
    private User user;
    @Column(name="preferred_style")
    private String preferredStyle;
    @Column(name="preferred_hairstyle")
    private String preferredHairStyle;
    @Column(name="preferred_color")
    private String preferredColor;
    @Column(name="preferred_occasions")
    private String preferredOccasions;
    @Column(name="created_at")
    private Instant createdAt = Instant.now();
}
