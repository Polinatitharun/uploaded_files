package com.example.vastrika.repository;

import com.example.vastrika.entity.Measurements;
import com.example.vastrika.entity.StylePreference;
import com.example.vastrika.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface MeasurementsRepository extends JpaRepository<Measurements,String> {
    Measurements findByUser(User user);
}
