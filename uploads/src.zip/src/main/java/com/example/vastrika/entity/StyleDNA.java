package com.example.vastrika.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Table(name="style_dna")
public class StyleDNA {
    @Id
    @Column(name="dna_id")
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID dnaId;
    @ManyToOne(optional = false,fetch = FetchType.LAZY)
    @JoinColumn(name="user_id")
    private User user;
    @ManyToOne(optional = false,fetch = FetchType.LAZY)
    @JoinColumn(name="measurement_id")
    private Measurements measurement;
    @Column(name="face_shape")
    private String faceShape;
    @Column(name="body_type")
    private  String bodytype;
    @Column(name="skin_tone")
    private String skinTone;
    @Column(name="hair_type")
    private String hairType;
    @Column(name="age")
    private Integer age;
    @Column(name="gender")
    private  String gender;
    @Column(name="region")
    private String region;
    @Column(name="created_at")
    private Instant createdAt = Instant.now();

}
