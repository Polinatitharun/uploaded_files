package com.example.vastrika.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class UserPreferenceRequest {

    //private Long userId;

    private String preferredStyle;

    private String preferredHairStyle;

    private String preferredColors;

    private String preferredOccasion;

    private Integer chest;

    private Integer waist ;

    private Integer hip;

    private String  faceShape;

    private String  bodyType;

    private String  skinTone;

    private String  hairType;

    private  Integer age;

    private  String gender;

    private String region;







}
