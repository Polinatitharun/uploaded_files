package com.example.vastrika.controller;

import com.example.vastrika.dto.UserPreferenceRequest;
import com.example.vastrika.dto.UserPreferenceResponse;
import com.example.vastrika.service.UserPreferenceService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class StylePreferenceController {

    @Autowired
    private UserPreferenceService preferenceService;

    // SAVE (Save With JWT)
    @PostMapping("/stylerequest")
    public ResponseEntity<?> savePreferences(
            @Valid @RequestBody UserPreferenceRequest styleRequest,
            BindingResult errorMessage) {

        log.info("Request {}", styleRequest);

        if (errorMessage.hasErrors()) {
            return ResponseEntity.badRequest().body(errorMessage.getAllErrors());
        }

        preferenceService.getUserPreferences(styleRequest);

        return ResponseEntity.ok("Details Saved Successfully");
    }

    // VIEW (NO userId, With JWT )
    @GetMapping("/view")
    public ResponseEntity<UserPreferenceResponse> view() {
        return ResponseEntity.ok(preferenceService.getMyPreferences());
    }

    // UPDATE With JWT
    @PutMapping("/update")
    public ResponseEntity<String> update(@RequestBody UserPreferenceRequest req) {
        return ResponseEntity.ok(preferenceService.updateUserPreferences(req));
    }
}