package com.example.vastrika.dto;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@Builder
public class UserPreferenceResponse {

    private Long userId;

    private String preferredStyle;

    private String preferredHairStyle;

    private String preferredColors;

    private String preferredOccasion;

    private Integer chest;

    private Integer waist ;

    private Integer hip;

    private String  faceShape;

    private String  bodyType;

    private String  skinTone;

    private String  hairType;

    private  String gender;

    private  Integer age;

    private String region;

}
