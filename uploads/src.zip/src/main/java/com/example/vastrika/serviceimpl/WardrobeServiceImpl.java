package com.example.vastrika.serviceimpl;

import com.example.vastrika.dto.WardrobeRequest;
import com.example.vastrika.entity.User;
import com.example.vastrika.entity.WardrobeItem;
import com.example.vastrika.entity.WardrobeItem;
import com.example.vastrika.repository.UserRepository;
import com.example.vastrika.repository.WardrobeItemRepository;
import com.example.vastrika.service.WardrobeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class WardrobeServiceImpl implements WardrobeService {


    @Autowired
    private WardrobeItemRepository repo;

    @Autowired
    private UserRepository userRepository;

    private User getLoggedInUser() {
        String username = SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();

        return userRepository.findByEmail(username)
                .orElseThrow(() -> new RuntimeException("User Not Found"));
    }

    @Override
    public String addItem(WardrobeRequest request) {

        User user = getLoggedInUser();

        WardrobeItem item = WardrobeItem.builder()
                .user(user)
                .itemName(request.getItemName())
                .category(request.getCategory())
                .color(request.getColor())
                .imageUrl(request.getImageUrl())
                .createdAt(LocalDateTime.now())
                .build();

        repo.save(item);

        return "Item Added";
    }

    @Override
    public List<WardrobeItem> getMyItems() {
        User user = getLoggedInUser();
        return repo.findByUser(user);
    }


    @Override
    public String removeItem(Long itemId) {

        WardrobeItem item = repo.findById(itemId)
                .orElseThrow(() ->
                        new RuntimeException("Wardrobe item not found"));
        repo.delete(item);

        return "Item removed successfully";
    }

}
