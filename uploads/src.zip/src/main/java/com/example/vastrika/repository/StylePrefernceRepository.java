package com.example.vastrika.repository;

import com.example.vastrika.entity.StylePreference;
import com.example.vastrika.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;


@Repository
public interface StylePrefernceRepository extends JpaRepository<StylePreference,String> {
    StylePreference findByUser(User user);
}
