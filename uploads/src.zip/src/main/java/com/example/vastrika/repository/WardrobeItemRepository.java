package com.example.vastrika.repository;

import com.example.vastrika.entity.User;
import com.example.vastrika.entity.WardrobeItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WardrobeItemRepository extends JpaRepository<WardrobeItem, Long> {
    List<WardrobeItem> findByUser(User user);
}
