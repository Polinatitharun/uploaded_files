package com.example.vastrika.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Table(name="measurements")
public class Measurements {

    @Column(name="measurement_id")
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID measurementId;
    @ManyToOne(optional = false,fetch = FetchType.LAZY)
    @JoinColumn(name="user_id")
    private User user;
    @Column(name="chest")
    private Integer chest;
    @Column(name="waist")
    private Integer waist;
    @Column(name="hip")
    private Integer hip;
    @Column(name="created_at")
    private Instant createdAt = Instant.now();



}
