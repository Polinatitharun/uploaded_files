package com.example.vastrika.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class UserDetailsDTO {

    private Long id;
    private String fullName;
    private String email;
    private String phone;
//    private String passwordHash;
}
