package com.example.vastrika.config;

import com.example.vastrika.security.JwtUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtUtil jwtUtil;

    public SecurityConfig(JwtUtil jwtUtil){
        this.jwtUtil= jwtUtil;
    }
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                .csrf(csrf -> csrf.disable())
                .cors(cors-> {}) //enable cors
                .authorizeHttpRequests(auth -> auth
//                        .requestMatchers("/api/auth/**").permitAll() //allow login/register
//                        .anyRequest().authenticated() //secure others
                                .anyRequest().permitAll()
                ).addFilterBefore(jwtUtil, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}