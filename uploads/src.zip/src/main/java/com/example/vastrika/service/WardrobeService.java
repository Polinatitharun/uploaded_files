package com.example.vastrika.service;

import com.example.vastrika.dto.WardrobeRequest;
import com.example.vastrika.entity.WardrobeItem;

import java.util.List;

public interface WardrobeService {
    String addItem(WardrobeRequest request);
    List<WardrobeItem> getMyItems();
    String removeItem(Long itemId);
}
