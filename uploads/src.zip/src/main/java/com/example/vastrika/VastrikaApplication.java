package com.example.vastrika;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VastrikaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VastrikaApplication.class, args);
	}

}
