package com.example.vastrika.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WardrobeRequest {


        private String itemName;
        private String category;
        private String color;
        private String imageUrl;

}

