package com.example.vastrika.controller;

import com.example.vastrika.dto.*;
import com.example.vastrika.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletResponse;


import jakarta.validation.Valid;
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    //Register API
    @PostMapping("/register")
    public String register(@Valid @RequestBody RegisterRequest request,HttpServletResponse response) {
        authService.register(request);
        response.setStatus(HttpServletResponse.SC_CREATED);
        return "User registered successfully";
    }

    //Login API
    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }
}
