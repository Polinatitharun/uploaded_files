package com.ignite.CBL.dto.problem;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ignite.CBL.entity.Difficulty;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProblemDto{
    private Integer id;
    private String title;
    private String mainTopicName;
    private String subTopicTitle;

    @Enumerated(EnumType.STRING)
    private Difficulty difficulty;

    @JsonProperty("solvedLanguageList")
    private LanguageDto languageList;
    private ProblemStatusDto status;
}