package com.ignite.CBL.dto.problem;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import java.util.List;

@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProblemStatusResponseDto {
    private String version;
    private String generatedAt;
    private String userId;
    private List<ProblemDto> questions;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private PagingDto paging;
}










