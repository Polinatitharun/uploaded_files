package com.ignite.CBL.service;

import com.ignite.CBL.repository.UserMainTopicProgressRepository;
import org.springframework.stereotype.Service;

@Service
public class UserProgressService {
    private final UserMainTopicProgressRepository repository;

    public UserProgressService(UserMainTopicProgressRepository repository) {
        this.repository = repository;
    }

    public long getCompletedMainTopics(String userId) {
        return repository.countByUser_UserIdAndIsCompletedTrue(userId);
    }
}
