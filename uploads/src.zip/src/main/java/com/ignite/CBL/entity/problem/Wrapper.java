package com.ignite.CBL.entity.problem;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

@Entity
public class Wrapper {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(columnDefinition = "TEXT")
    private String wrapperCode;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="problem_id",nullable = false,unique = true)
    @JsonBackReference("problem-wrapper")
    private Problem problem;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getWrapperCode() {
        return wrapperCode;
    }

    public void setWrapperCode(String wrapperCode) {
        this.wrapperCode = wrapperCode;
    }

    public Problem getProblem() {
        return problem;
    }

    public void setProblem(Problem problem) {
        this.problem = problem;
    }
}
