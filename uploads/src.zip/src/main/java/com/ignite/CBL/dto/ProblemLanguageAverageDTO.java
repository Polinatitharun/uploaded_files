package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProblemLanguageAverageDTO {
    private Integer problemId;
    private String problemTitle;
    private String difficulty;
    private Integer topicId;
    private String topicTitle;
    private Integer mainTopicId;
    private String mainTopicTitle;
    private Double avgJavaTime;
    private Double avgPythonTime;
    private Double avgJavascriptTime;
    private Double avgTypescriptTime;
    private Double avgTotalTime;
    private Long javaCompletedCount;
    private Long pythonCompletedCount;
    private Long javascriptCompletedCount;
    private Long typescriptCompletedCount;
    private Long totalUsersAttempted;
}
