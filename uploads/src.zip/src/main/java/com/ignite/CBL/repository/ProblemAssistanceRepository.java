package com.ignite.CBL.repository;

import com.ignite.CBL.entity.problem.Problem;
import com.ignite.CBL.entity.problem.ProblemAssistances;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProblemAssistanceRepository extends JpaRepository<ProblemAssistances,Integer> {

    Optional<ProblemAssistances> findAssistanceByProblem(Problem problem);


}
