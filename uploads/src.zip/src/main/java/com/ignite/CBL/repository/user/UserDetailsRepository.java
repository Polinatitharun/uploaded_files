package com.ignite.CBL.repository.user;

import com.ignite.CBL.entity.user.UserDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails,String> {
    Optional<UserDetails> findByKeycloakId(String keycloakId);

}
