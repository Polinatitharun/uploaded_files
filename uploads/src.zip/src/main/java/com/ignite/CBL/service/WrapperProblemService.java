package com.ignite.CBL.service;

import com.ignite.CBL.dto.ProblemDTO;
import com.ignite.CBL.dto.WrapperProblemDTO;
import com.ignite.CBL.entity.ProblemTestCase;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.problem.Problem;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.repository.TopicRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class WrapperProblemService {
    @Autowired
    ProblemRepository problemRepository;
    @Autowired
    TopicRepository topicRepository;

    public WrapperProblemDTO fetchWrapperProblemById(Integer problemId) {
        Problem problem = problemRepository.findById(problemId)
                .orElseThrow(() -> {
                    log.error("Problem not found with id: {}", problemId);
                    return new ResourceNotFoundException("Problem not found with id: " + problemId);
                });
        log.debug("Fetched problem with id: {}", problemId);
        log.debug("Fetched Problem", problem);
        return convertToDTO(problem);
    }

    private WrapperProblemDTO convertToDTO(Problem problem) {
        WrapperProblemDTO dto = new WrapperProblemDTO();

        dto.setProblemId(problem.getProblemId());
        dto.setTitle(problem.getTitle());
        dto.setDescription(problem.getDescription());
        dto.setDifficulty(problem.getDifficulty());
        dto.setCreatedUsing(problem.getCreatedUsing());
        dto.setWrapper(problem.getWrapper());
        // Convert test cases if needed
//        if (problem.getWrapper()!=null){
//
//            dto.setWrapperCode(problem.getWrapper().getWrapperCode());
//        }

        return dto;
    }

    public WrapperProblemDTO saveProblem(Integer topicId, WrapperProblemDTO problemDTO) {
        log.debug("Saving problem for topic id: {}", topicId);
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));
        Problem problem = new Problem();
        problem.setTitle(problemDTO.getTitle());
        problem.setDescription(problemDTO.getDescription());
        problem.setDifficulty(problemDTO.getDifficulty());
        problem.setTopic(topic);
        problem.setWrapper(problemDTO.getWrapper());
        problem.setCreatedUsing(problemDTO.getCreatedUsing());
//        problem.setIsActive(problemDTO);
        if (problemDTO.getTestCases() != null) {
            problemDTO.getTestCases().forEach(tc -> {
                ProblemTestCase testCase = new ProblemTestCase();
                testCase.setInput(tc.getInput());
                testCase.setExpectedOutput(tc.getExpectedOutput());
                testCase.setIsPublic(tc.getIsPublic());
                problem.addTestCase(testCase);
            });
        }

        Problem savedProblem = problemRepository.save(problem);
        log.debug("Saved problem with id: {}", savedProblem.getProblemId());
        return convertToDTO(savedProblem);

    }
}
