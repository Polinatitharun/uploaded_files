package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "mcqs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MCQ {
    @Id
    @Column(name = "mcq_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer mcqId;


    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "content",nullable = false,columnDefinition = "jsonb")
    private JsonNode content;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "topic_id", nullable = false)
    @JsonBackReference("topic-mcqs")
    private Topic topic;

    @Column(name = "language",nullable = false)
    @Enumerated(EnumType.STRING)
    private Language language;

//    @OneToMany(
//            mappedBy = "mcq",
//            cascade = CascadeType.ALL,
//            orphanRemoval = true
//    )
//    private Set<McqAttempt> mcqAttempts = new HashSet<>();




}