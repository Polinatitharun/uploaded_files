package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProblemTestCaseDTO {
    private Integer testCaseId;
    private String input;
    private String expectedOutput;
    private Boolean isPublic;
    
    // Getters and setters
}