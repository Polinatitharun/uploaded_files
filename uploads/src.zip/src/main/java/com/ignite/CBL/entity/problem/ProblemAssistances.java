package com.ignite.CBL.entity.problem;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Getter
@Entity
@Table(name = "problem_assistance")
@Setter
public class ProblemAssistances {
    @Id
    @Column(name = "assistance_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer assistance_id;


    @Column(name = "hint", columnDefinition = "text")
    private String hint;


    @Column(name = "breakdown", columnDefinition = "text")
    private String breakdown;

    @Column(name = "concept_explanation", columnDefinition = "text")
    private String concept_explanation;

    @Column(name = "partial_solution", columnDefinition = "text")
    private String partial_solution;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false,unique = true)
    @JsonBackReference("problem-assistance")

    private Problem problem;


}
