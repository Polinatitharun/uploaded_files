package com.ignite.CBL.dto.problem;

import lombok.*;

@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProblemAssistanceDto {
    private Integer assistanceId;
    private Integer problemId;

    private String hint;
    private String breakdown;
    private String conceptExplanation;
    private String partialSolution;



}