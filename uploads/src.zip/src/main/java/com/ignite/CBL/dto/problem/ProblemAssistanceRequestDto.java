package com.ignite.CBL.dto.problem;

import jakarta.validation.constraints.NotNull;
import lombok.*;

@Setter
@Getter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProblemAssistanceRequestDto {
    private String hint;
    private String breakdown;
    private String conceptExplanation;
    private String partialSolution;

}
