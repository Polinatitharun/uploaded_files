package com.ignite.CBL.repository;

import com.ignite.CBL.dto.DropoffDto;
import com.ignite.CBL.dto.TopicFunnelDto;
import com.ignite.CBL.dto.TraineeProgressDto;
import com.ignite.CBL.dto.TraineeProgressQueryDto;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.UserTopicEngagement;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ignite.CBL.entity.UserTopicEngagementId;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserTopicEngagementRepository extends JpaRepository<UserTopicEngagement, UserTopicEngagementId> {

    Optional<UserTopicEngagement> findByUser_UserIdAndTopic_TopicId(String userId, Integer topicId);

    boolean existsByUser_UserIdAndTopic_TopicId(String userId, Integer topicId);

    @Modifying
    @Transactional
    @Query("DELETE FROM UserTopicEngagement ute WHERE ute.topic.topicId = :topicId")
    void deleteByTopicId(@Param("topicId") Integer topicId);

    // 🔥 NEW: Efficient query to fetch all subtopic engagements for a specific main topic and user
    @Query("SELECT ute FROM UserTopicEngagement ute " +
            "WHERE ute.user.userId = :userId " +
            "AND ute.topic.mainTopic.mainTopicId = :mainTopicId")
    List<UserTopicEngagement> findByUserIdAndMainTopicId(@Param("userId") String userId,
                                                         @Param("mainTopicId") Integer mainTopicId);


        @Query("""
     SELECT new com.ignite.CBL.dto.DropoffDto(
       'Viewed',
       COUNT(e)
     )
     FROM UserTopicEngagement e
     WHERE e.user.batch = :batch
     AND (
       e.javaVisited = true OR
       e.pythonVisited = true OR
       e.javascriptVisited = true OR
       e.typescriptVisited = true
     )
    """)
        DropoffDto viewed(@Param("batch") String batch);



    /* ---------- JAVA ---------- */
    @Query("""
      SELECT new com.ignite.CBL.dto.TopicFunnelDto(
        'JAVA',
        COUNT(e),
        SUM(CASE WHEN e.javaMcqVisited = true THEN 1 ELSE 0 END),
        SUM(CASE WHEN e.isCompleted = true THEN 1 ELSE 0 END)
      )
      FROM UserTopicEngagement e
      WHERE e.user.batch = :batch
    """)
    TopicFunnelDto javaFunnel(@Param("batch") String batch);

    /* ---------- PYTHON ---------- */
    @Query("""
      SELECT new com.ignite.CBL.dto.TopicFunnelDto(
        'PYTHON',
        COUNT(e),
        SUM(CASE WHEN e.pythonMcqVisited = true THEN 1 ELSE 0 END),
        SUM(CASE WHEN e.isCompleted = true THEN 1 ELSE 0 END)
      )
      FROM UserTopicEngagement e
      WHERE e.user.batch = :batch
    """)
    TopicFunnelDto pythonFunnel(@Param("batch") String batch);

    /* ---------- JAVASCRIPT ---------- */
    @Query("""
      SELECT new com.ignite.CBL.dto.TopicFunnelDto(
        'JAVASCRIPT',
        COUNT(e),
        SUM(CASE WHEN e.javascriptMcqVisited = true THEN 1 ELSE 0 END),
        SUM(CASE WHEN e.isCompleted = true THEN 1 ELSE 0 END)
      )
      FROM UserTopicEngagement e
      WHERE e.user.batch = :batch
    """)
    TopicFunnelDto javascriptFunnel(@Param("batch") String batch);

    /* ---------- TYPESCRIPT ---------- */
    @Query("""
      SELECT new com.ignite.CBL.dto.TopicFunnelDto(
        'TYPESCRIPT',
        COUNT(e),
        SUM(CASE WHEN e.typescriptMcqVisited = true THEN 1 ELSE 0 END),
        SUM(CASE WHEN e.isCompleted = true THEN 1 ELSE 0 END)
      )
      FROM UserTopicEngagement e
      WHERE e.user.batch = :batch
    """)
    TopicFunnelDto typescriptFunnel(@Param("batch") String batch);


        @Query("""
     SELECT new com.ignite.CBL.dto.DropoffDto(
       'MCQ Passed',
       COUNT(e)
     )
     FROM UserTopicEngagement e
     WHERE e.user.batch = :batch
     AND (
       e.javaMcqVisited = true OR
       e.pythonMcqVisited = true OR
       e.javascriptMcqVisited = true OR
       e.typescriptMcqVisited = true
     )
    """)
        DropoffDto mcqPassed(@Param("batch") String batch);


        @Query("""
     SELECT new com.ignite.CBL.dto.DropoffDto(
       'Completed',
       COUNT(e)
     )
     FROM UserTopicEngagement e
     WHERE e.user.batch = :batch
     AND e.isCompleted = true
    """)
        DropoffDto completed(@Param("batch") String batch);




        @Query("""
     SELECT new com.ignite.CBL.dto.TraineeProgressQueryDto(
       u.userId,
       SUM(CASE WHEN e.isCompleted = true THEN 1 ELSE 0 END),
       AVG(e.totalTimeSpent) * 1000,
       SUM(e.totalTimeSpent)
     )
     FROM User u
     JOIN UserTopicEngagement e ON e.user = u
     WHERE u.batch = :batch
     GROUP BY u.userId
    """)
        List<TraineeProgressQueryDto> fetchTraineeProgressRaw(
                @Param("batch") String batch
        );


        @Query("""
     SELECT t.title
     FROM UserTopicEngagement e
     JOIN e.topic t
     WHERE e.user.batch = :batch
     GROUP BY t.title
     ORDER BY SUM(e.totalTimeSpent) DESC
    """)
        List<String> findTrendingTopicsDesc(@Param("batch") String batch);


        @Query("""
     SELECT t.title
     FROM UserTopicEngagement e
     JOIN e.topic t
     WHERE e.user.batch = :batch
     GROUP BY t.title
     ORDER BY SUM(e.totalTimeSpent) ASC
    """)
        List<String> findTrendingTopicsAsc(@Param("batch") String batch);



}
