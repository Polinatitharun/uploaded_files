
package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DropoffDto {
    private String stage;
    private Long count;
}
