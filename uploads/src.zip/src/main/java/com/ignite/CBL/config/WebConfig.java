package com.ignite.CBL.config;

import com.ignite.CBL.Interceptor.AuthInterceptor;
import com.ignite.CBL.Interceptor.UserRequestLoggingInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    //  Interceptors
    private final AuthInterceptor authInterceptor;

    @Autowired
    private UserRequestLoggingInterceptor userRequestLoggingInterceptor;

    public WebConfig(AuthInterceptor authInterceptor) {
        this.authInterceptor = authInterceptor;
    }

    // CORS configuration
    @Value("${cors.frontend.url}")
    private String allowedOrigins;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                // Prefer property-based config
                .allowedOrigins(allowedOrigins)
                // If you really want open CORS
                // .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(false)
                .maxAge(3600);
    }

    // Swagger & webjars static resources
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/swagger-ui/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/springdoc-openapi-ui/")
                .resourceChain(false);

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

    // Swagger redirect
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addRedirectViewController("/swagger-ui", "/swagger-ui/index.html");
    }

    // Interceptor registration (ORDER MATTERS)
    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        // Auth interceptor (security first)
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/auth/**",
                        "/swagger-ui/**",
                        "/v3/api-docs/**",
                        "/api-docs/**",
                        "/webjars/**"
                );

        // API logging interceptor
        registry.addInterceptor(userRequestLoggingInterceptor)
                .addPathPatterns("/**");
    }
}
