package com.ignite.CBL.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class TopicImportRequest {
    private MultipartFile file;
}
