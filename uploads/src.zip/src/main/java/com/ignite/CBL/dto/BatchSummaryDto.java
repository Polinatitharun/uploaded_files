
package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BatchSummaryDto {
    private Long activeTrainees;
    private Long topicsCompleted;
    private Double avgTimeSpent;
    private String mostTrendingTopic;
    private String leastTrendingTopic;
    private String mostTrendingLanguage;
    private String leastTrendingLanguage;

    public BatchSummaryDto(
            Long activeTrainees,
            Long topicsCompleted,
            Double avgTimeSpent
    ) {
        this.activeTrainees = activeTrainees;
        this.topicsCompleted = topicsCompleted;
        this.avgTimeSpent = avgTimeSpent;
    }

}
