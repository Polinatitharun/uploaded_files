package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.TopicProblemLanguageAverageDTO;
import com.ignite.CBL.repository.TopicProblemLanguageAverageViewRepository;
import com.ignite.CBL.service.TopicProblemLanguageAverageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TopicProblemLanguageAverageServiceImpl implements TopicProblemLanguageAverageService {

    private final TopicProblemLanguageAverageViewRepository viewRepository;
    private final ModelMapper modelMapper;

    @Override
    public List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAverages() {
        log.debug("Fetching all topic-level problem language averages");
        return viewRepository.findAllByOrderByProblemIdAsc().stream()
                .map(view -> modelMapper.map(view, TopicProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAveragesByMainTopic(Integer mainTopicId) {
        log.debug("Fetching topic-level problem language averages for main topic: {}", mainTopicId);
        return viewRepository.findByMainTopicIdOrderByProblemIdAsc(mainTopicId).stream()
                .map(view -> modelMapper.map(view, TopicProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAveragesByTopic(Integer topicId) {
        log.debug("Fetching topic-level problem language averages for topic: {}", topicId);
        return viewRepository.findByTopicIdOrderByProblemIdAsc(topicId).stream()
                .map(view -> modelMapper.map(view, TopicProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAveragesByDifficulty(String difficulty) {
        log.debug("Fetching topic-level problem language averages for difficulty: {}", difficulty);
        return viewRepository.findByDifficultyOrderByProblemIdAsc(difficulty.toUpperCase()).stream()
                .map(view -> modelMapper.map(view, TopicProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }
}
