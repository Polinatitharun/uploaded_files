package com.ignite.CBL.repository;

import com.ignite.CBL.dto.SimpleOptionDto;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.entity.problem.Problem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ProblemRepository extends JpaRepository<Problem, Integer> {
    List<Problem> findByTopic_TopicId(Integer topicTopicId);

    @Query("SELECT p FROM Problem p WHERE p.mainTopic.mainTopicId = :mainTopicId")
    Optional<Problem> findProblemByMainTopicId(@Param("mainTopicId") Integer mainTopicId);




    @Query("SELECT p FROM Problem p WHERE p.topic.topicId = :topicId AND p.mainTopic IS NULL")
    List<Problem> findByTopicIdAndNotMainTopic(@Param("topicId") Integer topicId);

    @Query("""
            SELECT new com.ignite.CBL.dto.SimpleOptionDto(p.problemId,p.title)
            FROM Problem p
            WHERE (:topicId IS NULL OR p.topic.topicId=:topicId)
            """)
            List<SimpleOptionDto> findProblemsByTopic(@Param("topicId") Integer topicId);


}
