package com.ignite.CBL.service.problem.Impl;

import com.ignite.CBL.dto.problem.*;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.entity.problem.Problem;
import com.ignite.CBL.repository.MainTopicRepository;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.repository.ProblemSubmissionRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.problem.ProblemStatusService;
import com.ignite.CBL.utils.AppUtils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
@Transactional
@RequiredArgsConstructor
public class ProblemStatusServiceImpl implements ProblemStatusService {

    @Autowired
    private ProblemRepository problemRepository;
    @Autowired
    private ProblemSubmissionRepository problemSubmissionRepository;
    @Autowired
    private MainTopicRepository mainTopicRepository;

    @Autowired
    private TopicRepository topicRepository;

    @Override
    public ResponseEntity<ProblemStatusResponseDto> getQuestionsWithFilter(
            int page,
            int size,
            String mainTopic,
            String subTopic,
            Difficulty difficulty,
            Boolean isSolved,
            Boolean active) {

        String userId = AppUtils.getCurrentUserId();
        String now = Instant.now().toString();

        List<ProblemDto> result = new ArrayList<>();
        List<Problem> allProblems = problemRepository.findAll();

        boolean hasMainTopic = mainTopic != null && !mainTopic.isBlank();
        boolean hasSubTopic = subTopic != null && !subTopic.isBlank();
        boolean hasDifficulty = difficulty != null;
        boolean hasSolved = isSolved != null;

        for (Problem problem : allProblems) {

            if (active != null && !problem.getIsActive().equals(active)) {
                continue;
            }

            Map<String, String> topicMap =
                    getSubTopicAndMainTopicByProblemId(problem.getProblemId());
            Map<String, String> submission =
                    getSubmissionStatus(problem.getProblemId());

            ProblemDto dto = ProblemDto.builder()
                    .id(problem.getProblemId())
                    .title(problem.getTitle())
                    .mainTopicName(topicMap.get("mainTopic"))
                    .subTopicTitle(topicMap.get("subTopic"))
                    .difficulty(problem.getDifficulty())
                    .languageList(LanguageDto.builder()
                            .java(Boolean.parseBoolean(submission.get("JAVA")))
                            .python(Boolean.parseBoolean(submission.get("PYTHON")))
                            .javascript(Boolean.parseBoolean(submission.get("JAVASCRIPT")))
                            .typescript(Boolean.parseBoolean(submission.get("TYPESCRIPT")))
                            .build())
                    .status(ProblemStatusDto.builder()
                            .solved(Boolean.parseBoolean(submission.get("status")))
                            .attempts(Integer.parseInt(submission.get("attempts")))
                            .build())
                    .build();

            if (hasMainTopic && !mainTopic.equals(dto.getMainTopicName())) continue;
            if (hasSubTopic && !subTopic.equals(dto.getSubTopicTitle())) continue;
            if (hasDifficulty && !difficulty.equals(dto.getDifficulty())) continue;
            if (hasSolved && !isSolved.equals(dto.getStatus().isSolved())) continue;

            result.add(dto);
        }

        int total = result.size();
        int from = Math.min((page - 1) * size, total);
        int to = Math.min(from + size, total);
        List<ProblemDto> pagedData = result.subList(from, to);

        return ResponseEntity.ok(
                ProblemStatusResponseDto.builder()
                        .version("1")
                        .userId(userId)
                        .generatedAt(now)
                        .questions(pagedData)
                        .paging(PagingDto.builder()
                                .currentPage(page)
                                .pageSize(size)
                                .totalQuestions(total)
                                .totalPages((int) Math.ceil((double) total / size))
                                .hasNext(to < total)
                                .hasPrevious(page > 1)
                                .build())
                        .build()
        );
    }
    @Override
    public ResponseEntity<ProblemStatusResponseDto> getQuestionsWithStatus() {
        String userId = AppUtils.getCurrentUserId();
        System.out.println("User id " + userId);
        String now = Instant.now().toString();
        List<ProblemDto> problemDTOList = new ArrayList<>();
        List<Problem> findAllProblem = problemRepository.findAll();
        for (Problem problem : findAllProblem) {
            ProblemDto temporary = ProblemDto.builder()
                    .id(problem.getProblemId())
                    .title(problem.getTitle())
                    .subTopicTitle(getSubTopicAndMainTopicByProblemId(problem.getProblemId()).get("subTopic"))
                    .mainTopicName(getSubTopicAndMainTopicByProblemId(problem.getProblemId()).get("mainTopic"))
                    .difficulty(problem.getDifficulty())
                    .languageList(LanguageDto.builder()
                            .java(Boolean.parseBoolean(getSubmissionStatus(problem.getProblemId()).get("JAVA")))
                            .python(Boolean.parseBoolean(getSubmissionStatus(problem.getProblemId()).get("PYTHON")))
                            .javascript(
                                    Boolean.parseBoolean(getSubmissionStatus(problem.getProblemId()).get("JAVASCRIPT")))
                            .typescript(
                                    Boolean.parseBoolean(getSubmissionStatus(problem.getProblemId()).get("TYPESCRIPT")))
                            .build())
                    .status(
                            ProblemStatusDto.builder()
                                    .solved(Objects.equals(getSubmissionStatus(problem.getProblemId()).get("status"),
                                            "true"))
                                    .attempts(Integer
                                            .parseInt(getSubmissionStatus(problem.getProblemId()).get("attempts")))
                                    .build())
                    .build();

            problemDTOList.add(temporary);
        }

        ProblemStatusResponseDto problemStatusResponseDto = ProblemStatusResponseDto.builder()
                .version("1")
                .userId(userId)
                .generatedAt(now)
                .questions(problemDTOList)
                .paging(PagingDto.builder()

                        .build())
                .build();

        return ResponseEntity.ok().body(problemStatusResponseDto);
    }

    @Override
    public ResponseEntity<ProblemStatusResponseDto> getQuestionsWithActiveStatus() {
        String userId = AppUtils.getCurrentUserId();
        String now = Instant.now().toString();
        List<ProblemDto> problemDTOList = new ArrayList<>();
        List<Problem> findAllProblem = problemRepository.findAll();
        for (Problem problem : findAllProblem) {
            if (problem.getIsActive()) {
                ProblemDto temporary = ProblemDto.builder()
                        .id(problem.getProblemId())
                        .title(problem.getTitle())
                        .subTopicTitle(getSubTopicAndMainTopicByProblemId(problem.getProblemId()).get("subTopic"))
                        .mainTopicName(getSubTopicAndMainTopicByProblemId(problem.getProblemId()).get("mainTopic"))
                        .difficulty(problem.getDifficulty())
                        .languageList(LanguageDto.builder()
                                .java(Boolean.parseBoolean(getSubmissionStatus(problem.getProblemId()).get("JAVA")))
                                .python(Boolean.parseBoolean(getSubmissionStatus(problem.getProblemId()).get("PYTHON")))
                                .javascript(Boolean
                                        .parseBoolean(getSubmissionStatus(problem.getProblemId()).get("JAVASCRIPT")))
                                .typescript(Boolean
                                        .parseBoolean(getSubmissionStatus(problem.getProblemId()).get("TYPESCRIPT")))
                                .build())
                        .status(
                                ProblemStatusDto.builder()
                                        .solved(Objects.equals(
                                                getSubmissionStatus(problem.getProblemId()).get("status"),
                                                "true"))
                                        .attempts(Integer
                                                .parseInt(getSubmissionStatus(problem.getProblemId()).get("attempts")))
                                        .build())
                        .build();

                problemDTOList.add(temporary);
            }
        }

        ProblemStatusResponseDto problemStatusResponseDto = ProblemStatusResponseDto.builder()
                .version("1")
                .userId(userId)
                .generatedAt(now)
                .questions(problemDTOList)
                .paging(PagingDto.builder()
                        .build())
                .build();

        return ResponseEntity.ok().body(problemStatusResponseDto);
    }

    private Map<String, String> getSubmissionStatus(int problemId) {
        String userId = AppUtils.getCurrentUserId();
        Map<String, String> response = new HashMap<>();
        int maxAttend = 0;
        boolean isSolved = false;
        List<ProblemSubmission> problemSubmissionOptional = problemSubmissionRepository
                .findByProblem_ProblemIdAndUser_UserId(problemId, userId);
        for (ProblemSubmission problemSubmission : problemSubmissionOptional) {
            if (problemSubmission.getIsSolved()) {
                isSolved = true;
                response.put(problemSubmission.getLanguage().toString(), "true");
                maxAttend = Math.max(maxAttend, problemSubmission.getVersion());
            }
            response.put(problemSubmission.getSubmissionId().toString(), "false");
        }
        response.put("status", String.valueOf(isSolved));
        response.put("attempts", String.valueOf(maxAttend));
        return response;
    }

    private Map<String, String> getSubTopicAndMainTopicByProblemId(int problemId) {
        Map<String, String> response = new HashMap<>();
        Optional<Problem> problem = problemRepository.findById(problemId);
        if (problem.isPresent()) {
            Problem found = problem.get();
            int topicId = found.getTopic().getTopicId();
            Optional<Topic> topicOptional = topicRepository.findById(topicId);
            if (topicOptional.isPresent()) {
                Topic foundSubTopic = topicOptional.get();
                response.put("subTopic", foundSubTopic.getTitle());
                Optional<MainTopic> mainTopicOptional = mainTopicRepository
                        .findById(foundSubTopic.getMainTopic().getMainTopicId());
                if (mainTopicOptional.isPresent()) {
                    MainTopic mainTopic = mainTopicOptional.get();
                    response.put("mainTopic", mainTopic.getTitle());
                }
            }
        }
        return response;
    }
}
