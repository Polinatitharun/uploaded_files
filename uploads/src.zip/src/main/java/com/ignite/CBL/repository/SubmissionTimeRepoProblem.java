package com.ignite.CBL.repository;

import com.ignite.CBL.entity.UserProblemEngagement;
import com.ignite.CBL.entity.UserProblemEngagementId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubmissionTimeRepoProblem extends JpaRepository<UserProblemEngagement, UserProblemEngagementId> {
    @Query("""
            SELECT COALESCE(SUM(a.totalSecondsSpent), 0)
                   FROM UserProblemEngagement a
                   WHERE a.problem.problemId = :problemId
            """)
    Integer findTotalTimeSpentForProblem(@Param("problemId") Integer problemId);
}
