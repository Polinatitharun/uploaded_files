
package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LanguageLeaderboardDto {
    private String language;
    private Long viewed;
    private Long mcqPassed;
    private Long codingCompleted;
    private Long topicCompleted;
}
