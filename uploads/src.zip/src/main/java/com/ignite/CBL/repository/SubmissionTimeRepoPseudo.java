package com.ignite.CBL.repository;

import com.ignite.CBL.entity.PseudocodeSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubmissionTimeRepoPseudo extends JpaRepository<PseudocodeSubmission,Integer> {
    @Query("""
            SELECT COALESCE(SUM(a.totalSecondSpent), 0)
                   FROM PseudocodeSubmission a
                   WHERE a.problem.problemId = :problemId
            """)
    Integer findTotalTimeSpentForPseudo(@Param("problemId") Integer problemId);
}
