package com.ignite.CBL.controller;

import com.ignite.CBL.dto.SubmissionTimeResponse;
import com.ignite.CBL.service.impl.SubmissionTimeServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sme/submission-time")
public class SubmissionTimeController {

    private SubmissionTimeServiceImpl submissionTimeServiceImpl;

    SubmissionTimeController(SubmissionTimeServiceImpl submissionTimeServiceImpl){
        this.submissionTimeServiceImpl=submissionTimeServiceImpl;
    }

    @GetMapping("/get")
    public ResponseEntity<SubmissionTimeResponse> getSubmission(@RequestParam("problem_id") Integer ProblemId){
        return ResponseEntity.status(200).body(submissionTimeServiceImpl.getAllTime(ProblemId));
    }
}
