package com.ignite.CBL.controller;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.repository.ProblemSubmissionRepository;
import com.ignite.CBL.service.ProblemHintService;
import com.ignite.CBL.service.ProblemSubmissionService;
import com.ignite.CBL.utils.AppUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.time.Duration;
import java.time.LocalDateTime;



@RestController
@RequestMapping("/user/problem-submissions")
@RequiredArgsConstructor
@Tag(name = "Problem Submission", description = "Problem submission and code execution APIs")
public class ProblemSubmissionController {

    private final ProblemSubmissionService problemSubmissionService;
    private final ProblemHintService problemHintService;
    private final ProblemSubmissionRepository problemSubmissionRepository;


    @Value("${submission.cooldown.seconds:60}")
    private int cooldownSeconds;


    @GetMapping("/{problemId}/hint")
    @Operation(summary = "Get problem hint", description = "Retrieves or generates a problem hint from the LLM API and caches it in the database.")
    public ResponseEntity<ProblemHintResponseDTO> getHint(@PathVariable Integer problemId) {
        ProblemHintResponseDTO hint = problemHintService.getHintForProblem(problemId);
        return ResponseEntity.ok(hint);
    }

    @GetMapping("/{problemId}")
    @Operation(summary = "Get problem to solve", description = "Retrieves problem details with saved code and time spent. Requires correct algorithm and pseudocode submissions.")
    public ResponseEntity<ProblemCodeResponceDTO> getProblemToSolve(@PathVariable Integer problemId) {
        ProblemCodeResponceDTO response = problemSubmissionService.getProblemToSolve(problemId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{problemId}/submissions")
    @Operation(summary = "Get all submissions for a problem", description = "Retrieves all problem submissions for a specific problem and user")
    public ResponseEntity<List<ProblemSubmissionResponceDTO>> getAllSubmissions(@PathVariable Integer problemId) {
        List<ProblemSubmissionResponceDTO> response = problemSubmissionService.getAllSubmissions(problemId);
        return ResponseEntity.ok(response);
    }

//    @PutMapping("/submission")
//    @Operation(summary = "Save problem submission", description = "Saves or updates a problem submission with code, test result")
//    public ResponseEntity<Boolean> saveSubmission(@Valid @RequestBody ProblemSubmissionRequestDTO problemSubmissionRequestDTO) {
//        boolean result = problemSubmissionService.saveSubmission(problemSubmissionRequestDTO);
//        return ResponseEntity.ok(result);
//    }



    @PutMapping("/submission")
    @Operation(summary = "Save problem submission", description = "Saves or updates a problem submission with code, test result; backend enforces cooldown")
    public ResponseEntity<SubmissionResponseDTO> saveSubmission(
            @Valid @RequestBody ProblemSubmissionRequestDTO dto) {

        final String userId = AppUtils.getCurrentUserId();
        final LocalDateTime now = LocalDateTime.now();

        // ---- Choose policy: per-language or any-language ----
        // Per-language:
        var lastOpt = problemSubmissionRepository
                .findTopByProblem_ProblemIdAndUser_UserIdAndLanguageOrderBySubmittedAtDesc(
                        dto.getProblemId(), userId, dto.getLanguage());

        // If you prefer any-language cooldown, replace the above with:
        // var lastOpt = problemSubmissionRepository
        //        .findTopByProblem_ProblemIdAndUser_UserIdOrderBySubmittedAtDesc(
        //                dto.getProblemId(), userId);

        if (lastOpt.isPresent()) {
            var last = lastOpt.get().getSubmittedAt();
            if (last != null) {
                long elapsedSec = Duration.between(last, now).getSeconds();
                long remaining = cooldownSeconds - elapsedSec;
                if (remaining > 0) {
                    long cooldownUntilMillis = System.currentTimeMillis() + remaining * 1000L;
                    return ResponseEntity.status(429)
                            .header("Retry-After", String.valueOf(remaining))
                            .body(new SubmissionResponseDTO(
                                    false,
                                    "Please wait " + remaining + " seconds before submitting again.",
                                    cooldownUntilMillis
                            ));
                }
            }
        }

        // Not in cooldown → proceed to save
        boolean ok = problemSubmissionService.saveSubmission(dto);

        // Optional: return next allowed time for display (not for blocking)
        long nextAllowedMillis = System.currentTimeMillis() + cooldownSeconds * 1000L;
        return ResponseEntity.ok(new SubmissionResponseDTO(
                ok,
                ok ? "Submission saved." : "Submission skipped (already solved and new one incorrect).",
                nextAllowedMillis
        ));
    }

        @PutMapping("/save-code")
    @Operation(summary = "Save code and time", description = "Saves the current code and time spent on a problem")
    public ResponseEntity<Void> saveCodeAndTime(@Valid @RequestBody SaveCodeAndTimeRequest saveCodeAndTimeRequest) {
        problemSubmissionService.saveCodeAndTime(saveCodeAndTimeRequest);
        return ResponseEntity.ok().build();
    }
    @Operation(
            summary = "Get main topic problem",
            description = "Get the problem associated with a main topic (covers all subtopics)"
    )
    @GetMapping("/main-topic")
    public ProblemCodeResponceDTO getMainTopicProblem(
            @Parameter(description = "ID of the main topic") @RequestParam Integer mainTopicId) {
        return problemSubmissionService.getMainTopicProblem(mainTopicId);
    }
    
    @Operation(summary = "Get all problems",
            description = "Get a list of all problems with their topics Optional ")
    @GetMapping("/all")
    public ResponseEntity<List<MainTopicSubTopicsResponceDTO>> getAllProblems() {
        return ResponseEntity.ok(problemSubmissionService.getAllProblems());
    }




}