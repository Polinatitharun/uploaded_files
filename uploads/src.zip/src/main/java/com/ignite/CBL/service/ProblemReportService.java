package com.ignite.CBL.service;

import com.ignite.CBL.entity.problem.Problem;
import com.ignite.CBL.entity.user.User;

public interface ProblemReportService {
    void generateInsightAsync(User user, Problem problem);
}