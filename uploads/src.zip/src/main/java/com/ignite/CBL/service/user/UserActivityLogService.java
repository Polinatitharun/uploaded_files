package com.ignite.CBL.service.user;

public interface UserActivityLogService {
    public void log(String keycloakId,String username,String action,
                    String endpoint,String method,String ip);
}
