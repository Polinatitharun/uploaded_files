package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SimpleOptionDto {
    private Integer id;
    private String title;
}
