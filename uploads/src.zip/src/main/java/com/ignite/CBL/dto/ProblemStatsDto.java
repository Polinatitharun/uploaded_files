
package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProblemStatsDto {
    private String language;
    private Long attempts;
    private Long solved;
    private Double avgTime;
}
