package com.ignite.CBL.service.user.Impl;

import com.ignite.CBL.entity.user.UserActivityLog;
import com.ignite.CBL.repository.user.UserActivityLogRepository;
import com.ignite.CBL.service.user.UserActivityLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class UserActivityLogServiceImpl implements UserActivityLogService {

    @Autowired
    private UserActivityLogRepository userActivityLogRepository;

    @Override
    public void log(String keycloakId,String username,String action,String endpoint,String method,String ip){

        UserActivityLog userActivityLog=UserActivityLog.builder()
        .keycloakId(keycloakId)
        .username(username)
        .action(action)
        .endpoint(endpoint)
        .httpMethod(method)
        .ipAddress(ip)
        .timestamp(LocalDateTime.now())
        .build();

        userActivityLogRepository.save(userActivityLog);

    }
}
