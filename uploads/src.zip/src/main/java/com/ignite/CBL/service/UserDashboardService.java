package com.ignite.CBL.service;

import com.ignite.CBL.dto.user.UserDashboardResponceDTO;
import com.ignite.CBL.dto.user.UserProblemStats;

import java.util.List;
import java.util.Map;

public interface UserDashboardService {
    UserDashboardResponceDTO getUserDashboard();
    List<UserDashboardResponceDTO> getAllUsersDashboard();
    public Map<String, Object> getUserDashboardStats();
    public List<UserProblemStats> getAllUsersWithProblemStats();
    public Map<String, Object> getUserDashboardStats(String userId);



}
