package com.ignite.CBL.service.problem.Impl;

import com.ignite.CBL.dto.problem.ProblemAssistanceRequestDto;
import com.ignite.CBL.dto.problem.ProblemAssistanceDto;
import com.ignite.CBL.dto.problem.ProblemAssistanceResponseDto;
import com.ignite.CBL.entity.problem.Problem;
import com.ignite.CBL.entity.problem.ProblemAssistances;
import com.ignite.CBL.repository.ProblemAssistanceRepository;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.service.problem.ProblemAssistanceService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.isAllEmpty;


@Service
@Transactional
@RequiredArgsConstructor
public class ProblemAssistanceServiceImpl implements ProblemAssistanceService {

    @Autowired
    private final ProblemAssistanceRepository assistanceRepo;
    @Autowired
    private final ProblemRepository problemRepo;





    @Override
    public ResponseEntity<?> create(Integer problemId, ProblemAssistanceRequestDto request) {
        if (problemId == null) {
            return ResponseEntity.badRequest().body("Problem id is required.");
        }

        if (isAllEmpty(request.getHint(), request.getBreakdown(),
                request.getConceptExplanation(), request.getPartialSolution())) {
            return ResponseEntity.badRequest().body("Provide at least one of: hint, breakdown, conceptExplanation, partialSolution");
        }

        Problem problem = problemRepo.findById(problemId).orElse(null);
        if (problem == null) {
            return (ResponseEntity<?>) ResponseEntity.status(HttpStatus.NOT_FOUND).body("Problem not found.");
        }

        Optional<ProblemAssistances> existing = assistanceRepo.findAssistanceByProblem(problem);
        if (existing.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Problem assistance already exists.");
        }

        // 3) Build and save entity
        ProblemAssistances entity = new ProblemAssistances();
        entity.setProblem(problem);
        entity.setHint(trimToNull(request.getHint()));
        entity.setBreakdown(trimToNull(request.getBreakdown()));
        entity.setConcept_explanation(trimToNull(request.getConceptExplanation()));
        entity.setPartial_solution(trimToNull(request.getPartialSolution()));

        ProblemAssistances saved = assistanceRepo.save(entity);

        ProblemAssistanceResponseDto body = new ProblemAssistanceResponseDto();
        body.setMessage("Problem assistance created successfully");
        body.setProblem(toResponse(saved));
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }


    @Override
    public ResponseEntity<?> getProblemAssistance(Integer problemId){
        Optional<Problem> problem=problemRepo.findById(problemId);
        if(problem.isPresent()){
            Problem saveProblem=problem.get();
            Optional<ProblemAssistances> problemAssistance= assistanceRepo.findAssistanceByProblem(saveProblem);
            if(problemAssistance.isPresent()) {
                ProblemAssistanceResponseDto response=new ProblemAssistanceResponseDto();
                response.setProblem(toResponse(problemAssistance.get()));
                response.setMessage("Problem assistance found.");

                return ResponseEntity.status(200).body(response);
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Problem found but for this problem no assistance available.");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Problem not found.");
    }




        @Override
        @Transactional
        public ResponseEntity<?> update(Integer problemId, ProblemAssistanceRequestDto request) {
            Problem problem = problemRepo.findById(problemId)
                    .orElse(null);
            if (problem == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Problem not found.");
            }

            // Fetch assistance for this problem
            Optional<ProblemAssistances> assistanceOpt = assistanceRepo.findAssistanceByProblem(problem);
            if (assistanceOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Problem found but for this problem no assistance available.");
            }

            ProblemAssistances assistance = assistanceOpt.get();

            boolean changed = applyUpdates(assistance, request);

            if (!changed) {
                ProblemAssistanceResponseDto response = new ProblemAssistanceResponseDto();
                response.setProblem(toResponse(assistance));
                response.setMessage("No changes detected; assistance remains the same.");
                return ResponseEntity.ok(response);
            }

            assistance = assistanceRepo.save(assistance);

            ProblemAssistanceResponseDto response = new ProblemAssistanceResponseDto();
            response.setProblem(toResponse(assistance));
            response.setMessage("Problem assistance updated successfully.");

            return ResponseEntity.ok(response);
        }


    @Override
    @Transactional
    public ResponseEntity<?> delete(Integer problemId) {
        Optional<Problem> problem=problemRepo.findById(problemId);
        if (problem.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Problem not found");
        }

        Optional<ProblemAssistances> exist=assistanceRepo.findAssistanceByProblem(problem.get());

        if(exist.isPresent()){
            assistanceRepo.delete(exist.get());
            return ResponseEntity.ok("Problem Assistance deleted successfully");
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No Problem Assistance found to delete");
    }

    private boolean applyUpdates(ProblemAssistances entity, ProblemAssistanceRequestDto req) {
            boolean changed = false;

            if (req.getHint() != null && equalsSafe(entity.getHint(), req.getHint())) {
                entity.setHint(req.getHint());
                changed = true;
            }
            if (req.getBreakdown() != null && equalsSafe(entity.getBreakdown(), req.getBreakdown())) {
                entity.setBreakdown(req.getBreakdown());
                changed = true;
            }
            if (req.getConceptExplanation() != null && equalsSafe(entity.getConcept_explanation(), req.getConceptExplanation())) {
                entity.setConcept_explanation(req.getConceptExplanation());
                changed = true;
            }
            if (req.getPartialSolution() != null && equalsSafe(entity.getPartial_solution(), req.getPartialSolution())) {
                entity.setPartial_solution(req.getPartialSolution());
                changed = true;
            }
            return changed;
        }

        private boolean equalsSafe(String a, String b) {
            return (a != null || b != null) && (a == null || !a.equals(b));
        }


    private String trimToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private String customResponse(ProblemAssistanceDto problemAssistanceResponseDto){
        Map<String, ProblemAssistanceDto> responseDtoMap=new HashMap<>();
        responseDtoMap.put("Problem",problemAssistanceResponseDto);
        return responseDtoMap.toString();
    }

    private ProblemAssistanceDto toResponse(ProblemAssistances e) {
        ProblemAssistanceDto response=new ProblemAssistanceDto();
        response.setAssistanceId(e.getAssistance_id());
        response.setProblemId(e.getProblem().getProblemId());
        response.setHint(e.getHint());
        response.setConceptExplanation(e.getConcept_explanation());
        response.setBreakdown(e.getBreakdown());
        response.setPartialSolution(e.getPartial_solution());
        return response;
    }
}