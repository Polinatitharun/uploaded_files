package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.SubmissionTimeResponse;
import com.ignite.CBL.repository.SubmissionTimeRepoAlgo;
import com.ignite.CBL.repository.SubmissionTimeRepoProblem;
import com.ignite.CBL.repository.SubmissionTimeRepoPseudo;
import com.ignite.CBL.service.SubmissionTimeService;
import org.springframework.stereotype.Service;

@Service
public class SubmissionTimeServiceImpl implements SubmissionTimeService {

    private final SubmissionTimeRepoAlgo submissionTimeRepoAlgo;
    private final SubmissionTimeRepoPseudo submissionTimeRepoPseudo;
    private final SubmissionTimeRepoProblem submissionTimeRepoProblem;

    public SubmissionTimeServiceImpl(SubmissionTimeRepoAlgo submissionTimeRepoAlgo, SubmissionTimeRepoPseudo submissionTimeRepoPseudo, SubmissionTimeRepoProblem submissionTimeRepoProblem) {
        this.submissionTimeRepoAlgo = submissionTimeRepoAlgo;
        this.submissionTimeRepoPseudo = submissionTimeRepoPseudo;
        this.submissionTimeRepoProblem = submissionTimeRepoProblem;
    }

    @Override
    public SubmissionTimeResponse getAllTime(Integer ProblemId) {
        SubmissionTimeResponse obj=new SubmissionTimeResponse();

        obj.setAlgoTIme(submissionTimeRepoAlgo.findTotalTimeSpentForAlgo(ProblemId));
        obj.setProblemTime(submissionTimeRepoProblem.findTotalTimeSpentForProblem(ProblemId));
        obj.setPseudocodeTime(submissionTimeRepoPseudo.findTotalTimeSpentForPseudo(ProblemId));
        return obj;
    }
}
