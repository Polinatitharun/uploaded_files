package com.ignite.CBL.entity.user;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "user_details")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class UserDetails {

    @Id
    @Column(name = "keycloak_id", unique = true, nullable = false)
    private String keycloakId;

    @Column(name = "username")
    private String username;

    @Column(name = "email")
    private String email;
}
