package com.ignite.CBL.dto;

import com.ignite.CBL.entity.SavedCodes;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class SaveCodeAndTimeRequest {
    private Integer problemId;
    private SavedCodes savedCodes;


    private Long javaTimeSeconds;
    private Long pythonTimeSeconds;
    private Long javascriptTimeSeconds;
    private Long typescriptTimeSeconds;
}