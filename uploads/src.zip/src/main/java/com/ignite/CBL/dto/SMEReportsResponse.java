
package com.ignite.CBL.dto;

import lombok.Data;
import java.util.List;

@Data
public class SMEReportsResponse {
    private BatchSummaryDto summary;
    private List<LanguageLeaderboardDto> languageLeaderboard;
    private List<TopicFunnelDto> topicFunnel;
    private List<ProblemStatsDto> problemStats;
    private List<DropoffDto> dropoff;
    private List<TraineeProgressDto> traineeProgress;
}
