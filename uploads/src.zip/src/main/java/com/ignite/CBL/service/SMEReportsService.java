//
//package com.ignite.CBL.service;
//
//import com.ignite.CBL.dto.*;
//import com.ignite.CBL.entity.LanguageDto;
//import com.ignite.CBL.entity.view.MainTopicLanguageAverageView;
//import com.ignite.CBL.entity.view.TopicProblemLanguageAverageView;
//import com.ignite.CBL.repository.*;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.util.*;
//
//
//@Service
//@RequiredArgsConstructor
//public class SMEReportsService {
//
//    private final UserRepository userRepo;
//    private final UserMainTopicEngagementRepository mainRepo;
//    private final MainTopicLanguageAverageViewRepository langRepo;
//    private final UserTopicEngagementRepository topicRepo;
//    private final TopicProblemLanguageAverageViewRepository problemViewRepo;
//    private final UserProblemReportRepository problemReportRepo;
//    private final TopicRepository topicRepoSecond;
//    private final ProblemRepository problemRepo;
//    public SMEReportsResponse buildReport(String batch, LocalDate date, Integer problemId) {
//
//        SMEReportsResponse res = new SMEReportsResponse();
//
//
//
//        TopicFunnelDto javaFunnel = topicRepo.javaFunnel(batch);
//
//        res.setTopicFunnel(
//                javaFunnel != null ? List.of(javaFunnel) : List.of()
//        );
//
//
//        // 1️⃣ Active trainees = ALL users in batch
//        Long activeTrainees = userRepo.countUsersByBatch(batch);
//
//        // 2️⃣ Other metrics from engagement
//        BatchSummaryDto engagementSummary =
//                mainRepo.getBatchSummary(batch, date);
//
//        Long topicsCompleted =
//                engagementSummary != null ? engagementSummary.getTopicsCompleted() : 0L;
//
//        Double avgTimeSpent =
//                engagementSummary != null ? engagementSummary.getAvgTimeSpent() : 0.0;
//
//        // 3️⃣ Final summary
//        res.setSummary(
//                new BatchSummaryDto(
//                        activeTrainees != null ? activeTrainees : 0L,
//                        topicsCompleted,
//                        avgTimeSpent
//                )
//        );
//
//        // 4️⃣ LanguageDto leaderboard (already fixed)
//        MainTopicLanguageAverageView v =
//                langRepo.findAll().stream().findFirst().orElse(null);
//
//        res.setLanguageLeaderboard(List.of(
//                new LanguageLeaderboardDto("JAVA",
//                        v != null ? v.getJavaCompletedCount() : 0L,
//                        v != null ? v.getJavaCompletedCount() : 0L,
//                        v != null ? v.getJavaCompletedCount() : 0L,
//                        v != null ? v.getJavaCompletedCount() : 0L),
//                new LanguageLeaderboardDto("PYTHON",
//                        v != null ? v.getPythonCompletedCount() : 0L,
//                        v != null ? v.getPythonCompletedCount() : 0L,
//                        v != null ? v.getPythonCompletedCount() : 0L,
//                        v != null ? v.getPythonCompletedCount() : 0L),
//                new LanguageLeaderboardDto("JAVASCRIPT",
//                        v != null ? v.getJavascriptCompletedCount() : 0L,
//                        v != null ? v.getJavascriptCompletedCount() : 0L,
//                        v != null ? v.getJavascriptCompletedCount() : 0L,
//                        v != null ? v.getJavascriptCompletedCount() : 0L),
//                new LanguageLeaderboardDto("TYPESCRIPT",
//                        v != null ? v.getTypescriptCompletedCount() : 0L,
//                        v != null ? v.getTypescriptCompletedCount() : 0L,
//                        v != null ? v.getTypescriptCompletedCount() : 0L,
//                        v != null ? v.getTypescriptCompletedCount() : 0L)
//        ));
//
//        // 5️⃣ Safe defaults
//
//
//
//        List<TopicFunnelDto> funnel = List.of(
//                topicRepo.javaFunnel(batch),
//                topicRepo.pythonFunnel(batch),
//                topicRepo.javascriptFunnel(batch),
//                topicRepo.typescriptFunnel(batch)
//        );
//
//        res.setTopicFunnel(
//                funnel.stream()
//                        .filter(f -> f != null)
//                        .toList()
//        );
//
//
//
//        List<TopicProblemLanguageAverageView> views =
//                problemViewRepo.findByProblem(
//                        problemId != null ? Integer.valueOf(problemId) : null
//                );
//
//        List<ProblemStatsDto> stats = new ArrayList<>();
//
//        for (TopicProblemLanguageAverageView f : views) {
//
//            stats.add(new ProblemStatsDto(
//                    "JAVA",
//                    f.getJavaCompletedCount(),
//                    f.getJavaCompletedCount(),
//                    f.getAvgJavaTime() * 1000 // seconds → ms
//            ));
//
//            stats.add(new ProblemStatsDto(
//                    "PYTHON",
//                    f.getPythonCompletedCount(),
//                    f.getPythonCompletedCount(),
//                    v.getAvgPythonTime() * 1000
//            ));
//
//            stats.add(new ProblemStatsDto(
//                    "JAVASCRIPT",
//                    f.getJavascriptCompletedCount(),
//                    f.getJavascriptCompletedCount(),
//                    v.getAvgJavascriptTime() * 1000
//            ));
//
//            stats.add(new ProblemStatsDto(
//                    "TYPESCRIPT",
//                    f.getTypescriptCompletedCount(),
//                    f.getTypescriptCompletedCount(),
//                    v.getAvgTypescriptTime() * 1000
//            ));
//        }
//
//        res.setProblemStats(stats);
//
//
//        DropoffDto viewed = topicRepo.viewed(batch);
//        DropoffDto mcqPassed = topicRepo.mcqPassed(batch);
//        DropoffDto completed = topicRepo.completed(batch);
//
//        res.setDropoff(
//                List.of(viewed, mcqPassed, completed)
//                        .stream()
//                        .filter(d -> d != null)
//                        .toList()
//        );
//
//
//
//        List<TraineeProgressQueryDto> base =
//                topicRepo.fetchTraineeProgressRaw(batch);
//
//        Map<String, Set<LanguageDto>> languageMap = new HashMap<>();
//
//        for (Object[] row : problemReportRepo.fetchLanguagesUsed(batch)) {
//            String userId = (String) row[0];
//            Set<LanguageDto> langs = (Set<LanguageDto>) row[1];
//
//            languageMap
//                    .computeIfAbsent(userId, k -> new HashSet<>())
//                    .addAll(langs);
//        }
//
//        List<TraineeProgressDto> finalResult = new ArrayList<>();
//
//        for (TraineeProgressQueryDto q : base) {
//            long langCount = languageMap
//                    .getOrDefault(q.getTraineeId(), Set.of())
//                    .size();
//
//            finalResult.add(
//                    new TraineeProgressDto(
//                            q.getTraineeId(),
//                            q.getTopicsCompleted(),
//                            q.getAvgTimeMs(),
//                            langCount,
//                            q.getParallelActivity()
//                    )
//            );
//        }
//
//        res.setTraineeProgress(finalResult);
//
//
//
//        return res;
//    }
//    public FiltersMetaDto getFilters(Integer topicId)
//    {
//        List<String> batches=userRepo.findDistinctBatches();
//        List<SimpleOptionDto> topics=topicRepoSecond.findAllTopics();
//        List<SimpleOptionDto> problems=problemRepo.findProblemsByTopic(topicId);
//
//        return new FiltersMetaDto(batches,topics,problems);
//    }
//}
//



package com.ignite.CBL.service;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.view.MainTopicLanguageAverageView;
import com.ignite.CBL.entity.view.TopicProblemLanguageAverageView;
import com.ignite.CBL.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
public class SMEReportsService {

    private final UserRepository userRepo;
    private final UserMainTopicEngagementRepository mainRepo;
    private final MainTopicLanguageAverageViewRepository langRepo;
    private final UserTopicEngagementRepository topicRepo;
    private final TopicProblemLanguageAverageViewRepository problemViewRepo;
    private final UserProblemReportRepository problemReportRepo;
    private final TopicRepository topicRepoSecond;
    private final ProblemRepository problemRepo;

    public SMEReportsResponse buildReport(String batch, LocalDate date, Integer problemId) {

        SMEReportsResponse res = new SMEReportsResponse();

        /* =====================================================
           1️⃣ BATCH SUMMARY
        ===================================================== */

        Long activeTrainees = userRepo.countUsersByBatch(batch);

        BatchSummaryDto engagement =
                mainRepo.getBatchSummary(batch, date);

        BatchSummaryDto summary = new BatchSummaryDto(
                activeTrainees != null ? activeTrainees : 0L,
                engagement != null ? engagement.getTopicsCompleted() : 0L,
                engagement != null ? engagement.getAvgTimeSpent() : 0.0
        );

        /* -------- TRENDING TOPIC -------- */
        List<String> mostTopics = topicRepo.findTrendingTopicsDesc(batch);
        List<String> leastTopics = topicRepo.findTrendingTopicsAsc(batch);

        summary.setMostTrendingTopic(
                mostTopics.isEmpty() ? "N/A" : mostTopics.get(0)
        );
        summary.setLeastTrendingTopic(
                leastTopics.isEmpty() ? "N/A" : leastTopics.get(0)
        );

        /* -------- TRENDING LANGUAGE -------- */
        MainTopicLanguageAverageView v =
                langRepo.findAll().stream().findFirst().orElse(null);

        Map<String, Long> langMap = new HashMap<>();
        if (v != null) {
            langMap.put("JAVA", v.getJavaCompletedCount());
            langMap.put("PYTHON", v.getPythonCompletedCount());
            langMap.put("JAVASCRIPT", v.getJavascriptCompletedCount());
            langMap.put("TYPESCRIPT", v.getTypescriptCompletedCount());
        }

        summary.setMostTrendingLanguage(
                langMap.entrySet().stream()
                        .max(Map.Entry.comparingByValue())
                        .map(Map.Entry::getKey)
                        .orElse("N/A")
        );

        summary.setLeastTrendingLanguage(
                langMap.entrySet().stream()
                        .min(Map.Entry.comparingByValue())
                        .map(Map.Entry::getKey)
                        .orElse("N/A")
        );

        res.setSummary(summary);

        /* =====================================================
           2️⃣ LANGUAGE LEADERBOARD
        ===================================================== */

        if (v != null) {
            res.setLanguageLeaderboard(List.of(
                    new LanguageLeaderboardDto("JAVA",
                            v.getJavaCompletedCount(),
                            v.getJavaCompletedCount(),
                            v.getJavaCompletedCount(),
                            v.getJavaCompletedCount()),
                    new LanguageLeaderboardDto("PYTHON",
                            v.getPythonCompletedCount(),
                            v.getPythonCompletedCount(),
                            v.getPythonCompletedCount(),
                            v.getPythonCompletedCount()),
                    new LanguageLeaderboardDto("JAVASCRIPT",
                            v.getJavascriptCompletedCount(),
                            v.getJavascriptCompletedCount(),
                            v.getJavascriptCompletedCount(),
                            v.getJavascriptCompletedCount()),
                    new LanguageLeaderboardDto("TYPESCRIPT",
                            v.getTypescriptCompletedCount(),
                            v.getTypescriptCompletedCount(),
                            v.getTypescriptCompletedCount(),
                            v.getTypescriptCompletedCount())
            ));
        }

        /* =====================================================
           3️⃣ TOPIC FUNNEL
        ===================================================== */

        res.setTopicFunnel(
                List.of(
                        topicRepo.javaFunnel(batch),
                        topicRepo.pythonFunnel(batch),
                        topicRepo.javascriptFunnel(batch),
                        topicRepo.typescriptFunnel(batch)
                ).stream().filter(Objects::nonNull).toList()
        );

        /* =====================================================
           4️⃣ PROBLEM STATS
        ===================================================== */

        List<TopicProblemLanguageAverageView> views =
                problemViewRepo.findByProblem(problemId);

        List<ProblemStatsDto> stats = new ArrayList<>();

        for (TopicProblemLanguageAverageView f : views) {

            stats.add(new ProblemStatsDto(
                    "JAVA",
                    f.getJavaCompletedCount(),
                    f.getJavaCompletedCount(),
                    f.getAvgJavaTime() * 1000
            ));
            stats.add(new ProblemStatsDto(
                    "PYTHON",
                    f.getPythonCompletedCount(),
                    f.getPythonCompletedCount(),
                    f.getAvgPythonTime() * 1000
            ));
            stats.add(new ProblemStatsDto(
                    "JAVASCRIPT",
                    f.getJavascriptCompletedCount(),
                    f.getJavascriptCompletedCount(),
                    f.getAvgJavascriptTime() * 1000
            ));
            stats.add(new ProblemStatsDto(
                    "TYPESCRIPT",
                    f.getTypescriptCompletedCount(),
                    f.getTypescriptCompletedCount(),
                    f.getAvgTypescriptTime() * 1000
            ));
        }

        res.setProblemStats(stats);

        /* =====================================================
           5️⃣ DROPOFF
        ===================================================== */

        res.setDropoff(
                List.of(
                        topicRepo.viewed(batch),
                        topicRepo.mcqPassed(batch),
                        topicRepo.completed(batch)
                ).stream().filter(Objects::nonNull).toList()
        );

        /* =====================================================
           6️⃣ TRAINEE PROGRESS
        ===================================================== */

        List<TraineeProgressQueryDto> base =
                topicRepo.fetchTraineeProgressRaw(batch);

        Map<String, Set<Language>> languageMap = new HashMap<>();

        for (Object[] row : problemReportRepo.fetchLanguagesUsed(batch)) {
            languageMap
                    .computeIfAbsent((String) row[0], k -> new HashSet<>())
                    .addAll((Set<Language>) row[1]);
        }

        List<TraineeProgressDto> traineeProgress = new ArrayList<>();

        for (TraineeProgressQueryDto q : base) {
            traineeProgress.add(
                    new TraineeProgressDto(
                            q.getTraineeId(),
                            Long.valueOf(q.getTopicsCompleted()),
                            q.getAvgTimeMs(),
                            Long.valueOf(languageMap
                                    .getOrDefault(q.getTraineeId(), Set.of())
                                    .size()),
                            Long.valueOf(q.getParallelActivity())
                    )


            );
        }

        res.setTraineeProgress(traineeProgress);

        return res;
    }

    /* =====================================================
       FILTERS
    ===================================================== */

    public FiltersMetaDto getFilters(Integer topicId) {

        return new FiltersMetaDto(
                userRepo.findDistinctBatches(),
                topicRepoSecond.findAllTopics(),
                problemRepo.findProblemsByTopic(topicId)
        );
    }
}
