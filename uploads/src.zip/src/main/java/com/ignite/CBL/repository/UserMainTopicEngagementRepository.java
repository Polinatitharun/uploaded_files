package com.ignite.CBL.repository;

import com.ignite.CBL.dto.BatchSummaryDto;
import com.ignite.CBL.entity.*;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface UserMainTopicEngagementRepository extends JpaRepository<UserMainTopicEngagement, UserMainTopicEngagementId> {
    
    Optional<UserMainTopicEngagement> findByUser_UserIdAndMainTopic_MainTopicId(String userId, Integer mainTopicId);
    
    boolean existsByUser_UserIdAndMainTopic_MainTopicId(String userId, Integer maintopicId);
    
//    @Modifying
//    @Transactional
//    @Query("DELETE FROM UserTopicEngagement ute WHERE ute.topic.topicId = :topicId")
//    void deleteByTopicId(@Param("topicId") Integer topicId);


    @Query("""
 SELECT new com.ignite.CBL.dto.BatchSummaryDto(
   COUNT(DISTINCT e.user.userId),
   COALESCE(SUM(CASE WHEN e.isCompleted = true THEN 1 ELSE 0 END), 0),
   COALESCE(AVG(e.totalTimeSpent), 0)
 )
 FROM UserMainTopicEngagement e
 WHERE e.user.batch = :batch
 AND DATE(e.lastActivityAt) = :date
""")
    BatchSummaryDto getBatchSummary(
            @Param("batch") String batch,
            @Param("date") LocalDate date
    );

}
