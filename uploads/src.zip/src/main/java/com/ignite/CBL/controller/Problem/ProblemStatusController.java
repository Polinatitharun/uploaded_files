package com.ignite.CBL.controller.Problem;


import com.ignite.CBL.dto.problem.ProblemStatusResponseDto;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.service.problem.ProblemStatusService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/problems")
@RequiredArgsConstructor
public class ProblemStatusController {

    @Autowired
    private final ProblemStatusService service;


    @GetMapping("/")
    public ResponseEntity<ProblemStatusResponseDto> QuestionsWithStatus() {
        return service.getQuestionsWithStatus();
    }

    @GetMapping("/active")
    public ResponseEntity<ProblemStatusResponseDto> QuestionWithActiveStatus(){
        return service.getQuestionsWithActiveStatus();
    }

    /**
     * Get paginated problems with user-specific status and filters
     *
     * Example:
     * GET /api/v1/problems?page=1&size=20&topic=Arrays&difficulty=EASY&isSolved=true&active=true
     */
    @GetMapping("/filter")
    public ResponseEntity<ProblemStatusResponseDto> getProblemsWithStatus(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "7") int size,
            @RequestParam(required = false) String mainTopic,
            @RequestParam(required = false) String subTopic,
            @RequestParam(required = false) Difficulty difficulty,
            @RequestParam(required = false) Boolean isSolved,
            @RequestParam(defaultValue = "true") Boolean active
    ) {
        return service.getQuestionsWithFilter(
                page,
                size,
                mainTopic,
                subTopic,
                difficulty,
                isSolved,
                active
        );
    }

    }
