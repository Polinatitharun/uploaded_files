package com.ignite.CBL.repository;

import com.ignite.CBL.entity.AlgorithmSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubmissionTimeRepoAlgo extends JpaRepository<AlgorithmSubmission,Integer> {
    @Query("""
            SELECT COALESCE(SUM(a.totalSecondSpent), 0)
                   FROM AlgorithmSubmission a
                   WHERE a.problem.problemId = :problemId
            """)
    Integer findTotalTimeSpentForAlgo(@Param("problemId") Integer problemId);
}
