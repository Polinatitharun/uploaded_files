package com.ignite.CBL.controller.Problem;

import com.ignite.CBL.dto.ProblemDTO;
import com.ignite.CBL.dto.WrapperProblemDTO;
import com.ignite.CBL.service.WrapperProblemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/sme/problems/wrapper")
public class WrapperProblemSMEController {

    @Autowired
    WrapperProblemService wrapperProblemService;

    @Operation(
            summary = "Get problem by ID",
            description = "Retrieves a problem by its unique identifier"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Problem found",
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))),
            @ApiResponse(responseCode = "404", description = "Problem not found")
    })
    @GetMapping(
            value = "/{problemId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<WrapperProblemDTO> getWrapperProblemById(
            @Parameter(description = "ID of the problem to be retrieved", required = true)
            @PathVariable Integer problemId) {
        WrapperProblemDTO problem = wrapperProblemService.fetchWrapperProblemById(problemId);
        return ResponseEntity.ok(problem);
    }




    @Operation(
            summary = "Create a new problem",
            description = "Creates a new problem for a specific topic"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Problem created successfully",
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input"),
            @ApiResponse(responseCode = "404", description = "Topic not found")
    })
    @PostMapping(
            value = "/topic/{topicId}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<WrapperProblemDTO> createProblem(
            @Parameter(description = "ID of the topic to add the problem to", required = true)
            @PathVariable Integer topicId,

            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Problem object that needs to be added",
                    required = true,
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))
            )
            @RequestBody WrapperProblemDTO problemDTO) {
        WrapperProblemDTO createdProblem = wrapperProblemService.saveProblem(topicId,problemDTO );
        return new ResponseEntity<>(createdProblem, HttpStatus.CREATED);
    }

}
