package com.ignite.CBL.dto.problem;


import lombok.*;

@Setter
@Getter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProblemAssistanceResponseDto {
    private String message;
    private ProblemAssistanceDto problem;


}
