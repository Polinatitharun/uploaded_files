package com.ignite.CBL.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class SubmissionResponseDTO {
    private boolean ok;
    private String message;
    private Long cooldownUntil; // epoch millis; null if not provided

    public boolean isOk() {
        return ok;
    }

    public String getMessage() {
        return message;
    }

    public Long getCooldownUntil() {
        return cooldownUntil;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setCooldownUntil(Long cooldownUntil) {
        this.cooldownUntil = cooldownUntil;
    }
}
