
package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
public class TopicFunnelDto {
    private String language;
    private Long viewed;
    private Long mcqPassed;
    private Long completed;
}
