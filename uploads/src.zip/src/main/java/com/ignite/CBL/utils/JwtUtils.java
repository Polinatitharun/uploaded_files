package com.ignite.CBL.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.springframework.security.oauth2.jwt.Jwt;

import java.time.Instant;
import java.util.*;

public class JwtUtils {

    public static List<String> extractRoles(String token, String clientId) {
        try {
            String[] parts = token.split("\\.");
            String payload = new String(Base64.getDecoder().decode(parts[1]));

            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> json = mapper.readValue(payload, Map.class);

            List<String> roles = new ArrayList<>();

            // 🔹 Realm roles
            Map<String, Object> realmAccess = (Map<String, Object>) json.get("realm_access");
            if (realmAccess != null && realmAccess.get("roles") != null) {
                roles.addAll((List<String>) realmAccess.get("roles"));
            }

            // 🔹 Client roles
            Map<String, Object> resourceAccess = (Map<String, Object>) json.get("resource_access");
            if (resourceAccess != null && resourceAccess.get(clientId) != null) {
                Map<String, Object> client =
                        (Map<String, Object>) resourceAccess.get(clientId);

                roles.addAll((List<String>) client.get("roles"));
            }

            return roles;

        } catch (Exception e) {
            throw new RuntimeException("Invalid JWT token");
        }
    }

    public static String extractUserId(String token) {
        Map<String, Object> json = JwtUtils.decodeToken(token);
        return (String) json.get("sub");
    }

    public static String extractUsername(String token) {
        Map<String, Object> json = JwtUtils.decodeToken(token);
        return (String) json.get("name");
    }

    public static String extractEmail(String token) {
        Map<String, Object> json = JwtUtils.decodeToken(token);
        return (String) json.get("email");
    }


    public static Map<String, Object> decodeToken(String token) {
        String[] parts = token.split("\\.");
        String payload = new String(Base64.getDecoder().decode(parts[1]));

        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(payload, Map.class);
        } catch (Exception e) {
            throw new RuntimeException("Invalid token", e);
        }
    }


    public static Jwt decode(String token) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(token);
            JWTClaimsSet claims = signedJWT.getJWTClaimsSet();

            Map<String, Object> claimsMap = claims.getClaims();

            Instant issuedAt = convertToInstant(claims.getIssueTime());
            Instant expiresAt = convertToInstant(claims.getExpirationTime());

            return new Jwt(
                    token,
                    issuedAt,
                    expiresAt,
                    Map.of("alg", signedJWT.getHeader().getAlgorithm().getName()),
                    claimsMap
            );

        } catch (Exception e) {
            throw new RuntimeException("Invalid JWT token", e);
        }
    }

    private static Instant convertToInstant(Date date) {
        return date != null ? date.toInstant() : null;
    }

}