package com.ignite.CBL.repository;

import com.ignite.CBL.entity.user.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
    Optional<User> findByUserId(String userId);
    @Query("""
            SELECT COUNT(u)
            FROM User u
            WHERE u.batch = :batch
            """)
    Long countUsersByBatch(@Param("batch") String batch);

    @Query("SELECT DISTINCT u.batch FROM User u WHERE u.batch IS NOT NULL")
    List<String> findDistinctBatches();
}
