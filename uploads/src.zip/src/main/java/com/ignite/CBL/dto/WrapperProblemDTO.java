package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.entity.problem.Wrapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WrapperProblemDTO {
    private Integer problemId;
    private String title;
    private String description;
    private Difficulty difficulty;
    private Set<ProblemTestCaseDTO> TestCases;
    private String createdUsing;
    private Wrapper wrapper;
//    private String wrapperCode;
    private JsonNode hint;

}
