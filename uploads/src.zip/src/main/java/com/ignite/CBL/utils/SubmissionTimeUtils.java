package com.ignite.CBL.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class SubmissionTimeUtils {

    // Formatter for microsecond precision: yyyy-MM-dd HH:mm:ss.SS
    private static final DateTimeFormatter INPUT_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-ddHH:mm:ss.SSSSSS");


    public static String getLastSubmissionTime(String ts1, String ts2, ZoneId zone) {
        LocalDateTime ldt1 = parseOrNull(ts1);
        LocalDateTime ldt2 = parseOrNull(ts2);

        if (ldt1 == null && ldt2 == null) return null;
        if (ldt1 == null) return ts2;
        if (ldt2 == null) return ts1;

        // Interpret both local date times in the same zone for a fair comparison
        ZonedDateTime zdt1 = ldt1.atZone(zone);
        ZonedDateTime zdt2 = ldt2.atZone(zone);

        return zdt1.isAfter(zdt2) ? ts1 : ts2;
    }

    private static LocalDateTime parseOrNull(String s) {
        if (s == null || s.trim().isEmpty()) return null;
        return LocalDateTime.parse(s.trim(), INPUT_FORMAT);
    }


}