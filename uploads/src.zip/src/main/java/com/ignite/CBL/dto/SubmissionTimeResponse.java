package com.ignite.CBL.dto;

import lombok.Data;


public class SubmissionTimeResponse {

    private Integer AlgoTIme;
    private Integer PseudocodeTime;
    private Integer ProblemTime;

    public Integer getAlgoTIme() {
        return AlgoTIme;
    }

    public Integer getPseudocodeTime() {
        return PseudocodeTime;
    }

    public Integer getProblemTime() {
        return ProblemTime;
    }

    public void setAlgoTIme(Integer algoTIme) {
        AlgoTIme = algoTIme;
    }

    public void setPseudocodeTime(Integer pseudocodeTime) {
        PseudocodeTime = pseudocodeTime;
    }

    public void setProblemTime(Integer problemTime) {
        ProblemTime = problemTime;
    }
}
