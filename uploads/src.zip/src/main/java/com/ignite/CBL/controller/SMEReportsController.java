
package com.ignite.CBL.controller;

import com.ignite.CBL.dto.FiltersMetaDto;
import com.ignite.CBL.dto.SMEReportsResponse;
import com.ignite.CBL.service.SMEReportsService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class SMEReportsController {

    private final SMEReportsService service;

    @GetMapping("/sme")
    public SMEReportsResponse getReport(
            @RequestParam String batch,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(required=false) Integer problemId
    ) {
        return service.buildReport(batch, date, problemId);
    }

    @GetMapping("/filters")
    public FiltersMetaDto getFilters(
            @RequestParam(required = false) Integer topicId
    ){
        return service.getFilters(topicId);
    }
}
