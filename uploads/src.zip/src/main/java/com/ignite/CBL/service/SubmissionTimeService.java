package com.ignite.CBL.service;

import com.ignite.CBL.dto.SubmissionTimeResponse;
import org.springframework.stereotype.Service;

@Service
public interface SubmissionTimeService {

    public SubmissionTimeResponse getAllTime(Integer ProblemId);
}
