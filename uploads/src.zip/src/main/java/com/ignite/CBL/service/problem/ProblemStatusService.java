package com.ignite.CBL.service.problem;

import com.ignite.CBL.dto.problem.ProblemStatusResponseDto;
import com.ignite.CBL.entity.Difficulty;
import org.springframework.http.ResponseEntity;

public interface ProblemStatusService {
    ResponseEntity<ProblemStatusResponseDto> getQuestionsWithStatus();
//
    ResponseEntity<ProblemStatusResponseDto> getQuestionsWithActiveStatus();

    ResponseEntity<ProblemStatusResponseDto> getQuestionsWithFilter(int page, int size, String mainTopic,String subTopic, Difficulty difficulty, Boolean isSolved, Boolean active);
}
