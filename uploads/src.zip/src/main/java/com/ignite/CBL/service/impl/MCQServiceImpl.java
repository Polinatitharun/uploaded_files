package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.entity.user.User;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.MCQService;
import com.ignite.CBL.utils.AppUtils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class MCQServiceImpl implements MCQService {

//    private String userId;

    private final MCQRepository mcqRepository;
    private final TopicRepository topicRepository;
    private final UserTopicEngagementRepository userTopicEngagementRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper = new ModelMapper();



    @Override
    public Optional<MCQDTO> findMCQById(Integer mcqId) {
        log.debug("Finding MCQ by id: {}", mcqId);
        return mcqRepository.findMCQDTOById(mcqId);
    }

    @Override
    @Transactional
    public List<MCQDTO> findAllMCQByTopicId(Integer topicId) {
        System.out.println("MCQServiceImpl.findAllMCQByTopicId");
        String userId = AppUtils.getCurrentUserId();
        System.out.println("This ia user id"+userId);

        log.debug("Finding all MCQs for topic id: {}", topicId);

        // ✅ Validate topic existence
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));


        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));


        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(user.getUserId(), topicId)
                .orElseGet(() -> createNewEngagement(user, topic));


        if (Boolean.FALSE.equals(engagement.getMcqVisited())) {
            engagement.setMcqVisited(true);
            engagement.setLastActivityAt(LocalDateTime.now());
            userTopicEngagementRepository.save(engagement);
            log.info("MCQs marked as visited for topic {} by user {}", topicId, user.getUserId());
        }


        return mcqRepository.findAllByTopicId(topicId);
    }
    private UserTopicEngagement createNewEngagement(User user, Topic topic) {
        UserTopicEngagement engagement = new UserTopicEngagement();
        UserTopicEngagementId id = new UserTopicEngagementId();
        id.setUserId(user.getUserId());
        id.setTopicId(topic.getTopicId());
        engagement.setUserTopicEngagementId(id);
        engagement.setUser(user);
        engagement.setTopic(topic);
        engagement.setLastActivityAt(LocalDateTime.now());
        engagement.setTotalTimeSpent(0);
        return userTopicEngagementRepository.save(engagement);
    }


    @Override
    public Page<MCQDTO> findPaginatedMCQByTopicId(Integer topicId, Pageable pageable) {
        log.debug("Finding paginated MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.findPaginatedByTopicId(topicId, pageable);
    }

    @Override
    public MCQDTO createMCQ(Integer topicId, MCQDTO mcqDTO) {
        log.debug("Creating new MCQ for topic id: {}", topicId);
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        MCQ mcq = new MCQ();
        mcq.setContent(mcqDTO.getContent());
        mcq.setTopic(topic);
        mcq.setLanguage(mcqDTO.getLanguage());
        
        return convertToDTO(mcqRepository.save(mcq));
    }

    @Override
    public int createMCQs(Integer topicId, List<MCQDTO> mcqDTOs) {
        log.debug("Creating {} MCQs for topic id: {}", mcqDTOs != null ? mcqDTOs.size() : 0, topicId);
        if (topicId == null || mcqDTOs == null || mcqDTOs.isEmpty()) {
            return 0;
        }

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        List<MCQ> mcqs = mcqDTOs.stream()
                .map(dto -> {
                    MCQ mcq = new MCQ();
                    mcq.setContent(dto.getContent());
                    mcq.setTopic(topic);
                    mcq.setLanguage(dto.getLanguage());
                    return mcq;
                })
                .toList();

        return mcqRepository.saveAll(mcqs).size();
    }

    @Override
    public Optional<MCQDTO> updateMCQ(Integer mcqId, MCQDTO mcqDTO) {
        log.debug("Updating MCQ with id: {}", mcqId);
        return mcqRepository.findById(mcqId)
                .map(existingMCQ -> {
                    existingMCQ.setContent(mcqDTO.getContent());
                    
                    if (mcqDTO.getTopicId() != null && 
                        !mcqDTO.getTopicId().equals(existingMCQ.getTopic().getTopicId())) {
                        Topic newTopic = topicRepository.findById(mcqDTO.getTopicId())
                                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + mcqDTO.getTopicId()));
                        existingMCQ.setTopic(newTopic);
                    }
                    
                    return convertToDTO(mcqRepository.save(existingMCQ));
                });
    }

    @Override
    public boolean deleteMCQById(Integer mcqId) {
        log.debug("Deleting MCQ with id: {}", mcqId);
        if (!mcqRepository.existsById(mcqId)) {
            return false;
        }
        mcqRepository.deleteById(mcqId);
        return true;
    }

    @Override
    public int deleteAllMCQByTopicId(Integer topicId) {
        log.debug("Deleting all MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.deleteAllByTopicId(topicId);
    }

    @Override
    public long countByTopicId(Integer topicId) {
        log.debug("Counting MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.countByTopic_TopicId(topicId);
    }

    @Override
    public boolean existsById(Integer mcqId) {
        return mcqRepository.existsByMcqId(mcqId);
    }
    @Override
    public List<MCQDTO> findAllMCQByTopicIdAndLanguage(Integer topicId, Language language) {
        log.debug("Finding all MCQs for topic id: {} and language: {}", topicId, language);

        String userId = AppUtils.getCurrentUserId();
        log.debug("Current User ID: {}", userId);

        // Validate topic
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        // Validate user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // Create or update engagement
        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(user.getUserId(), topicId)
                .orElseGet(() -> createNewEngagement(user, topic));

        if (Boolean.FALSE.equals(engagement.getMcqVisited())) {
            engagement.setMcqVisited(true);
            engagement.setLastActivityAt(LocalDateTime.now());
            userTopicEngagementRepository.save(engagement);
            log.info("MCQs marked as visited for topic {} and language {} by user {}", topicId, language, user.getUserId());
        }

        return mcqRepository.findAllByTopicIdAndLanguage(topicId, language);
    }

    @Override
    public long countByTopicIdAndLanguage(Integer topicId, Language language) {
        log.debug("Counting MCQs for topic id: {} and language: {}", topicId, language);

        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }

        return mcqRepository.countByTopicIdAndLanguage(topicId, language);
    }

    // Helper method to convert entity to DTO
    private MCQDTO convertToDTO(MCQ mcq) {
        MCQDTO dto = new MCQDTO();
        dto.setMcqId(mcq.getMcqId());
        dto.setContent(mcq.getContent());
        dto.setTopicId(mcq.getTopic().getTopicId());
        return dto;
    }
}


