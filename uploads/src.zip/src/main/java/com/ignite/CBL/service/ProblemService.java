package com.ignite.CBL.service;

import com.ignite.CBL.dto.ProblemCodeResponceDTO;
import com.ignite.CBL.dto.ProblemDTO;
import com.ignite.CBL.dto.WrapperProblemDTO;
import com.ignite.CBL.entity.Difficulty;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

public interface ProblemService {
    ProblemDTO saveProblem(Integer topicId,ProblemDTO problemDTO);
    List<ProblemDTO> saveProblemsByTopicId(Integer topicId, List<ProblemDTO> problemDTOs);
    void deleteProblemById(Integer problemId);
    int deleteProblemByTopicId(Integer topicId);
    ProblemDTO fetchProblemById(Integer problemId);
    List<ProblemDTO> fetchProblemsByTopicId(Integer topicId);

    ProblemDTO updateProblem(Integer problemId, @Valid ProblemDTO problemDTO);

}
