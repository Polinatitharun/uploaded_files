package com.ignite.CBL.dto.problem;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LanguageDto {
    @Builder.Default
    private boolean java=false;
    @Builder.Default
    private boolean python=false;
    @Builder.Default
    private boolean javascript=false;
    @Builder.Default
    private boolean typescript=false;
}
