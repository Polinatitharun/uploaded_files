package com.ignite.CBL.repository.user;

import com.ignite.CBL.entity.user.UserActivityLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserActivityLogRepository extends JpaRepository<UserActivityLog,Long> {
}
