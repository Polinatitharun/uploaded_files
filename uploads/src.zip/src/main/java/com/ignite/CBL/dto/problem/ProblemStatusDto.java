package com.ignite.CBL.dto.problem;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ProblemStatusDto {
    @JsonProperty("isSolved")
    private boolean solved;

    private int attempts;

    private int correctAttempts;
}