package com.ignite.CBL.repository;

import com.ignite.CBL.entity.PseudocodeSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PseudocodeSubmissionRepository extends JpaRepository<PseudocodeSubmission, Integer> {
    Optional<PseudocodeSubmission> findByProblem_ProblemIdAndUser_UserId(Integer problemId, String userId);
}
