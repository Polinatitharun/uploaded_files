package com.ignite.CBL.repository;

import com.ignite.CBL.entity.MainTopic;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MainTopicRepository extends JpaRepository<MainTopic, Integer> {
    Optional<MainTopic> findByTitle(String title);

//    Optional<>

}
