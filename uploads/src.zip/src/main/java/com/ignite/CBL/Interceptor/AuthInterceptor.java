package com.ignite.CBL.Interceptor;

import com.ignite.CBL.service.user.UserActivityLogService;
import com.ignite.CBL.utils.JwtUtils;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    private final RedisTemplate<String, Object> redisTemplate;

    @Autowired
    private UserActivityLogService userActivityService;

    public AuthInterceptor(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) {

        if (!(handler instanceof HandlerMethod method)) {
            return true;
        }

        // Extract SESSION_ID
        Cookie[] cookies = request.getCookies();

        if (cookies == null) {
            response.setStatus(401);
            return false;
        }

        String sessionId = Arrays.stream(cookies)
                .filter(c -> "SESSION_ID".equals(c.getName()))
                .findFirst()
                .map(Cookie::getValue)
                .orElse(null);

        if (sessionId == null) {
            response.setStatus(401);
            return false;
        }

        Object sessionObj = redisTemplate.opsForValue().get(sessionId);

        if (!(sessionObj instanceof Map)) {
            response.setStatus(401);
            return false;
        }

        Map<String, Object> session = (Map<String, Object>) sessionObj;

        // Refresh session TTL (sliding session)
        redisTemplate.expire(sessionId, Duration.ofMinutes(5));

        request.setAttribute("USER_SESSION", session);

        // Extract token
        String accessToken = (String) session.get("access_token");

        if (accessToken == null) {
            response.setStatus(401);
            return false;
        }

        String userId = JwtUtils.extractUserId(accessToken);
        String username = JwtUtils.extractUsername(accessToken);

        // Role check
        RoleRequired roleRequired = method.getMethodAnnotation(RoleRequired.class);

        if (roleRequired != null) {

            List<String> userRoles = (List<String>) session.get("roles");

            if (userRoles == null) {
                response.setStatus(403);
                return false;
            }

            boolean allowed = Arrays.stream(roleRequired.value())
                    .anyMatch(userRoles::contains);

            if (!allowed) {
                response.setStatus(403);
                return false;
            }
        }

        // Optional: track API usage instead of LOGIN
        userActivityService.log(
                userId,
                username,
                "API_CALL",
                request.getRequestURI(),
                request.getMethod(),
                request.getRemoteAddr()
        );

        return true;
    }
}