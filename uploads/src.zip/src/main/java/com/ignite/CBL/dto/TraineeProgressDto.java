
package com.ignite.CBL.dto;

import lombok.Data;

@Data
public class TraineeProgressDto {

    private String trainee_id;
    private Long topics_completed;
    private Double avg_time_to_complete_ms;
    private Long languages_count;
    private Long parallel_activity;

    public TraineeProgressDto(
            String trainee_id,
            Long topics_completed,
            Double avg_time_to_complete_ms,
            Long languages_count,
            Long parallel_activity
    ) {
        this.trainee_id = trainee_id;
        this.topics_completed = topics_completed;
        this.avg_time_to_complete_ms = avg_time_to_complete_ms;
        this.languages_count = languages_count;
        this.parallel_activity = parallel_activity;
    }

    // getters
}
