
package com.ignite.CBL.dto;

public class TraineeProgressQueryDto {

    private final String traineeId;
    private final Long topicsCompleted;
    private final Double avgTimeMs;
    private final Long parallelActivity;

    public TraineeProgressQueryDto(
            String traineeId,
            Long topicsCompleted,
            Double avgTimeMs,
            Long parallelActivity
    ) {
        this.traineeId = traineeId;
        this.topicsCompleted = topicsCompleted;
        this.avgTimeMs = avgTimeMs;
        this.parallelActivity = parallelActivity;
    }

    public String getTraineeId() {
        return traineeId;
    }

    public Long getTopicsCompleted() {
        return topicsCompleted;
    }

    public Double getAvgTimeMs() {
        return avgTimeMs;
    }

    public Long getParallelActivity() {
        return parallelActivity;
    }
}
