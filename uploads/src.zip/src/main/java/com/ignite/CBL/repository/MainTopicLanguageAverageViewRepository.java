package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.view.MainTopicLanguageAverageView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MainTopicLanguageAverageViewRepository extends JpaRepository<MainTopicLanguageAverageView, Integer>, JpaSpecificationExecutor<Topic> {
    @Query("SELECT v FROM MainTopicLanguageAverageView v")
    List<MainTopicLanguageAverageView> findAllStats();
}