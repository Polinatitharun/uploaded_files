package com.ignite.CBL.service.problem;



import com.ignite.CBL.dto.problem.ProblemAssistanceRequestDto;
import org.springframework.http.ResponseEntity;

public interface ProblemAssistanceService {

    ResponseEntity<?> create(Integer problemId,ProblemAssistanceRequestDto request);

    ResponseEntity<?> update(Integer problemId, ProblemAssistanceRequestDto request);

    ResponseEntity<?> delete(Integer problemId);

    ResponseEntity<?> getProblemAssistance(Integer problemId);
}