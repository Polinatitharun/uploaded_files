package com.ignite.CBL.controller;

import com.ignite.CBL.service.UserProgressService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/progress")
public class UserProgressController {
    private final UserProgressService service;

    public UserProgressController(UserProgressService service) {
        this.service = service;
    }

    @GetMapping("/completed/{userId}")
    public long getCompletedTopics(@PathVariable String userId) {
        return service.getCompletedMainTopics(userId);
    }
}
