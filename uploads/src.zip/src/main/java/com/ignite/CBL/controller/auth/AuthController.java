package com.ignite.CBL.controller.auth;


import com.ignite.CBL.entity.user.UserDetails;
import com.ignite.CBL.repository.user.UserDetailsRepository;
import com.ignite.CBL.service.user.UserActivityLogService;
import com.ignite.CBL.utils.JwtUtils;
import com.ignite.CBL.utils.TokenResponse;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.time.Duration;
import java.util.*;


@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@EnableScheduling
public class AuthController {

    private final RedisTemplate<String, Object> redisTemplate;

    private static final List<String> ROLE_PRIORITY = List.of("ADMIN", "SME", "USER");
    // 🔹 From application.yml
    @Value("${spring.security.oauth2.client.registration.keycloak.client-id}")
    private String clientId;

    @Value("${spring.security.oauth2.client.registration.keycloak.authorization-grant-type}")
    private String grantType;

    @Value("${spring.security.oauth2.client.registration.keycloak.client-secret}")
    private String clientSecret;

    @Value("${spring.security.oauth2.client.registration.keycloak.redirect-uri}")
    private String redirectUri;

    @Value("${spring.security.oauth2.client.provider.keycloak.issuer-uri}")
    private String issuerUri;

    @Value("${cors.frontend.url}")
    private String frontendUrl;
    private final RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private UserActivityLogService userActivityService;

    @Autowired
    private UserDetailsRepository userRepo;
    // LOGIN REDIRECT
    @GetMapping("/login")
    public void login(HttpServletResponse response) throws IOException {

        String authUrl = issuerUri + "/protocol/openid-connect/auth" +
                "?client_id=" + clientId +
                "&response_type=code" +
                "&scope=openid profile email" +
                "&redirect_uri=" + redirectUri;
        response.sendRedirect(authUrl);
    }

    //  CALLBACK
    @GetMapping("/callback")
    public void callback(@RequestParam String code, HttpServletResponse response, HttpServletRequest request) throws IOException {

        TokenResponse token = exchangeCodeForToken(code);

        //  Extract roles
        List<String> roles = JwtUtils.
extractRoles(token.getAccessToken(), clientId);

        //  Create session
        String sessionId = UUID.randomUUID().toString();

        Map<String, Object> sessionData = new HashMap<>();
        sessionData.put("access_token", token.getAccessToken());
        sessionData.put("refresh_token", token.getRefreshToken());
        sessionData.put("roles", roles);

        redisTemplate.opsForValue()
                .set(sessionId, sessionData, Duration.ofMinutes(5));

        Optional<UserDetails> isExistUser=userRepo.findByKeycloakId(JwtUtils.
extractUserId(token.getAccessToken()));
        if(isExistUser.isEmpty()){
            UserDetails user = new UserDetails();
            user.setKeycloakId(JwtUtils.
extractUserId(token.getAccessToken()));
            user.setUsername(JwtUtils.
extractUsername(token.getAccessToken()));
            user.setEmail(JwtUtils.
extractEmail(token.getAccessToken()));
            userRepo.save(user);
        }
        //  Cookie
        Cookie cookie = new Cookie("SESSION_ID", sessionId);
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        cookie.setMaxAge(1800);

        Cookie hintCookie = new Cookie("LOGGED_IN", "true");
        hintCookie.setHttpOnly(false);
        hintCookie.setPath("/");
        hintCookie.setMaxAge(1800);
        response.addCookie(hintCookie);

        response.addCookie(cookie);

        userActivityService.log(
                JwtUtils.
extractUserId(token.getAccessToken()),
                JwtUtils.
extractUsername(token.getAccessToken()),
                "LOGIN",
                "/auth/callback",
                "GET",
                request.getRemoteAddr()
        );

        //  Role-based redirect
        String highestRole = getHighestPriorityRole(roles);
        String redirectUrl = getRedirectUrl(highestRole);

        response.sendRedirect(redirectUrl);
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@CookieValue(name = "SESSION_ID", required = false) String sessionId) {

        if (sessionId == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("No session");
        }

        Map<String, Object> session =
                (Map<String, Object>) redisTemplate.opsForValue().get(sessionId);

        if (session == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session expired");
        }

        String accessToken = (String) session.get("access_token");

        //  Call Keycloak userinfo endpoint
        String userInfoUrl = issuerUri + "/protocol/openid-connect/userinfo";

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<Map> userInfoResponse = restTemplate.exchange(
                userInfoUrl,
                HttpMethod.GET,
                entity,
                Map.class
        );

        Map<String, Object> userInfo = userInfoResponse.getBody();

        //  Merge roles from session
        List<String> roles = (List<String>) session.get("roles");

        Map<String, Object> response = new HashMap<>();
        response.put("username", userInfo.get("preferred_username"));
        response.put("email", userInfo.get("email"));
        response.put("name", userInfo.get("name"));
        response.put("roles", roles);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/logout")
    public ResponseEntity<?> logout(
            @CookieValue(name = "SESSION_ID", required = false) String sessionId,
            HttpServletResponse response,HttpServletRequest request) {

        if (sessionId != null) {

            Map<String, Object> session =
                    (Map<String, Object>) redisTemplate.opsForValue().get(sessionId);

            if (session != null) {
                String refreshToken = (String) session.get("refresh_token");
                String token = (String) session.get("access_token");
                // 🔹 Keycloak logout
                String logoutUrl = issuerUri + "/protocol/openid-connect/logout";

                userActivityService.log(
                        JwtUtils.
extractUserId(token),
                        JwtUtils.
extractUsername(token),
                        "LOGOUT",
                        "/auth/logout",
                        "GET",
                        request.getRemoteAddr()
                );

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

                String body = "client_id=" + clientId +
                        "&client_secret=" + clientSecret +
                        "&refresh_token=" + refreshToken;

                HttpEntity<String> req = new HttpEntity<>(body, headers);

                try {
                    restTemplate.exchange(
                            logoutUrl,
                            HttpMethod.POST,
                            req,
                            String.class
                    );
                } catch (Exception e) {
                    System.out.println("Keycloak logout failed: " + e.getMessage());
                }
            }

            // Delete Redis session
            redisTemplate.delete(sessionId);
        }

        //  Clear SESSION cookie
        Cookie sessionCookie = new Cookie("SESSION_ID", null);
        sessionCookie.setHttpOnly(true);
        sessionCookie.setPath("/");
        sessionCookie.setMaxAge(0);
        sessionCookie.setSecure(false); // true in HTTPS

        //  Clear hint cookie
        Cookie hintCookie = new Cookie("LOGGED_IN", null);
        hintCookie.setHttpOnly(false);
        hintCookie.setPath("/");
        hintCookie.setMaxAge(0);
        hintCookie.setSecure(false);

        response.addCookie(sessionCookie);
        response.addCookie(hintCookie);




        return ResponseEntity.ok("Logged out successfully");
    }

    private String getRedirectUrl(String role) {
        if (role == null) return frontendUrl;

        return switch (role) {
            case "ADMIN" -> frontendUrl + "/admin";
            case "SME" -> frontendUrl + "/sme";
            case "USER" -> frontendUrl + "/home";
            default -> frontendUrl;
        };
    }

    private String getHighestPriorityRole(List<String> userRoles) {
        for (String role : ROLE_PRIORITY) {
            if (userRoles.contains(role)) {
                return role;
            }
        }
        return null; // fallback
    }
    // TOKEN EXCHANGE (uses client secret)
    private TokenResponse exchangeCodeForToken(String code) {

        String tokenUrl = issuerUri + "/protocol/openid-connect/token";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        String body = "grant_type=" + grantType+
                "&client_id=" + clientId +
                "&client_secret=" + clientSecret +
                "&code=" + code +
                "&redirect_uri=" + redirectUri;

        HttpEntity<String> request = new HttpEntity<>(body, headers);


        ResponseEntity<Map> response = restTemplate.exchange(
                tokenUrl,
                HttpMethod.POST,
                request,
                Map.class
        );

        Map<String, Object> res = response.getBody();

        return new TokenResponse(
                (String) res.get("access_token"),
                (String) res.get("refresh_token")
        );
    }


    @Scheduled(fixedRate = 300000) // 5 minutes
    public void cleanupSessions() {
        Set<String> keys = redisTemplate.keys("session:*");

        for (String key : keys) {
            Long ttl = redisTemplate.getExpire(key);

            if (ttl == null || ttl <= 0) {
                redisTemplate.delete(key);
            }
        }
    }
}