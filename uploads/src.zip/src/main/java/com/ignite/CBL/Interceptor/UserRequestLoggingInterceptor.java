package com.ignite.CBL.Interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class UserRequestLoggingInterceptor implements HandlerInterceptor {

    private static final Logger logger= LoggerFactory.getLogger(UserRequestLoggingInterceptor.class);




    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse res, Object handler) throws Exception {
        String uri=request.getRequestURI();
        String method =request.getMethod();
        String username="Anonymous";

        Authentication auth= SecurityContextHolder.getContext().getAuthentication();
        if(auth!=null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken)){
            username=auth.getName();

        }
        logger.info("User: {} -> {} {}",username,method,uri);

        return true;
    }

}
