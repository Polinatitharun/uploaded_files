package com.ignite.CBL.dto.user;

import com.ignite.CBL.dto.UserProblemReportDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class UserDashboardResponceDTO {
    private String userId;
    private String userName;
    private String batchName;
    private List<UserProblemReportDTO> userProblemReportDTOS;
}
