package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class FiltersMetaDto {
    private List<String> batches;
    private List<SimpleOptionDto> topics;
    private List<SimpleOptionDto> problems;
}
