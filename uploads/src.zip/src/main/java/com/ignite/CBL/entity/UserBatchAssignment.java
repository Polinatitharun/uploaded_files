package com.ignite.CBL.entity;

import com.ignite.CBL.entity.user.User;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "user_batch_assignments")
@Getter
@Setter
public class UserBatchAssignment {

    @EmbeddedId
    private UserBatchAssignmentId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("userId")
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("batchId")
    @JoinColumn(name = "batch_id")
    private Batch batch;
}
