package com.ignite.CBL.controller.Problem;

import com.ignite.CBL.dto.problem.ProblemAssistanceRequestDto;

import com.ignite.CBL.service.problem.ProblemAssistanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/problem/assistance")
@RequiredArgsConstructor
public class ProblemAssistanceController {

    @Autowired
    private final ProblemAssistanceService service;

    // Create
    @PostMapping("/{problemId}")
    public ResponseEntity<?> create(@PathVariable("problemId") Integer problemId,@Valid @RequestBody ProblemAssistanceRequestDto request) {
        return service.create(problemId,request);
    }


    @GetMapping("/{problemId}")
    public ResponseEntity<?> getByProblemId(@PathVariable("problemId") Integer problemId){
        return service.getProblemAssistance(problemId);
    }


    // Update (full)
    @PutMapping("/{problemId}")
    public  ResponseEntity<?> update(@PathVariable("problemId") Integer problemId,
                                               @Valid @RequestBody ProblemAssistanceRequestDto request) {
        return service.update(problemId, request);
    }

    // Delete
    @DeleteMapping("/{problemId}")
    public ResponseEntity<?> delete(@PathVariable("problemId") Integer id) {
        return service.delete(id);
    }

}
