package com.ignite.CBL.repository;

import com.ignite.CBL.entity.UserMainTopicEngagement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserMainTopicProgressRepository extends JpaRepository<UserMainTopicEngagement,Long> {
    long countByUser_UserIdAndIsCompletedTrue(String userId);
}
