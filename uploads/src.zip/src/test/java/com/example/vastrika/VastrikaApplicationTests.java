package com.example.vastrika;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VastrikaApplicationTests {

	@Test
	void contextLoads() {
	}

}
