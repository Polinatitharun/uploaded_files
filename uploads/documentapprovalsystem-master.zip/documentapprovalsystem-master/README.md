# Document Approval Workflow System

A comprehensive document approval workflow system built with React, Express.js, and MongoDB.

## Tech Stack

- **Frontend**: React 18 with pure CSS (no CSS frameworks)
- **Backend**: Express.js with Node.js
- **Database**: MongoDB
- **Authentication**: Keycloak JWT integration
- **File Storage**: Local file system

## Features

- Multi-step document approval workflows
- Document versioning and audit trails
- Role-based access control (Author, Approver, Admin)
- Comment system for document feedback
- File attachment support
- Real-time status tracking
- Search and filtering capabilities

## Project Structure

```
document-approval-workflow/
├── backend/
│   ├── models/          # MongoDB models
│   ├── routes/          # API routes
│   ├── middleware/      # Express middleware
│   ├── uploads/         # File upload directory
│   └── server.js        # Main server file
├── frontend/
│   ├── src/
│   │   ├── components/  # React components
│   │   ├── pages/       # Page components
│   │   ├── services/    # API services
│   │   └── styles/      # CSS styles
│   └── public/
└── package.json
```

## Installation

1. Install dependencies for all packages:
```bash
npm run install-all
```

2. Set up MongoDB:
```bash
# Make sure MongoDB is running on localhost:27017
```

3. Configure environment variables:
```bash
# Edit backend/.env with your configuration
```

4. Start the development servers:
```bash
npm run dev
```

The frontend will run on http://localhost:3000
The backend will run on http://localhost:5000

## API Endpoints

### Document APIs
- POST /api/documents - Create document
- GET /api/documents - Get all documents (with filters)
- GET /api/documents/:id - Get document details
- PUT /api/documents/:id - Update document
- DELETE /api/documents/:id - Delete document
- POST /api/documents/:id/submit - Submit for approval

### Workflow APIs
- POST /api/workflows - Create workflow
- GET /api/workflows - Get workflows
- PUT /api/workflows/:id - Update workflow

### Approval APIs
- POST /api/approvals/:id/approve - Approve document
- POST /api/approvals/:id/reject - Reject document
- POST /api/approvals/:id/request-changes - Request changes

### Comments APIs
- POST /api/comments - Add comment
- GET /api/comments/document/:id - Get document comments

### Version APIs
- GET /api/documents/:id/versions - Get document versions

### Audit API
- GET /api/audit/document/:id - Get approval history

## Authentication

The system uses Keycloak for authentication. Users log in through a custom React login page that communicates with Keycloak's OpenID Connect endpoint.

## User Roles

- **Author**: Creates and submits documents
- **Approver**: Reviews and approves/rejects documents
- **Admin**: Manages workflows and system settings
