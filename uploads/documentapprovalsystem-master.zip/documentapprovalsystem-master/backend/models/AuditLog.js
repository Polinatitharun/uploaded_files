const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema({
  documentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Document',
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  action: {
    type: String,
    enum: [
      'created',
      'updated',
      'submitted',
      'approved',
      'rejected',
      'changes_requested',
      'published',
      'deleted',
      'version_created',
      'comment_added'
    ],
    required: true
  },
  details: {
    type: mongoose.Schema.Types.Mixed
  },
  previousStatus: String,
  newStatus: String,
  timestamp: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

auditLogSchema.index({ documentId: 1, timestamp: -1 });
auditLogSchema.index({ userId: 1, timestamp: -1 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
