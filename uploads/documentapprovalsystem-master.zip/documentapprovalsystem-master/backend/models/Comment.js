const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  documentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Document',
    required: true
  },
  authorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  content: {
    type: String,
    required: true
  },
  isInternal: {
    type: Boolean,
    default: false
  },
  parentCommentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Comment'
  },
  stage: {
    type: Number
  }
}, {
  timestamps: true
});

commentSchema.index({ documentId: 1, createdAt: -1 });

module.exports = mongoose.model('Comment', commentSchema);
