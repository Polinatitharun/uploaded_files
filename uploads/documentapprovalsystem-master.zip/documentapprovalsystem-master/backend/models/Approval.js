const mongoose = require('mongoose');

const approvalSchema = new mongoose.Schema({
  documentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Document',
    required: true
  },
  workflowId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Workflow',
    required: true
  },
  stage: {
    type: Number,
    required: true
  },
  approverId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  action: {
    type: String,
    enum: ['approved', 'rejected', 'changes_requested'],
    required: true
  },
  comments: {
    type: String
  },
  documentVersion: {
    type: Number,
    required: true
  }
}, {
  timestamps: true
});

approvalSchema.index({ documentId: 1, stage: 1 });

module.exports = mongoose.model('Approval', approvalSchema);
