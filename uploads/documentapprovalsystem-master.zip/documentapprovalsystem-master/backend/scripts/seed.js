const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Import models
const User = require('../models/User');
const Workflow = require('../models/Workflow');
const Category = require('../models/Category');

// Sample data
const sampleUsers = [
  {
    username: 'admin',
    email: 'admin@example.com',
    firstName: 'Admin',
    lastName: 'User',
    role: 'admin',
    department: 'IT',
    keycloakId: 'admin-keycloak-id'
  },
  {
    username: 'author',
    email: 'author@example.com',
    firstName: 'Author',
    lastName: 'User',
    role: 'author',
    department: 'HR',
    keycloakId: 'author-keycloak-id'
  },
  {
    username: 'approver',
    email: 'approver@example.com',
    firstName: 'Approver',
    lastName: 'User',
    role: 'approver',
    department: 'Finance',
    keycloakId: 'approver-keycloak-id'
  }
];

const sampleWorkflows = [
  {
    name: 'HR Policy Workflow',
    description: 'Standard workflow for HR policy documents',
    stages: [
      {
        name: 'HR Manager Review',
        description: 'Initial review by HR Manager',
        assignedRole: 'approver',
        order: 0,
        isRequired: true
      },
      {
        name: 'Director Approval',
        description: 'Final approval by Director',
        assignedRole: 'admin',
        order: 1,
        isRequired: true
      }
    ]
  },
  {
    name: 'Technical Document Workflow',
    description: 'Workflow for technical architecture documents',
    stages: [
      {
        name: 'Technical Lead Review',
        description: 'Review by Technical Lead',
        assignedRole: 'approver',
        order: 0,
        isRequired: true
      },
      {
        name: 'Architecture Board',
        description: 'Review by Architecture Board',
        assignedRole: 'admin',
        order: 1,
        isRequired: true
      }
    ]
  },
  {
    name: 'Procurement Request Workflow',
    description: 'Workflow for procurement requests',
    stages: [
      {
        name: 'Department Head Approval',
        description: 'Approval from Department Head',
        assignedRole: 'approver',
        order: 0,
        isRequired: true
      },
      {
        name: 'Finance Review',
        description: 'Financial review and approval',
        assignedRole: 'approver',
        order: 1,
        isRequired: true
      },
      {
        name: 'Executive Approval',
        description: 'Final executive approval',
        assignedRole: 'admin',
        order: 2,
        isRequired: true
      }
    ]
  }
];

const sampleCategories = [
  {
    name: 'HR Policies',
    description: 'Human resources policies and procedures'
  },
  {
    name: 'Technical Architecture',
    description: 'Technical design and architecture documents'
  },
  {
    name: 'Procurement',
    description: 'Procurement requests and contracts'
  },
  {
    name: 'Legal Agreements',
    description: 'Legal contracts and agreements'
  }
];

async function seedDatabase() {
  try {
    console.log('Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/document_approval');
    console.log('Connected to MongoDB');

    // Clear existing data
    console.log('Clearing existing data...');
    await User.deleteMany({});
    await Workflow.deleteMany({});
    await Category.deleteMany({});
    console.log('Existing data cleared');

    // Create users
    console.log('Creating users...');
    const createdUsers = [];
    for (const userData of sampleUsers) {
      const user = new User(userData);
      await user.save();
      createdUsers.push(user);
      console.log(`Created user: ${user.username}`);
    }

    // Create workflows
    console.log('Creating workflows...');
    const createdWorkflows = [];
    for (const workflowData of sampleWorkflows) {
      const workflow = new Workflow({
        ...workflowData,
        createdBy: createdUsers[0]._id // Admin user
      });
      await workflow.save();
      createdWorkflows.push(workflow);
      console.log(`Created workflow: ${workflow.name}`);
    }

    // Create categories
    console.log('Creating categories...');
    for (let i = 0; i < sampleCategories.length; i++) {
      const categoryData = sampleCategories[i];
      const workflowId = createdWorkflows[i % createdWorkflows.length]._id;
      
      const category = new Category({
        ...categoryData,
        workflowId
      });
      await category.save();
      console.log(`Created category: ${category.name}`);
    }

    console.log('Database seeded successfully!');
    console.log('\nLogin credentials:');
    console.log('Admin: admin / password');
    console.log('Author: author / password');
    console.log('Approver: approver / password');

  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

// Run the seed function
seedDatabase();
