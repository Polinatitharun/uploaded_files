const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
const Workflow = require('../models/Workflow');
const { auth, authorize } = require('../middleware/auth');

// Get all categories
router.get('/', auth, async (req, res) => {
  try {
    const categories = await Category.find({ isActive: true })
      .populate('workflowId', 'name description')
      .sort({ name: 1 });

    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create category
router.post('/', auth, authorize('admin'), async (req, res) => {
  try {
    const { name, description, workflowId } = req.body;

    if (!name || !workflowId) {
      return res.status(400).json({ message: 'Name and workflow ID are required' });
    }

    const workflow = await Workflow.findById(workflowId);
    if (!workflow) {
      return res.status(400).json({ message: 'Invalid workflow ID' });
    }

    const category = new Category({
      name,
      description,
      workflowId
    });

    await category.save();

    const populatedCategory = await Category.findById(category._id)
      .populate('workflowId', 'name description');

    res.status(201).json(populatedCategory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update category
router.put('/:id', auth, authorize('admin'), async (req, res) => {
  try {
    const { name, description, workflowId } = req.body;
    const category = await Category.findById(req.params.id);

    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    if (workflowId && workflowId !== category.workflowId.toString()) {
      const workflow = await Workflow.findById(workflowId);
      if (!workflow) {
        return res.status(400).json({ message: 'Invalid workflow ID' });
      }
      
      // Check if any documents are using this category
      const Document = require('../models/Document');
      const documentsUsingCategory = await Document.find({ categoryId: req.params.id });
      if (documentsUsingCategory.length > 0) {
        return res.status(400).json({ 
          message: 'Cannot change workflow. Documents are using this category.' 
        });
      }
    }

    if (name) category.name = name;
    if (description !== undefined) category.description = description;
    if (workflowId) category.workflowId = workflowId;

    await category.save();

    const populatedCategory = await Category.findById(category._id)
      .populate('workflowId', 'name description');

    res.json(populatedCategory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete category (soft delete)
router.delete('/:id', auth, authorize('admin'), async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);

    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    // Check if any documents are using this category
    const Document = require('../models/Document');
    const documentsUsingCategory = await Document.find({ categoryId: req.params.id });
    if (documentsUsingCategory.length > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete category. Documents are using this category.' 
      });
    }

    category.isActive = false;
    await category.save();

    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
