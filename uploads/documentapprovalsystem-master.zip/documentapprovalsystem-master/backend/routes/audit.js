const express = require('express');
const router = express.Router();
const AuditLog = require('../models/AuditLog');
const Document = require('../models/Document');
const { auth, authorize } = require('../middleware/auth');

// Get approval history for a document
router.get('/document/:documentId', auth, async (req, res) => {
  try {
    const { documentId } = req.params;

    const document = await Document.findById(documentId);
    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    // Check if user has access to this document
    if (document.authorId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to view audit history for this document' });
    }

    const auditLogs = await AuditLog.find({ documentId })
      .populate('userId', 'firstName lastName email role')
      .sort({ timestamp: -1 });

    res.json(auditLogs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get system-wide audit logs (admin only)
router.get('/', auth, authorize('admin'), async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 50, 
      action, 
      userId, 
      startDate, 
      endDate 
    } = req.query;

    const filter = {};
    
    if (action) filter.action = action;
    if (userId) filter.userId = userId;
    
    if (startDate || endDate) {
      filter.timestamp = {};
      if (startDate) filter.timestamp.$gte = new Date(startDate);
      if (endDate) filter.timestamp.$lte = new Date(endDate);
    }

    const auditLogs = await AuditLog.find(filter)
      .populate('userId', 'firstName lastName email role')
      .populate('documentId', 'title')
      .sort({ timestamp: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await AuditLog.countDocuments(filter);

    res.json({
      auditLogs,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user activity logs
router.get('/user/:userId', auth, async (req, res) => {
  try {
    const { userId } = req.params;

    // Users can only see their own activity unless they're admin
    if (userId !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to view this user\'s activity' });
    }

    const { page = 1, limit = 20, action } = req.query;

    const filter = { userId };
    if (action) filter.action = action;

    const auditLogs = await AuditLog.find(filter)
      .populate('documentId', 'title status')
      .sort({ timestamp: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await AuditLog.countDocuments(filter);

    res.json({
      auditLogs,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
