const express = require('express');
const router = express.Router();
const Workflow = require('../models/Workflow');
const Category = require('../models/Category');
const { auth, authorize } = require('../middleware/auth');

// Get all workflows
router.get('/', auth, async (req, res) => {
  try {
    const workflows = await Workflow.find({ isActive: true })
      .populate('createdBy', 'firstName lastName email')
      .populate('stages.assignedUserId', 'firstName lastName email')
      .sort({ createdAt: -1 });

    res.json(workflows);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create workflow
router.post('/', auth, authorize('admin'), async (req, res) => {
  try {
    const { name, description, stages } = req.body;

    if (!name || !stages || stages.length === 0) {
      return res.status(400).json({ message: 'Name and stages are required' });
    }

    // Validate stages
    for (let i = 0; i < stages.length; i++) {
      const stage = stages[i];
      if (!stage.name || !stage.assignedRole) {
        return res.status(400).json({ message: `Stage ${i + 1} is missing required fields` });
      }
      stage.order = i;
    }

    const workflow = new Workflow({
      name,
      description,
      stages,
      createdBy: req.user._id
    });

    await workflow.save();

    const populatedWorkflow = await Workflow.findById(workflow._id)
      .populate('createdBy', 'firstName lastName email')
      .populate('stages.assignedUserId', 'firstName lastName email');

    res.status(201).json(populatedWorkflow);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update workflow
router.put('/:id', auth, authorize('admin'), async (req, res) => {
  try {
    const { name, description, stages } = req.body;
    const workflow = await Workflow.findById(req.params.id);

    if (!workflow) {
      return res.status(404).json({ message: 'Workflow not found' });
    }

    // Check if workflow is being used by any category
    const categoriesUsingWorkflow = await Category.find({ workflowId: req.params.id });
    if (categoriesUsingWorkflow.length > 0) {
      return res.status(400).json({ 
        message: 'Cannot update workflow. It is being used by categories.' 
      });
    }

    if (name) workflow.name = name;
    if (description) workflow.description = description;
    if (stages && stages.length > 0) {
      // Validate stages
      for (let i = 0; i < stages.length; i++) {
        const stage = stages[i];
        if (!stage.name || !stage.assignedRole) {
          return res.status(400).json({ message: `Stage ${i + 1} is missing required fields` });
        }
        stage.order = i;
      }
      workflow.stages = stages;
    }

    await workflow.save();

    const populatedWorkflow = await Workflow.findById(workflow._id)
      .populate('createdBy', 'firstName lastName email')
      .populate('stages.assignedUserId', 'firstName lastName email');

    res.json(populatedWorkflow);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete workflow (soft delete)
router.delete('/:id', auth, authorize('admin'), async (req, res) => {
  try {
    const workflow = await Workflow.findById(req.params.id);

    if (!workflow) {
      return res.status(404).json({ message: 'Workflow not found' });
    }

    // Check if workflow is being used by any category
    const categoriesUsingWorkflow = await Category.find({ workflowId: req.params.id });
    if (categoriesUsingWorkflow.length > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete workflow. It is being used by categories.' 
      });
    }

    workflow.isActive = false;
    await workflow.save();

    res.json({ message: 'Workflow deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
