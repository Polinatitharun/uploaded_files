const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');
const Document = require('../models/Document');
const { auth } = require('../middleware/auth');

// Add comment
router.post('/', auth, async (req, res) => {
  try {
    const { documentId, content, isInternal, parentCommentId, stage } = req.body;

    if (!documentId || !content) {
      return res.status(400).json({ message: 'Document ID and content are required' });
    }

    const document = await Document.findById(documentId);
    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    const comment = new Comment({
      documentId,
      authorId: req.user._id,
      content,
      isInternal: isInternal || false,
      parentCommentId,
      stage
    });

    await comment.save();

    // Log comment addition
    await AuditLog.create({
      documentId,
      userId: req.user._id,
      action: 'comment_added',
      details: { commentId: comment._id, isInternal: comment.isInternal }
    });

    const populatedComment = await Comment.findById(comment._id)
      .populate('authorId', 'firstName lastName email')
      .populate('parentCommentId', 'content authorId')
      .populate({
        path: 'parentCommentId',
        populate: {
          path: 'authorId',
          select: 'firstName lastName email'
        }
      });

    res.status(201).json(populatedComment);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get document comments
router.get('/document/:documentId', auth, async (req, res) => {
  try {
    const { documentId } = req.params;
    const { includeInternal = false } = req.query;

    const document = await Document.findById(documentId);
    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    let filter = { documentId };
    
    // Only show internal comments to admins and the document author
    if (!includeInternal || (req.user.role !== 'admin' && document.authorId.toString() !== req.user._id.toString())) {
      filter.isInternal = false;
    }

    const comments = await Comment.find(filter)
      .populate('authorId', 'firstName lastName email')
      .populate('parentCommentId', 'content authorId')
      .populate({
        path: 'parentCommentId',
        populate: {
          path: 'authorId',
          select: 'firstName lastName email'
        }
      })
      .sort({ createdAt: -1 });

    res.json(comments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update comment
router.put('/:id', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }

    if (comment.authorId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to update this comment' });
    }

    comment.content = content;
    await comment.save();

    const populatedComment = await Comment.findById(comment._id)
      .populate('authorId', 'firstName lastName email')
      .populate('parentCommentId', 'content authorId')
      .populate({
        path: 'parentCommentId',
        populate: {
          path: 'authorId',
          select: 'firstName lastName email'
        }
      });

    res.json(populatedComment);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete comment
router.delete('/:id', auth, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }

    if (comment.authorId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to delete this comment' });
    }

    // Check if comment has replies
    const replies = await Comment.find({ parentCommentId: req.params.id });
    if (replies.length > 0) {
      return res.status(400).json({ message: 'Cannot delete comment with replies' });
    }

    await Comment.findByIdAndDelete(req.params.id);

    res.json({ message: 'Comment deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
