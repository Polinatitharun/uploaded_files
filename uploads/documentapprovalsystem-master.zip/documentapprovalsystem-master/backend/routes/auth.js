const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const axios = require('axios');
const User = require('../models/User');

// Keycloak authentication
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Authenticate with Keycloak
    const keycloakResponse = await axios.post(
      `http://localhost:8080/realms/document-approval/protocol/openid-connect/token`,
      new URLSearchParams({
        grant_type: 'password',
        client_id: 'document-client',
        username,
        password
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    const keycloakData = keycloakResponse.data;

    // Get user info from Keycloak
    const userInfoResponse = await axios.get(
      `http://localhost:8080/realms/document-approval/protocol/openid-connect/userinfo`,
      {
        headers: {
          'Authorization': `Bearer ${keycloakData.access_token}`
        }
      }
    );

    const userInfo = userInfoResponse.data;

    // Find or create user in our database
    let user = await User.findOne({ keycloakId: userInfo.sub });
    
    if (!user) {
      // Create new user
      user = new User({
        username: userInfo.preferred_username,
        email: userInfo.email,
        firstName: userInfo.given_name,
        lastName: userInfo.family_name,
        keycloakId: userInfo.sub,
        role: 'author' // Default role
      });
      await user.save();
    } else {
      // Update user info if changed
      user.username = userInfo.preferred_username;
      user.email = userInfo.email;
      user.firstName = userInfo.given_name;
      user.lastName = userInfo.family_name;
      await user.save();
    }

    // Generate our JWT token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        department: user.department
      },
      keycloakToken: keycloakData.access_token
    });
  } catch (error) {
    console.error('Authentication error:', error.message);
    if (error.response && error.response.status === 401) {
      res.status(401).json({ message: 'Invalid credentials' });
    } else {
      res.status(500).json({ message: 'Authentication failed' });
    }
  }
});

// Refresh token
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ message: 'Refresh token is required' });
    }

    // Refresh with Keycloak
    const keycloakResponse = await axios.post(
      `http://localhost:8080/realms/document-approval/protocol/openid-connect/token`,
      new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: 'document-client',
        refresh_token: refreshToken
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    const keycloakData = keycloakResponse.data;

    res.json({
      keycloakToken: keycloakData.access_token,
      refreshToken: keycloakData.refresh_token
    });
  } catch (error) {
    console.error('Token refresh error:', error.message);
    res.status(401).json({ message: 'Token refresh failed' });
  }
});

// Logout
router.post('/logout', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      // Logout from Keycloak
      await axios.post(
        `http://localhost:8080/realms/document-approval/protocol/openid-connect/logout`,
        new URLSearchParams({
          client_id: 'document-client',
          refresh_token: refreshToken
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
    }

    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    console.error('Logout error:', error.message);
    res.status(500).json({ message: 'Logout failed' });
  }
});

// Get current user info
router.get('/me', async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId).select('-password');
    
    if (!user) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    res.json({
      id: user._id,
      username: user.username,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      department: user.department
    });
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

module.exports = router;
