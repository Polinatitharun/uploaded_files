const express = require('express');
const router = express.Router();
const Document = require('../models/Document');
const Workflow = require('../models/Workflow');
const Approval = require('../models/Approval');
const AuditLog = require('../models/AuditLog');
const { auth, authorize } = require('../middleware/auth');

// Approve document
router.post('/:documentId/approve', auth, authorize('approver', 'admin'), async (req, res) => {
  try {
    const { documentId } = req.params;
    const { comments } = req.body;

    const document = await Document.findById(documentId).populate('workflowId');
    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    if (document.status !== 'pending_approval') {
      return res.status(400).json({ message: 'Document is not pending approval' });
    }

    const workflow = document.workflowId;
    const currentStage = workflow.stages[document.currentStage];

    // Check if user is authorized to approve at this stage
    if (currentStage.assignedRole !== req.user.role && 
        (!currentStage.assignedUserId || currentStage.assignedUserId.toString() !== req.user._id.toString())) {
      return res.status(403).json({ message: 'Not authorized to approve at this stage' });
    }

    // Create approval record
    const approval = new Approval({
      documentId,
      workflowId: workflow._id,
      stage: document.currentStage,
      approverId: req.user._id,
      action: 'approved',
      comments,
      documentVersion: document.version
    });
    await approval.save();

    // Log approval
    await AuditLog.create({
      documentId,
      userId: req.user._id,
      action: 'approved',
      details: { stage: document.currentStage, comments },
      previousStatus: document.status,
      newStatus: document.status
    });

    // Move to next stage or approve completely
    if (document.currentStage < workflow.stages.length - 1) {
      document.currentStage += 1;
    } else {
      document.status = 'approved';
      document.publishedAt = new Date();
      
      await AuditLog.create({
        documentId,
        userId: req.user._id,
        action: 'published',
        details: { workflowName: workflow.name },
        previousStatus: 'pending_approval',
        newStatus: 'approved'
      });
    }

    await document.save();

    const updatedDocument = await Document.findById(documentId)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name');

    res.json(updatedDocument);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Reject document
router.post('/:documentId/reject', auth, authorize('approver', 'admin'), async (req, res) => {
  try {
    const { documentId } = req.params;
    const { comments, reason } = req.body;

    const document = await Document.findById(documentId).populate('workflowId');
    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    if (document.status !== 'pending_approval') {
      return res.status(400).json({ message: 'Document is not pending approval' });
    }

    const workflow = document.workflowId;
    const currentStage = workflow.stages[document.currentStage];

    // Check if user is authorized to reject at this stage
    if (currentStage.assignedRole !== req.user.role && 
        (!currentStage.assignedUserId || currentStage.assignedUserId.toString() !== req.user._id.toString())) {
      return res.status(403).json({ message: 'Not authorized to reject at this stage' });
    }

    // Create approval record
    const approval = new Approval({
      documentId,
      workflowId: workflow._id,
      stage: document.currentStage,
      approverId: req.user._id,
      action: 'rejected',
      comments: comments || reason,
      documentVersion: document.version
    });
    await approval.save();

    // Update document status
    const oldStatus = document.status;
    document.status = 'rejected';
    document.rejectedAt = new Date();
    document.rejectionReason = comments || reason;
    await document.save();

    // Log rejection
    await AuditLog.create({
      documentId,
      userId: req.user._id,
      action: 'rejected',
      details: { stage: document.currentStage, reason: comments || reason },
      previousStatus: oldStatus,
      newStatus: document.status
    });

    const updatedDocument = await Document.findById(documentId)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name');

    res.json(updatedDocument);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Request changes
router.post('/:documentId/request-changes', auth, authorize('approver', 'admin'), async (req, res) => {
  try {
    const { documentId } = req.params;
    const { comments, changeRequests } = req.body;

    const document = await Document.findById(documentId).populate('workflowId');
    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    if (document.status !== 'pending_approval') {
      return res.status(400).json({ message: 'Document is not pending approval' });
    }

    const workflow = document.workflowId;
    const currentStage = workflow.stages[document.currentStage];

    // Check if user is authorized to request changes at this stage
    if (currentStage.assignedRole !== req.user.role && 
        (!currentStage.assignedUserId || currentStage.assignedUserId.toString() !== req.user._id.toString())) {
      return res.status(403).json({ message: 'Not authorized to request changes at this stage' });
    }

    // Create approval record
    const approval = new Approval({
      documentId,
      workflowId: workflow._id,
      stage: document.currentStage,
      approverId: req.user._id,
      action: 'changes_requested',
      comments,
      documentVersion: document.version
    });
    await approval.save();

    // Update document status back to draft
    const oldStatus = document.status;
    document.status = 'draft';
    document.currentStage = 0;
    await document.save();

    // Log change request
    await AuditLog.create({
      documentId,
      userId: req.user._id,
      action: 'changes_requested',
      details: { stage: document.currentStage, comments, changeRequests },
      previousStatus: oldStatus,
      newStatus: document.status
    });

    const updatedDocument = await Document.findById(documentId)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name');

    res.json(updatedDocument);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
