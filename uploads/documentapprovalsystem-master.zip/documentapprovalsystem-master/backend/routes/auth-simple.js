const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Simple local authentication (for testing without Keycloak)
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Simple authentication - in production, use proper password hashing
    let user = await User.findOne({ username });
    
    if (!user) {
      // Create user if not exists (for demo)
      user = new User({
        username,
        email: `${username}@example.com`,
        firstName: username.charAt(0).toUpperCase() + username.slice(1),
        lastName: 'User',
        role: username === 'admin' ? 'admin' : username === 'approver' ? 'approver' : 'author',
        department: 'IT',
        keycloakId: `local-${username}`
      });
      await user.save();
    }

    // Simple password check (accept any password for demo)
    if (!password) {
      return res.status(401).json({ message: 'Password is required' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        department: user.department
      }
    });
  } catch (error) {
    console.error('Authentication error:', error);
    res.status(500).json({ message: 'Authentication failed' });
  }
});

// Get current user info
router.get('/me', async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId).select('-password');
    
    if (!user) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    res.json({
      id: user._id,
      username: user.username,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      department: user.department
    });
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

// Logout
router.post('/logout', async (req, res) => {
  res.json({ message: 'Logged out successfully' });
});

module.exports = router;
