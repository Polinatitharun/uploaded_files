const express = require('express');
const router = express.Router();
const Document = require('../models/Document');
const DocumentVersion = require('../models/DocumentVersion');
const Category = require('../models/Category');
const Workflow = require('../models/Workflow');
const AuditLog = require('../models/AuditLog');
const { auth, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Get all documents with filters
router.get('/', auth, async (req, res) => {
  try {
    const { status, author, category, page = 1, limit = 10 } = req.query;
    const filter = {};
    
    if (status) filter.status = status;
    if (author) filter.authorId = author;
    if (category) filter.categoryId = category;

    const documents = await Document.find(filter)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Document.countDocuments(filter);

    res.json({
      documents,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get document details
router.get('/:id', auth, async (req, res) => {
  try {
    const document = await Document.findById(req.params.id)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name description')
      .populate('workflowId', 'name stages');

    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    res.json(document);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create document
router.post('/', auth, upload.array('attachments', 5), async (req, res) => {
  try {
    const { title, description, content, categoryId } = req.body;

    const category = await Category.findById(categoryId).populate('workflowId');
    if (!category) {
      return res.status(400).json({ message: 'Invalid category' });
    }

    const attachments = req.files ? req.files.map(file => ({
      filename: file.filename,
      originalName: file.originalname,
      path: file.path,
      size: file.size,
      mimeType: file.mimetype
    })) : [];

    const document = new Document({
      title,
      description,
      content,
      categoryId,
      workflowId: category.workflowId._id,
      authorId: req.user._id,
      attachments
    });

    await document.save();

    // Create initial version
    const version = new DocumentVersion({
      documentId: document._id,
      versionNumber: 1,
      title,
      description,
      content,
      attachments,
      changeLog: 'Initial version',
      createdBy: req.user._id
    });
    await version.save();

    // Log creation
    await AuditLog.create({
      documentId: document._id,
      userId: req.user._id,
      action: 'created',
      details: { title, categoryId },
      newStatus: 'draft'
    });

    const populatedDoc = await Document.findById(document._id)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name');

    res.status(201).json(populatedDoc);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update document
router.put('/:id', auth, upload.array('attachments', 5), async (req, res) => {
  try {
    const { title, description, content } = req.body;
    const document = await Document.findById(req.params.id);

    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    if (document.authorId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to update this document' });
    }

    if (document.status !== 'draft') {
      return res.status(400).json({ message: 'Can only update draft documents' });
    }

    const oldStatus = document.status;
    document.title = title || document.title;
    document.description = description || document.description;
    document.content = content || document.content;

    if (req.files && req.files.length > 0) {
      const newAttachments = req.files.map(file => ({
        filename: file.filename,
        originalName: file.originalname,
        path: file.path,
        size: file.size,
        mimeType: file.mimeType
      }));
      document.attachments = [...document.attachments, ...newAttachments];
    }

    await document.save();

    // Log update
    await AuditLog.create({
      documentId: document._id,
      userId: req.user._id,
      action: 'updated',
      details: { title, description },
      previousStatus: oldStatus,
      newStatus: document.status
    });

    const populatedDoc = await Document.findById(document._id)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name');

    res.json(populatedDoc);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete document
router.delete('/:id', auth, async (req, res) => {
  try {
    const document = await Document.findById(req.params.id);

    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    if (document.authorId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to delete this document' });
    }

    if (document.status !== 'draft') {
      return res.status(400).json({ message: 'Can only delete draft documents' });
    }

    await Document.findByIdAndDelete(req.params.id);
    await DocumentVersion.deleteMany({ documentId: req.params.id });
    await AuditLog.create({
      documentId: req.params.id,
      userId: req.user._id,
      action: 'deleted',
      details: { title: document.title }
    });

    res.json({ message: 'Document deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Submit document for approval
router.post('/:id/submit', auth, async (req, res) => {
  try {
    const document = await Document.findById(req.params.id).populate('workflowId');

    if (!document) {
      return res.status(404).json({ message: 'Document not found' });
    }

    if (document.authorId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to submit this document' });
    }

    if (document.status !== 'draft') {
      return res.status(400).json({ message: 'Document is already submitted' });
    }

    const oldStatus = document.status;
    document.status = 'pending_approval';
    document.currentStage = 0;
    await document.save();

    // Log submission
    await AuditLog.create({
      documentId: document._id,
      userId: req.user._id,
      action: 'submitted',
      details: { workflowName: document.workflowId.name },
      previousStatus: oldStatus,
      newStatus: document.status
    });

    const populatedDoc = await Document.findById(document._id)
      .populate('authorId', 'firstName lastName email')
      .populate('categoryId', 'name')
      .populate('workflowId', 'name');

    res.json(populatedDoc);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get document versions
router.get('/:id/versions', auth, async (req, res) => {
  try {
    const versions = await DocumentVersion.find({ documentId: req.params.id })
      .populate('createdBy', 'firstName lastName email')
      .sort({ versionNumber: -1 });

    res.json(versions);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
