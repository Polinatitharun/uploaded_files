# Document Approval Workflow System - Startup Guide

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (running on localhost:27017)
- Git

### Installation Steps

1. **Install Dependencies**
```bash
npm run install-all
```

2. **Set Up Environment Variables**
```bash
# Edit backend/.env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/document_approval
JWT_SECRET=your_jwt_secret_key_here
UPLOAD_DIR=./uploads
NODE_ENV=development
```

3. **Start MongoDB**
```bash
# Make sure MongoDB is running
mongod
```

4. **Seed the Database**
```bash
cd backend
node scripts/seed.js
```

5. **Start Development Servers**
```bash
# From root directory
npm run dev
```

This will start:
- Frontend: http://localhost:3000
- Backend: http://localhost:5000

## 📱 Demo Credentials

### Login Users
- **Admin**: `admin` / `password`
- **Author**: `author` / `password`  
- **Approver**: `approver` / `password`

## 🎯 Key Features

### User Roles & Permissions

**Author**
- Create documents
- Edit drafts
- Submit for approval
- View own documents

**Approver**
- Review documents in approval queue
- Approve/reject/request changes
- Add comments
- View all documents

**Admin**
- All approver permissions
- Manage workflows
- Manage categories
- View audit logs
- System administration

### Document Workflow States
1. **Draft** → Author creates and edits
2. **Pending Approval** → In review process
3. **Approved** → Fully approved
4. **Rejected** → Rejected with reason
5. **Published** → Final published state

### Core Workflows (Pre-configured)
- **HR Policy Workflow**: HR Manager → Director
- **Technical Document Workflow**: Technical Lead → Architecture Board
- **Procurement Workflow**: Department Head → Finance → Executive

## 📁 Project Structure

```
document-approval-workflow/
├── backend/
│   ├── models/          # MongoDB models
│   ├── routes/          # API routes (16 endpoints)
│   ├── middleware/      # Auth & file upload
│   ├── scripts/         # Database seeding
│   └── server.js        # Express server
├── frontend/
│   ├── src/
│   │   ├── components/  # React components
│   │   ├── pages/       # Page components
│   │   ├── services/    # API services
│   │   ├── contexts/    # React contexts
│   │   └── styles/      # Pure CSS styles
│   └── public/
└── README.md
```

## 🔧 API Endpoints

### Document APIs (6 endpoints)
- `POST /api/documents` - Create document
- `GET /api/documents` - Get documents with filters
- `GET /api/documents/:id` - Get document details
- `PUT /api/documents/:id` - Update document
- `DELETE /api/documents/:id` - Delete document
- `POST /api/documents/:id/submit` - Submit for approval

### Workflow APIs (3 endpoints)
- `POST /api/workflows` - Create workflow
- `GET /api/workflows` - Get workflows
- `PUT /api/workflows/:id` - Update workflow

### Approval APIs (3 endpoints)
- `POST /api/approvals/:id/approve` - Approve document
- `POST /api/approvals/:id/reject` - Reject document
- `POST /api/approvals/:id/request-changes` - Request changes

### Comments APIs (2 endpoints)
- `POST /api/comments` - Add comment
- `GET /api/comments/document/:id` - Get document comments

### Version APIs (1 endpoint)
- `GET /api/documents/:id/versions` - Get document versions

### Audit API (1 endpoint)
- `GET /api/audit/document/:id` - Get approval history

## 🎨 Frontend Pages

### Core Pages
- **Login** - User authentication
- **Dashboard** - Overview and statistics
- **Document List** - Browse and filter documents
- **Document Create** - Create new documents
- **Document Details** - View document with tabs

### Role-Specific Pages
- **Approval Queue** - For approvers (pending documents)
- **Workflow Management** - For admins (manage workflows)
- **Admin Panel** - For admins (system management)

## 🔐 Authentication

The system uses Keycloak for authentication:
- Custom React login page
- JWT token management
- Role-based access control
- Automatic token refresh

## 📁 File Upload

- Local file storage in `/backend/uploads`
- Supported formats: PDF, Word, Excel, PowerPoint, text, images
- 10MB file size limit
- Multiple file attachments per document

## 🛠️ Development Commands

```bash
# Install all dependencies
npm run install-all

# Start development servers
npm run dev

# Start backend only
npm run server

# Start frontend only
npm run client

# Seed database
cd backend && node scripts/seed.js
```

## 🌟 Getting Started Workflow

1. **Login as Admin** (`admin`/`password`)
2. **Create Workflows** - Go to Workflows page
3. **Create Categories** - Go to Admin panel
4. **Login as Author** (`author`/`password`)
5. **Create Document** - Go to Documents → Create
6. **Submit for Approval** - Submit the document
7. **Login as Approver** (`approver`/`password`)
8. **Review Document** - Go to Approval Queue
9. **Approve/Reject** - Take action on document

## 🐛 Troubleshooting

### Common Issues

**MongoDB Connection Error**
- Ensure MongoDB is running on localhost:27017
- Check MONGODB_URI in backend/.env

**Port Already in Use**
- Change PORT in backend/.env
- Kill process using the port

**File Upload Issues**
- Ensure uploads directory exists
- Check file permissions

**Authentication Issues**
- Verify JWT_SECRET in backend/.env
- Clear browser localStorage

### Debug Mode
Set `NODE_ENV=development` in backend/.env for detailed error messages.

## 📊 Database Schema

### Core Collections
- **users** - User accounts and roles
- **documents** - Document metadata and content
- **workflows** - Approval workflow definitions
- **categories** - Document categories
- **approvals** - Approval actions and decisions
- **comments** - Document comments
- **auditLogs** - System audit trail
- **documentVersions** - Document version history

## 🚀 Production Deployment

### Environment Setup
```bash
NODE_ENV=production
MONGODB_URI=mongodb://your-production-db
JWT_SECRET=your-production-secret
```

### Security Considerations
- Use HTTPS in production
- Set strong JWT secrets
- Configure MongoDB authentication
- Set up proper file upload permissions
- Enable rate limiting
- Use environment variables for secrets

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the API documentation
3. Check the database schema
4. Verify environment configuration
