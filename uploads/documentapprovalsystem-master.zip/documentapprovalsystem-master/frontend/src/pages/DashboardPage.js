import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { documentsAPI, auditAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const DashboardPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalDocuments: 0,
    draftDocuments: 0,
    pendingDocuments: 0,
    approvedDocuments: 0,
    rejectedDocuments: 0,
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [recentDocuments, setRecentDocuments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Fetch documents statistics
      const documentsResponse = await documentsAPI.getAll({
        author: user.role === 'author' ? user.id : undefined,
        limit: 1000
      });
      
      const documents = documentsResponse.data.documents;
      const stats = {
        totalDocuments: documents.length,
        draftDocuments: documents.filter(doc => doc.status === 'draft').length,
        pendingDocuments: documents.filter(doc => doc.status === 'pending_approval').length,
        approvedDocuments: documents.filter(doc => doc.status === 'approved').length,
        rejectedDocuments: documents.filter(doc => doc.status === 'rejected').length,
      };
      setStats(stats);

      // Fetch recent documents
      const recentDocsResponse = await documentsAPI.getAll({
        author: user.role === 'author' ? user.id : undefined,
        limit: 5,
        sort: 'createdAt'
      });
      setRecentDocuments(recentDocsResponse.data.documents);

      // Fetch recent activity
      const activityResponse = await auditAPI.getUserActivity(user.id, { limit: 10 });
      setRecentActivity(activityResponse.data.auditLogs);

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'draft': return 'status-draft';
      case 'pending_approval': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'rejected': return 'status-rejected';
      case 'published': return 'status-published';
      default: return '';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex-center" style={{ minHeight: '400px' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="mt-4">
        <h1>Dashboard</h1>
        <p>Welcome back, {user?.firstName} {user?.lastName}!</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-4 mt-4">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Total Documents</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#3498db' }}>
              {stats.totalDocuments}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Draft</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#95a5a6' }}>
              {stats.draftDocuments}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Pending Approval</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#f39c12' }}>
              {stats.pendingDocuments}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Approved</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#27ae60' }}>
              {stats.approvedDocuments}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Documents and Activity */}
      <div className="grid grid-2 mt-4">
        {/* Recent Documents */}
        <div className="card">
          <div className="card-header flex-between">
            <h3 className="card-title">Recent Documents</h3>
            <button 
              className="btn btn-secondary btn-sm"
              onClick={() => navigate('/documents')}
            >
              View All
            </button>
          </div>
          
          {recentDocuments.length === 0 ? (
            <p className="text-center" style={{ color: '#666' }}>
              No documents found
            </p>
          ) : (
            <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
              {recentDocuments.map((doc) => (
                <div 
                  key={doc._id} 
                  className="flex-between"
                  style={{ 
                    padding: '0.75rem 0', 
                    borderBottom: '1px solid #eee',
                    cursor: 'pointer'
                  }}
                  onClick={() => navigate(`/documents/${doc._id}`)}
                >
                  <div>
                    <div className="font-bold">{doc.title}</div>
                    <div className="text-sm" style={{ color: '#666' }}>
                      {formatDate(doc.createdAt)}
                    </div>
                  </div>
                  <span className={`status-badge ${getStatusColor(doc.status)}`}>
                    {doc.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Activity */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Recent Activity</h3>
          </div>
          
          {recentActivity.length === 0 ? (
            <p className="text-center" style={{ color: '#666' }}>
              No recent activity
            </p>
          ) : (
            <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
              {recentActivity.map((activity) => (
                <div 
                  key={activity._id}
                  style={{ 
                    padding: '0.75rem 0', 
                    borderBottom: '1px solid #eee'
                  }}
                >
                  <div className="font-bold">
                    {activity.action.replace('_', ' ').charAt(0).toUpperCase() + 
                     activity.action.replace('_', ' ').slice(1)}
                  </div>
                  <div className="text-sm" style={{ color: '#666' }}>
                    {activity.details?.title || 'Document'}
                  </div>
                  <div className="text-sm" style={{ color: '#999' }}>
                    {formatDate(activity.timestamp)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      {user?.role === 'author' && (
        <div className="card mt-4">
          <div className="card-header">
            <h3 className="card-title">Quick Actions</h3>
          </div>
          <div className="flex gap-2">
            <button 
              className="btn btn-primary"
              onClick={() => navigate('/documents/new')}
            >
              Create Document
            </button>
            <button 
              className="btn btn-secondary"
              onClick={() => navigate('/documents')}
            >
              View Documents
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardPage;
