import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { documentsAPI, approvalsAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const ApprovalQueuePage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  useEffect(() => {
    fetchApprovalQueue();
  }, []);

  const fetchApprovalQueue = async () => {
    try {
      setLoading(true);
      
      // Fetch pending documents
      const response = await documentsAPI.getAll({
        status: 'pending_approval',
        limit: 100
      });
      
      // Filter documents based on user role and workflow stage
      const filteredDocs = response.data.documents.filter(doc => {
        if (user.role === 'admin') return true;
        
        const workflow = doc.workflowId;
        if (!workflow || !workflow.stages) return false;
        
        const currentStage = workflow.stages[doc.currentStage];
        return currentStage?.assignedRole === user.role;
      });
      
      setDocuments(filteredDocs);
    } catch (error) {
      console.error('Error fetching approval queue:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'draft': return 'status-draft';
      case 'pending_approval': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'rejected': return 'status-rejected';
      case 'published': return 'status-published';
      default: return '';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const handleApprove = async (documentId) => {
    if (!window.confirm('Are you sure you want to approve this document?')) return;

    setActionLoading(documentId);
    try {
      await approvalsAPI.approve(documentId, { comments: '' });
      
      // Remove from the queue
      setDocuments(prev => prev.filter(doc => doc._id !== documentId));
    } catch (error) {
      console.error('Error approving document:', error);
      alert('Error approving document');
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (documentId) => {
    const reason = prompt('Please provide a reason for rejection:');
    if (!reason) return;

    setActionLoading(documentId);
    try {
      await approvalsAPI.reject(documentId, { comments: reason });
      
      // Remove from the queue
      setDocuments(prev => prev.filter(doc => doc._id !== documentId));
    } catch (error) {
      console.error('Error rejecting document:', error);
      alert('Error rejecting document');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRequestChanges = async (documentId) => {
    const comments = prompt('Please specify the changes needed:');
    if (!comments) return;

    setActionLoading(documentId);
    try {
      await approvalsAPI.requestChanges(documentId, { comments });
      
      // Remove from the queue
      setDocuments(prev => prev.filter(doc => doc._id !== documentId));
    } catch (error) {
      console.error('Error requesting changes:', error);
      alert('Error requesting changes');
    } finally {
      setActionLoading(null);
    }
  };

  const getCurrentStageName = (document) => {
    if (!document.workflowId?.stages || document.currentStage === undefined) {
      return 'Unknown';
    }
    
    const stage = document.workflowId.stages[document.currentStage];
    return stage?.name || `Stage ${document.currentStage + 1}`;
  };

  if (loading) {
    return (
      <div className="flex-center" style={{ minHeight: '400px' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="mt-4">
        <h1>Approval Queue</h1>
        <p>Documents pending your approval</p>
      </div>

      <div className="card mt-4">
        <div className="card-header">
          <h3 className="card-title">
            Pending Documents ({documents.length})
          </h3>
        </div>

        {documents.length === 0 ? (
          <div className="text-center py-4">
            <p style={{ color: '#666' }}>No documents pending your approval</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Category</th>
                  <th>Current Stage</th>
                  <th>Submitted</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {documents.map((doc) => (
                  <tr key={doc._id}>
                    <td>
                      <div 
                        style={{ cursor: 'pointer', fontWeight: 'bold' }}
                        onClick={() => navigate(`/documents/${doc._id}`)}
                      >
                        {doc.title}
                      </div>
                    </td>
                    <td>
                      {doc.authorId?.firstName} {doc.authorId?.lastName}
                    </td>
                    <td>{doc.categoryId?.name || 'N/A'}</td>
                    <td>
                      <span className="status-badge status-pending">
                        {getCurrentStageName(doc)}
                      </span>
                    </td>
                    <td>{formatDate(doc.updatedAt)}</td>
                    <td>
                      <div className="flex gap-1 flex-column">
                        <button 
                          className="btn btn-success btn-sm"
                          onClick={() => handleApprove(doc._id)}
                          disabled={actionLoading === doc._id}
                        >
                          {actionLoading === doc._id ? 'Processing...' : 'Approve'}
                        </button>
                        
                        <button 
                          className="btn btn-danger btn-sm"
                          onClick={() => handleReject(doc._id)}
                          disabled={actionLoading === doc._id}
                        >
                          {actionLoading === doc._id ? 'Processing...' : 'Reject'}
                        </button>
                        
                        <button 
                          className="btn btn-warning btn-sm"
                          onClick={() => handleRequestChanges(doc._id)}
                          disabled={actionLoading === doc._id}
                        >
                          {actionLoading === doc._id ? 'Processing...' : 'Request Changes'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Statistics */}
      <div className="grid grid-3 mt-4">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Total Pending</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#f39c12' }}>
              {documents.length}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Your Role</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#3498db' }}>
              {user?.role.charAt(0).toUpperCase() + user?.role.slice(1)}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Queue Status</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ 
              color: documents.length > 0 ? '#e74c3c' : '#27ae60' 
            }}>
              {documents.length > 0 ? 'Action Required' : 'All Clear'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApprovalQueuePage;
