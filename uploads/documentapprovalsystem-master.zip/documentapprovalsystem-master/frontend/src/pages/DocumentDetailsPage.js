import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { documentsAPI, commentsAPI, auditAPI, approvalsAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const DocumentDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  
  const [document, setDocument] = useState(null);
  const [comments, setComments] = useState([]);
  const [auditHistory, setAuditHistory] = useState([]);
  const [versions, setVersions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('details');
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState(location.state?.message || '');

  useEffect(() => {
    if (message) {
      setTimeout(() => setMessage(''), 5000);
    }
    fetchDocument();
  }, [id]);

  const fetchDocument = async () => {
    try {
      setLoading(true);
      
      // Fetch document details
      const docResponse = await documentsAPI.getById(id);
      setDocument(docResponse.data);

      // Fetch comments
      const commentsResponse = await commentsAPI.getByDocument(id);
      setComments(commentsResponse.data);

      // Fetch audit history
      const auditResponse = await auditAPI.getDocumentHistory(id);
      setAuditHistory(auditResponse.data);

      // Fetch versions
      const versionsResponse = await documentsAPI.getVersions(id);
      setVersions(versionsResponse.data);

    } catch (error) {
      console.error('Error fetching document:', error);
      setMessage('Error loading document');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'draft': return 'status-draft';
      case 'pending_approval': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'rejected': return 'status-rejected';
      case 'published': return 'status-published';
      default: return '';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setSubmitting(true);
    try {
      await commentsAPI.add({
        documentId: id,
        content: newComment,
        isInternal: false
      });
      
      setNewComment('');
      // Refresh comments
      const commentsResponse = await commentsAPI.getByDocument(id);
      setComments(commentsResponse.data);
      setMessage('Comment added successfully');
    } catch (error) {
      console.error('Error adding comment:', error);
      setMessage('Error adding comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async () => {
    if (!window.confirm('Are you sure you want to approve this document?')) return;

    try {
      await approvalsAPI.approve(id, { comments: '' });
      setMessage('Document approved successfully');
      fetchDocument();
    } catch (error) {
      console.error('Error approving document:', error);
      setMessage('Error approving document');
    }
  };

  const handleReject = async () => {
    const reason = prompt('Please provide a reason for rejection:');
    if (!reason) return;

    try {
      await approvalsAPI.reject(id, { comments: reason });
      setMessage('Document rejected');
      fetchDocument();
    } catch (error) {
      console.error('Error rejecting document:', error);
      setMessage('Error rejecting document');
    }
  };

  const handleSubmitForApproval = async () => {
    if (!window.confirm('Are you sure you want to submit this document for approval?')) return;

    try {
      await documentsAPI.submit(id);
      setMessage('Document submitted for approval');
      fetchDocument();
    } catch (error) {
      console.error('Error submitting document:', error);
      setMessage('Error submitting document');
    }
  };

  const canEdit = () => {
    return document?.status === 'draft' && document?.authorId?._id === user?.id;
  };

  const canApprove = () => {
    return document?.status === 'pending_approval' && 
           (user?.role === 'approver' || user?.role === 'admin');
  };

  if (loading) {
    return (
      <div className="flex-center" style={{ minHeight: '400px' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="container mt-4">
        <div className="alert alert-error">
          Document not found
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="mt-4">
        {message && (
          <div className={`alert ${message.includes('Error') ? 'alert-error' : 'alert-success'}`}>
            {message}
          </div>
        )}

        {/* Document Header */}
        <div className="card">
          <div className="flex-between">
            <div>
              <h1>{document.title}</h1>
              <p className="text-sm" style={{ color: '#666', marginTop: '0.5rem' }}>
                Created by {document.authorId?.firstName} {document.authorId?.lastName} on {formatDate(document.createdAt)}
              </p>
            </div>
            
            <div className="flex-column flex-center gap-2">
              <span className={`status-badge ${getStatusColor(document.status)}`}>
                {document.status.replace('_', ' ')}
              </span>
              
              <div className="flex gap-2">
                {canEdit() && (
                  <>
                    <button 
                      className="btn btn-primary"
                      onClick={() => navigate(`/documents/${id}/edit`)}
                    >
                      Edit
                    </button>
                    <button 
                      className="btn btn-success"
                      onClick={handleSubmitForApproval}
                    >
                      Submit for Approval
                    </button>
                  </>
                )}
                
                {canApprove() && (
                  <>
                    <button 
                      className="btn btn-success"
                      onClick={handleApprove}
                    >
                      Approve
                    </button>
                    <button 
                      className="btn btn-danger"
                      onClick={handleReject}
                    >
                      Reject
                    </button>
                  </>
                )}
                
                <button 
                  className="btn btn-secondary"
                  onClick={() => navigate('/documents')}
                >
                  Back to List
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="card mt-4">
          <div className="flex gap-4" style={{ borderBottom: '1px solid #eee' }}>
            {['details', 'comments', 'history', 'versions'].map((tab) => (
              <button
                key={tab}
                className={`btn ${activeTab === tab ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setActiveTab(tab)}
                style={{ borderRadius: '4px 4px 0 0' }}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div style={{ padding: '1rem 0' }}>
            {activeTab === 'details' && (
              <div>
                <div className="form-group">
                  <label className="form-label">Description</label>
                  <p>{document.description}</p>
                </div>

                {document.content && (
                  <div className="form-group">
                    <label className="form-label">Content</label>
                    <div style={{ 
                      backgroundColor: '#f8f9fa', 
                      padding: '1rem', 
                      borderRadius: '4px',
                      whiteSpace: 'pre-wrap'
                    }}>
                      {document.content}
                    </div>
                  </div>
                )}

                <div className="form-group">
                  <label className="form-label">Category</label>
                  <p>{document.categoryId?.name || 'N/A'}</p>
                </div>

                <div className="form-group">
                  <label className="form-label">Workflow</label>
                  <p>{document.workflowId?.name || 'N/A'}</p>
                </div>

                {document.attachments && document.attachments.length > 0 && (
                  <div className="form-group">
                    <label className="form-label">Attachments</label>
                    <ul style={{ listStyle: 'none', padding: 0 }}>
                      {document.attachments.map((attachment, index) => (
                        <li key={index} className="flex-between" style={{ padding: '0.5rem 0' }}>
                          <span>{attachment.originalName}</span>
                          <span className="text-sm" style={{ color: '#666' }}>
                            {(attachment.size / 1024 / 1024).toFixed(2)} MB
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {document.rejectionReason && (
                  <div className="form-group">
                    <label className="form-label">Rejection Reason</label>
                    <div className="alert alert-error">
                      {document.rejectionReason}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'comments' && (
              <div>
                {/* Add Comment Form */}
                <div className="card mb-4">
                  <h3>Add Comment</h3>
                  <form onSubmit={handleCommentSubmit}>
                    <div className="form-group">
                      <textarea
                        className="form-textarea"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Enter your comment..."
                        disabled={submitting}
                        style={{ minHeight: '100px' }}
                      />
                    </div>
                    <button 
                      type="submit"
                      className="btn btn-primary"
                      disabled={submitting || !newComment.trim()}
                    >
                      {submitting ? 'Adding...' : 'Add Comment'}
                    </button>
                  </form>
                </div>

                {/* Comments List */}
                <div>
                  <h3>Comments ({comments.length})</h3>
                  {comments.length === 0 ? (
                    <p style={{ color: '#666' }}>No comments yet</p>
                  ) : (
                    <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                      {comments.map((comment) => (
                        <div key={comment._id} className="card mb-2">
                          <div className="flex-between">
                            <strong>
                              {comment.authorId?.firstName} {comment.authorId?.lastName}
                            </strong>
                            <span className="text-sm" style={{ color: '#666' }}>
                              {formatDate(comment.createdAt)}
                            </span>
                          </div>
                          <p style={{ marginTop: '0.5rem' }}>{comment.content}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'history' && (
              <div>
                <h3>Audit History</h3>
                {auditHistory.length === 0 ? (
                  <p style={{ color: '#666' }}>No history available</p>
                ) : (
                  <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                    {auditHistory.map((log) => (
                      <div key={log._id} className="card mb-2">
                        <div className="flex-between">
                          <strong>
                            {log.action.replace('_', ' ').charAt(0).toUpperCase() + 
                             log.action.replace('_', ' ').slice(1)}
                          </strong>
                          <span className="text-sm" style={{ color: '#666' }}>
                            {formatDate(log.timestamp)}
                          </span>
                        </div>
                        <p style={{ marginTop: '0.5rem', color: '#666' }}>
                          By: {log.userId?.firstName} {log.userId?.lastName}
                        </p>
                        {log.details && Object.keys(log.details).length > 0 && (
                          <div style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: '#666' }}>
                            Details: {JSON.stringify(log.details)}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'versions' && (
              <div>
                <h3>Document Versions</h3>
                {versions.length === 0 ? (
                  <p style={{ color: '#666' }}>No versions available</p>
                ) : (
                  <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                    {versions.map((version) => (
                      <div key={version._id} className="card mb-2">
                        <div className="flex-between">
                          <strong>Version {version.versionNumber}</strong>
                          <span className="text-sm" style={{ color: '#666' }}>
                            {formatDate(version.createdAt)}
                          </span>
                        </div>
                        <p style={{ marginTop: '0.5rem', color: '#666' }}>
                          Created by: {version.createdBy?.firstName} {version.createdBy?.lastName}
                        </p>
                        {version.changeLog && (
                          <p style={{ marginTop: '0.5rem', fontSize: '0.875rem' }}>
                            {version.changeLog}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentDetailsPage;
