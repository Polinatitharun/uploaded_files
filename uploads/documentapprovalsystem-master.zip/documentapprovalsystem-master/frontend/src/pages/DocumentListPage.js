import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { documentsAPI, categoriesAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const DocumentListPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [documents, setDocuments] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: '',
    category: '',
    author: '',
  });
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0,
  });

  useEffect(() => {
    fetchDocuments();
    fetchCategories();
  }, [filters, pagination.page]);

  const fetchDocuments = async () => {
    try {
      setLoading(true);
      const params = {
        ...filters,
        page: pagination.page,
        limit: 10,
      };

      // Filter by author if user is an author
      if (user.role === 'author') {
        params.author = user.id;
      }

      const response = await documentsAPI.getAll(params);
      setDocuments(response.data.documents);
      setPagination({
        page: response.data.currentPage,
        totalPages: response.data.totalPages,
        total: response.data.total,
      });
    } catch (error) {
      console.error('Error fetching documents:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await categoriesAPI.getAll();
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'draft': return 'status-draft';
      case 'pending_approval': return 'status-pending';
      case 'approved': return 'status-approved';
      case 'rejected': return 'status-rejected';
      case 'published': return 'status-published';
      default: return '';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const handlePageChange = (newPage) => {
    setPagination(prev => ({ ...prev, page: newPage }));
  };

  if (loading && documents.length === 0) {
    return (
      <div className="flex-center" style={{ minHeight: '400px' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="mt-4">
        <div className="flex-between">
          <h1>Documents</h1>
          {user.role === 'author' && (
            <button 
              className="btn btn-primary"
              onClick={() => navigate('/documents/new')}
            >
              Create Document
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="card mt-4">
        <div className="card-header">
          <h3 className="card-title">Filters</h3>
        </div>
        <div className="grid grid-4">
          <div className="form-group">
            <label className="form-label">Status</label>
            <select 
              className="form-select"
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
            >
              <option value="">All Status</option>
              <option value="draft">Draft</option>
              <option value="pending_approval">Pending Approval</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
              <option value="published">Published</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Category</label>
            <select 
              className="form-select"
              value={filters.category}
              onChange={(e) => handleFilterChange('category', e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((category) => (
                <option key={category._id} value={category._id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          {user.role !== 'author' && (
            <div className="form-group">
              <label className="form-label">Author</label>
              <input 
                type="text"
                className="form-input"
                placeholder="Search by author name"
                value={filters.author}
                onChange={(e) => handleFilterChange('author', e.target.value)}
              />
            </div>
          )}

          <div className="form-group flex-center">
            <button 
              className="btn btn-secondary"
              onClick={() => setFilters({ status: '', category: '', author: '' })}
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>

      {/* Documents Table */}
      <div className="card mt-4">
        <div className="card-header">
          <h3 className="card-title">
            Documents ({pagination.total})
          </h3>
        </div>

        {documents.length === 0 ? (
          <div className="text-center py-4">
            <p style={{ color: '#666' }}>No documents found</p>
            {user.role === 'author' && (
              <button 
                className="btn btn-primary mt-2"
                onClick={() => navigate('/documents/new')}
              >
                Create Your First Document
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Author</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {documents.map((doc) => (
                    <tr key={doc._id}>
                      <td>
                        <div 
                          style={{ cursor: 'pointer', fontWeight: 'bold' }}
                          onClick={() => navigate(`/documents/${doc._id}`)}
                        >
                          {doc.title}
                        </div>
                      </td>
                      <td>{doc.categoryId?.name || 'N/A'}</td>
                      <td>
                        {doc.authorId?.firstName} {doc.authorId?.lastName}
                      </td>
                      <td>
                        <span className={`status-badge ${getStatusColor(doc.status)}`}>
                          {doc.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td>{formatDate(doc.createdAt)}</td>
                      <td>
                        <div className="flex gap-1">
                          <button 
                            className="btn btn-secondary btn-sm"
                            onClick={() => navigate(`/documents/${doc._id}`)}
                          >
                            View
                          </button>
                          {doc.status === 'draft' && 
                           doc.authorId?._id === user.id && (
                            <button 
                              className="btn btn-primary btn-sm"
                              onClick={() => navigate(`/documents/${doc._id}/edit`)}
                            >
                              Edit
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex-center gap-2 mt-4">
                <button 
                  className="btn btn-secondary"
                  disabled={pagination.page === 1}
                  onClick={() => handlePageChange(pagination.page - 1)}
                >
                  Previous
                </button>
                
                <span className="text-sm">
                  Page {pagination.page} of {pagination.totalPages}
                </span>
                
                <button 
                  className="btn btn-secondary"
                  disabled={pagination.page === pagination.totalPages}
                  onClick={() => handlePageChange(pagination.page + 1)}
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default DocumentListPage;
