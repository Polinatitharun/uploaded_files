import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { categoriesAPI, auditAPI, documentsAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const AdminPanelPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalDocuments: 0,
    totalUsers: 0,
    totalWorkflows: 0,
    totalCategories: 0,
    pendingApprovals: 0,
  });
  const [categories, setCategories] = useState([]);
  const [recentActivity, setRecentActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateCategory, setShowCreateCategory] = useState(false);
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    description: '',
    workflowId: ''
  });
  const [workflows, setWorkflows] = useState([]);

  useEffect(() => {
    if (user?.role !== 'admin') {
      navigate('/dashboard');
      return;
    }
    fetchAdminData();
  }, [user, navigate]);

  const fetchAdminData = async () => {
    try {
      setLoading(true);

      // Fetch documents for stats
      const documentsResponse = await documentsAPI.getAll({ limit: 1000 });
      const documents = documentsResponse.data.documents;

      // Fetch categories
      const categoriesResponse = await categoriesAPI.getAll();
      setCategories(categoriesResponse.data);

      // Fetch recent activity
      const activityResponse = await auditAPI.getAll({ limit: 20 });
      setRecentActivity(activityResponse.data.auditLogs);

      // Set stats
      setStats({
        totalDocuments: documents.length,
        totalUsers: 0, // Would need users API
        totalWorkflows: 0, // Would need workflows API
        totalCategories: categoriesResponse.data.length,
        pendingApprovals: documents.filter(doc => doc.status === 'pending_approval').length,
      });

      // Extract workflows from categories
      const uniqueWorkflows = [...new Set(categoriesResponse.data.map(cat => cat.workflowId?._id).filter(Boolean))];
      setWorkflows(uniqueWorkflows);

    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCategory = async () => {
    if (!categoryForm.name || !categoryForm.workflowId) {
      alert('Please fill in all required fields');
      return;
    }

    try {
      await categoriesAPI.create(categoryForm);
      setShowCreateCategory(false);
      setCategoryForm({ name: '', description: '', workflowId: '' });
      fetchAdminData();
    } catch (error) {
      console.error('Error creating category:', error);
      alert(error.response?.data?.message || 'Failed to create category');
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    if (!window.confirm('Are you sure you want to delete this category?')) return;

    try {
      await categoriesAPI.delete(categoryId);
      fetchAdminData();
    } catch (error) {
      console.error('Error deleting category:', error);
      alert(error.response?.data?.message || 'Failed to delete category');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex-center" style={{ minHeight: '400px' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="mt-4">
        <h1>Admin Panel</h1>
        <p>System administration and management</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-4 mt-4">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Total Documents</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#3498db' }}>
              {stats.totalDocuments}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Categories</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#27ae60' }}>
              {stats.totalCategories}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Pending Approvals</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#f39c12' }}>
              {stats.pendingApprovals}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">System Status</h3>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold" style={{ color: '#27ae60' }}>
              Healthy
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card mt-4">
        <div className="card-header">
          <h3 className="card-title">Quick Actions</h3>
        </div>
        <div className="grid grid-3">
          <button 
            className="btn btn-primary"
            onClick={() => navigate('/workflows')}
          >
            Manage Workflows
          </button>
          <button 
            className="btn btn-secondary"
            onClick={() => setShowCreateCategory(true)}
          >
            Create Category
          </button>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/audit')}
          >
            View Audit Logs
          </button>
        </div>
      </div>

      {/* Create Category Modal */}
      {showCreateCategory && (
        <div className="card mt-4">
          <div className="card-header">
            <h3 className="card-title">Create Category</h3>
          </div>
          
          <div className="form-group">
            <label className="form-label">Category Name *</label>
            <input
              type="text"
              className="form-input"
              value={categoryForm.name}
              onChange={(e) => setCategoryForm(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter category name"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-textarea"
              value={categoryForm.description}
              onChange={(e) => setCategoryForm(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Enter category description"
              style={{ minHeight: '80px' }}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Workflow *</label>
            <select
              className="form-select"
              value={categoryForm.workflowId}
              onChange={(e) => setCategoryForm(prev => ({ ...prev, workflowId: e.target.value }))}
            >
              <option value="">Select workflow</option>
              {workflows.map((workflowId) => (
                <option key={workflowId} value={workflowId}>
                  Workflow {workflowId}
                </option>
              ))}
            </select>
          </div>

          <div className="flex gap-2 mt-4">
            <button
              className="btn btn-primary"
              onClick={handleCreateCategory}
            >
              Create Category
            </button>
            
            <button
              className="btn btn-secondary"
              onClick={() => {
                setShowCreateCategory(false);
                setCategoryForm({ name: '', description: '', workflowId: '' });
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Categories Management */}
      <div className="card mt-4">
        <div className="card-header flex-between">
          <h3 className="card-title">Categories ({categories.length})</h3>
          <button 
            className="btn btn-secondary"
            onClick={() => setShowCreateCategory(true)}
          >
            Add Category
          </button>
        </div>

        {categories.length === 0 ? (
          <div className="text-center py-4">
            <p style={{ color: '#666' }}>No categories found</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Workflow</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {categories.map((category) => (
                  <tr key={category._id}>
                    <td>
                      <div style={{ fontWeight: 'bold' }}>{category.name}</div>
                    </td>
                    <td>{category.description || 'No description'}</td>
                    <td>
                      <span className="status-badge status-approved">
                        {category.workflowId?.name || 'Unknown'}
                      </span>
                    </td>
                    <td>{formatDate(category.createdAt)}</td>
                    <td>
                      <button 
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDeleteCategory(category._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <div className="card mt-4">
        <div className="card-header">
          <h3 className="card-title">Recent System Activity</h3>
        </div>

        {recentActivity.length === 0 ? (
          <div className="text-center py-4">
            <p style={{ color: '#666' }}>No recent activity</p>
          </div>
        ) : (
          <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
            {recentActivity.map((activity) => (
              <div key={activity._id} className="card mb-2">
                <div className="flex-between">
                  <strong>
                    {activity.action.replace('_', ' ').charAt(0).toUpperCase() + 
                     activity.action.replace('_', ' ').slice(1)}
                  </strong>
                  <span className="text-sm" style={{ color: '#666' }}>
                    {formatDate(activity.timestamp)}
                  </span>
                </div>
                <p style={{ marginTop: '0.5rem', color: '#666' }}>
                  By: {activity.userId?.firstName} {activity.userId?.lastName}
                </p>
                {activity.documentId && (
                  <p style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: '#666' }}>
                    Document: {activity.documentId?.title || 'Unknown'}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanelPage;
