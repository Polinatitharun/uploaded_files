import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { documentsAPI, categoriesAPI } from '../services/api';

const DocumentCreatePage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    content: '',
    categoryId: '',
  });
  const [categories, setCategories] = useState([]);
  const [attachments, setAttachments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await categoriesAPI.getAll();
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    
    // Validate file types and sizes
    const validFiles = files.filter(file => {
      const maxSize = 10 * 1024 * 1024; // 10MB
      const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'image/jpeg',
        'image/png',
        'image/gif'
      ];

      if (!allowedTypes.includes(file.type)) {
        setErrors(prev => ({
          ...prev,
          attachments: `Invalid file type: ${file.name}. Only PDF, Word, Excel, PowerPoint, text files and images are allowed.`
        }));
        return false;
      }

      if (file.size > maxSize) {
        setErrors(prev => ({
          ...prev,
          attachments: `File too large: ${file.name}. Maximum size is 10MB.`
        }));
        return false;
      }

      return true;
    });

    setAttachments(prev => [...prev, ...validFiles]);
    
    // Clear file input
    e.target.value = '';
  };

  const removeAttachment = (index) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
    if (errors.attachments) {
      setErrors(prev => ({ ...prev, attachments: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (!formData.categoryId) {
      newErrors.categoryId = 'Category is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const formDataToSend = new FormData();
      
      // Add form fields
      Object.keys(formData).forEach(key => {
        if (key !== 'attachments') {
          formDataToSend.append(key, formData[key]);
        }
      });

      // Add attachments
      attachments.forEach(file => {
        formDataToSend.append('attachments', file);
      });

      const response = await documentsAPI.create(formDataToSend);
      
      // Navigate to the created document
      navigate(`/documents/${response.data._id}`, {
        state: { message: 'Document created successfully!' }
      });
    } catch (error) {
      console.error('Error creating document:', error);
      setErrors({
        submit: error.response?.data?.message || 'Failed to create document'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="mt-4">
        <h1>Create Document</h1>
        <p>Fill in the details below to create a new document.</p>
      </div>

      <div className="card mt-4">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label" htmlFor="title">
              Title *
            </label>
            <input
              type="text"
              id="title"
              name="title"
              className="form-input"
              value={formData.title}
              onChange={handleChange}
              placeholder="Enter document title"
              disabled={loading}
            />
            {errors.title && (
              <div className="alert alert-error mt-1">
                {errors.title}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="description">
              Description *
            </label>
            <textarea
              id="description"
              name="description"
              className="form-textarea"
              value={formData.description}
              onChange={handleChange}
              placeholder="Enter document description"
              disabled={loading}
            />
            {errors.description && (
              <div className="alert alert-error mt-1">
                {errors.description}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="categoryId">
              Category *
            </label>
            <select
              id="categoryId"
              name="categoryId"
              className="form-select"
              value={formData.categoryId}
              onChange={handleChange}
              disabled={loading}
            >
              <option value="">Select a category</option>
              {categories.map((category) => (
                <option key={category._id} value={category._id}>
                  {category.name}
                  {category.description && ` - ${category.description}`}
                </option>
              ))}
            </select>
            {errors.categoryId && (
              <div className="alert alert-error mt-1">
                {errors.categoryId}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="content">
              Content
            </label>
            <textarea
              id="content"
              name="content"
              className="form-textarea"
              value={formData.content}
              onChange={handleChange}
              placeholder="Enter document content (optional)"
              disabled={loading}
              style={{ minHeight: '200px' }}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="attachments">
              Attachments
            </label>
            <input
              type="file"
              id="attachments"
              multiple
              onChange={handleFileChange}
              disabled={loading}
              style={{ display: 'none' }}
            />
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => document.getElementById('attachments').click()}
              disabled={loading}
            >
              Add Files
            </button>
            
            <div className="mt-2 text-sm" style={{ color: '#666' }}>
              Supported formats: PDF, Word, Excel, PowerPoint, text files, images (Max 10MB per file)
            </div>

            {attachments.length > 0 && (
              <div className="mt-2">
                <strong>Selected Files:</strong>
                <ul style={{ listStyle: 'none', padding: 0, marginTop: '0.5rem' }}>
                  {attachments.map((file, index) => (
                    <li key={index} className="flex-between" style={{ padding: '0.25rem 0' }}>
                      <span>{file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                      <button
                        type="button"
                        className="btn btn-danger btn-sm"
                        onClick={() => removeAttachment(index)}
                        disabled={loading}
                      >
                        Remove
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {errors.attachments && (
              <div className="alert alert-error mt-1">
                {errors.attachments}
              </div>
            )}
          </div>

          {errors.submit && (
            <div className="alert alert-error">
              {errors.submit}
            </div>
          )}

          <div className="flex gap-2 mt-4">
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? (
                <span className="flex-center gap-2">
                  <div className="spinner"></div>
                  Creating...
                </span>
              ) : (
                'Create Document'
              )}
            </button>
            
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/documents')}
              disabled={loading}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DocumentCreatePage;
