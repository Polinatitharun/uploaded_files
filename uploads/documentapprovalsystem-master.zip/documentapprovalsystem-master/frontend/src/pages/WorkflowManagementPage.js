import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { workflowsAPI, categoriesAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const WorkflowManagementPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [workflows, setWorkflows] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingWorkflow, setEditingWorkflow] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    stages: [
      { name: 'Manager Review', assignedRole: 'approver', isRequired: true },
      { name: 'Final Approval', assignedRole: 'admin', isRequired: true }
    ]
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (user?.role !== 'admin') {
      navigate('/dashboard');
      return;
    }
    fetchWorkflows();
    fetchCategories();
  }, [user, navigate]);

  const fetchWorkflows = async () => {
    try {
      const response = await workflowsAPI.getAll();
      setWorkflows(response.data);
    } catch (error) {
      console.error('Error fetching workflows:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await categoriesAPI.getAll();
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleCreateWorkflow = async () => {
    if (!validateForm()) return;

    try {
      await workflowsAPI.create(formData);
      setShowCreateForm(false);
      resetForm();
      fetchWorkflows();
    } catch (error) {
      console.error('Error creating workflow:', error);
      setErrors({ submit: error.response?.data?.message || 'Failed to create workflow' });
    }
  };

  const handleUpdateWorkflow = async () => {
    if (!validateForm()) return;

    try {
      await workflowsAPI.update(editingWorkflow._id, formData);
      setEditingWorkflow(null);
      resetForm();
      fetchWorkflows();
    } catch (error) {
      console.error('Error updating workflow:', error);
      setErrors({ submit: error.response?.data?.message || 'Failed to update workflow' });
    }
  };

  const handleDeleteWorkflow = async (workflowId) => {
    if (!window.confirm('Are you sure you want to delete this workflow?')) return;

    try {
      await workflowsAPI.delete(workflowId);
      fetchWorkflows();
    } catch (error) {
      console.error('Error deleting workflow:', error);
      alert(error.response?.data?.message || 'Failed to delete workflow');
    }
  };

  const handleEditWorkflow = (workflow) => {
    setEditingWorkflow(workflow);
    setFormData({
      name: workflow.name,
      description: workflow.description,
      stages: workflow.stages.map(stage => ({
        name: stage.name,
        assignedRole: stage.assignedRole,
        isRequired: stage.isRequired
      }))
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Workflow name is required';
    }

    if (!formData.stages || formData.stages.length === 0) {
      newErrors.stages = 'At least one stage is required';
    } else {
      formData.stages.forEach((stage, index) => {
        if (!stage.name.trim()) {
          newErrors[`stage_${index}_name`] = 'Stage name is required';
        }
        if (!stage.assignedRole) {
          newErrors[`stage_${index}_role`] = 'Stage role is required';
        }
      });
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      stages: [
        { name: 'Manager Review', assignedRole: 'approver', isRequired: true },
        { name: 'Final Approval', assignedRole: 'admin', isRequired: true }
      ]
    });
    setErrors({});
  };

  const addStage = () => {
    setFormData(prev => ({
      ...prev,
      stages: [...prev.stages, { name: '', assignedRole: 'approver', isRequired: true }]
    }));
  };

  const removeStage = (index) => {
    setFormData(prev => ({
      ...prev,
      stages: prev.stages.filter((_, i) => i !== index)
    }));
  };

  const updateStage = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      stages: prev.stages.map((stage, i) => 
        i === index ? { ...stage, [field]: value } : stage
      )
    }));
  };

  const getCategoriesUsingWorkflow = (workflowId) => {
    return categories.filter(cat => cat.workflowId?._id === workflowId);
  };

  if (loading) {
    return (
      <div className="flex-center" style={{ minHeight: '400px' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="mt-4">
        <div className="flex-between">
          <h1>Workflow Management</h1>
          <button 
            className="btn btn-primary"
            onClick={() => setShowCreateForm(true)}
          >
            Create Workflow
          </button>
        </div>
      </div>

      {/* Create/Edit Workflow Form */}
      {(showCreateForm || editingWorkflow) && (
        <div className="card mt-4">
          <div className="card-header">
            <h3 className="card-title">
              {editingWorkflow ? 'Edit Workflow' : 'Create Workflow'}
            </h3>
          </div>

          {errors.submit && (
            <div className="alert alert-error">
              {errors.submit}
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Workflow Name *</label>
            <input
              type="text"
              className="form-input"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter workflow name"
            />
            {errors.name && (
              <div className="alert alert-error mt-1">
                {errors.name}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-textarea"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Enter workflow description"
              style={{ minHeight: '80px' }}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Workflow Stages *</label>
            {errors.stages && (
              <div className="alert alert-error">
                {errors.stages}
              </div>
            )}

            {formData.stages.map((stage, index) => (
              <div key={index} className="card mb-2">
                <div className="flex-between">
                  <h4>Stage {index + 1}</h4>
                  {formData.stages.length > 1 && (
                    <button
                      type="button"
                      className="btn btn-danger btn-sm"
                      onClick={() => removeStage(index)}
                    >
                      Remove
                    </button>
                  )}
                </div>

                <div className="grid grid-3 gap-2">
                  <div className="form-group">
                    <label className="form-label">Stage Name *</label>
                    <input
                      type="text"
                      className="form-input"
                      value={stage.name}
                      onChange={(e) => updateStage(index, 'name', e.target.value)}
                      placeholder="Enter stage name"
                    />
                    {errors[`stage_${index}_name`] && (
                      <div className="alert alert-error mt-1">
                        {errors[`stage_${index}_name`]}
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <label className="form-label">Assigned Role *</label>
                    <select
                      className="form-select"
                      value={stage.assignedRole}
                      onChange={(e) => updateStage(index, 'assignedRole', e.target.value)}
                    >
                      <option value="">Select role</option>
                      <option value="author">Author</option>
                      <option value="approver">Approver</option>
                      <option value="admin">Admin</option>
                    </select>
                    {errors[`stage_${index}_role`] && (
                      <div className="alert alert-error mt-1">
                        {errors[`stage_${index}_role`]}
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <label className="form-label">
                      <input
                        type="checkbox"
                        checked={stage.isRequired}
                        onChange={(e) => updateStage(index, 'isRequired', e.target.checked)}
                      />
                      Required Stage
                    </label>
                  </div>
                </div>
              </div>
            ))}

            <button
              type="button"
              className="btn btn-secondary"
              onClick={addStage}
            >
              Add Stage
            </button>
          </div>

          <div className="flex gap-2 mt-4">
            <button
              className="btn btn-primary"
              onClick={editingWorkflow ? handleUpdateWorkflow : handleCreateWorkflow}
            >
              {editingWorkflow ? 'Update Workflow' : 'Create Workflow'}
            </button>
            
            <button
              className="btn btn-secondary"
              onClick={() => {
                setShowCreateForm(false);
                setEditingWorkflow(null);
                resetForm();
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Workflows List */}
      <div className="card mt-4">
        <div className="card-header">
          <h3 className="card-title">Workflows ({workflows.length})</h3>
        </div>

        {workflows.length === 0 ? (
          <div className="text-center py-4">
            <p style={{ color: '#666' }}>No workflows found</p>
            <button 
              className="btn btn-primary mt-2"
              onClick={() => setShowCreateForm(true)}
            >
              Create Your First Workflow
            </button>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Stages</th>
                  <th>Categories Using</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {workflows.map((workflow) => {
                  const usingCategories = getCategoriesUsingWorkflow(workflow._id);
                  return (
                    <tr key={workflow._id}>
                      <td>
                        <div style={{ fontWeight: 'bold' }}>{workflow.name}</div>
                      </td>
                      <td>{workflow.description || 'No description'}</td>
                      <td>
                        <div className="text-sm">
                          {workflow.stages.map((stage, index) => (
                            <div key={index}>
                              {index + 1}. {stage.name} ({stage.assignedRole})
                            </div>
                          ))}
                        </div>
                      </td>
                      <td>
                        <span className={`status-badge ${usingCategories.length > 0 ? 'status-approved' : 'status-draft'}`}>
                          {usingCategories.length} categories
                        </span>
                      </td>
                      <td>{new Date(workflow.createdAt).toLocaleDateString()}</td>
                      <td>
                        <div className="flex gap-1">
                          <button 
                            className="btn btn-secondary btn-sm"
                            onClick={() => handleEditWorkflow(workflow)}
                            disabled={usingCategories.length > 0}
                          >
                            Edit
                          </button>
                          <button 
                            className="btn btn-danger btn-sm"
                            onClick={() => handleDeleteWorkflow(workflow._id)}
                            disabled={usingCategories.length > 0}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkflowManagementPage;
