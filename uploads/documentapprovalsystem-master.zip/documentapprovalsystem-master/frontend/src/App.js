import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Header from './components/Header';

// Import pages
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import DocumentListPage from './pages/DocumentListPage';
import DocumentCreatePage from './pages/DocumentCreatePage';
import DocumentDetailsPage from './pages/DocumentDetailsPage';
import ApprovalQueuePage from './pages/ApprovalQueuePage';
import WorkflowManagementPage from './pages/WorkflowManagementPage';
import AdminPanelPage from './pages/AdminPanelPage';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex-center" style={{ minHeight: '100vh' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return isAuthenticated ? children : <Navigate to="/login" />;
};

// Public Route Component (redirect to dashboard if authenticated)
const PublicRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex-center" style={{ minHeight: '100vh' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return !isAuthenticated ? children : <Navigate to="/dashboard" />;
};

// Main App Content
const AppContent = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Public Routes */}
          <Route 
            path="/login" 
            element={
              <PublicRoute>
                <LoginPage />
              </PublicRoute>
            } 
          />

          {/* Protected Routes */}
          <Route 
            path="/*" 
            element={
              <ProtectedRoute>
                <Header />
                <Routes>
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/documents" element={<DocumentListPage />} />
                  <Route path="/documents/new" element={<DocumentCreatePage />} />
                  <Route path="/documents/:id" element={<DocumentDetailsPage />} />
                  <Route path="/approval-queue" element={<ApprovalQueuePage />} />
                  <Route path="/workflows" element={<WorkflowManagementPage />} />
                  <Route path="/admin" element={<AdminPanelPage />} />
                  
                  {/* Default redirect */}
                  <Route path="/" element={<Navigate to="/dashboard" />} />
                  
                  {/* Catch all route */}
                  <Route path="*" element={<Navigate to="/dashboard" />} />
                </Routes>
              </ProtectedRoute>
            } 
          />
        </Routes>
      </div>
    </Router>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
