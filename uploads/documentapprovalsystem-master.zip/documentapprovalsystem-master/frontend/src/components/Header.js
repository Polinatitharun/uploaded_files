import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';

const Header = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const isActivePath = (path) => {
    return location.pathname === path;
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <header className="header">
      <div className="container">
        <div className="header-content">
          <div className="logo">Document Approval</div>
          
          <nav>
            <ul className="nav-links">
              <li>
                <a 
                  href="/dashboard" 
                  className={isActivePath('/dashboard') ? 'active' : ''}
                  onClick={(e) => {
                    e.preventDefault();
                    navigate('/dashboard');
                  }}
                >
                  Dashboard
                </a>
              </li>
              <li>
                <a 
                  href="/documents" 
                  className={isActivePath('/documents') ? 'active' : ''}
                  onClick={(e) => {
                    e.preventDefault();
                    navigate('/documents');
                  }}
                >
                  Documents
                </a>
              </li>
              {(user?.role === 'approver' || user?.role === 'admin') && (
                <li>
                  <a 
                    href="/approval-queue" 
                    className={isActivePath('/approval-queue') ? 'active' : ''}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate('/approval-queue');
                    }}
                  >
                    Approval Queue
                  </a>
                </li>
              )}
              {user?.role === 'admin' && (
                <>
                  <li>
                    <a 
                      href="/workflows" 
                      className={isActivePath('/workflows') ? 'active' : ''}
                      onClick={(e) => {
                        e.preventDefault();
                        navigate('/workflows');
                      }}
                    >
                      Workflows
                    </a>
                  </li>
                  <li>
                    <a 
                      href="/admin" 
                      className={isActivePath('/admin') ? 'active' : ''}
                      onClick={(e) => {
                        e.preventDefault();
                        navigate('/admin');
                      }}
                    >
                      Admin
                    </a>
                  </li>
                </>
              )}
            </ul>
          </nav>

          <div className="user-info">
            <span>Welcome, {user?.firstName} {user?.lastName}</span>
            <span className="text-sm">({user?.role})</span>
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
