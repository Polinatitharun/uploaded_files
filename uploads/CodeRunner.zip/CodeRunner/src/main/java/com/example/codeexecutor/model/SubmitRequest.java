package com.example.codeexecutor.model;

import java.util.List;
import java.util.Map;

public class SubmitRequest {
    private String language;
    private String source;
    private Integer problemId;

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public Integer getProblemId() {
        return problemId;
    }

    public void setProblemId(Integer problemId) {
        this.problemId = problemId;
    }
}
