package com.example.codeexecutor.model;

public class RunRequest {
    private String language;
    private String source;
    private String input; // Optional input

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getInput() { return input; }
    public void setInput(String input) { this.input = input; }
}