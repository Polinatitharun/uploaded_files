package com.example.codeexecutor.model;



public class SubmitWrapper {



        private String language;
        private String source;
        private String wrapper;
        private Integer problemId;

    public Integer getProblemId() {
        return problemId;
    }

    public void setProblemId(Integer problemId) {
        this.problemId = problemId;
    }

    public String getLanguage() {
            return language;
        }

        public void setLanguage(String language) {
            this.language = language;
        }

        public String getSource() {
            return source;
        }

        public void setSource(String source) {
            this.source = source;
        }

        public String getWrapper() {
            return wrapper;
        }

        public void setWrapper(String wrapper) {
            this.wrapper = wrapper;
        }


}
