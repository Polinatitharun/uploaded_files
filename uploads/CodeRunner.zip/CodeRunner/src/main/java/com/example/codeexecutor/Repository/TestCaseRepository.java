package com.example.codeexecutor.Repository;

import com.example.codeexecutor.Entity.ProblemTestCase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TestCaseRepository extends JpaRepository<com.example.codeexecutor.Entity.ProblemTestCase,Integer> {

    List<ProblemTestCase> findByProblemId(Integer problemId);
}
