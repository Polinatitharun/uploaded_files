package com.example.codeexecutor.Config;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class KeycloakRoleConverter implements Converter<Jwt,Collection<GrantedAuthority>> {

    @Override
    public Collection<GrantedAuthority> convert(Jwt source) {
        Map<String,Object> realmAccess=source.getClaim("realm_access");
        if (realmAccess== null){
            return Collections.emptyList();
        }
        Collection<String> roles=(Collection<String>) realmAccess.get("roles");
        return roles.stream().map(role-> new SimpleGrantedAuthority("ROLE"+role))
                .collect(Collectors.toList());
    }
}
