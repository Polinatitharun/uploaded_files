
package com.example.codeexecutor.controller;

import com.example.codeexecutor.model.*;
import com.example.codeexecutor.service.ExecutionService;
import com.example.codeexecutor.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/v1")
public class ExecuteController {

    @Autowired
    private ExecutionService executionService;
    @Autowired
    private TestService testService;

    // Run single code with optional input
    @PostMapping("/run")
    public RunResponse runCode(@RequestBody RunRequest request) {
        return executionService.runSingle(request.getLanguage(), request.getSource(), request.getInput());
    }

    // Submit multiple test cases
    @PostMapping("/submit")
    public SubmitResponse submitCode(@RequestBody SubmitRequest request) {
        return executionService.runTestCases(request.getLanguage(), request.getSource(), request.getProblemId());
    }

    @PostMapping("/run/wrapper")
    public RunResponse runWrapper(@RequestBody RunWrapper rw){
        return executionService.runWrapperSingle(rw.getWrapper(),rw.getLanguage(),rw.getSource(),rw.getInput());
    }

    @PostMapping("/submit/wrapper")
    public SubmitResponse submitWrapper(@RequestBody SubmitWrapper sw){
        return executionService.submitWrapper(sw.getWrapper(),sw.getLanguage(),sw.getSource(),sw.getProblemId());
    }

    @GetMapping("/testcases/{problemId}")
    public List<TestCases> runWrapper(@PathVariable Integer problemId){
        return testService.getTestCases(problemId);
    }
}