package com.example.codeexecutor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeexecutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeexecutorApplication.class, args);
	}

}
