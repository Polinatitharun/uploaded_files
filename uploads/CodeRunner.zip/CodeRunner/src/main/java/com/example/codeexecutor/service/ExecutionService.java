package com.example.codeexecutor.service;

import com.example.codeexecutor.Entity.ProblemTestCase;
import com.example.codeexecutor.Repository.TestCaseRepository;
import com.example.codeexecutor.model.RunResponse;
import com.example.codeexecutor.model.SubmitResponse;
import com.example.codeexecutor.model.TestCaseResult;
import com.example.codeexecutor.model.TestCases;
import com.example.codeexecutor.util.DockerRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.*;


@Service
public class ExecutionService {

    @Autowired
    private DockerRunner dockerRunner;

    @Autowired
    TestCaseRepository testCaseRepository;

    @Autowired
    TestService testService;

        
    private static final Pattern[] FORBIDDEN_PATTERNS = new Pattern[] {
        // Dynamic execution & reflection
        Pattern.compile("\\beval\\s*\\("),
        Pattern.compile("\\bexec\\s*\\("),
        Pattern.compile("\\bcompile\\s*\\("),
        Pattern.compile("\\b__import__\\s*\\("),
        Pattern.compile("\\bgetattr\\s*\\("),
        Pattern.compile("\\bsetattr\\s*\\("),
        Pattern.compile("\\bglobals\\s*\\(\\s*\\)"),
        Pattern.compile("\\blocals\\s*\\(\\s*\\)"),
        Pattern.compile("\\bbuiltins\\b"),

        // Dangerous imports / modules
        Pattern.compile("\\bimport\\s+os\\b"),
        Pattern.compile("\\bimport\\s+sys\\b"),
        Pattern.compile("\\bimport\\s+subprocess\\b"),
        Pattern.compile("\\bimport\\s+shutil\\b"),
        Pattern.compile("\\bimport\\s+socket\\b"),
        Pattern.compile("\\bimport\\s+multiprocessing\\b"),
        Pattern.compile("\\bimport\\s+threading\\b"),
        Pattern.compile("\\bimport\\s+ctypes\\b"),
        Pattern.compile("\\bimport\\s+pickle\\b"),
        Pattern.compile("\\bimport\\s+marshal\\b"),
        Pattern.compile("\\bimport\\s+importlib\\b"),
        Pattern.compile("\\bfrom\\s+os\\s+import\\b"),
        Pattern.compile("\\bfrom\\s+sys\\s+import\\b"),
        Pattern.compile("\\bfrom\\s+subprocess\\s+import\\b"),

        // Filesystem access
        Pattern.compile("\\bopen\\s*\\("),
        Pattern.compile("\\bos\\.system\\s*\\("),
        Pattern.compile("\\bos\\.popen\\s*\\("),
        Pattern.compile("\\bshutil\\.(rmtree|move|copy|copytree)\\s*\\("),
        Pattern.compile("\\bpathlib\\b"),
        
        // suspicious write modes
        Pattern.compile("\\bopen\\s*\\(.*[, ]['\\\"]w['\\\"]"),
        Pattern.compile("\\bopen\\s*\\(.*[, ]['\\\"]a['\\\"]"),

        // Process / shell spawning
        Pattern.compile("\\bsubprocess\\.(Popen|run|call|check_call|check_output)\\s*\\("),
        Pattern.compile("\\bshlex\\b"),
        Pattern.compile("(?i)\\b(os|subprocess)\\.(system|popen)\\s*\\("),
        // obvious shell commands embedded
        Pattern.compile("(?i)\\b(rm\\s+-rf|chmod\\s+|chown\\s+|curl\\s+|wget\\s+|bash\\s+-c)\\b"),

        // Network / exfiltration
        Pattern.compile("\\brequests\\b"),
        Pattern.compile("\\burllib(\\.request|\\.urlopen)?\\b"),
        Pattern.compile("\\bsocket\\b"),
        Pattern.compile("\\bhttp(s)?://"),
        Pattern.compile("\\bftp://"),
        Pattern.compile("\\b\\d{1,3}(\\.\\d{1,3}){3}\\b"), // naive IPv4 literal

        // Obfuscation / payload decoding
        Pattern.compile("\\bbase64\\.(b64decode|b32decode)\\s*\\("),
        Pattern.compile("\\bcodecs\\.(decode|encode)\\s*\\("),
        Pattern.compile("\\bzlib\\.(decompress|decompressobj)\\s*\\("),
        Pattern.compile("\\bgzip\\.(decompress|open)\\s*\\("),
        Pattern.compile("\\bmarshal\\.(loads|load)\\s*\\("),

        // Environment / runtime manipulation
        Pattern.compile("\\bos\\.environ\\b"),
        Pattern.compile("\\bsys\\.(argv|path|exit)\\b"),
        Pattern.compile("\\bresource\\b"),
        Pattern.compile("\\bpty\\b"),
        Pattern.compile("\\btempfile\\b"),

        // Dangerous eval via JSON/pickle etc.
        Pattern.compile("\\bpickle\\.(load|loads)\\s*\\("),   // arbitrary code execution risk
        Pattern.compile("\\bjsonpickle\\b"),

        // Indirect dynamic import
        Pattern.compile("\\bimportlib\\.(import_module|reload)\\s*\\("),

        // Attempted package installation / environment changes 
        Pattern.compile("(?i)\\bpip\\s+install\\b"),
        Pattern.compile("(?i)\\bvenv\\b"),
        Pattern.compile("(?i)\\bvirtualenv\\b")
    };


    private void validateSource(String source) throws Exception {
        // Check for matches against forbidden patterns
        for (Pattern pattern : FORBIDDEN_PATTERNS) {
            Matcher matcher = pattern.matcher(source);
            if (matcher.find()) {
                throw new Exception("Malicious code detected: forbidden pattern '" + pattern.pattern() + "' found in source code.");
            }
        }
    }

    public RunResponse runSingle(String language, String source, String input) {
        try {
            validateSource(source);
            Map<String, String> result = dockerRunner.runOnce(language, source, input);
            return new RunResponse(result.getOrDefault("output", ""), result.getOrDefault("error", ""));
        } catch (Exception e) {
            return new RunResponse("", e.getMessage());
        }
    }
    public RunResponse runWrapperSingle(String wrapper,String language, String source, String input) {
        try {
            validateSource(source);
            String newSource=wrapper+"\n"+source;
            Map<String, String> result = dockerRunner.runOnce(language, newSource, input);
            return new RunResponse(result.getOrDefault("output", ""), result.getOrDefault("error", ""));
        } catch (Exception e) {
            return new RunResponse("", e.getMessage());
        }
    }


    public SubmitResponse runTestCases(String language, String source, Integer problemId) {
        try {
            validateSource(source);
        } catch (Exception e) {
            List<TestCaseResult> results = new ArrayList<>();
            results.add(new TestCaseResult("", "", e.getMessage(), false));
            return new SubmitResponse(results, false);
        }

        List<TestCaseResult> results = new ArrayList<>();
        boolean allPassed = true;
        List<TestCases> testCase= testService.getTestCases(problemId);
        for (TestCases test : testCase) {
            String input = test.getInput();
            String expectedOutput = test.getExpectedOutput();
            String actualOutput;
            boolean passed;

            try {
                Map<String, String> result = dockerRunner.runOnce(language, source, input);
                actualOutput = result.getOrDefault("output", "");
                String error = result.getOrDefault("error", "");
                if (!error.isEmpty()) actualOutput += "\n" + error;
                passed = actualOutput.trim().equals(expectedOutput.trim());
            } catch (Exception e) {
                actualOutput = e.getMessage();
                passed = false;
            }

            if (!passed) allPassed = false;
            results.add(new TestCaseResult(input, expectedOutput, actualOutput, passed));
        }

        return new SubmitResponse(results, allPassed);
    }

    public SubmitResponse submitWrapper(String wrapper, String language, String source, Integer problemId) {
        String newSource=wrapper+"\n"+source;
        SubmitResponse response=runTestCases(language,newSource,problemId);
        return response;


    }
}
