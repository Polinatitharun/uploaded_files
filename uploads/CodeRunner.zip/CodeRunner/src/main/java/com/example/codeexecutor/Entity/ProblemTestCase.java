package com.example.codeexecutor.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "problem_test_cases")
@Data
public class ProblemTestCase {
    @Id
    @Column(name = "test_case_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer testCaseId;


    @Column(name = "input", columnDefinition = "text")
    private String input;


    @Column(name = "expected_output", columnDefinition = "text")
    private String expectedOutput;

    @Column(name = "is_public", nullable = false)
    Boolean isPublic = true;

    @Column(name="problem_id", nullable = false)
    private Integer problemId;
}