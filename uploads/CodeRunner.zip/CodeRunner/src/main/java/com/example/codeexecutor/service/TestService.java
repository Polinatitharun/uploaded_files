package com.example.codeexecutor.service;

import com.example.codeexecutor.Entity.ProblemTestCase;
import com.example.codeexecutor.Repository.TestCaseRepository;
import com.example.codeexecutor.model.TestCases;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TestService {
    @Autowired
    TestCaseRepository testCaseRepository;

    public List<TestCases> getTestCases(Integer problemId) {
        List<ProblemTestCase> testCase= (List<ProblemTestCase>) testCaseRepository.findByProblemId(problemId);

        List<TestCases> tests= new ArrayList<>();

        for(ProblemTestCase test:testCase){
            tests.add(new TestCases(test.getInput(),test.getExpectedOutput()));
        }
        return tests;
    }


}
