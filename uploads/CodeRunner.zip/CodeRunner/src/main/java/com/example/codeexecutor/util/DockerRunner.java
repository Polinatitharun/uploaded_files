package com.example.codeexecutor.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Component
public class DockerRunner {

    @Value("${executor.timeout.ms:5000}")
    private long timeoutMs;

    private static String getFileName(String language) {
        return switch (language.toLowerCase()) {
            case "java" -> "Main.java";
            case "python" -> "main.py";
            case "javascript" -> "main.js";
            case "typescript" -> "main.ts";
            default -> throw new RuntimeException("Unsupported language: " + language);
        };
    }

    private static List<String> buildDockerCommand(String language, Path workdir, String containerName) {

        String base = workdir.toAbsolutePath().toString();

        List<String> command = new ArrayList<>(List.of(
                "podman", "run",
                "--rm",
                "--name", containerName,
                "--network", "none",
                "--memory", "256m",
                "--cpus", "1",
                "--pids-limit", "64",
                "--security-opt", "no-new-privileges",
                "-i",
                "-v", base + ":/code:Z",
                "-w", "/code"
        ));

        switch (language.toLowerCase()) {

            case "java" -> command.addAll(List.of(
                    "eclipse-temurin:17-jdk-jammy",
                    "sh", "-c",
                    "javac Main.java && java Main"
            ));

            case "python" -> command.addAll(List.of(
                    "python:3.11-alpine",
                    "python", "main.py"
            ));

            case "javascript" -> command.addAll(List.of(
                    "node:20-alpine",
                    "node", "main.js"
            ));

            case "typescript" -> command.addAll(List.of(
                    "-e", "TS_NODE_TRANSPILE_ONLY=1",
                    "-e", "TS_NODE_COMPILER_OPTIONS={\"module\":\"commonjs\",\"target\":\"es2020\",\"strict\":true,\"esModuleInterop\":true}",
                    "typescript-runner:20-alpine",
                    "ts-node", "main.ts"
            ));

            default -> throw new RuntimeException("Unsupported language: " + language);
        }

        return command;
    }

    public Map<String, String> runOnce(String language, String source, String input) {

        Map<String, String> result = new HashMap<>();
        Path workdir = null;
        String containerName = "exec-" + UUID.randomUUID();

        try {
            workdir = Files.createTempDirectory("exec-");
            Files.writeString(workdir.resolve(getFileName(language)), source);

            ProcessBuilder pb = new ProcessBuilder(
                    buildDockerCommand(language, workdir, containerName)
            );
            pb.redirectErrorStream(true);

            Process process = pb.start();   // ✅ not reassigned → effectively final

            // Send input
            if (input != null && !input.isBlank()) {
                try (BufferedWriter writer =
                             new BufferedWriter(new OutputStreamWriter(process.getOutputStream()))) {
                    writer.write(input);
                    writer.newLine();
                    writer.flush();
                }
            }
            process.getOutputStream().close();

            ExecutorService executor = Executors.newSingleThreadExecutor();

            Future<String> outputFuture = executor.submit(() -> {
                try (BufferedReader reader =
                             new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    return reader.lines().collect(Collectors.joining("\n"));
                }
            });

            String output;

            try {
                output = outputFuture.get(timeoutMs, TimeUnit.MILLISECONDS);
            } catch (TimeoutException e) {

                process.destroyForcibly();
                forceRemoveContainer(containerName);

                output = "Error: Execution timed out (" + timeoutMs + " ms)";
            } finally {
                executor.shutdownNow();
            }

            boolean finished = process.waitFor(2, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
            }

            int exitCode;
            try {
                exitCode = process.exitValue();
            } catch (IllegalThreadStateException e) {
                exitCode = -1;
            }

            result.put("output", output.trim());
            result.put("error", exitCode == 0 ? "" : "Runtime or compilation error occurred");

        } catch (Exception e) {
            result.put("output", "");
            result.put("error", e.getMessage());
        } finally {

            // Final safety cleanup
            forceRemoveContainer(containerName);

            if (workdir != null) {
                try {
                    Files.walk(workdir)
                            .sorted(Comparator.reverseOrder())
                            .map(Path::toFile)
                            .forEach(File::delete);
                } catch (IOException ignored) {
                }
            }
        }

        return result;
    }

    private void forceRemoveContainer(String containerName) {
        try {
            new ProcessBuilder("podman", "rm", "-f", containerName)
                    .start()
                    .waitFor(3, TimeUnit.SECONDS);
        } catch (Exception ignored) {
        }
    }
}
