package com.example.codeexecutor.model;

import java.util.List;

public class SubmitResponse {
    private List<TestCaseResult> results;
    private boolean allPassed;

    public SubmitResponse(List<TestCaseResult> results, boolean allPassed) {
        this.results = results;
        this.allPassed = allPassed;
    }

    public List<TestCaseResult> getResults() { return results; }
    public void setResults(List<TestCaseResult> results) { this.results = results; }

    public boolean isAllPassed() { return allPassed; }
    public void setAllPassed(boolean allPassed) { this.allPassed = allPassed; }
}